<?php
ini_set('xdebug.dump.GET', '*');
ini_set('xdebug.dump.SERVER','*');
xdebug_dump_superglobals();

    function fix_string($a)
    {
        echo "Called @ ".
            xdebug_call_file().
            ":".
            xdebug_call_line().
            " from ".
            xdebug_call_function();
    }
 
    $ret = fix_string(array('Derick'));


    $text = "coding everybody";
$prev_mem = xdebug_memory_usage();
for($i=0; $i<10; $i++){
        $text.=$text;
        echo $i.':'.xdebug_memory_usage().':'.(xdebug_memory_usage()-$prev_mem).':'.strlen($text)."\n";
}


echo xdebug_time_index()."\n";
for($i=0; $i<3; $i++){
        echo xdebug_time_index()."<br />\n";
        sleep(1);
}

class test {
    public $pub = false;
    private $priv = true;
    protected $prot = 42;
}
$t = new test;
$t->pub = $t;
$data = array(
    'one' => 'a somewhat long string!',
    'two' => array(
        'two.one' => array(
            'two.one.zero' => 210,
            'two.one.one' => array(
                'two.one.one.zero' => 3.141592564,
                'two.one.one.one'  => 2.7,
            ),
        ),
    ),
    'three' => $t,
    'four' => range(0, 5),
);
var_dump( $data );
?>