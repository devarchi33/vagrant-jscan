<?php

require_once dirname(__FILE__)."/path.php";
require_once APPPATH."config/database.php";
require_once APPPATH."helpers/common_helper.php";
require_once APPPATH."libraries/ReqReceiver.php";

define("DEBUG_SPACE", "Commander");
define("DEBUG_LEVEL", "1");

extract($db[$active_group]);

switch ($pid = pcntl_fork()) {
	case -1:

		// @fail
		die('Fork failed');
		break;

	case 0:

		$ReqReceiver = new ReqReceiver();
		$ReqReceiver->run();

		break;
}

file_put_contents('./run/'.basename(__FILE__).'.pid', $pid);

exit();

/* End of file index.php */
/* Location: ./index.php */