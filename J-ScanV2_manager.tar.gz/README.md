# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

* Summary of set up
* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact

수정 내역
1. 공유메모리 싱글로 변경 - 일단 쓰레드 제거
2. newsql 쿼리 상세 화면 안나오는 오류 수정
3. 다량 조회 IP안나오는 문제 수정 
4. 서버 동기화 안되는 오류 수정
5. 서버 모드 변경 안되는 오류 수정