<?php

require_once dirname(__FILE__)."/path.php";
require_once APPPATH."config/database.php";
require_once APPPATH."config/shmop.php";
require_once APPPATH."helpers/common_helper.php";
require_once APPPATH."libraries/AgentCacher.php";

//define("DEBUG_SPACE", "AgentCacher");
define("DEBUG_LEVEL", "1");

extract($db[$active_group]);

switch ($pid = pcntl_fork()) {
	case -1:

		// @fail
		die('Fork failed');
		break;

	case 0:

		$AgentCacher = new AgentCacher($hostname, $username, $password, $database, $config['cache_agent']);
		$AgentCacher->run();

		break;
}

file_put_contents('./run/'.basename(__FILE__).'.pid', $pid);

exit();

/* End of file index.php */
/* Location: ./index.php */