<?php

require_once dirname(__FILE__)."/path.php";
require_once APPPATH."config/database.php";
require_once APPPATH."config/constants.php";
require_once APPPATH."config/shmop.php";
require_once APPPATH."helpers/common_helper.php";
require_once APPPATH."libraries/LogSummary.php";

//define("DEBUG_SPACE", "LogSummary");
define("DEBUG_LEVEL", "1");

extract($db[$active_group]);

switch ($pid = pcntl_fork()) {
	case -1:

		// @fail
		die('Fork failed');
		break;

	case 0:	

		$LogSummary = new LogSummary($hostname, $username, $password, $database);
		$LogSummary->run();

		break;
}

file_put_contents('./run/'.basename(__FILE__).'.pid', $pid);

exit();
/* End of file daemon-summary.php */
/* Location: ./daemon-summary.php */