<?php
require_once dirname(__FILE__)."/path.php";
require_once APPPATH."config/shmop.php";
require_once APPPATH."config/database.php";
require_once APPPATH."config/constants.php";
require_once APPPATH."helpers/common_helper.php";
require_once APPPATH."libraries/LogSaverThread.php";
require_once APPPATH."libraries/LogSaver.php";

//define("DEBUG_SPACE", "LogSaver");
define("DEBUG_LEVEL", "1");

extract($db[$active_group]);

switch ($pid = pcntl_fork()) {
	case -1:

		// @fail
		die('Fork failed');
		break;

	case 0:

        $memUniqSql    = array();
        $memNewSql     = array();
        $memWhiteSql   = array();
        $memClassTrace = array();
        $memDbConnUrl  = array();
        $memPolicyList = array();
        $memApprovalWhiteSql = array();
        
        // $saver = array();
        // foreach(range(1, 10) as $nIdx => $nSaver){

        //     $saver[$nSaver] = new LogSaverThread(
        //         $nSaver, 
        //         $hostname, $username, $password, $database
        //     );

        //     $saver[$nSaver]->start();
        // }

        $Logger = new LogSaver(
        	$hostname, $username, $password, $database
        );
        $Logger->run();

        break;
}



file_put_contents('./run/'.basename(__FILE__).'.pid', $pid);

exit();

/* End of file index.php */
/* Location: ./index.php */