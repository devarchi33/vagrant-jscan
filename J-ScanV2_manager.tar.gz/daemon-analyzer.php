<?php

require_once dirname(__FILE__)."/path.php";
require_once APPPATH."config/database.php";
require_once APPPATH."config/constants.php";
require_once APPPATH."config/shmop.php";
require_once APPPATH."config/realtime.php";
require_once APPPATH."helpers/common_helper.php";
require_once APPPATH."libraries/LogSelector.php";
//require_once APPPATH."libraries/LogCacher.php";
require_once APPPATH."libraries/EventCacher.php";
require_once APPPATH."libraries/LogAnalizer.php";
require_once APPPATH."libraries/LogEvent.php";

//define("DEBUG_SPACE", "LogCacher");
define("DEBUG_LEVEL", "1");

extract($db[$active_group]);

switch ($pid = pcntl_fork()) {
	case -1:

		// @fail
		die('Fork failed');
		break;

	case 0:

        //로그 셀렉팅
		$LogSelector = new LogSelector($hostname, $username, $password, $database);

		// //SQL 로그 캐쉬
        //$LogCacher = new LogCacher($config['cache_sql_log']);

        //이벤트 로그 캐쉬
        $EventCacher = new EventCacher($config['cache_event_log']);

        //SQL 로그 분석
        $LogAnalyzer = new LogAnalyzer($config['analysis'], $config['buffer_size']);

		//Action 등록 - 초기화 메소드
		$LogSelector->addInitAction($LogAnalyzer, 'truncate');
		
		//Action 등록 - SQL로그 분석
		$LogSelector->addSQLLogAction($LogAnalyzer, 'analSQLLog');
		
		//Action 등록 - 이벤트 로그 분석
		$LogSelector->addEventLogAction($LogAnalyzer, 'analEventLog');

		//Action 등록 - 이벤트 로그 캐쉬
		$LogSelector->addEventLogAction($EventCacher, 'cacheLog');

		//Action 등록 - SQL로그 캐쉬
		//$LogSelector->addSQLLogAction($LogCacher, 'cacheLog');

		//Selector 실행
		$LogSelector->run();

		break;
}

file_put_contents('./run/'.basename(__FILE__).'.pid', $pid);

exit();

/* End of file index.php */
/* Location: ./index.php */