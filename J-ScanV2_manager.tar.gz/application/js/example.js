//app.js

Ext.require("Ext.container.Viewport");
Ext.application({
	name:'App',
	appFolder:'app',
	controllers:['Members'],
	
	launch:function(){
		Ext.create("Ext.container.Viewport",{
			layout: 'border',
			defaults:{split:true,collapsible: true},
            items: [
                {
                    xtype: 'memberList',
                    region: 'center',
					collapsible: false
                },
                {
                    xtype: 'memberView',
                    region: 'east',
                    width: 150
                }
            ]
		})
	}
});


//contorller

Ext.define('App.controller.Members',{
	extend:'Ext.app.Controller',
	stores:['Member'],
	models:['Member'],
	views:['member.MemberList','member.MemberView','member.MemberWrite'],
	refs: [
		{ref: 'panel',	selector: 'memberView',autoCreate:true},
		{ref: 'memberWrite',	selector: 'memberWrite',autoCreate:true, xtype: 'memberWrite'}
	],
	init:function(){
		this.getMemberStore().load();
		this.control({
            'viewport > memberList dataview': {
            	itemclick: this.bindGridToPanel
            },
			'memberList button[action=newWin]': {
            	click: this.newWinShow
            },
			'memberWrite button[action=reset]': {
            	click: this.writeReset
            },
			'memberWrite button[action=close]': {
            	click: this.writeClose
            },
			'memberWrite button[action=submit]': {
            	click: this.writeSubmit
            }
        });
	},
	bindGridToPanel : function(grid, record) {
		this.getPanel().updateDetail(record.data);
	},
	newWinShow : function(){		
		this.getMemberWrite().show();		
	},
	writeReset : function (btn, e){
		Ext.getCmp("memberWriteForm").getForm().reset();	
	},
	writeClose : function(btn,e){
		this.getMemberWrite().hide();
	},
	writeSubmit : function(btn, e){
		var memberForm = Ext.getCmp("memberWriteForm");
		if(memberForm.getForm().isValid()){
			var cnt = this.getMemberStore().data.length+1;	
			var userName = Ext.getCmp("userName").getValue();
			var userEmail = Ext.getCmp("userEmail").getValue();
			
			this.getMemberStore().add({seq:cnt,name:userName,email:userEmail});
			this.writeReset();
			this.writeClose();
		}		
	}
});

//model

Ext.define('App.model.Member',{
	extend:'Ext.data.Model',
	fields:['seq','name','email']
});

//view
Ext.define('App.view.member.MemberList',{
	extend:'Ext.grid.Panel',
	alias:'widget.memberList',
	title:'Members',
	initComponent:function(){
		this.store = "Member";
		this.columns = [
			{text:"Seq",		width:100,	dataIndex:'seq',		sortable:true},
			{text:"Name",		flex:1,		dataIndex:'name',		sortable:true},
			{text:"Email",		width:200,	dataIndex:'email',		sortable:true}
		];
		this.tbar = [{
			xtype:'button',
			action:'newWin',
			text:'Member Add'
		}];
		this.viewConfig = {
	        forceFit: true
	    };
		this.callParent(arguments);
	}
});


Ext.define('App.view.member.MemberView', {
	extend: 'Ext.Panel',        
	alias: 'widget.memberView',
	tplMarkup: [
		'<b>Seq:</b> {seq}<br/>',
		'<b>Name:</b> {name}<br/>',
		'<b>Email:</b> {email}<br/>'			
	],
	startingMarkup: 'Please select a book to see additional details.',
	bodyPadding: 7,
	
	initComponent: function() {
		this.tpl = Ext.create('Ext.Template', this.tplMarkup);
		this.html = this.startingMarkup;

		this.bodyStyle = {
			background: '#ffffff'
		};		
		this.callParent(arguments);
	},	
	updateDetail: function(data) {
		this.tpl.overwrite(this.body, data);
	}
});

Ext.define('App.view.member.MemberWrite',{
	extend: 'Ext.window.Window',
	alias:'widget.memberWrite',
	requires: ['Ext.form.Panel', 'Ext.form.field.Text'],	
	title:'Write',
	height: 150,
	width: 400,	
	closeAction: 'hide',
	iconCls: 'rss',
	layout: 'fit',

	initComponent:function(){
		this.items = [{
			xtype: 'form',
			id : 'memberWriteForm',
			bodyStyle: 'padding: 10px;',
			items: [{
				itemId: 'userName',
				id: 'userName',
				anchor: '0',
				fieldLabel: 'Name',
				allowBlank : false,
				labelWidth:100,				
				xtype: 'textfield'
			},{
				itemId: 'userEmail',
				id: 'userEmail',
				anchor: '0',
				fieldLabel: 'Email',
				allowBlank : false,
				vtype : 'email',
				labelWidth:100,				
				xtype: 'textfield'
			}]
		}];
		this.buttons = [{
			text: 'Save',
			action: 'submit'
		},{
			text: 'Reset',
			action: 'reset'
		},{
			text: 'Close',
			action: 'close'
		}];
		
		this.callParent(arguments);
	}	
});

//store

Ext.define('App.store.Member',{
	extend:'Ext.data.Store',
	model:'App.model.Member',
	proxy: {
		type: 'ajax',
		url:'./data/member.php',
		extraParams: {
		},
		reader: {
			type: 'json',
			totalProperty: 'totalCount',
			root: 'data'
		}
	}
});

//member.php
{
	totalCount:1,
	data:[
		{"seq":1, "name":"홍일동", "email":"hong1@test.co.kr"},
		{"seq":2, "name":"홍이동", "email":"hong2@test.co.kr"},
		{"seq":3, "name":"홍삼동", "email":"hong3@test.co.kr"}
	]
}
