<?php
/**
* Model_tbl_whitesql_policy_list 
*
* tbl_whitesql_policy_list 테이블과 대응되는 모델 
*
* @uses CI_Model    
*
* @package  WhiteSql
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
*/
class Model_tbl_whitesql_policy_list extends CI_Model {
	
	//테이블 이름
	private $tbl = 'tbl_whitesql_policy_list';

	//테이블이 가지고 있는 기본 컬럼
	private $columns = array();

	//셀렉트 함수에 의해 셀렉트 된 컬럼 디폴트는 $this->columns와 연결
	private $select_columns = array();

	/**
	 * __construct
	 * 
	 * 모델 생성자
	 *
	 * @access public
	 *
	 */
	public function __construct() {

		parent::__construct();
		
		//데이터 베이스 연결
		$this->load->database();

		//기본컬럼 설정
		array_push($this->columns, 'whitesql_policy_id');
		array_push($this->columns, 'state');
		array_push($this->columns, 'succ_flag');
		array_push($this->columns, 'on_off');
		array_push($this->columns, 'agent_id');
		array_push($this->columns, 'uniqsql_id');
		array_push($this->columns, 'class_id');
		array_push($this->columns, 'registration_time');
		array_push($this->columns, 'registration_user_id');
		array_push($this->columns, 'last_work_time');
		array_push($this->columns, 'last_work_user_id');

		//초기화
		$this->initialize();
	}

	/**
	 * initialize
	 * 
	 * 초기화
	 *
	 * @access private
	 *
	 * @return context $this
	 */
	private function initialize(){

		$this->select_columns = $this->columns;

		return $this;
	}

	/**
	 * select
	 * 
	 * 기본 column에 더하거나 새롭게 select 컬럼을 설정할 때 쓰인다.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function select($select, $reset = true){

		if($reset === true){

			if(is_array($select) === true){

				$this->select_columns = $select;
			}
			else {

				$this->select_columns = explode("," ,$select);
			}
		}
		else {

			if(is_array($select) === true){

				$this->select_columns = array_merge($this->select_columns, $select);	
			}
			else {

				$this->select_columns = array_merge($this->select_columns, explode(",", $select));
			}
		}

		$this->select_columns = array_unique($this->select_columns);

		return $this;
	}

	/**
	 * get
	 * 
	 * 레코드를 셀렉트 한다(가져온다).
	 * @param mixed $whitesql_policy_id Description.
	 *
	 * @access public
	 *
	 * @return mixed result_array.
	 */
	public function get($whitesql_policy_id = NULL) {

		$this->db->select(implode(",", $this->select_columns), false);

		$this->db->from($this->tbl." as white");	
		
		
		if($whitesql_policy_id !== NULL){
			
			$this->db->where('whitesql_policy_id', $whitesql_policy_id);
		} 
		
		$query = $this->db->get();
		
		return $query->result_array();
	}

	/**
	 * add
	 * 
	 * 레코드 추가
	 *
	 * @param mixed $values 추가할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return mixed last insert id.
	 */
	public function add($values) {

		$values = array_merge($values, array(
			));
		
		$this->db->insert($this->tbl, $values);

		return $this->db->insert_id();
	}

	/**
	 * mod
	 * 
	 * 프라이머리 키에 의한 수정
	 *
	 * @param mixed $whitesql_policy_id 수정할 primary key.
	 * @param mixed $values 수정할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function mod($whitesql_policy_id, $values) {
		
		$this->db->where('whitesql_policy_id', $whitesql_policy_id);
				
		$values = array_merge($values, array(
			));
		$this->db->update($this->tbl, $values);
		
		return $this;
	}

	/**
	 * del
	 * 
	 * 프라이머리 키에 의한 삭제
	 *
	 * @param mixed $whitesql_policy_id 삭제할 primary key.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function del($whitesql_policy_id) {
		
		$this->db->where('whitesql_policy_id', $whitesql_policy_id);
				

		$this->db->delete($this->tbl);
		
		return $this;
	}
	
	/**
	 * add
	 * 
	 * 카운트 메소드
	 *
	 * @access public
	 *
	 * @return integer $cnt
	 */
	public function count() {
		
		$cnt = $this->db->count_all_results($this->tbl." as white");
		
		return $cnt;
	}

	/**
	 * limit
	 * 
	 * limit offset 설정
	 *
	 * @param integer $start_no 시작 오프셋
	 * @param integer $end_no 종료 오프셋
	 *
	 * @access public
	 *
	 * @return context $this.
	 */
	public function limit($start_no, $end_no){

		$this->db->limit($end_no, $start_no);

		return $this;
	}

    /**
     * joinUniqSQL
     * 
     * UniqSQL 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinUniqSQL(){

		$this->db->join('tbl_uniqsql uniq', 'uniq.uniqsql_id = white.uniqsql_id', 'left outer');
		return $this;
	}

    /**
     * joinClassTrace
     * 
     * 클래스 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinClassTrace(){

		$this->db->join('tbl_class_trace class', 'class.class_id = white.class_id', 'left outer');
		return $this;
	}

    /**
     * setAgentId
     * 
     * 에이전트 아이디를 조건절에 추가한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function setAgentId($aHosts){
	
		if(is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $this->db->where_in('agent_id', $aHosts);
			else $this->db->where('agent_id', $aHosts[0]);
		}
		return $this;
	}

    /**
     * setPolicyType
     * 
     * 검색할 정책 타입을 조건절에 추가한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function setPolicyType($nPolicyType){
	
		$this->db->where('policy_type', $nPolicyType);
		return $this;
	}

    /**
     * setClassString
     * 
     * 검색할 클래스 명을 조건절에 추가한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function setClassString($sClassString){
	
		$this->db->like('class_string', $sClassString);
		return $this;
	}

    /**
     * setUniqSQLQuery
     * 
     * 검색할 UniqSQL 쿼리를 조건절에 추가한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function setUniqSQLQuery($sQuery){
	
		$this->db->like('uniq.sqltext', $sQuery);
		return $this;
	}
}
/* End of file model_tbl_whitesql_policy_list.php */
/* Location: ./application/models/model_tbl_whitesql_policy_list.php */?>