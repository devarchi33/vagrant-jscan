<?php
/**
* Model_tbl_whitesql_list 
*
* tbl_whitesql_list 테이블과 대응되는 모델 
*
* @uses CI_Model    
*
* @package  WhiteSql
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
*/
class Model_tbl_whitesql_list extends CI_Model {
	
	//테이블 이름
	private $tbl = 'tbl_whitesql_list';

	//테이블이 가지고 있는 기본 컬럼
	private $columns = array();

	//셀렉트 함수에 의해 셀렉트 된 컬럼 디폴트는 $this->columns와 연결
	private $select_columns = array();

	/**
	 * __construct
	 * 
	 * 모델 생성자
	 *
	 * @access public
	 *
	 */
	public function __construct() {

		parent::__construct();
		
		//데이터 베이스 연결
		$this->load->database();

		//기본컬럼 설정
		array_push($this->columns, 'whitesql.whitesql_id');
		array_push($this->columns, 'whitesql.agent_id');
		array_push($this->columns, 'whitesql.uniqsql_id');
		array_push($this->columns, 'whitesql.class_id');
		array_push($this->columns, 'whitesql.reg_time');
		array_push($this->columns, 'whitesql.approval_yn');
		array_push($this->columns, 'whitesql.approval_time');
		array_push($this->columns, 'whitesql.approval_user_id');
		array_push($this->columns, 'whitesql.last_work_time');
		array_push($this->columns, 'whitesql.last_work_user_id');
		array_push($this->columns, 'whitesql.state');
		array_push($this->columns, 'whitesql.on_off');
		array_push($this->columns, 'whitesql.sync_flag');
		array_push($this->columns, 'whitesql.sync_succ_flag');
		array_push($this->columns, 'whitesql.sync_time');
		array_push($this->columns, 'whitesql.sync_user_id');

		//초기화
		$this->initialize();
	}

	/**
	 * initialize
	 * 
	 * 초기화
	 *
	 * @access private
	 *
	 * @return context $this
	 */
	private function initialize(){

		$this->select_columns = $this->columns;

		return $this;
	}

	/**
	 * select
	 * 
	 * 기본 column에 더하거나 새롭게 select 컬럼을 설정할 때 쓰인다.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function select($select, $reset = true){

		if($reset === true){

			if(is_array($select) === true){

				$this->select_columns = $select;
			}
			else {

				$this->select_columns = explode("," ,$select);
			}
		}
		else {

			if(is_array($select) === true){

				$this->select_columns = array_merge($this->select_columns, $select);	
			}
			else {

				$this->select_columns = array_merge($this->select_columns, explode(",", $select));
			}
		}

		$this->select_columns = array_unique($this->select_columns);

		return $this;
	}

	/**
	 * get
	 * 
	 * 레코드를 셀렉트 한다(가져온다).
	 * @param mixed $whitesql_id Description.
	 *
	 * @access public
	 *
	 * @return mixed result_array.
	 */
	public function get($whitesql_id = NULL) {

		$this->db->select(implode(",", $this->select_columns), false);

		$this->db->from($this->tbl." as whitesql");	
			
		if($whitesql_id !== NULL){
			
			if(is_array($whitesql_id) === true) $this->db->where_in('whitesql_id', $whitesql_id);
			else $this->db->where('whitesql_id', $whitesql_id);
		} 
		else {

			$this->db->where_in("state", array("A", "M", "N"));
		}
		
		$query = $this->db->get();
		
		return $query->result_array();
	}

	/**
	 * add
	 * 
	 * 레코드 추가
	 *
	 * @param mixed $values 추가할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return mixed last insert id.
	 */
	public function add($values) {

		$aUser = getUserInfo();

		$values = array_merge($values, array(
			'state'				=> 'A',
			'sync_flag'			=> '0',
			'sync_succ_flag'	=> '0',
			'sync_time'			=> 0,
			'sync_user_id'		=> 0,
			'last_work_user_id' => $aUser['user_id'],
			'last_work_time' => time()
		));
		
		$this->db->insert($this->tbl, $values);

		return $this->db->insert_id();
	}

	/**
	 * mod
	 * 
	 * 프라이머리 키에 의한 수정
	 *
	 * @param mixed $whitesql_id 수정할 primary key.
	 * @param mixed $values 수정할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function mod($whitesql_id, $values) {

		$aUser = getUserInfo();

		$values = array_merge($values, array(
			'sync_flag'			=> '0',
			'sync_succ_flag'	=> '0',
			'sync_time'			=> 0,
			'sync_user_id'		=> 0,
			'last_work_user_id'	=> $aUser['user_id'],
			'last_work_time'	=> time()
		));
		
		if(!isset($values['state'])) $this->db->set('state', 'IF(state = "A", "A", "M")', false);

		$this->db->where('whitesql_id', $whitesql_id);
		$this->db->update($this->tbl, $values);
		
		return $this;
	}

	/**
	 * del
	 * 
	 * 프라이머리 키에 의한 삭제
	 *
	 * @param mixed $whitesql_id 삭제할 primary key.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function del($whitesql_id) {
		
		$this->mod($whitesql_id, array(
			'state' => 'D',
			'on_off' => '0',
			'approval_yn' => '0'
		));

		return $this;
	}
	
	/**
	 * add
	 * 
	 * 카운트 메소드
	 *
	 * @access public
	 *
	 * @return integer $cnt
	 */
	public function count() {
		
		$cnt = $this->db->count_all_results($this->tbl." as whitesql");
		
		return $cnt;
	}

	/**
	 * limit
	 * 
	 * limit offset 설정
	 *
	 * @param integer $start_no 시작 오프셋
	 * @param integer $end_no 종료 오프셋
	 *
	 * @access public
	 *
	 * @return context $this.
	 */
	public function limit($start_no, $end_no){

		$this->db->limit($end_no, $start_no);

		return $this;
	}

    /**
     * joinUniqSQL
     * 
     * UniqSQL 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinUniqSQL(){

		$this->db->join('tbl_uniqsql uniq', 'uniq.uniqsql_id = whitesql.uniqsql_id', 'left outer');
		return $this;
	}

    /**
     * joinNewSQL
     * 
     * NewSQL 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinNewSQL(){

		$this->db->join('tbl_newsql newsql', 'newsql.uniqsql_id = whitesql.uniqsql_id AND newsql.agent_id=whitesql.agent_id AND newsql.class_id=whitesql.class_id', 'left outer');
		return $this;
	}


    /**
     * joinClassTrace
     * 
     * 클래스 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinClassTrace(){

		$this->db->join('tbl_class_trace class', 'class.class_id = whitesql.class_id', 'left outer');
		return $this;
	}

    /**
     * joinAgentInfo
     * 
     * 에이전트 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinAgentInfo(){

		$this->db->join('tbl_agent_info agent', 'agent.agent_id = whitesql.agent_id', 'left outer');
		return $this;
	}

    /**
     * joinApprovalUserInfo
     * 
     * 승인 유저 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinApprovalUserInfo(){

		$this->db->join('tbl_userinfo user', 'user.user_id = whitesql.approval_user_id', 'left outer');
		return $this;
	}	

    /**
     * setAgentId
     * 
     * 에이전트 아이디를 조건절에 추가한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function setAgentId($aHosts){
	
		if(is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $this->db->where_in('whitesql.agent_id', $aHosts);
			else $this->db->where('whitesql.agent_id', $aHosts[0]);
		}
		return $this;
	}

    /**
     * setPolicyType
     * 
     * 검색할 정책 타입을 조건절에 추가한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function setPolicyType($nPolicyType){
	
		$this->db->where('policy_type', $nPolicyType);
		return $this;
	}

    /**
     * setClassString
     * 
     * 검색할 클래스 명을 조건절에 추가한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function setClassString($sClassString){
	
		$this->db->like('class_string', $sClassString);
		return $this;
	}

    /**
     * setUniqSQLQuery
     * 
     * 검색할 UniqSQL 쿼리를 조건절에 추가한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function setUniqSQLQuery($sQuery){
	
		$this->db->like('uniq.orig_sqltext', $sQuery);
		return $this;
	}

    /**
     * setApprovalYn
     * 
     * 승인 SQL조건 추가
     * 
     * @access public
     *
     * @return context $this
     */
	public function setApprovalYn($nApprovalYn){

		$this->db->where('approval_yn', $nApprovalYn);
		return $this;
	}	
}
/* End of file model_tbl_whitesql_list.php */
/* Location: ./application/models/model_tbl_whitesql_list.php */?>