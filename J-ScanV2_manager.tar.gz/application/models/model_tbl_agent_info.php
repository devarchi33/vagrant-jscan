<?php
/**
* Model_tbl_agent_info 
*
* tbl_agent_info 테이블과 대응되는 모델 
*
* @uses CI_Model    
*
* @package  WhiteSql
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
*/
class Model_tbl_agent_info extends CI_Model {
	
	//테이블 이름
	private $tbl = 'tbl_agent_info';

	//테이블이 가지고 있는 기본 컬럼
	private $columns = array();

	//셀렉트 함수에 의해 셀렉트 된 컬럼 디폴트는 $this->columns와 연결
	private $select_columns = array();

	/**
	 * __construct
	 * 
	 * 모델 생성자
	 *
	 * @access public
	 *
	 */
	public function __construct() {

		parent::__construct();
		
		//데이터 베이스 연결
		$this->load->database();

		//기본컬럼 설정
		array_push($this->columns, 'agent.agent_id');
		array_push($this->columns, 'agent.agent_name');
		array_push($this->columns, 'agent.ipaddr');
		array_push($this->columns, 'agent.port');
		array_push($this->columns, 'agent.group_id');
		array_push($this->columns, 'agent.status');
		array_push($this->columns, 'agent.agent_mode');
		array_push($this->columns, 'agent.privacy_flag');
		array_push($this->columns, 'agent.rs_logging_yn');
		array_push($this->columns, 'agent.sync_flag');
		array_push($this->columns, 'agent.license_check');
		array_push($this->columns, 'agent.license_expiredate');
		array_push($this->columns, 'agent.license_key');
		array_push($this->columns, 'agent.license_status');
		array_push($this->columns, 'agent.description');
		array_push($this->columns, 'agent.last_work_time');
		array_push($this->columns, 'agent.last_work_user_id');
		array_push($this->columns, 'agent.server_type');
		array_push($this->columns, 'agent.db_user_id');
		array_push($this->columns, 'agent.db_passwd');
		array_push($this->columns, 'agent.sid');
		array_push($this->columns, 'agent.db_kind');
		

		//초기화
		$this->initialize();
	}

	/**
	 * initialize
	 * 
	 * 초기화
	 *
	 * @access private
	 *
	 * @return context $this
	 */
	private function initialize(){

		$this->select_columns = $this->columns;

		return $this;
	}

	/**
	 * select
	 * 
	 * 기본 column에 더하거나 새롭게 select 컬럼을 설정할 때 쓰인다.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function select($select, $reset = true){

		if($reset === true){

			if(is_array($select) === true){

				$this->select_columns = $select;
			}
			else {

				$this->select_columns = explode("," ,$select);
			}
		}
		else {

			if(is_array($select) === true){

				$this->select_columns = array_merge($this->select_columns, $select);	
			}
			else {

				$this->select_columns = array_merge($this->select_columns, explode(",", $select));
			}
		}

		$this->select_columns = array_unique($this->select_columns);

		return $this;
	}

	/**
	 * get
	 * 
	 * 레코드를 셀렉트 한다(가져온다).
	 * @param mixed $agent_id Description.
	 *
	 * @access public
	 *
	 * @return mixed result_array.
	 */
	public function get($agent_id = NULL) {

		$this->db->select(implode(",", $this->select_columns), false);

		$this->db->from($this->tbl.' as agent');	
		
		$this->db->where('del_yn', '0');
		
		if($agent_id && $agent_id !== NULL){
			
			if(is_array($agent_id) === true){

				$this->db->where_in('agent_id', $agent_id);
			}
			else {

				$this->db->where('agent_id', $agent_id);
			}
		} 
		
		$query = $this->db->get();
		
		$this->initialize();

		return $query->result_array();
	}

    public function getMinLicenseDate(){

        $this->db->select_min('license_expiredate');
        $this->db->where('del_yn', '0');
        $query = $this->db->get('tbl_agent_info');

        return $query->result_array();

    }


	public function isAgent(){

		$this->db->where('server_type', '1');
		return $this;
	}

	/**
	 * add
	 * 
	 * 레코드 추가
	 *
	 * @param mixed $values 추가할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return mixed last insert id.
	 */
	public function add($values) {

		$aUser = getUserInfo();

		$values = array_merge($values, array(
			'last_work_user_id' => $aUser['user_id'],
			'last_work_time' => time()
		));

		$this->db->insert($this->tbl, $values);

		return $this->db->insert_id();
	}

	/**
	 * mod
	 * 
	 * 프라이머리 키에 의한 수정
	 *
	 * @param mixed $agent_id 수정할 primary key.
	 * @param mixed $values 수정할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function mod($agent_id, $values) {
				
		$aUser = getUserInfo();

		$this->db->where('agent_id', $agent_id);

		$values = array_merge($values, array(
			'last_work_user_id' => $aUser['user_id'],
			'last_work_time' => time()
		));
		
		$this->db->update($this->tbl, $values);
		
		return $this;
	}

	/**
	 * del
	 * 
	 * 프라이머리 키에 의한 삭제
	 *
	 * @param mixed $agent_id 삭제할 primary key.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function del($agent_id) {
		
		$this->mod($agent_id, array('del_yn' => '1'));
	}
	
	/**
	 * add
	 * 
	 * 카운트 메소드
	 *
	 * @access public
	 *
	 * @return integer $cnt
	 */
	public function count() {
		
		$cnt = $this->db->count_all_results($this->tbl);
		
		return $cnt;
	}

	/**
	 * limit
	 * 
	 * limit offset 설정
	 *
	 * @param integer $start_no 시작 오프셋
	 * @param integer $end_no 종료 오프셋
	 *
	 * @access public
	 *
	 * @return context $this.
	 */
	public function limit($start_no, $end_no){

		$this->db->limit($end_no, $start_no);

		return $this;
	}

    /**
     * setGroupId
     * 
     * @param mixed $group_id 불러올 그룹 아이디.
     *
     * @access public
     *
     * @return context this.
     */
	public function setGroupId($group_id){

		$this->db->where('agent.group_id', $group_id);

		return $this;
	}

    /**
     * setAgentName
     * 
     * @param mixed $agent_name 불러올 에이전트 이름.
     *
     * @access public
     *
     * @return context this.
     */
	public function setAgentName($agent_name){

		$this->db->where('agent.agent_name', $agent_name);

		return $this;
	}

    /**
     * joinAgentGroupInfo
     * 
     * 에이전트 그룹 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinAgentGroupInfo(){

		$this->db->join('tbl_agentgroup_info agent_grp', 'agent_grp.group_id = agent.group_id', 'left outer');
		return $this;
	}

    /**
     * live
     * 
     * 삭제되지 않은 에어전트만 가져오도록 한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function live(){

		$this->db->where('del_yn', '0');
		return $this;
	}
}
/* End of file model_tbl_agent_info.php */
/* Location: ./application/models/model_tbl_agent_info.php */?>