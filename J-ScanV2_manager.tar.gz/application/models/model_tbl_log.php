<?php
/**
* Model_tbl_log 
*
* tbl_log 테이블과 대응되는 모델 
*
* @uses CI_Model    
*
* @package  WhiteSql
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
*/
class Model_tbl_log extends CI_Model {
	
	//테이블 이름
	private $tbl = 'tbl_log';

	//테이블이 가지고 있는 기본 컬럼
	private $columns = array();

	//셀렉트 함수에 의해 셀렉트 된 컬럼 디폴트는 $this->columns와 연결
	private $select_columns = array();

	/**
	 * __construct
	 * 
	 * 모델 생성자
	 *
	 * @access public
	 *
	 */
	public function __construct() {

		parent::__construct();
		
		//데이터 베이스 연결
		$this->load->database();

		//기본컬럼 설정
		array_push($this->columns, 'log.log_id');
		array_push($this->columns, 'log.sqllog_id');
		array_push($this->columns, 'log.agent_id');
		array_push($this->columns, 'log.agent_mode');
		array_push($this->columns, 'log.request_time');
		array_push($this->columns, 'log.prestmt');
		array_push($this->columns, 'log.sql_str');
		array_push($this->columns, 'log.sql_param');
		array_push($this->columns, 'log.dbconn_url');
		array_push($this->columns, 'log.dbconn_account');
		array_push($this->columns, 'log.class_trace');
		array_push($this->columns, 'log.policy_id');
		array_push($this->columns, 'log.block_yn');
		array_push($this->columns, 'log.login_id');
		array_push($this->columns, 'log.ipaddr');
		array_push($this->columns, 'log.exec_starttime');
		array_push($this->columns, 'log.exec_elapsedtime');
		array_push($this->columns, 'log.execute_yn');
		array_push($this->columns, 'log.fail_code');
		array_push($this->columns, 'log.result_count');
		array_push($this->columns, 'log.privacy_type');
		array_push($this->columns, 'log.privacy_value');
		array_push($this->columns, 'log.result_data');

		//초기화
		$this->initialize();
	}

	/**
	 * initialize
	 * 
	 * 초기화
	 *
	 * @access private
	 *
	 * @return context $this
	 */
	private function initialize(){

		$this->select_columns = $this->columns;

		return $this;
	}

	/**
	 * select
	 * 
	 * 기본 column에 더하거나 새롭게 select 컬럼을 설정할 때 쓰인다.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function select($select, $reset = true){

		if($reset === true){

			if(is_array($select) === true){

				$this->select_columns = $select;
			}
			else {

				$this->select_columns = explode("," ,$select);
			}
		}
		else {

			if(is_array($select) === true){

				$this->select_columns = array_merge($this->select_columns, $select);	
			}
			else {

				$this->select_columns = array_merge($this->select_columns, explode(",", $select));
			}
		}

		$this->select_columns = array_unique($this->select_columns);

		return $this;
	}

	/**
	 * get
	 * 
	 * 레코드를 셀렉트 한다(가져온다).
	 * @param mixed $log_id Description.
	 *
	 * @access public
	 *
	 * @return mixed result_array.
	 */
	public function get($log_id = NULL) {

		$this->db->select(implode(",", $this->select_columns), false);

		$this->db->from($this->tbl.' as log');	
		
		
		if($log_id !== NULL){
			
			$this->db->where('log.log_id', $log_id);
		} 
		
		$query = $this->db->get();
		
		return $query->result_array();
	}

	public function getNumOfQueryExecPerSec($aHosts, $sFDate, $sTDate = null){

		$aWhere = array();

		$aHosts = array();

		if($aHosts && is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $aWhere[] = 'agent_id in ('.implode(',', $aHosts).')';
			else $aWhere[] = 'agent_id = '.$aHosts[0];
		}

		$aWhere[] = "
			request_time 
			BETWEEN concat(date_format('".$sFDate."', '%Y-%m-%d %H:%i:%s'), '.000000') 
			AND concat(date_format('".$sTDate."', '%Y-%m-%d %H:%i:%s'), '.999999')
		";
		$sWhere = implode(' AND ', $aWhere);

		$query = $this->db->query("
			SELECT agent_id, COUNT(1) as cnt, DATE_FORMAT(request_time, '%Y%m%d%H%i%s') as ymdhis 
			FROM tbl_log 
			WHERE ".$sWhere."
			GROUP BY agent_id, ymdhis 
		");
		
		return $query->result_array();
	}	

	public function getResponseTimePerSec($aHosts, $sFDate, $sTDate = null){

		$aWhere = array();

		$aHosts = array();

		if($aHosts && is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $aWhere[] = 'agent_id in ('.implode(',', $aHosts).')';
			else $aWhere[] = 'agent_id = '.$aHosts[0];
		}

		$aWhere[] = "
			request_time 
			BETWEEN concat(date_format('".$sFDate."', '%Y-%m-%d %H:%i:%s'), '.000000') 
			AND concat(date_format('".$sTDate."', '%Y-%m-%d %H:%i:%s'), '.999999')
		";
		$sWhere = implode(' AND ', $aWhere);

		$query = $this->db->query("
			SELECT agent_id, ROUND(AVG(exec_elapsedtime), 3) as cnt, DATE_FORMAT(request_time, '%Y%m%d%H%i%s') as ymdhis 
			FROM tbl_log 
			WHERE ".$sWhere."
			GROUP BY agent_id, ymdhis 
		");
	
		return $query->result_array();
	}

    /**
     * setRequestTime
     *
     * 시작 종료일을 조건절에 추가하여 검색 한다.
     *
     * @access public
     *
     * @return context $this
     */
    public function setRequestTime($sFDate, $sTDate = null){

        if($sFDate && $sTDate){

            $this->db->where('log.request_time BETWEEN "'.$sFDate.' 00:00:00.000000" AND "'.$sTDate.' 23:59:59.999999"');
        }
        else {

            if(preg_match('/[0-9]{4}-[0-9]{2}-[0-9]{2}\s[0-9]{2}:[0-9]{2}:[0-9]{2}/', $sFDate) == true){

                $this->db->where('log.request_time BETWEEN "'.$sFDate.'.000000" AND "'.$sFDate.'.999999"');
            }
            else {

                $this->db->where('log.request_time BETWEEN "'.$sFDate.' 00:00:00.000000" AND "'.$sFDate.' 23:59:59.999999"');
            }
        }
        return $this;
    }

    /**
     * joinAgentInfo
     * 
     * 에이전트 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinAgentInfo(){

		$this->db->join('tbl_agent_info agent', 'agent.agent_id = log.agent_id', 'left outer');
		return $this;
	}


    /**
     * joinAnalLog
     *
     * 분석 로그와 조인한다.
     *
     * @access public
     *
     * @return context $this
     */
    public function joinAnalLog(){

        $this->db->join('tbl_anal_log anal', 'log.sqllog_id = anal.sqllog_id', 'left outer');
        return $this;
    }

	/**
     * joinPolicyList
     * 
     * 정책 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinPolicyList(){

		$this->db->join('tbl_policy_list policy', 'policy.policy_id = anal.blocksql_id', 'left outer');
		return $this;
	}


    public function liveAgent(){

        $this->db->where('agent.del_yn', '0');
        return $this;
    }

    /**
     * setAgentId
     *
     * 에이전트 아이디를 조건절에 추가한다.
     *
     * @access public
     *
     * @return context $this
     */
    public function setAgentId($aHosts){

        if(is_array($aHosts) === false){

            $aHosts = explode(",", $aHosts);
        }

        if(count($aHosts) > 0){

            if(count($aHosts) > 1) $this->db->where_in('log.agent_id', $aHosts);
            else $this->db->where('log.agent_id', $aHosts[0]);
        }
        return $this;
    }


    /**
	 * add
	 * 
	 * 레코드 추가
	 *
	 * @param mixed $values 추가할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return mixed last insert id.
	 */
	public function add($values) {

		$values = array_merge($values, array(
			));
		
		$this->db->insert($this->tbl, $values);

		return $this->db->insert_id();
	}

	/**
	 * mod
	 * 
	 * 프라이머리 키에 의한 수정
	 *
	 * @param mixed $log_id 수정할 primary key.
	 * @param mixed $values 수정할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function mod($log_id, $values) {
		
		$this->db->where('log_id', $log_id);
				
		$values = array_merge($values, array(
			));
		$this->db->update($this->tbl, $values);
		
		return $this;
	}

	/**
	 * del
	 * 
	 * 프라이머리 키에 의한 삭제
	 *
	 * @param mixed $log_id 삭제할 primary key.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function del($log_id) {
		
		$this->db->where('log_id', $log_id);
				

		$this->db->delete($this->tbl);
		
		return $this;
	}
	
	/**
	 * add
	 * 
	 * 카운트 메소드
	 *
	 * @access public
	 *
	 * @return integer $cnt
	 */
	public function count() {
		
		$cnt = $this->db->count_all_results($this->tbl.' as log');
		
		return $cnt;
	}

	/**
	 * limit
	 * 
	 * limit offset 설정
	 *
	 * @param integer $start_no 시작 오프셋
	 * @param integer $end_no 종료 오프셋
	 *
	 * @access public
	 *
	 * @return context $this.
	 */
	public function limit($start_no, $end_no){

		$this->db->limit($end_no, $start_no);

		return $this;
	}
}
/* End of file model_tbl_log.php */
/* Location: ./application/models/model_tbl_log.php */?>