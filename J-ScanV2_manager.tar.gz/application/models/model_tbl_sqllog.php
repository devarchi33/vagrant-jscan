<?php
/**
* Model_tbl_sqllog 
*
* tbl_sqllog 테이블과 대응되는 모델 
*
* @uses CI_Model    
*
* @package  WhiteSql
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
*/
class Model_tbl_sqllog extends CI_Model {
	
	//테이블 이름
	private $tbl = 'tbl_sqllog';

	//테이블이 가지고 있는 기본 컬럼
	private $columns = array();

	//셀렉트 함수에 의해 셀렉트 된 컬럼 디폴트는 $this->columns와 연결
	private $select_columns = array();

	/**
	 * __construct
	 * 
	 * 모델 생성자
	 *
	 * @access public
	 *
	 */
	public function __construct() {

		parent::__construct();
		
		//데이터 베이스 연결
		$this->load->database();
		
		//기본컬럼 설정
		array_push($this->columns, 'sql_log.sqllog_id');
		array_push($this->columns, 'sql_log.agent_id');
		array_push($this->columns, 'sql_log.agent_mode');
		array_push($this->columns, 'sql_log.request_time');
		array_push($this->columns, 'sql_log.sql_type');
		array_push($this->columns, 'sql_log.req_sqltext');
		array_push($this->columns, 'sql_log.uniqsql_id');
		array_push($this->columns, 'sql_log.sqlparam');
		array_push($this->columns, 'sql_log.dbconn_id');
		array_push($this->columns, 'sql_log.dbconn_url');
		array_push($this->columns, 'sql_log.dbconn_account');
		array_push($this->columns, 'sql_log.class_text');
		array_push($this->columns, 'sql_log.class_id');
		array_push($this->columns, 'sql_log.whitesql_id');
		array_push($this->columns, 'sql_log.convsql_id');
		array_push($this->columns, 'sql_log.blocksql_id');
		array_push($this->columns, 'sql_log.block_yn');
		array_push($this->columns, 'sql_log.login_id');
		array_push($this->columns, 'sql_log.ipaddr');
		array_push($this->columns, 'sql_log.session_id');
		array_push($this->columns, 'sql_log.session_createtime');
		array_push($this->columns, 'sql_log.exec_starttime');
		array_push($this->columns, 'sql_log.exec_endtime');
		array_push($this->columns, 'sql_log.exec_elapsedtime');
		array_push($this->columns, 'sql_log.execute_yn');
		array_push($this->columns, 'sql_log.result_count');
		array_push($this->columns, 'sql_log.result_data_saved');
		array_push($this->columns, 'sql_log.fail_code');
		array_push($this->columns, 'sql_log.sqllog_check');
		array_push($this->columns, 'sql_log.privacy_type');
		array_push($this->columns, 'sql_log.privacy_value');
		
		//초기화
		$this->initialize();
	}

	/**
	 * initialize
	 * 
	 * 초기화
	 *
	 * @access private
	 *
	 * @return context $this
	 */
	private function initialize(){

		$this->select_columns = $this->columns;

		return $this;
	}

	/**
	 * select
	 * 
	 * 기본 column에 더하거나 새롭게 select 컬럼을 설정할 때 쓰인다.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function select($select, $reset = true){

		if($reset === true){

			if(is_array($select) === true){

				$this->select_columns = $select;
			}
			else {

				$this->select_columns = explode("," ,$select);
			}
		}
		else {

			if(is_array($select) === true){

				$this->select_columns = array_merge($this->select_columns, $select);	
			}
			else {

				$this->select_columns = array_merge($this->select_columns, explode(",", $select));
			}
		}

		$this->select_columns = array_unique($this->select_columns);

		return $this;
	}

	/**
	 * get
	 * 
	 * 레코드를 셀렉트 한다(가져온다).
	 * @param mixed $sqllog_id Description.
	 * @param mixed $agent_id Description.
	 *
	 * @access public
	 *
	 * @return mixed result_array.
	 */
	public function get($sqllog_id = NULL, $agent_id = NULL) {

		$this->db->select(implode(",", $this->select_columns), false);

		$this->db->from($this->tbl.' as sql_log');	
		
		if($sqllog_id !== NULL){
			
			$this->db->where('sql_log.sqllog_id', $sqllog_id);
		} 

		if($agent_id !== NULL){
			
			$this->db->where('sql_log.agent_id', $agent_id);
		} 
		
		$query = $this->db->get();
		
		return $query->result_array();
	}

	public function liveAgent(){

		$this->db->where('agent.del_yn', '0');
		return $this;
	}

	public function getQueryExecuteTop20($aHosts, $sFDate, $sTDate = null){

		$aWhere = array();

		if(is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $aWhere[] = 'agent_id in ('.implode(',', $aHosts).')';
			else $aWhere[] = 'agent_id = '.$aHosts[0];
		}


		$aWhere[] = 'request_time BETWEEN "'.$sFDate.' 00:00:00.000000" AND "'.$sTDate.' 23:59:59.999999"';
		$sWhere = implode(' AND ', $aWhere);

		$query = $this->db->query('
			SELECT * FROM (
				SELECT 	
				  `login_id`, `ipaddr`, `req_sqltext`, COUNT(1) AS cnt
				FROM `tbl_sqllog` a 
				WHERE '.$sWhere.'
				GROUP BY ipaddr, login_id, uniqsql_id
			) AS a
			ORDER BY cnt DESC LIMIT 20
		');

		return $query->result_array();
	}

	public function getResultCountTop20($aHosts, $sFDate, $sTDate = null){

		$aWhere = array();

		if(is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $aWhere[] = 'agent_id in ('.implode(',', $aHosts).')';
			else $aWhere[] = 'agent_id = '.$aHosts[0];
		}

		$aWhere[] = 'request_time BETWEEN "'.$sFDate.' 00:00:00.000000" AND "'.$sTDate.' 23:59:59.999999"';
		$sWhere = implode(' AND ', $aWhere);

		$query = $this->db->query('
			SELECT * FROM (
				SELECT 	
				  `login_id`, `ipaddr`, `req_sqltext`, SUM(`result_count`) AS cnt
				FROM `tbl_sqllog` a 
				WHERE '.$sWhere.'
				GROUP BY ipaddr, login_id, uniqsql_id
			) AS a
			ORDER BY cnt DESC LIMIT 20
		');
		
		return $query->result_array();
	}

	public function getIPExecutionCount($aHosts, $sFDate, $sTDate = null){

		$aWhere = array();

		if(is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $aWhere[] = 'agent_id in ('.implode(',', $aHosts).')';
			else $aWhere[] = 'agent_id = '.$aHosts[0];
		}

		$aWhere[] = 'request_time BETWEEN "'.$sFDate.' 00:00:00.000000" AND "'.$sTDate.' 23:59:59.999999"';
		$sWhere = implode(' AND ', $aWhere);

		$query = $this->db->query('
			SELECT 
				ipaddr as ip, COUNT(1) AS cnt, 
				SUM(IF(sql_type = "SELECT", 1, 0)) AS `view`,
				SUM(IF(sql_type = "INSERT", 1, 0)) AS `add`,
				SUM(IF(sql_type = "UPDATE", 1, 0)) AS `mod`,
				SUM(IF(sql_type = "DELETE", 1, 0)) AS `del`,
				SUM(IF(sql_type = "SELECT" AND sql_type = "INSERT" AND sql_type = "UPDATE" AND sql_type = "DELETE", 1, 0)) AS `etc`
			FROM tbl_sqllog `log` 
			WHERE '.$sWhere.'
			GROUP BY ipaddr
		');
		
		return $query->result_array();
	}

	public function getLoginIDPExecutionCount($aHosts, $sFDate, $sTDate = null){

		$aWhere = array();

		if(is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $aWhere[] = 'agent_id in ('.implode(',', $aHosts).')';
			else $aWhere[] = 'agent_id = '.$aHosts[0];
		}

		$aWhere[] = 'request_time BETWEEN "'.$sFDate.' 00:00:00.000000" AND "'.$sTDate.' 23:59:59.999999"';
		$sWhere = implode(' AND ', $aWhere);

		$query = $this->db->query('
			SELECT 
				login_id, COUNT(1) AS cnt, 
				SUM(IF(sql_type = "SELECT", 1, 0)) AS `view`,
				SUM(IF(sql_type = "INSERT", 1, 0)) AS `add`,
				SUM(IF(sql_type = "UPDATE", 1, 0)) AS `mod`,
				SUM(IF(sql_type = "DELETE", 1, 0)) AS `del`,
				SUM(IF(sql_type = "SELECT" AND sql_type = "INSERT" AND sql_type = "UPDATE" AND sql_type = "DELETE", 1, 0)) AS `etc`
			FROM tbl_sqllog `log` 
			WHERE '.$sWhere.'
			GROUP BY login_id
		');
		
		return $query->result_array();
	}

	public function getWeeklyExecutionCount($aHosts, $sFDate, $sTDate = null){

		$aWhere = array();

		if(is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $aWhere[] = 'agent_id in ('.implode(',', $aHosts).')';
			else $aWhere[] = 'agent_id = '.$aHosts[0];
		}

		$aWhere[] = 'request_time BETWEEN "'.$sFDate.' 00:00:00.000000" AND "'.$sTDate.' 23:59:59.999999"';
		$sWhere = implode(' AND ', $aWhere);

		$query = $this->db->query('
			SELECT 
				DAYOFWEEK(request_time) AS wday, 
				COUNT(1) AS cnt
			FROM tbl_sqllog `log` 
			WHERE '.$sWhere.'
			GROUP BY DAYOFWEEK(request_time)
		');
		
		return $query->result_array();
	}

	public function getHourlyExecutionCount($aHosts, $sFDate, $sTDate = null){

		$aWhere = array();

		if(is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $aWhere[] = 'agent_id in ('.implode(',', $aHosts).')';
			else $aWhere[] = 'agent_id = '.$aHosts[0];
		}

		$aWhere[] = 'request_time BETWEEN "'.$sFDate.' 00:00:00.000000" AND "'.$sTDate.' 23:59:59.999999"';
		$sWhere = implode(' AND ', $aWhere);

		$query = $this->db->query('
			SELECT 
				HOUR(request_time) AS `hour`, 
				COUNT(1) AS cnt
			FROM tbl_sqllog `log` 
			WHERE '.$sWhere.'
			GROUP BY HOUR(request_time)
		');
		
		return $query->result_array();
	}

	public function getDailyExecutionCount($aHosts, $sFDate, $sTDate = null){

		$aWhere = array();

		if(is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $aWhere[] = 'agent_id in ('.implode(',', $aHosts).')';
			else $aWhere[] = 'agent_id = '.$aHosts[0];
		}

		$aWhere[] = 'request_time BETWEEN "'.$sFDate.' 00:00:00.000000" AND "'.$sTDate.' 23:59:59.999999"';
		$sWhere = implode(' AND ', $aWhere);

		$query = $this->db->query('
			SELECT 
				DAY(request_time) AS `day`, 
				COUNT(1) AS cnt
			FROM tbl_sqllog `log` 
			WHERE '.$sWhere.'
			GROUP BY DAY(request_time)
		');
		
		return $query->result_array();
	}

	public function getDateExecutionCount($aHosts, $sFDate, $sTDate = null){

		$aWhere = array();

		if(is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $aWhere[] = 'agent_id in ('.implode(',', $aHosts).')';
			else $aWhere[] = 'agent_id = '.$aHosts[0];
		}

		$aWhere[] = 'request_time BETWEEN "'.$sFDate.' 00:00:00.000000" AND "'.$sTDate.' 23:59:59.999999"';
		$sWhere = implode(' AND ', $aWhere);

		$query = $this->db->query('
			SELECT 
				DATE(request_time) AS `day`, 
				COUNT(1) AS cnt
			FROM tbl_sqllog `log` 
			WHERE '.$sWhere.'
			GROUP BY DATE(request_time)
		');
		
		return $query->result_array();
	}	

	public function getAccessCount($sMode, $aHosts, $sFDate, $sTDate = null){

		$aWhere = array();

		if(is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if($sMode == 'PersonalInfo'){

			$sType = POLICY_PERSONAL_INFO_TABLE;
		}
		else {

			$sType = POLICY_TABLE;	
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $aWhere[] = $sWhere = 'agent_id in ('.implode(',', $aHosts).')';
			else $aWhere[] = $sWhere = 'agent_id = '.$aHosts[0];

			$aWhere[] = 'blocksql_id IN (SELECT policy_id FROM tbl_policy_list WHERE '.$sWhere.' AND policy_type = '.$sType.')';
		}
		else {

			$aWhere[] = 'blocksql_id IN (SELECT policy_id FROM tbl_policy_list WHERE policy_type = '.$sType.')';	
		}

		$aWhere[] = 'request_time BETWEEN "'.$sFDate.' 00:00:00.000000" AND "'.$sTDate.' 23:59:59.999999"';

		$sWhere = implode(' AND ', $aWhere);

		$query = $this->db->query('
			SELECT 
				ipaddr, COUNT(1) AS cnt, 
				SUM(IF(sql_type = "SELECT", 1, 0)) AS `view`,
				SUM(IF(sql_type = "INSERT", 1, 0)) AS `add`,
				SUM(IF(sql_type = "UPDATE", 1, 0)) AS `mod`,
				SUM(IF(sql_type = "DELETE", 1, 0)) AS `del`,
				SUM(IF(sql_type = "SELECT" AND sql_type = "INSERT" AND sql_type = "UPDATE" AND sql_type = "DELETE", 1, 0)) AS `etc`
			FROM tbl_sqllog `log`
			WHERE '.$sWhere.'
			GROUP BY ipaddr
		');
		
		return $query->result_array();
	}

	public function getNumOfQueryExecPerSec($aHosts, $sFDate, $sTDate = null){

		$aWhere = array();

		$aHosts = array();

		if($aHosts && is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $aWhere[] = 'agent_id in ('.implode(',', $aHosts).')';
			else $aWhere[] = 'agent_id = '.$aHosts[0];
		}

		$aWhere[] = "
			request_time 
			BETWEEN concat(date_format('".$sFDate."', '%Y-%m-%d %H:%i:%s'), '.000000') 
			AND concat(date_format('".$sTDate."', '%Y-%m-%d %H:%i:%s'), '.999999')
		";
		$sWhere = implode(' AND ', $aWhere);

		$query = $this->db->query("
			SELECT agent_id, COUNT(1) as cnt, DATE_FORMAT(request_time, '%Y%m%d%H%i%s') as ymdhis 
			FROM tbl_sqllog 
			WHERE ".$sWhere."
			GROUP BY agent_id, ymdhis 
		");
		
		return $query->result_array();
	}	

	public function getResponseTimePerSec($aHosts, $sFDate, $sTDate = null){

		$aWhere = array();

		$aHosts = array();

		if($aHosts && is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $aWhere[] = 'agent_id in ('.implode(',', $aHosts).')';
			else $aWhere[] = 'agent_id = '.$aHosts[0];
		}

		$aWhere[] = "
			request_time 
			BETWEEN concat(date_format('".$sFDate."', '%Y-%m-%d %H:%i:%s'), '.000000') 
			AND concat(date_format('".$sTDate."', '%Y-%m-%d %H:%i:%s'), '.999999')
		";
		$sWhere = implode(' AND ', $aWhere);

		$query = $this->db->query("
			SELECT agent_id, ROUND(AVG(exec_elapsedtime), 3) as cnt, DATE_FORMAT(request_time, '%Y%m%d%H%i%s') as ymdhis 
			FROM tbl_sqllog 
			WHERE ".$sWhere."
			GROUP BY agent_id, ymdhis 
		");
	
		return $query->result_array();
	}	

	/**
	 * add
	 * 
	 * 레코드 추가
	 *
	 * @param mixed $values 추가할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return mixed last insert id.
	 */
	public function add($values) {

		$values = array_merge($values, array(
			));
		
		$this->db->insert($this->tbl, $values);

		return $this->db->insert_id();
	}

	/**
	 * mod
	 * 
	 * 프라이머리 키에 의한 수정
	 *
	 * @param mixed $sqllog_id 수정할 primary key.
	 * @param mixed $agent_id 수정할 primary key.
	 * @param mixed $values 수정할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function mod($sqllog_id, $agent_id, $values) {
		
		$this->db->where('sqllog_id', $sqllog_id);
		$this->db->where('agent_id', $agent_id);
				
		$values = array_merge($values, array(
			));
		$this->db->update($this->tbl, $values);
		
		return $this;
	}

	/**
	 * del
	 * 
	 * 프라이머리 키에 의한 삭제
	 *
	 * @param mixed $sqllog_id 삭제할 primary key.
	 * @param mixed $agent_id 삭제할 primary key.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function del($sqllog_id, $agent_id) {
		
		$this->db->where('sqllog_id', $sqllog_id);
		$this->db->where('agent_id', $agent_id);
				

		$this->db->delete($this->tbl);
		
		return $this;
	}
	
	/**
	 * count
	 * 
	 * 카운트 메소드
	 *
	 * @access public
	 *
	 * @return integer $cnt
	 */
	public function count() {
		
		$cnt = $this->db->count_all_results($this->tbl." as sql_log");
		
		return $cnt;
	}

	/**
	 * limit
	 * 
	 * limit offset 설정
	 *
	 * @param integer $start_no 시작 오프셋
	 * @param integer $end_no 종료 오프셋
	 *
	 * @access public
	 *
	 * @return context $this.
	 */
	public function limit($start_no, $end_no){

		$this->db->limit($end_no, $start_no);

		return $this;
	}

    /**
     * joinAgentInfo
     * 
     * 에이전트 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinAgentInfo(){

		$this->db->join('tbl_agent_info agent', 'agent.agent_id = sql_log.agent_id', 'left outer');
		return $this;
	}

    /**
     * joinPolicyList
     * 
     * 정책 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinBlockSQLList(){

		$this->db->join('tbl_blocksql_list blocksql', 'blocksql.blocksql_id = sql_log.policy_id', 'left outer');
		return $this;
	}

    /**
     * joinWhiteSQLPolicyList
     * 
     * WhiteSQL 정책 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinWhiteSQLList(){

		$this->db->join('tbl_whitesql_list whitesql', 'whitesql.whitesql_id = sql_log.whitesql_id', 'left outer');
		$this->db->join('tbl_uniqsql whitesql_uniq', 'whitesql_uniq.uniqsql_id = whitesql.uniqsql_id', 'left outer');
		return $this;
	}

    /**
     * joinConvertSQLPolicyList
     * 
     * ConvertSQL 정책 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinConvertSQLList(){

		$this->db->join('tbl_convsql_list convsql', 'convsql.convsql_id = sql_log.convsql_id', 'left outer');
		return $this;
	}

	/**
     * joinPolicyList
     * 
     * 정책 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinPolicyList(){

		$this->db->join('tbl_policy_list policy', 'policy.policy_id = sql_log.blocksql_id', 'left outer');
		return $this;
	}

    /**
     * setAgentId
     * 
     * 에이전트 아이디를 조건절에 추가한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function setAgentId($aHosts){
	
		if(is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $this->db->where_in('sql_log.agent_id', $aHosts);
			else $this->db->where('sql_log.agent_id', $aHosts[0]);
		}
		return $this;
	}

    /**
     * setRequestTime
     * 
     * 시작 종료일을 조건절에 추가하여 검색 한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function setRequestTime($sFDate, $sTDate = null){
		
		if($sFDate && $sTDate){

			$this->db->where('sql_log.request_time BETWEEN "'.$sFDate.' 00:00:00.000000" AND "'.$sTDate.' 23:59:59.999999"');
		}
		else {

			if(preg_match('/[0-9]{4}-[0-9]{2}-[0-9]{2}\s[0-9]{2}:[0-9]{2}:[0-9]{2}/', $sFDate) == true){

				$this->db->where('sql_log.request_time BETWEEN "'.$sFDate.'.000000" AND "'.$sFDate.'.999999"');
			}
			else {

				$this->db->where('sql_log.request_time BETWEEN "'.$sFDate.' 00:00:00.000000" AND "'.$sFDate.' 23:59:59.999999"');	
			}			
		}
		return $this;
	}

	public function setPolicyType($nPolicyType){
	
		$this->db->where('sql_log.policy_type', $nPolicyType);
		return $this;
	}

	public function setSqlText($sQuery){
	
		$this->db->like('sql_log.req_sqltext', $sQuery);
		return $this;
	}

	public function setIp($sIp){
	
		$this->db->like('sql_log.ipaddr', $sIp);
		return $this;
	}

    /**
     * setUniqSqlId
     * 
     * Uniq SQL 아이디를 조건절에 추가한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function setUniqSqlId($nUniqSqlId){
	
		$this->db->where('sql_log.uniqsql_id', $nUniqSqlId);
		return $this;
	}

    /**
     * setClassId
     * 
     * 클래스 아이디를 조건절에 추가한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function setClassId($nClassId){
	
		$this->db->where('sql_log.class_id', $nClassId);
		return $this;
	}
}
/* End of file model_tbl_sqllog.php */
/* Location: ./application/models/model_tbl_sqllog.php */?>