<?php
class Model_generate extends CI_Model {

	function __construct()
	{
		parent::__construct();
		
		$this->load->database();
	}

	function get_table_list()
	{
		$tbl_list[''] = 'Select Table';
		foreach ($this->db->list_tables() as $tbl) {
			$tbl_list[$tbl] = $tbl;
		}

		return $tbl_list;		
	}
	
	function get_table_info($tbl = NULL)
	{
		$ret = FALSE;
		
		if($tbl !== NULL && $this->db->table_exists($tbl)) {
			$ret = $this->db->field_data($tbl);
		}
		
		return $ret;
	}

	function get_field_list($tbl = NULL)
	{
		$ret = $this->get_table_info($tbl);
		
		if($ret !== FALSE) {
			$field_list[''] = 'Select Primary Key';
			foreach ($ret as $field) {
				$field_list[$field->name] = $field->name;
			}
			
			$ret = $field_list;
		}

		return $ret;
	}
}