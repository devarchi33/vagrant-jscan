<?php
/**
* Model_tbl_sqllog_convert_summary
*
* tbl_sqllog_convert_summary 테이블과 대응되는 모델 
*
* @uses CI_Model    
*
* @package  WhiteSql
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
*/
class Model_tbl_sqllog_convert_summary extends CI_Model {
	
	//테이블 이름
	private $tbl = 'tbl_sqllog_convert_summary';

	//테이블이 가지고 있는 기본 컬럼
	private $columns = array();

	//셀렉트 함수에 의해 셀렉트 된 컬럼 디폴트는 $this->columns와 연결
	private $select_columns = array();

	/**
	 * __construct
	 * 
	 * 모델 생성자
	 *
	 * @access public
	 *
	 */
	public function __construct() {

		parent::__construct();
		
		//데이터 베이스 연결
		$this->load->database();

		//기본컬럼 설정
		array_push($this->columns, 'date_f');
		array_push($this->columns, 'agent_id');
		array_push($this->columns, 'uniqsql_id');
		array_push($this->columns, 'class_id');
		array_push($this->columns, 'sum_count');
		array_push($this->columns, 'avg_elapsedtime');
		array_push($this->columns, 'avg_result_count');

		//초기화
		$this->initialize();
	}

	/**
	 * initialize
	 * 
	 * 초기화
	 *
	 * @access private
	 *
	 * @return context $this
	 */
	private function initialize(){

		$this->select_columns = $this->columns;

		return $this;
	}

	/**
	 * select
	 * 
	 * 기본 column에 더하거나 새롭게 select 컬럼을 설정할 때 쓰인다.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function select($select, $reset = true){

		if($reset === true){

			if(is_array($select) === true){

				$this->select_columns = $select;
			}
			else {

				$this->select_columns = explode("," ,$select);
			}
		}
		else {

			if(is_array($select) === true){

				$this->select_columns = array_merge($this->select_columns, $select);	
			}
			else {

				$this->select_columns = array_merge($this->select_columns, explode(",", $select));
			}
		}

		$this->select_columns = array_unique($this->select_columns);

		return $this;
	}

	/**
	 * get
	 * 
	 * 레코드를 셀렉트 한다(가져온다).
	 *
	 * @access public
	 *
	 * @return mixed result_array.
	 */
	public function get() {

		$this->db->select(implode(",", $this->select_columns), false);

		$this->db->from($this->tbl.' as sum_log');	
				
		$query = $this->db->get();
		
		return $query->result_array();
	}

	/**
	 * count
	 * 
	 * 카운트 메소드
	 *
	 * @access public
	 *
	 * @return integer $cnt
	 */
	public function count() {
		
		$cnt = $this->db->count_all_results($this->tbl.' as sum_log');
		
		return $cnt;
	}

	/**
	 * limit
	 * 
	 * limit offset 설정
	 *
	 * @param integer $start_no 시작 오프셋
	 * @param integer $end_no 종료 오프셋
	 *
	 * @access public
	 *
	 * @return context $this.
	 */
	public function limit($start_no, $end_no){

		$this->db->limit($end_no, $start_no);

		return $this;
	}

    /**
     * joinAgentInfo
     * 
     * 에이전트 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinAgentInfo(){

		$this->db->join('tbl_agent_info agent', 'agent.agent_id = sum_log.agent_id', 'left outer');
		return $this;
	}

    /**
     * joinClassTrace
     * 
     * 클래스 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinClassTrace(){

		$this->db->join('tbl_class_trace cls', 'cls.class_id = sum_log.class_id', 'left outer');
		return $this;
	}

    /**
     * joinUniqSql
     * 
     * UniqSQL 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinUniqSql(){

		$this->db->join('tbl_uniqsql uniq', 'uniq.uniqsql_id = sum_log.uniqsql_id', 'left outer');
		return $this;
	}

    /**
     * setAgentId
     * 
     * 에이전트 아이디를 조건절에 추가한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function setAgentId($aHosts){
	
		if(is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $this->db->where_in('sum_log.agent_id', $aHosts);
			else $this->db->where('sum_log.agent_id', $aHosts[0]);
		}
		return $this;
	}

    /**
     * setSumTime
     * 
     * 시작 종료일을 조건절에 추가하여 검색 한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function setDate($sFDate, $sTDate){
		
		if($sFDate == $sTDate) $sTDate = null;

		if($sFDate && $sTDate){

			$this->db->where('date_f BETWEEN "'.$sFDate.'" AND "'.$sTDate.'"');
		}
		else {

			$this->db->where('date_f', $sFDate);	
		}
		return $this;
	}

	public function setSqlText($sQuery){
	
		$this->db->like('uniq.orig_sqltext', $sQuery);
		return $this;
	}
}
/* End of file model_tbl_sqllog_convert_summary.php */
/* Location: ./application/models/model_tbl_sqllog_convert_summary.php */?>