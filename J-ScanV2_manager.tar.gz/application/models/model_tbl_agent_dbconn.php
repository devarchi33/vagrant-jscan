<?php
/**
* Model_tbl_agent_dbconn 
*
* tbl_agent_dbconn 테이블과 대응되는 모델 
*
* @uses CI_Model    
*
* @package  WhiteSql
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
*/
class Model_tbl_agent_dbconn extends CI_Model {
	
	//테이블 이름
	private $tbl = 'tbl_agent_dbconn';

	//테이블이 가지고 있는 기본 컬럼
	private $columns = array();

	//셀렉트 함수에 의해 셀렉트 된 컬럼 디폴트는 $this->columns와 연결
	private $select_columns = array();

	/**
	 * __construct
	 * 
	 * 모델 생성자
	 *
	 * @access public
	 *
	 */
	public function __construct() {

		parent::__construct();
		
		//데이터 베이스 연결
		$this->load->database();

		//기본컬럼 설정
		array_push($this->columns, 'agent_id');
		array_push($this->columns, 'dbconn_id');

		//초기화
		$this->initialize();
	}

	/**
	 * initialize
	 * 
	 * 초기화
	 *
	 * @access private
	 *
	 * @return context $this
	 */
	private function initialize(){

		$this->select_columns = $this->columns;

		return $this;
	}

	/**
	 * select
	 * 
	 * 기본 column에 더하거나 새롭게 select 컬럼을 설정할 때 쓰인다.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function select($select, $reset = true){

		if($reset === true){

			if(is_array($select) === true){

				$this->select_columns = $select;
			}
			else {

				$this->select_columns = explode("," ,$select);
			}
		}
		else {

			if(is_array($select) === true){

				$this->select_columns = array_merge($this->select_columns, $select);	
			}
			else {

				$this->select_columns = array_merge($this->select_columns, explode(",", $select));
			}
		}

		$this->select_columns = array_unique($this->select_columns);

		return $this;
	}

	/**
	 * get
	 * 
	 * 레코드를 셀렉트 한다(가져온다).
	 * @param mixed $agent_id Description.
	 * @param mixed $dbconn_id Description.
	 *
	 * @access public
	 *
	 * @return mixed result_array.
	 */
	public function get($agent_id = NULL, $dbconn_id = NULL) {

		$this->db->select(implode(",", $this->select_columns), false);

		$this->db->from($this->tbl);	
		
		
		if($agent_id !== NULL && $dbconn_id !== NULL){
			
			$this->db->where('agent_id', $agent_id);
			$this->db->where('dbconn_id', $dbconn_id);
		} 
		
		$query = $this->db->get();
		
		return $query->result_array();
	}

	/**
	 * add
	 * 
	 * 레코드 추가
	 *
	 * @param mixed $values 추가할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return mixed last insert id.
	 */
	public function add($values) {

		$values = array_merge($values, array(
			));
		
		$this->db->insert($this->tbl, $values);

		return $this->db->insert_id();
	}

	/**
	 * mod
	 * 
	 * 프라이머리 키에 의한 수정
	 *
	 * @param mixed $agent_id 수정할 primary key.
	 * @param mixed $dbconn_id 수정할 primary key.
	 * @param mixed $values 수정할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function mod($agent_id, $dbconn_id, $values) {
		
		$this->db->where('agent_id', $agent_id);
		$this->db->where('dbconn_id', $dbconn_id);
				
		$values = array_merge($values, array(
			));
		$this->db->update($this->tbl, $values);
		
		return $this;
	}

	/**
	 * del
	 * 
	 * 프라이머리 키에 의한 삭제
	 *
	 * @param mixed $agent_id 삭제할 primary key.
	 * @param mixed $dbconn_id 삭제할 primary key.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function del($agent_id, $dbconn_id) {
		
		$this->db->where('agent_id', $agent_id);
		$this->db->where('dbconn_id', $dbconn_id);
				

		$this->db->delete($this->tbl);
		
		return $this;
	}
	
	/**
	 * add
	 * 
	 * 카운트 메소드
	 *
	 * @access public
	 *
	 * @return integer $cnt
	 */
	public function count() {
		
		$cnt = $this->db->count_all_results($this->tbl);
		
		return $cnt;
	}

	/**
	 * limit
	 * 
	 * limit offset 설정
	 *
	 * @param integer $start_no 시작 오프셋
	 * @param integer $end_no 종료 오프셋
	 *
	 * @access public
	 *
	 * @return context $this.
	 */
	public function limit($start_no, $end_no){

		$this->db->limit($end_no, $start_no);

		return $this;
	}
}
/* End of file model_tbl_agent_dbconn.php */
/* Location: ./application/models/model_tbl_agent_dbconn.php */?>