<?php
/**
* Model_tbl_work_history 
*
* tbl_work_history 테이블과 대응되는 모델 
*
* @uses CI_Model    
*
* @package  WhiteSql
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
*/
class Model_tbl_work_history extends CI_Model {
	
	//테이블 이름
	private $tbl = 'tbl_work_history';

	//테이블이 가지고 있는 기본 컬럼
	private $columns = array();

	//셀렉트 함수에 의해 셀렉트 된 컬럼 디폴트는 $this->columns와 연결
	private $select_columns = array();

	/**
	 * __construct
	 * 
	 * 모델 생성자
	 *
	 * @access public
	 *
	 */
	public function __construct() {

		parent::__construct();
		
		//데이터 베이스 연결
		$this->load->database();

		//기본컬럼 설정
		array_push($this->columns, 'work_history_id');
		array_push($this->columns, 'work_type');
		array_push($this->columns, 'work_time');
		array_push($this->columns, 'agent_id');
		array_push($this->columns, 'work_user_id');
		array_push($this->columns, 'work_message');
		array_push($this->columns, 'work_target');
		array_push($this->columns, 'work_before');
		array_push($this->columns, 'work_after');

		//초기화
		$this->initialize();
	}

	/**
	 * initialize
	 * 
	 * 초기화
	 *
	 * @access private
	 *
	 * @return context $this
	 */
	private function initialize(){

		$this->select_columns = $this->columns;

		return $this;
	}

	/**
	 * select
	 * 
	 * 기본 column에 더하거나 새롭게 select 컬럼을 설정할 때 쓰인다.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function select($select, $reset = true){

		if($reset === true){

			if(is_array($select) === true){

				$this->select_columns = $select;
			}
			else {

				$this->select_columns = explode("," ,$select);
			}
		}
		else {

			if(is_array($select) === true){

				$this->select_columns = array_merge($this->select_columns, $select);	
			}
			else {

				$this->select_columns = array_merge($this->select_columns, explode(",", $select));
			}
		}

		$this->select_columns = array_unique($this->select_columns);

		return $this;
	}

	/**
	 * get
	 * 
	 * 레코드를 셀렉트 한다(가져온다).
	 * @param mixed $work_history_id Description.
	 *
	 * @access public
	 *
	 * @return mixed result_array.
	 */
	public function get($work_history_id = NULL) {

		$this->db->select(implode(",", $this->select_columns), false);

		$this->db->from($this->tbl." as work_his");	
		
		
		if($work_history_id !== NULL){
			
			$this->db->where('work_history_id', $work_history_id);
		} 
		
		$query = $this->db->get();
		
		return $query->result_array();
	}

	/**
	 * add
	 * 
	 * 레코드 추가
	 *
	 * @param mixed $values 추가할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return mixed last insert id.
	 */
	public function add($values) {

		$aUser = getUserInfo();

		$values = array_merge($values, array(
			'work_user_id' => (int)$aUser['user_id'],
			'work_time' => time()
		));
		
		$this->db->insert($this->tbl, $values);

		return $this->db->insert_id();
	}

	/**
	 * mod
	 * 
	 * 프라이머리 키에 의한 수정
	 *
	 * @param mixed $work_history_id 수정할 primary key.
	 * @param mixed $values 수정할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function mod($work_history_id, $values) {
		
			
		$aUser = getUserInfo();

		$values = array_merge($values, array(
			'work_user_id' => (int)$aUser['user_id'],
			'work_time' => time()
		));
		
		$this->db->where('work_history_id', $work_history_id);
		$this->db->update($this->tbl, $values);
		
		return $this;
	}

	/**
	 * del
	 * 
	 * 프라이머리 키에 의한 삭제
	 *
	 * @param mixed $work_history_id 삭제할 primary key.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function del($work_history_id) {
		
		$this->db->where('work_history_id', $work_history_id);
				

		$this->db->delete($this->tbl);
		
		return $this;
	}
	
	/**
	 * add
	 * 
	 * 카운트 메소드
	 *
	 * @access public
	 *
	 * @return integer $cnt
	 */
	public function count() {
		
		$cnt = $this->db->count_all_results($this->tbl.' as work_his');
		
		return $cnt;
	}

	/**
	 * limit
	 * 
	 * limit offset 설정
	 *
	 * @param integer $start_no 시작 오프셋
	 * @param integer $end_no 종료 오프셋
	 *
	 * @access public
	 *
	 * @return context $this.
	 */
	public function limit($start_no, $end_no){

		$this->db->limit($end_no, $start_no);

		return $this;
	}

    /**
     * joinAgentInfo
     * 
     * 에이전트 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinAgentInfo(){

		$this->db->join('tbl_agent_info agent', 'agent.agent_id = work_his.agent_id', 'left outer');
		return $this;
	}

    /**
     * joinPolicyList
     * 
     * 정책 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinPolicyList(){

		$this->db->join('tbl_policy_list pol', 'pol.policy_id = work_his.policy_id', 'left outer');
		return $this;
	}

	/**
     * joinUserInfo
     * 
     * 유저 정보와 조인한다.
     * 
     * @access public
     *
     * @return context $this
     */
	public function joinUserInfo(){

		$this->db->join('tbl_userinfo usr', 'usr.user_id = work_his.work_user_id', 'left outer');
		return $this;
	}

	public function setAgentId($aHosts){
	
		if(is_array($aHosts) === false){

			$aHosts = explode(",", $aHosts);
		}

		if(count($aHosts) > 0){

			if(count($aHosts) > 1) $this->db->where_in('work_his.agent_id', $aHosts);
			else $this->db->where('work_his.agent_id', $aHosts[0]);
		}
		return $this;
	}

	public function setWorkTime($sFDate, $sTDate){
		
		if($sFDate && $sTDate){

			$this->db->where('work_his.work_time BETWEEN unix_timestamp("'.$sFDate.' 00:00:00") AND unix_timestamp("'.$sTDate.' 23:59:59")');
		}
		else {

			$this->db->where('work_his.work_time', 'unix_timestamp("'.$sFDate.'")');	
		}
		return $this;
	}

	public function setWorkType($nWorkType){
	
		$this->db->where('work_his.work_type', $nWorkType);
		return $this;
	}

	public function setUserId($sUser){
	
		$this->db->where('work_his.work_user_id', $sUser);
		return $this;
	}

	public function setMessage($sMessage){
	
		$this->db->like('work_his.work_message', $sMessage);
		return $this;
	}
}
/* End of file model_tbl_work_history.php */
/* Location: ./application/models/model_tbl_work_history.php */?>