<?php
/**
* Model_tbl_summary 
*
* tbl_summary 테이블과 대응되는 모델 
*
* @uses CI_Model    
*
* @package  WhiteSql
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
*/
class Model_tbl_summary extends CI_Model {
	
	//테이블 이름
	private $tbl = 'tbl_summary';

	//테이블이 가지고 있는 기본 컬럼
	private $columns = array();

	//셀렉트 함수에 의해 셀렉트 된 컬럼 디폴트는 $this->columns와 연결
	private $select_columns = array();

	/**
	 * __construct
	 * 
	 * 모델 생성자
	 *
	 * @access public
	 *
	 */
	public function __construct() {

		parent::__construct();
		
		//데이터 베이스 연결
		$this->load->database();

		//기본컬럼 설정
		array_push($this->columns, 'name');
		array_push($this->columns, 'type');
		array_push($this->columns, 'view_group');
		array_push($this->columns, 'data');
		array_push($this->columns, 'sdate');
		array_push($this->columns, 'edate');

		//초기화
		$this->initialize();
	}

	/**
	 * initialize
	 * 
	 * 초기화
	 *
	 * @access private
	 *
	 * @return context $this
	 */
	private function initialize(){

		$this->select_columns = $this->columns;

		return $this;
	}

	/**
	 * select
	 * 
	 * 기본 column에 더하거나 새롭게 select 컬럼을 설정할 때 쓰인다.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function select($select, $reset = true){

		if($reset === true){

			if(is_array($select) === true){

				$this->select_columns = $select;
			}
			else {

				$this->select_columns = explode("," ,$select);
			}
		}
		else {

			if(is_array($select) === true){

				$this->select_columns = array_merge($this->select_columns, $select);	
			}
			else {

				$this->select_columns = array_merge($this->select_columns, explode(",", $select));
			}
		}

		$this->select_columns = array_unique($this->select_columns);

		return $this;
	}

	/**
	 * get
	 * 
	 * 레코드를 셀렉트 한다(가져온다).
	 * @param mixed $name Description.
	 * @param mixed $type Description.
	 * @param mixed $view_group Description.
	 *
	 * @access public
	 *
	 * @return mixed result_array.
	 */
	public function get($name = NULL, $type = NULL, $view_group = NULL) {

		$this->db->select(implode(",", $this->select_columns), false);

		$this->db->from($this->tbl);	
		
		
		if($name !== NULL && $type !== NULL && $view_group !== NULL){
			
			$this->db->where('name', $name);
			$this->db->where('type', $type);
			$this->db->where('view_group', $view_group);
		} 
		
		$this->db->order_by('edate', 'desc');
		$this->db->limit(1);
		$query = $this->db->get();
		
		return $query->result_array();
	}

    public function getNumOfEvent($sType, $sServer){

    	$aData = @(array)json_decode(
    		array_pop($this->select('data')->get('num_of_event', $sType, $sServer))['data'], 
    		true
    	);

	    $aSummary = array_fill_keys(array('notice', 'attention', 'alert', 'danger', 'serious'), 0);
	    foreach($aData as $nIdx => $aRow){

	        foreach($aSummary as $sKey => $nVal){

	            $aSummary[$sKey] += $aRow[$sKey];    
	        }
	    }

	    $aData = @array(
	        array('event' => '알림', 'value' => (int)$aSummary['notice']),
	        array('event' => '주의', 'value' => (int)$aSummary['attention']),
	        array('event' => '경고', 'value' => (int)$aSummary['alert']),
	        array('event' => '위험', 'value' => (int)$aSummary['danger']),
	        array('event' => '심각', 'value' => (int)$aSummary['serious'])
	    );

        return $aData;
    }

    public function getNumOfEventByAgent($sType, $sServer){

    	$aData = @(array)json_decode(
    		array_pop($this->select('data')->get('num_of_event', $sType, $sServer))['data'], 
    		true
    	);

        return $aData;
    }

    public function getNumOfQueryExecByPolicy($sType, $sServer){

    	$aData = @(array)json_decode(
    		array_pop($this->select('data')->get('num_of_query_exec_by_policy', $sType, $sServer))['data'], 
    		true
    	);

        //정책별 쿼리수
        $aCount = array_fill(0, 8, 0);
        foreach($aData as $nIdx => $aRow){

            $aCount[0] += $aRow[0];
            $aCount[1] += $aRow[1];
            $aCount[2] += $aRow[2];
            $aCount[3] += $aRow[3];
            $aCount[4] += $aRow[4];
            $aCount[5] += $aRow[5];
            $aCount[6] += $aRow[6];
            $aCount[7] += $aRow[7];
        }

        if(
        	$aCount[0] == 0 && $aCount[1] == 0 && $aCount[2] == 0 
        	&& $aCount[3] == 0 && $aCount[4] == 0 && $aCount[5] == 0 
        	&& $aCount[6] == 0 && $aCount[7] == 0
        ){

            $aSize = array_fill(0, 8, 1);
        }
        else {

            $aSize = $aCount;
        }


        $aData = array();
        array_push($aData, array('event' => 'None WhiteSQL', 'value' => (int)$aCount[0], 'size' => (int)$aSize[0]));
        array_push($aData, array('event' => 'SQL',           'value' => (int)$aCount[1], 'size' => (int)$aSize[1]));
        array_push($aData, array('event' => 'SQL변경',       'value' => (int)$aCount[2], 'size' => (int)$aSize[2]));
        array_push($aData, array('event' => 'IP',            'value' => (int)$aCount[3], 'size' => (int)$aSize[3]));
        array_push($aData, array('event' => 'LOGIN ID',      'value' => (int)$aCount[4], 'size' => (int)$aSize[4]));
        array_push($aData, array('event' => '주요TABLE',     'value' => (int)$aCount[5], 'size' => (int)$aSize[5]));
        array_push($aData, array('event' => 'SQL유형',       'value' => (int)$aCount[6], 'size' => (int)$aSize[6]));
        array_push($aData, array('event' => '개인정보TABLE', 'value' => (int)$aCount[7], 'size' => (int)$aSize[7]));

        return $aData;
    }

    public function getAvgNumOfQueryExecResults($sType, $sServer){

    	$aData = @(array)json_decode(
    		array_pop($this->select('data')->get('avg_num_of_query_exec_results', $sType, $sServer))['data'], 
    		true
    	);
        return $aData;
    }

    public function getNumOfQueryExec($sType, $sServer){

    	$aData = @(array)json_decode(
    		array_pop($this->select('data')->get('num_of_query_exec', $sType, $sServer))['data'], 
    		true
    	);
        return $aData;
    }
    
    public function getStatusOfQueryExec($sType, $sServer){

        $this->load->config("system", true);
        $aEventLevel = $this->config->item('event_level', 'system');

        $aAgents = $this->getAgentList($sServer);
        
    	$aSummary = @(array)json_decode(
    		array_pop($this->select('data')->get('status_of_query_exec', $sType, $sServer))['data'], 
    		true
    	);

    	$aData = array();

    	foreach($aSummary as $nIdx => $aRow){

    		$aData[$aRow['agent_id']] = $aRow;
    	}

    	foreach($aAgents as $nIdx => $aAgent){

			$aAgents[$nIdx]['event_level'] = @(int)$aData[$aAgent['agent_id']]['event_level'] ? $aEventLevel[$aData[$aAgent['agent_id']]['event_level']] : '-';
			$aAgents[$nIdx]['cnt_exec'] = @(int)$aData[$aAgent['agent_id']]['cnt_exec'];
			$aAgents[$nIdx]['cnt_personal_info'] = @(int)$aData[$aAgent['agent_id']]['cnt_personal_info'];
			$aAgents[$nIdx]['cnt_table'] = @(int)$aData[$aAgent['agent_id']]['cnt_table'];
			$aAgents[$nIdx]['cnt_fail'] = @(int)$aData[$aAgent['agent_id']]['cnt_fail'];
			$aAgents[$nIdx]['cnt_conv'] = @(int)$aData[$aAgent['agent_id']]['cnt_conv'];
    	}
        return $aAgents;
    }

    private function getAgentList($sServer = 'root'){

    	if($sServer == 'root'){

			$aServer = null;
		}
		else {

			$aServer = getServerList($sServer);
		}

        $this->load->model('tbl_agent_info');

        $aAgents = $this->tbl_agent_info->get($aServer);

        // $aData = array();
        // foreach($aAgents as $nIdx => $aRow){

        // 	$aData[$aRow['agent_id']] = $aRow;
        // }
        return $aAgents;
    }

    public function getMostAccessIP($sType, $sServer){

    	$aData = @(array)json_decode(
    		array_pop($this->select('data')->get('most_access_ip', $sType, $sServer))['data'], 
    		true
    	);

        return $aData;
    }

    public function getMuchLookupIP($sType, $sServer){

    	$aData = @(array)json_decode(
    		array_pop($this->select('data')->get('much_lookup_ip', $sType, $sServer))['data'], 
    		true
    	);

        return $aData;
    }

    public function getPersonalInfoAccessIP($sType, $sServer){

    	$aData = @(array)json_decode(
    		array_pop($this->select('data')->get('personal_info_access_ip', $sType, $sServer))['data'], 
    		true
    	);
        return $aData;
    }

	/**
	 * add
	 * 
	 * 레코드 추가
	 *
	 * @param mixed $values 추가할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return mixed last insert id.
	 */
	public function add($values) {

		$values = array_merge($values, array(
			));
		
		$this->db->insert($this->tbl, $values);

		return $this->db->insert_id();
	}

	/**
	 * mod
	 * 
	 * 프라이머리 키에 의한 수정
	 *
	 * @param mixed $name 수정할 primary key.
	 * @param mixed $type 수정할 primary key.
	 * @param mixed $view_group 수정할 primary key.
	 * @param mixed $values 수정할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function mod($name, $type, $view_group, $values) {
		
		$this->db->where('name', $name);
		$this->db->where('type', $type);
		$this->db->where('view_group', $view_group);
				
		$values = array_merge($values, array(
			));
		$this->db->update($this->tbl, $values);
		
		return $this;
	}

	/**
	 * del
	 * 
	 * 프라이머리 키에 의한 삭제
	 *
	 * @param mixed $name 삭제할 primary key.
	 * @param mixed $type 삭제할 primary key.
	 * @param mixed $view_group 삭제할 primary key.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function del($name, $type, $view_group) {
		
		$this->db->where('name', $name);
		$this->db->where('type', $type);
		$this->db->where('view_group', $view_group);
				

		$this->db->delete($this->tbl);
		
		return $this;
	}
	
	/**
	 * add
	 * 
	 * 카운트 메소드
	 *
	 * @access public
	 *
	 * @return integer $cnt
	 */
	public function count() {
		
		$cnt = $this->db->count_all_results($this->tbl);
		
		return $cnt;
	}

	/**
	 * limit
	 * 
	 * limit offset 설정
	 *
	 * @param integer $start_no 시작 오프셋
	 * @param integer $end_no 종료 오프셋
	 *
	 * @access public
	 *
	 * @return context $this.
	 */
	public function limit($start_no, $end_no){

		$this->db->limit($end_no, $start_no);

		return $this;
	}
}
/* End of file model_tbl_summary.php */
/* Location: ./application/models/model_tbl_summary.php */?>