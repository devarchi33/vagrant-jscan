<tree id="0" radio="1">
    <item text="<?php echo _("All Servers")?>" id="server_tree_all" child="1" im0="host_all.png" im1="host_all.png" im2="host_all.png" open="1">
        <userdata name="node_type">ALL</userdata>
        <userdata name="node_id">0</userdata>
        <?php foreach($agent_group as $group_id => $group_name) :?>
            <item id="server_tree_group_<?php echo $group_id?>" im0="host_group_en.png" im1="host_group_en.png" im2="host_group_en.png" open="1">
                <itemtext><![CDATA[<?php echo $group_name?>]]></itemtext>
                <userdata name="node_type">GRP</userdata>
                <userdata name="node_id"><?php echo $group_id?></userdata>
                <?php if(isset($agent[$group_id])) :?>
                    <?php foreach($agent[$group_id] as $idx => $row):?>
                        <?php if($row["status"]): ?>
                            <item id="server_tree_host_<?php echo $row['agent_id']?>" child="0" im0="host_en.png" im1="host_en.png" im2="host_en.png">
                                <itemtext><![CDATA[<?php echo $row["agent_name"]?>]]></itemtext>
                                <userdata name="node_type">HOST</userdata>
                                <userdata name="node_id"><?php echo $row['agent_id']?></userdata>
                                <userdata name="status"><?php echo $row["status"]?></userdata>
                                <userdata name="security_mode"><?php echo $row["security_mode"]?></userdata>
                            </item>
                        <?php else:?>
                            <item id="server_tree_host_<?php echo $row['agent_id']?>" child="0" im0="host_dis.png" im1="host_dis.png" im2="host_dis.png">
                                <itemtext><![CDATA[<font style="color:#F00;font-weight:bolder;"><?php echo $row["agent_name"]?></font>]]></itemtext>
                                <userdata name="node_type">HOST</userdata>
                                <userdata name="node_id"><?php echo $row['agent_id']?></userdata>
                                <userdata name="status"><?php echo $row["status"]?></userdata>
                                <userdata name="security_mode"><?php echo $row["security_mode"]?></userdata>
                            </item>
                        <?php endif;?>
                    <?php endforeach;?>
                <?php endif;?>
            </item>
        <?php endforeach;?>
    </item>
</tree>