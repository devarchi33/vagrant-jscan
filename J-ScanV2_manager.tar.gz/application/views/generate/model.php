/**
* Model_<?php echo $tbl;?> 
*
* <?php echo $tbl;?> 테이블과 대응되는 모델 
*
* @uses CI_Model    
*
* @package  WhiteSql
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
*/
class Model_<?php echo $tbl;?> extends CI_Model {
	
	//테이블 이름
	private $tbl = '<?=$tbl?>';

	//테이블이 가지고 있는 기본 컬럼
	private $columns = array();

	//셀렉트 함수에 의해 셀렉트 된 컬럼 디폴트는 $this->columns와 연결
	private $select_columns = array();

	/**
	 * __construct
	 * 
	 * 모델 생성자
	 *
	 * @access public
	 *
	 */
	public function __construct() {

		parent::__construct();
		
		//데이터 베이스 연결
		$this->load->database();

		//기본컬럼 설정
<?foreach($columns as $idx => $field){?>		array_push($this->columns, '<?=$field?>');
<?}?>

		//초기화
		$this->initialize();
	}

	/**
	 * initialize
	 * 
	 * 초기화
	 *
	 * @access private
	 *
	 * @return context $this
	 */
	private function initialize(){

		$this->select_columns = $this->columns;

		return $this;
	}

	/**
	 * select
	 * 
	 * 기본 column에 더하거나 새롭게 select 컬럼을 설정할 때 쓰인다.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function select($select, $reset = true){

		if($reset === true){

			if(is_array($select) === true){

				$this->select_columns = $select;
			}
			else {

				$this->select_columns = explode("," ,$select);
			}
		}
		else {

			if(is_array($select) === true){

				$this->select_columns = array_merge($this->select_columns, $select);	
			}
			else {

				$this->select_columns = array_merge($this->select_columns, explode(",", $select));
			}
		}

		$this->select_columns = array_unique($this->select_columns);

		return $this;
	}

	/**
	 * get
	 * 
	 * 레코드를 셀렉트 한다(가져온다).
<?foreach($primary_key as $idx => $field){?>	 * @param mixed $<?=$field?> Description.
<?}?>
	 *
	 * @access public
	 *
	 * @return mixed result_array.
	 */
	public function get(<?="$".implode(" = NULL, $", $primary_key)?> = NULL) {

		$this->db->select(implode(",", $this->select_columns), false);

		$this->db->from($this->tbl);	
		
		
		if(<?="$".implode(" !== NULL && $", $primary_key)?> !== NULL){
			
<?foreach($primary_key as $idx => $field){?>			$this->db->where('<?=$field?>', $<?=$field?>);
<?}?>		} 
		
		<?if(@$field_list["del_yn"]){?>$this->db->where('del_yn', 'n');
		<?}?>$query = $this->db->get();
		
		return $query->result_array();
	}

	/**
	 * add
	 * 
	 * 레코드 추가
	 *
	 * @param mixed $values 추가할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return mixed last insert id.
	 */
	public function add($values) {

		$values = array_merge($values, array(
			<?if(@$field_list["del_yn"]){?>'del_yn'  => 'n',
			<?}?><?if(@$field_list["add_date"]){?>'add_date' => date("Y-m-d H:i:s"),
			<?}?><?if(@$field_list["add_account_id"]){?>'add_account_id' => $this->input->cookie("account_id")
		<?}?>));
		
		$this->db->insert($this->tbl, $values);

		return $this->db->insert_id();
	}

	/**
	 * mod
	 * 
	 * 프라이머리 키에 의한 수정
	 *
<?foreach($primary_key as $idx => $field){?>	 * @param mixed $<?=$field?> 수정할 primary key.
<?}?>
	 * @param mixed $values 수정할 레코드의 column값 배열.
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function mod(<?="$".implode(", $", $primary_key)?>, $values) {
		
		<?foreach($primary_key as $idx => $field){?>$this->db->where('<?=$field?>', $<?=$field?>);
		<?}?>
		
		$values = array_merge($values, array(
			<?if(@$field_list["mod_date"]){?>'mod_date' => date("Y-m-d H:i:s"),
			<?}?><?if(@$field_list["mod_account_id"]){?>'mod_account_id' => $this->input->cookie("account_id")
		<?}?>));
		$this->db->update($this->tbl, $values);
		
		return $this;
	}

	/**
	 * del
	 * 
	 * 프라이머리 키에 의한 삭제
	 *
<?foreach($primary_key as $idx => $field){?>	 * @param mixed $<?=$field?> 삭제할 primary key.
<?}?>
	 *
	 * @access public
	 *
	 * @return context $this
	 */
	public function del(<?="$".implode(", $", $primary_key)?>) {
		
		<?foreach($primary_key as $idx => $field){?>$this->db->where('<?=$field?>', $<?=$field?>);
		<?}?>		

		<?if(@$field_list["del_yn"]){?>$this->db->update($this->tbl, array(
			<?if(@$field_list["del_yn"]){?>'del_yn' => 'y',
			<?}?><?if(@$field_list["del_date"]){?>'del_date' => date("Y-m-d H:i:s"),
			<?}?><?if(@$field_list["del_account_id"]){?>'del_account_id' => $this->input->cookie("account_id")
		<?}?>));
		<?}else{?>$this->db->delete($this->tbl);
		<?}?>

		return $this;
	}
	
	/**
	 * add
	 * 
	 * 카운트 메소드
	 *
	 * @access public
	 *
	 * @return integer $cnt
	 */
	public function count() {
		
		<?if(@$field_list["del_yn"]){?>if(!$where["del_yn"]) $this->db->where('del_yn', 'n'); 
		<?}?>$cnt = $this->db->count_all_results($this->tbl);
		
		return $cnt;
	}

	/**
	 * limit
	 * 
	 * limit offset 설정
	 *
	 * @param integer $start_no 시작 오프셋
	 * @param integer $end_no 종료 오프셋
	 *
	 * @access public
	 *
	 * @return context $this.
	 */
	public function limit($start_no, $end_no){

		$this->db->limit($end_no, $start_no);

		return $this;
	}
}
/* End of file model_<?php echo $tbl;?>.php */
/* Location: ./application/models/model_<?php echo $tbl;?>.php */