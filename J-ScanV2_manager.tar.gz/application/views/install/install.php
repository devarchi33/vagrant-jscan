<!DOCTYPE html>
<html>
<head>
    <title>White SQL - Dashboard</title>  
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="Content-Script-Type" content="text/javascript" />
    <meta http-equiv="Content-Style-Type" content="text/css" /> 
    <link rel="stylesheet" type="text/css" href="/extjs/resources/css/ext-all-gray.css"/>
    <script type="text/javascript" src="/extjs/ext-all.js"></script>
    <script type="text/javascript" src="/web/controller/install/Install.js"></script>
</head>
<body>
</body>
</html>