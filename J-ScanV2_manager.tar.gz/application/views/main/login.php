<!DOCTYPE html>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]> <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]> <html class="lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html lang="en"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>Login Form</title>
  <link rel="stylesheet" href="css/login.css">
  <!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <script type="text/javascript" src="/extjs/ext-all-debug.js"></script>
    <style>
    .CodeMirror {
        border-top: 1px solid black;
        border-bottom: 1px solid black;
    }
    /*.x-toolbar .x-btn{
    border-color: #9d9d9d;
    }*/
    body,
    html{
        margin:0px;
        padding:0px;
        width:100%;
        height:100%;
    }

    .loginIdDiv {
        position: absolute;
        left: 50%;
        top: 50%;
        text-align: center;        
        width:230px;
        height:40px;
        margin-left: 27px; /*half width*/
        margin-top: -112px; /*half height*/
    }
    .loginPWDiv {
        position: absolute;
        left: 50%;
        top: 50%;
        text-align: center;        
        width:230px;
        height:40px;
        margin-left: 27px; /*half width*/
        margin-top: -50px; /*half height*/
    }
    .submitDiv {
        position: absolute;
        left: 50%;
        top: 50%;
        text-align: center;        
        width:230px;
        height:40px;
        margin-left: 114px; /*half width*/
        margin-top: 10px; /*half height*/
    }
    .rememberDiv {
        position: absolute;
        left: 50%;
        top: 50%;
        text-align: center;        
        padding:10px;
        margin-left:25px; /*half width*/
        margin-top: 10px; /*half height*/
        background-color:#E8E8E8;
    }
    .btn {
        background: #d93434;
        background-image: -webkit-linear-gradient(top, #d93434, #ab0303);
        background-image: -moz-linear-gradient(top, #d93434, #ab0303);
        background-image: -ms-linear-gradient(top, #d93434, #ab0303);
        background-image: -o-linear-gradient(top, #d93434, #ab0303);
        background-image: linear-gradient(to bottom, #d93434, #ab0303);
        -webkit-border-radius: 2;
        -moz-border-radius: 2;
        border-radius: 2px;
        font-family: Arial;
        color: #ffffff;
        font-size: 12px;
        padding: 14px 40px 14px 40px;
        text-decoration: none;
        border:none !important;
        box-shadow:none !important;
    }

    .btn:hover {
        background: #d93434;
        background-image: -webkit-linear-gradient(top, #d93434, #ab0303);
        background-image: -moz-linear-gradient(top, #d93434, #ab0303);
        background-image: -ms-linear-gradient(top, #d93434, #ab0303);
        background-image: -o-linear-gradient(top, #d93434, #ab0303);
        background-image: linear-gradient(to bottom, #d93434, #ab0303);
        text-decoration: none;
    }
    </style>
</head>
<body>
    <div style="background:url('/images/login_back.jpg') no-repeat;background-color:#878682;background-position: center; width:100%;height:100%">
        <form name="frm-login" id="frm-login" method="post">
            <div class="loginIdDiv"><input type="text" name="login-id" id="login-id" value="" placeholder="ID"></div>
            <div class="loginPWDiv"><input type="password" name="login-pw" id="login-pw" value="" placeholder="Password"></div>
            <div class="submitDiv"><input type="submit" name="commit" value="Login" class="btn"></div>
            <div class="rememberDiv"><input type="checkbox" name="remember-me" id="remember-me" value="y"> Remember me </div>
        </form>
    </div>
    <script>
    function login(){

        var id = Ext.get('login-id').getValue();
        var pw = Ext.get('login-pw').getValue();
        var remember = Ext.get('remember-me');

        if(remember.dom.checked){

            Ext.util.Cookies.set('rememberInfo', Ext.encode({
                'login-id' : id,
                'login-pw' : pw
            }));
        }
        else {

            Ext.util.Cookies.set('rememberInfo', '');
        }

        Ext.Ajax.request({
            url : '/main/login/action',
            type : 'json',
            params : {
                'login-id':id,
                'login-pw':pw
            },
            async: false,
            success: function(response) {

                var res = Ext.JSON.decode(response.responseText);

                if(res.result == "success"){

                    document.location.reload();
                }
                else {
                    alert(res.message);
                }                
            }
        });

        return false;
    }
    Ext.onReady(function(){

        var frm = Ext.get('frm-login'),
            remember = Ext.get('remember-me');
        
        frm.on('submit', login, frm, {
            stopEvent : true
        });

        var rememberVal = Ext.util.Cookies.get('rememberInfo');

        if(rememberVal){

            var rememberObj = Ext.decode(rememberVal);

            Ext.get('login-id').dom.value = rememberObj['login-id'];
            Ext.get('login-pw').dom.value = rememberObj['login-pw'];
            remember.dom.checked = true;
        }

    });
    </script>
</body>
</html>