<!DOCTYPE HTML>
<head>
    <title>J-Scan</title>   
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="stylesheet" type="text/css" href="/extjs/resources/css/ext-all-gray.css"/>
    <link rel="stylesheet" href="/js/codemirror/codemirror.css"/>
    <script type="text/javascript" src="/extjs/ext-all-debug.js"></script>
    <script type="text/javascript" src="/web/app.js"></script>
    <style>

        .CodeMirror {
            border-top: 1px solid #eee;
            border-bottom: 1px solid #eee;
            height: auto;
        }
        .CodeMirror-scroll {
            overflow-y: hidden;
            overflow-x: auto;
        }

        .btn {
            border-color: #9d9d9d;
            background-image: none;
            background-color: #f3f3f3;
            background-image: -webkit-gradient(linear, 50% 0%, 50% 100%, color-stop(0%, #fbfbfb), color-stop(100%, #e9e9e9));
            background-image: -webkit-linear-gradient(top, #fbfbfb, #e9e9e9);
            background-image: -moz-linear-gradient(top, #fbfbfb, #e9e9e9);
            background-image: -o-linear-gradient(top, #fbfbfb, #e9e9e9);
            background-image: linear-gradient(top, #fbfbfb, #e9e9e9);
        }

        .hangul .x-btn-inner,
        .hangul .x-header-text
        {
            font-size : 13px;
            font-family : dotum;
        }

/*        span {
            font : normal 11px/13px tahoma,arial,verdana,sans-serif;
        }*/
        /*.x-toolbar .x-btn{
          border-color: #9d9d9d;
      }*/

        /*
        <?php 
echo session_id();
 ?>
 */
</style>
</head>
<?php session_id()?>
<body>
</body>
</html>