<!DOCTYPE HTML>
<head>
	<meta charset="UTF-8">
    <title>White SQL - Dashboard</title>  
    <link rel="stylesheet" type="text/css" href="/extjs/resources/css/ext-all-gray.css"/>
    <script type="text/javascript" src="/extjs/ext-all.js"></script>
    <script type="text/javascript" src="/web/controller/monitoring/Dashboard.js"></script>
</head>
<body>
</body>
</html>