<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.1.6 or newer
 *
 * @package		CodeIgniter
 * @author		ExpressionEngine Dev Team
 * @copyright	Copyright (c) 2008 - 2011, EllisLab, Inc.
 * @license		http://codeigniter.com/user_guide/license.html
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * Input Class
 *
 * Pre-processes global input data for security
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 * @category	Input
 * @author		ExpressionEngine Dev Team
 * @link		http://codeigniter.com/user_guide/libraries/input.html
 */
class MY_Input extends CI_Input{


	/**
	 * Constructor
	 *
	 * Sets whether to globally enable the XSS processing
	 * and whether to allow the $_GET array
	 *
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	* Fetch an item from the GET array
	*
	* @access	public
	* @param	string
	* @param	string
	* @param	bool
	* @return	string
	*/
	function get($index = NULL, $default = '', $xss_clean = true)
	{
		$get = parent::get($index, $xss_clean);

		if($index !== NULL && $get == "") $get = $default;
		
		return $get;
	}

	// --------------------------------------------------------------------

	/**
	* Fetch an item from the POST array
	*
	* @access	public
	* @param	string
	* @param	string
	* @param	bool
	* @return	string
	*/
	function post($index = NULL, $default = '', $xss_clean = true)
	{
		$post = parent::post($index, $xss_clean);
		
		if($index !== NULL && $post == "") $post = $default;
		
		return $post;
	}

	function make_add($tbl, $data){

		$CI =& get_instance();
		$CI->load->library('db_table');
		$CI->db_table->make_add($tbl, $data);
	}
}

/* End of file Input.php */
/* Location: ./system/core/Input.php */