<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

/*
 * 인증 클래스
 */
class MY_Loader extends CI_Loader {

	public $_ci_javascript = array();
	public $_ci_stylesheet = array();
	
    public function __construct()
    {
    	parent::__construct();
    }
		
	public function javascript($js){
		
		if(is_array($js) === true){
			
			$this->_ci_javascript = array_merge($this->_ci_javascript, $js);
				
		} else {
			
			array_push($this->_ci_javascript, $js);
		}
	}
	
	public function stylesheet($css){
		
		if(is_array($css) === true){
			
			$this->_ci_stylesheet = array_merge($this->_ci_stylesheet, $css);
				
		} else {
			
			array_push($this->_ci_stylesheet, $css);
		}	
	}
	
	private function add_prefix($model){
		
		if (($last_slash = strrpos($model, '/')) !== FALSE)
		{
			// The path is in front of the last slash
			$path = substr($model, 0, $last_slash + 1);

			// And the model name behind it
			$model = substr($model, $last_slash + 1);
			
			$model = str_replace("model_", "", $model);
			return $path."model_".$model;
		}
		else {
			
			$model = str_replace("model_", "", $model);
			return "model_".$model;
		}
	}
	
	private function sub_prefix($model){
		
		if (($last_slash = strrpos($model, '/')) !== FALSE)
		{
			$model = substr($model, $last_slash + 1);
			
			$model = str_replace("model_", "", $model);
			return $model;
		}
		else {
			
			$model = str_replace("model_", "", $model);
			return $model;
		}
	}

	public function model($model, $name = '', $db_conn = FALSE){
		
		$_org = $model;
		
		if (is_array($model))
		{
			foreach ($model as $idx => $_model)
			{
				parent::model($this->add_prefix($_model), $_model, $db_conn);
			}
		}
		else {

			parent::model($this->add_prefix($model), $this->sub_prefix($model), $db_conn);
		}
		
		return;
	}

	public function controller($controller_path){

		if (!file_exists(APPPATH.'controllers/'.$controller_path.'.php')) {

			show_error("File is not exists ".APPPATH.'controllers/'.$controller_path.'.php');
		}

		include_once(APPPATH.'controllers/'.$controller_path.'.php');		

		$name = strtolower(basename($controller_path));
		$class = ucfirst(basename($controller_path));

		if (isset($CI->$name))
		{
			show_error('The controller name you are loading is the name of a resource that is already being used: '.$name);
		}

		$CI =& get_instance();

		$CI->$name = new $class();

		return;
	}

	/**
	 * Class Loader
	 *
	 * This function lets users load and instantiate classes.
	 * It is designed to be called from a user's app controllers.
	 *
	 * @param	string	the name of the class
	 * @param	mixed	the optional parameters
	 * @param	string	an optional object name
	 * @return	void
	 */
	public function library($library = '', $params = NULL, $object_name = NULL)
	{
		if (is_array($library))
		{
			foreach ($library as $class)
			{
				$this->library($class, $params);
			}

			return;
		}

		if ($library == '' OR isset($this->_base_classes[$library]))
		{
			return FALSE;
		}

		if ( ! is_null($params) && ! is_array($params))
		{
			$params = NULL;
		}

		$static = false;
		if(substr($library, -2) == '::'){

			$library = substr($library, 0, -2);
			$static = true;
		}

		if($static == true){

			$this->_ci_load_static_class($library);
		}
		else {

			$this->_ci_load_class($library, $params, $object_name);
		}
	}

	/**
	 * Load class
	 *
	 * This function loads the requested class.
	 *
	 * @param	string	the item that is being loaded
	 * @param	mixed	any additional parameters
	 * @param	string	an optional object name
	 * @return	void
	 */
	protected function _ci_load_static_class($class)
	{
		// Get the class name, and while we're at it trim any slashes.
		// The directory path can be included as part of the class name,
		// but we don't want a leading slash
		$class = str_replace('.php', '', trim($class, '/'));

		// Was the path included with the class name?
		// We look for a slash to determine this
		$subdir = '';
		if (($last_slash = strrpos($class, '/')) !== FALSE)
		{
			// Extract the path
			$subdir = substr($class, 0, $last_slash + 1);

			// Get the filename from the path
			$class = substr($class, $last_slash + 1);
		}
		
		// We'll test for both lowercase and capitalized versions of the file name
		foreach (array(ucfirst($class), strtolower($class)) as $class)
		{
			

			$subclass = APPPATH.'libraries/'.$subdir.config_item('subclass_prefix').$class.'.php';
			
			// Is this a class extension request?
			if (file_exists($subclass))
			{
				$baseclass = BASEPATH.'libraries/'.ucfirst($class).'.php';

				if ( ! file_exists($baseclass))
				{
					log_message('error', "Unable to load the requested class: ".$class);
					show_error("Unable to load the requested class: ".$class);
				}

				// Safety:  Was the class already loaded by a previous call?
				if (in_array($subclass, $this->_ci_loaded_files))
				{
					$is_duplicate = TRUE;
					log_message('debug', $class." class already loaded. Second attempt ignored.");
					return;
				}

				include_once($baseclass);
				include_once($subclass);
				$this->_ci_loaded_files[] = $subclass;
				return;
			}

			// Lets search for the requested library file and load it.
			$is_duplicate = FALSE;
			foreach ($this->_ci_library_paths as $path)
			{
				$filepath = $path.'libraries/'.$subdir.$class.'.php';

				// Does the file exist?  No?  Bummer...
				if ( ! file_exists($filepath))
				{
					continue;
				}
				
				// Safety:  Was the class already loaded by a previous call?
				if (in_array($filepath, $this->_ci_loaded_files))
				{
					$is_duplicate = TRUE;
					log_message('debug', $class." class already loaded. Second attempt ignored.");
					return;
				}

				include_once($filepath);
				$this->_ci_loaded_files[] = $filepath;
				return;
			}

		} // END FOREACH

		// One last attempt.  Maybe the library is in a subdirectory, but it wasn't specified?
		if ($subdir == '')
		{
			$path = strtolower($class).'/'.$class;
			return $this->_ci_load_static_class($path);
		}

		// If we got this far we were unable to find the requested class.
		// We do not issue errors if the load call failed due to a duplicate request
		if ($is_duplicate == FALSE)
		{
			log_message('error', "Unable to load the requested class: ".$class);
			show_error("Unable to load the requested class: ".$class);
		}
	}

	/**
	 * Database Loader
	 *
	 * @param	string	the DB credentials
	 * @param	bool	whether to return the DB object
	 * @param	bool	whether to enable active record (this allows us to override the config setting)
	 * @return	object
	 */
	public function database($params = '', $return = FALSE, $active_record = NULL)
	{
		// Grab the super object
		$CI =& get_instance();

		// Do we even need to load the database class?
		if (class_exists('CI_DB') AND $return == FALSE AND $active_record == NULL AND isset($CI->db) AND is_object($CI->db))
		{
			return FALSE;
		}

		require_once(APPPATH.'database/DB.php');

		if ($return === TRUE)
		{
			return DB($params, $active_record);
		}

		// Initialize the db variable.  Needed to prevent
		// reference errors with some configurations
		$CI->db = '';

		// Load the DB class
		$CI->db =& DB($params, $active_record);
	}
}
?>
