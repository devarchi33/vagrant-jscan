<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.1.6 or newer
 *
 * @package		CodeIgniter
 * @author		ExpressionEngine Dev Team
 * @copyright	Copyright (c) 2008 - 2011, EllisLab, Inc.
 * @license		http://codeigniter.com/user_guide/license.html
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * Exceptions Class
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 * @category	Exceptions
 * @author		ExpressionEngine Dev Team
 * @link		http://codeigniter.com/user_guide/libraries/exceptions.html
 */
class MY_Exceptions extends CI_Exceptions {

	/**
	 * Constructor
	 */
	public function __construct()
	{
		parent::__construct();
	}

	// --------------------------------------------------------------------

	/**
	 * General Error Page
	 *
	 * This function takes an error message as input
	 * (either as a string or an array) and displays
	 * it using the specified template.
	 *
	 * @access	private
	 * @param	string	the heading
	 * @param	string	the message
	 * @param	string	the template name
	 * @param 	int		the status code
	 * @return	string
	 */
	function show_error($heading, $message, $template = 'error_general', $status_code = 500)
	{
		$buffer = parent::show_error($heading, $message, $template, $status_code);
		$this->send_error_mail($buffer);
		return $buffer;
	}

	// --------------------------------------------------------------------

	/**
	 * Native PHP error handler
	 *
	 * @access	private
	 * @param	string	the error severity
	 * @param	string	the error string
	 * @param	string	the error filepath
	 * @param	string	the error line number
	 * @return	string
	 */
	function show_php_error($severity, $message, $filepath, $line)
	{
		ob_start();
		
		parent::show_php_error($severity, $message, $filepath, $line);
		
		$buffer = ob_get_contents();
		ob_end_clean();
		
		$this->send_error_mail($buffer);
		
		echo $buffer;
	}

	function send_error_mail($buffer){
		
		//index.php에 ENVIRONMENT 값을 상용화 시점에서 production으로 바꾸면 에러가날때 
		//아래 설정된 개발자들 이메일로 메시지가 간다.
		if(defined('ENVIRONMENT'))
		{
			if(ENVIRONMENT != 'production')
			{
				return;
			}
		}
		
		$CI = &get_instance();
				
		$CI->load->library('email');
		
		$CI->email->to(array( //수신자
			"이정원"=>"jwlee@nasmedia.co.kr",
		    "기충빈"=>"cbkee@nasmedia.co.kr",
		    "김수정"=>"sjkim@nasmedia.co.kr"
		));
		$CI->email->subject('[디버깅 메일]ntree2.0 에러 발생');	
		$CI->email->message($buffer);				
		$CI->email->send();
	}
}
// END Exceptions Class

/* End of file Exceptions.php */
/* Location: ./system/core/Exceptions.php */