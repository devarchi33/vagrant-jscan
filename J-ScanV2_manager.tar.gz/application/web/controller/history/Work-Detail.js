Ext.define('WhiteSQL.controller.history.Work-Detail', {
    extend: 'Ext.app.Controller',

    initWindow : function(his_id){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id+'-detail',
            renderTo : this.tabId,
            title : 'Work History 상세내용',
            width : 900,
            height: 400,
            items : [
                this.initView(his_id)
            ]
        });
    },

    initView : function(his_id){

        var data = {};
        Ext.Ajax.request({
            url: '/history/work/getGridData/'+his_id,
            type : 'json',
            async:false,
            scope : this,
            success: function(res){

                var result = Ext.JSON.decode(res.responseText);
                if(result.list[0]) data = result.list[0];
            }
        });

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'vbox',
            width : '100%',
            height: '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 0',
            defaults : {
                labelWidth: 80,
                width : '100%',
                anchor : '100%'
            },
            items:[
                {
                    xtype : 'displayfield',
                    fieldLabel: '작업일시',
                    value : data.work_time
                },
                {
                    xtype : 'displayfield',
                    fieldLabel: '호스트명',
                    value : data.agent_name
                },
                {
                    xtype : 'displayfield',
                    fieldLabel: '정책유형',
                    value : data.work_type
                },
                {
                    xtype : 'displayfield',
                    fieldLabel: '작업자명',
                    value : data.user_name
                },
                {
                    xtype : 'fieldset',
                    title: '메시지',
                    height : 100,
                    padding : 10,
                    html : data.work_message
                }
                // {
                //     xtype : 'fieldset',
                //     title: '변경전',
                //     height : 150,
                //     padding : 10,
                //     html : data.work_before,
                //     hidden : (data.work_type == 'Mod' ? false : true)
                // },
                // {
                //     xtype : 'fieldset',
                //     title: '변경후',
                //     height : 150,
                //     padding : 10,
                //     html : data.work_after,
                //     hidden : (data.work_type == 'Mod' ? false : true)
                // }
            ]
        };

        return form;
    }
});