Ext.define('WhiteSQL.controller.history.Policy-Detail', {
    extend: 'Ext.app.Controller',

    initWindow : function(log_id){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id+'-detail',
            application : this.application,
            title : 'Policy History 상세내용',
            width : 900,
            height: 800,
            items : [
                this.initView(log_id)
            ]
        });
    },

    initView : function(log_id){

        var data = {};
        Ext.Ajax.request({
            url    : '/history/policy/getGridData/'+log_id,
            type   : 'json',
            async  :false,
            scope  : this,
            success: function(res){

                var result = Ext.JSON.decode(res.responseText);
                data = result.list[0];
            }
        });

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'vbox',
            width : '100%',
            height: '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 0',
            defaults : {
                labelWidth: 80,
                width : '100%',
                anchor : '100%'
            },
            items:[
                {
                    xtype : 'displayfield',
                    fieldLabel: '작업일시',
                    value : data.work_time
                },
                {
                    xtype : 'displayfield',
                    fieldLabel: '서버',
                    value : data.agent_name
                },
                {
                    xtype : 'displayfield',
                    fieldLabel: '정책유형',
                    value : data.policy_type
                },
                {
                    xtype : 'displayfield',
                    fieldLabel: '작업자명',
                    value : data.user_name
                },
                {
                    xtype : 'fieldset',
                    title: '메시지',
                    height : 100,
                    padding : 10,
                    html : data.work_message
                },
                {
                    xtype : 'fieldset',
                    title: '변경전',
                    height : 150,
                    padding : 10,
                    html : data.work_before,
                    hidden : (data.work_type == 'mod' ? false : true)
                },
                {
                    xtype : 'fieldset',
                    title: '변경후',
                    height : 150,
                    padding : 10,
                    html : data.work_after,
                    hidden : (data.work_type == 'mod' ? false : true)
                }
            ]
        };

        return form;
    }
});