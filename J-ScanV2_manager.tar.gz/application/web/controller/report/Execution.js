Ext.define('WhiteSQL.controller.report.Execution', {
    extend: 'Lib.TabController',
    grid : {},
    /**
     *
     * 탭 생성
     *
     * @return component Ext.container.Container
     */
    initTab : function(){

        Ext.syncRequire('WhiteSQL.chart.theme.ThemeGray');

        this.setTab(Ext.create('Lib.Tab', {
            id : this.getTabId(),
            title : '보고서 - 쿼리 수행수',
            items : [
                this.initSearch(),
                this.initMainContainer()
            ]
        }));

        // var task = {
        //     scope : this,
        //     run: function(){

        //         this.loadData();
        //     },
        //     interval: 1000 //1 second
        // };
        // Ext.TaskManager.start(task);
    },

    initMainContainer : function(){

        return {
            id : 'report-execution-panel-container',
            width : '100%',
            flex : 1,
            xtype : 'container',
            autoScroll : true,
            layout: {
                type: 'table',
                columns: 2,
                tableAttrs: {
                    style: {
                        width: '100%'
                    }
                },
                tdAttrs: {
                   style:{
                       width: '50%'
                   }
                }
            },
            defaults : {
                xtype : 'panel',
                layout : 'fit',
                margin : '5 5 0 0',
                cls : 'hangul',
                height : 300,
                tools: [{
                    scope : this,
                    type:'save',
                    tooltip: '이미지로 저장',
                    handler : function(event, toolEl, panelHeader, btn){

                        var chart = btn.up('panel').down('chart');
                        chart.save({
                             type: 'image/png'
                        });
                    }
                },
                {
                    scope : this,
                    type:'maximize',
                    handler: function(event, toolEl, owner, tool){

                        var container = Ext.getCmp("report-execution-panel-container");
                        var panel = owner.up("panel");

                        if(tool.type == 'maximize'){

                            var panels = container.query('>panel');
                            Ext.invoke(panels, 'hide');
                            panel.setWidth(container.getWidth() - 30);
                            panel.setHeight(container.getHeight() - 5);
                            panel.show();

                            tool.setType('restore');
                        }
                        else {

                            var panels = container.query('>panel');
                            Ext.invoke(panels, 'restoreSize');
                            Ext.invoke(panels, 'show');
                            tool.setType('maximize');
                        }
                    }
                }],
                listeners : {
                    boxready : function(panel){

                        var width = panel.getWidth();
                        var height = panel.getHeight();

                        Ext.applyIf(panel, {
                            originalWidth : width,
                            originalHeight : height,
                            restoreSize : function(){

                                this.setWidth(this.originalWidth);
                                this.setHeight(this.originalHeight);
                            }
                        });
                    }
                }
            },
            listeners : {
                scope : this,
                boxready : function(container){

                    this.initMainPanels(container);

                    var viewport = Ext.getCmp('WhiteSQL-Layout');
                    viewport.doLayout();

                }
            }
        };
    },

    initMainPanels : function(container){

        container.add([{
            title:'일자별 쿼리수행수',
            height : 400,
            items : this.initChart('Date')
        },{
            title:'일별 쿼리수행수',
            margin : '5 0 0 0',
            height : 400,
            items : this.initChart('Daily')
        },{
            title:'요일별 쿼리수행수',
            height : 400,
            items : this.initChart('Weekly')
        },{
            title:'시간대별 쿼리수행수',
            height : 400,
            margin : '5 0 0 0',
            items : this.initChart('Hourly')
        },{
            title:'IP별 쿼리수행수',
            height : 400,
            items : this.initGrid('IP'),
            tools: [{
                scope : this,
                type:'save',
                tooltip: '엑셀로 저장',
                handler : function(event, toolEl, panelHeader, btn){

                    var grid = btn.up('panel').down('grid');
                    grid.save();
                }
            },
            {
                scope : this,
                type:'maximize',
                handler: function(event, toolEl, owner, tool){

                    var container = Ext.getCmp("report-execution-panel-container");
                    var panel = owner.up("panel");

                    if(tool.type == 'maximize'){

                        var panels = container.query('>panel');
                        Ext.invoke(panels, 'hide');
                        panel.setWidth(container.getWidth() - 30);
                        panel.setHeight(container.getHeight() - 5);
                        panel.show();

                        tool.setType('restore');
                    }
                    else {

                        var panels = container.query('>panel');
                        Ext.invoke(panels, 'restoreSize');
                        Ext.invoke(panels, 'show');
                        tool.setType('maximize');
                    }
                }
            }]
        },{
            title:'LoginID별 쿼리수행수',
            margin : '5 0 0 0',
            height : 400,
            items : this.initGrid('LoginID'),
            tools: [{
                scope : this,
                type:'save',
                tooltip: '엑셀로 저장',
                handler : function(event, toolEl, panelHeader, btn){

                    var grid = btn.up('panel').down('grid');
                    grid.save();
                }
            },
            {
                scope : this,
                type:'maximize',
                handler: function(event, toolEl, owner, tool){

                    var container = Ext.getCmp("report-execution-panel-container");
                    var panel = owner.up("panel");

                    if(tool.type == 'maximize'){

                        var panels = container.query('>panel');
                        Ext.invoke(panels, 'hide');
                        panel.setWidth(container.getWidth() - 30);
                        panel.setHeight(container.getHeight() - 5);
                        panel.show();

                        tool.setType('restore');
                    }
                    else {

                        var panels = container.query('>panel');
                        Ext.invoke(panels, 'restoreSize');
                        Ext.invoke(panels, 'show');
                        tool.setType('maximize');
                    }
                }
            }]
        }]);

        this.initChartTip(container);
    },

    initChart: function(mode){

        var chart = {
            xtype : 'chart',
            background: {
                //color string
                fill: '#ffffff'
            },
            animate : true,
            shadow  : false,
            store: Ext.create('Ext.data.Store',{
                proxy: {
                    type: 'ajax',
                    url: '/report/summary/get'+mode+'ExecutionData',
                    extraParams : {
                        'server' : WhiteSQL.app.serverId
                    },
                    reader: {
                        type: 'json',
                        root: 'users'
                    }
                },
                fields: [
                    {name : 'date', type : 'string'},
                    {name : 'value', type : 'int'}
                ],
                autoLoad : true
            }),
            theme : 'ThemeGray',
            axes: [{
                type: 'Numeric',
                position: 'left',
                fields: ['value'],
                label: {
                    renderer: Ext.util.Format.numberRenderer('0,0')
                },
                title: false,
                grid: true,
                minimum: 0,
                majorTickSteps : 5,
                minorTickSteps : 1
            }, {
                type: 'Category',
                position: 'bottom',
                fields: ['date'],
                title: false,
                label:{
                    renderer: this['renderCategory'+mode]
                }
            }],
            series: [{
                type: 'column',
                axis: 'left',
                highlight: true,
                tips: {
                    width: 150,
                    trackMouse: true,
                    renderer: function(storeItem, item) {
                        this.setTitle(storeItem.get('date') + ' : ' + storeItem.get('value'));
                    }
                },
                xField: 'date',
                yField: 'value'
            }]
        };

        return chart;
    },

    initChartTip : function(container){

        var grids = container.query('grid');
        Ext.Array.each(grids, function(grid, key){

            var view = grid.getView();
            
            var tip = Ext.create('Ext.tip.ToolTip', {
                // The overall target element.
                target: view.el,
                // Each grid row causes its own separate show and hide.
                delegate: view.itemSelector,
                // Moving within the row should not hide the tip.
                trackMouse: true,
                // Render immediately so that tip.body can be referenced prior to the first show.
                renderTo: Ext.getBody(),
                layout : 'hbox',
                items : [
                    {
                        xtype : 'chart',
                        width: 150,
                        height: 150,
                        animate: false,
                        margin : '0 5 0 0',
                        store: Ext.create('Ext.data.Store', {
                            fields: ['name', 'value']
                        }),
                        shadow: false,
                        insetPadding: 0,
                        theme: 'Base:gradients',
                        series: [{
                            type: 'pie',
                            field: 'value',
                            showInLegend: false,
                            label: {
                                field: 'name',
                                display: 'rotate',
                                contrast: true,
                                font: '12px Arial'
                            }
                        }]
                    },
                    {
                        xtype : 'grid',
                        store: Ext.create('Ext.data.Store', {
                            fields: ['name', 'value']
                        }),
                        columns: [
                            { text: '속성',  dataIndex: 'name', width : 50},
                            { text: '값', dataIndex: 'value', flex: 1 }
                        ],
                        height: 150,
                        width: 400
                    }
                ],
                listeners: {
                    // Change content dynamically depending on which element triggered the show.
                    beforeshow: function updateTipBody(tip) {

                        var el = tip.triggerElement;
                        var record = view.getRecord(el);

                        var tmp = {};
                        Ext.Array.each(grid.columns, function(row, key){

                            tmp[row.dataIndex] = row.text;
                        });

                        var data = [];
                        Ext.Object.each(record.data, function(key, val){

                            if(['view', 'add', 'mod', 'del', 'etc'].indexOf(key) > -1){

                                data.push({ name : tmp[key], value : val });
                            }
                        });

                        var tipChart = tip.down('chart');
                        tipChart.store.loadData(data);

                        var tipGrid = tip.down('grid');                        
                        tipGrid.store.loadData(data);
                    }
                }
            });
        }, this);
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */ 
    initGrid : function(mode){

        var columns = this['make'+mode+'GridColumns']();

        var grid = Ext.create('Lib.Grid', {
            frame : false,
            columns : columns,
            remoteSort : false
        });

        this.grid[mode] = grid;

        this.loadGridData(mode);

        return grid;
    },

    loadGridData : function(mode){

        Ext.Ajax.request({
            url: '/report/summary/get'+mode+'GridData',
            type : 'json',
            method : 'get',
            params: {
                'server' : WhiteSQL.app.serverId,
                'fdate' : Ext.getCmp(this.id + '-fdate').getValue(),
                'tdate' : Ext.getCmp(this.id + '-tdate').getValue()
            },
            scope : this,
            success: function(res){

                var result = Ext.JSON.decode(res.responseText);
                this.grid[mode].store.loadData(result);
            }
        });
    },

    /**
     * initSearch
     *
     * 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initSearch : function(){

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'hbox',
            frame : true,
            width : '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 5 5',
            defaults : {
                labelWidth: 80,
                margin : '0 10 0 0'
            },
            items : [
                {
                    xtype       : 'displayfield',
                    id          : 'server-name-'+this.getTabId(),
                    fieldLabel  : "서버",
                    fieldBodyCls: "align-top",
                    width       : 200,
                    value       : this.application.getServerName()
                },
                {
                    xtype       : 'displayfield',
                    fieldLabel  : "기간",
                    fieldBodyCls: "align-top",
                    width       : 80
                },
                {
                    xtype: 'datefield',
                    format: 'Y-m-d',
                    id : this.id+'-fdate',
                    name : this.id+'-fdate',
                    editable : false,
                    width: 120,
                    value  : Ext.Date.subtract(new Date(), Ext.Date.MONTH, 1)

                },
                {
                    xtype: 'datefield',
                    format: 'Y-m-d',
                    id : this.id+'-tdate',
                    name : this.id+'-tdate',
                    editable : false,
                    width: 120,
                    value  : new Date()
                },
                {
                    xtype:'button',
                    icon : '/images/find.png',
                    text: '검색',
                    scope : this,
                    handler : this.search
                }
            ]
        };
        return form;
    },

    renderCategoryDate : function(val){

        return val;
    },  

    renderCategoryDaily : function(val){

        return val + '일';
    },  

    renderCategoryWeekly : function(val){

        return val;
    }, 

    renderCategoryHourly : function(val){

        return val + '-' + (parseInt(val, 10) + 1);
    }, 

    /**
     * initComboBox
     *
     * 콤보박스 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initComboBox : function(label, mode){

        var store = new Ext.data.Store({
            proxy: {
                type  : 'ajax',
                url: '/history/policy/get'+mode+'List',
                reader: {
                    type: 'json'
                }
            },
            fields: ['id','text']
        });

        // Simple ComboBox using the data store
        var combo = Ext.create('Ext.form.ComboBox', {
            name : this.id+'-'+mode,
            fieldLabel: label,
            emptyText : '선택',
            value: '',
            displayField : 'text',
            valueField: 'id',
            labelWidth: 80,
            store: store,
            typeAhead: true
        });

        return combo;
    },

    search : function(){

        var fdate = Ext.getCmp(this.id+'-fdate');
        var tdate = Ext.getCmp(this.id+'-tdate');
        var fdate_val = fdate.getValue();
        var tdate_val = tdate.getValue();

        if((fdate_val && tdate_val) && fdate_val.getTime() > tdate_val.getTime()){

            fdate.setValue(tdate_val);
            tdate.setValue(fdate_val);
        }        

        var params = Ext.getCmp('form-'+this.id).getValues();
        var tmp = {};
        Ext.Object.each(params, function(k, v){ 
            k = k.replace(this.id+'-', '');
            tmp[k] = v;
        }, this);
        params = tmp;

        var panels = this.getTab().query('grid, chart');

        Ext.Array.each(panels, function(panel, key){

            this.getApplication().fireEvent('grid-search', panel, params);        

            this.loadGridData('IP');
            this.loadGridData('LoginID');
            

        }, this);
    },

    /**
     * makeIPGridColumns
     *
     * Privacy SQL 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeIPGridColumns : function(){

        return [
            { text: 'IP',  dataIndex: 'ip', flex: 1, sortable: true, menuDisabled : true, draggable : false },
            { text: '수행건수', dataIndex: 'cnt', sortable: true, menuDisabled : true, draggable : false },
            { text: '조회', dataIndex: 'view', sortable: true, menuDisabled : true, draggable : false },
            { text: '추가', dataIndex: 'add', sortable: true, menuDisabled : true, draggable : false },
            { text: '수정', dataIndex: 'mod', sortable: true, menuDisabled : true, draggable : false },
            { text: '삭제', dataIndex: 'del', sortable: true, menuDisabled : true, draggable : false },
            { text: '기타', dataIndex: 'etc', sortable: true, menuDisabled : true, draggable : false }
        ];
    },

    /**
     * makeLoginIDGridColumns
     *
     * Privacy SQL 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeLoginIDGridColumns : function(){

        return [
            { text: 'ID',  dataIndex: 'login_id', flex: 1, sortable: true, menuDisabled : true, draggable : false },
            { text: '수행건수', dataIndex: 'cnt', sortable: true, menuDisabled : true, draggable : false },
            { text: '조회', dataIndex: 'view', sortable: true, menuDisabled : true, draggable : false },
            { text: '추가', dataIndex: 'add', sortable: true, menuDisabled : true, draggable : false },
            { text: '수정', dataIndex: 'mod', sortable: true, menuDisabled : true, draggable : false },
            { text: '삭제', dataIndex: 'del', sortable: true, menuDisabled : true, draggable : false },
            { text: '기타', dataIndex: 'etc', sortable: true, menuDisabled : true, draggable : false }
        ];
    }
});