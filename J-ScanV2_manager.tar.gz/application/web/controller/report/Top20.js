Ext.define('WhiteSQL.controller.report.Top20', {
    extend: 'Lib.TabController',

    /**
     *
     * 탭 생성
     *
     * @return component Ext.container.Container
     */
    initTab : function(){

        this.setTab(Ext.create('Lib.Tab', {
            id : this.getTabId(),
            layout : 'vbox',
            title : '보고서 - Top 20',
            items : [
                this.initSearch(),
                this.initGrid('쿼리 수행 건수 Top 20', 'QueryExecute'),
                this.initGrid('데이터 조회 결과 건수 Top 20', 'ResultCount')
            ]
        }));
    },

    /**
     * initSearch
     *
     * 그리드 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initSearch : function(){

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'hbox',
            frame : true,
            width : '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 5 5',
            defaults : {
                labelWidth: 80,
                margin : '0 10 0 0'
            },
            items : [
                {
                    xtype       : 'displayfield',
                    id          : 'server-name-'+this.getTabId(),
                    fieldLabel  : "서버",
                    fieldBodyCls: "align-top",
                    width       : 200,
                    value       : this.application.getServerName()
                },
                {
                    xtype       : 'displayfield',
                    fieldLabel  : "기간",
                    fieldBodyCls: "align-top",
                    width       : 80
                },
                {
                    xtype: 'datefield',
                    format: 'Y-m-d',
                    id : this.id+'-fdate',
                    name : this.id+'-fdate',
                    editable : false,
                    width: 120,
                    value  : Ext.Date.subtract(new Date(), Ext.Date.MONTH, 1)

                },
                {
                    xtype: 'datefield',
                    format: 'Y-m-d',
                    id : this.id+'-tdate',
                    name : this.id+'-tdate',
                    editable : false,
                    width: 120,
                    value  : new Date()
                },
                {
                    xtype:'button',
                    icon : '/images/find.png',
                    text: '검색',
                    scope : this,
                    handler : this.search
                }
                // {
                //     xtype: 'button',
                //     text  : '보고서 선택'
                // },
                // {
                //     xtype: 'button',
                //     text  : '파일로 저장'
                // },
            ]
        };
        return form;
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */ 
    initGrid : function(title, mode){

        var columns = this['make'+mode+'GridColumns']();

        var grid = Ext.create('Lib.Grid', {
            id        : 'grid-'+mode+'-'+this.id,
            url       : '/report/summary/get'+mode+'Top20',
            title     : title,
            columns   : columns,
            remoteSort : false,
            flex      : 1,
            tools: [{
                scope : this,
                type:'save',
                tooltip: '엑셀로 저장',
                handler : function(event, toolEl, panelHeader, btn){

                    var grid = btn.up('grid');
                    Lib.Excel.download(grid);
                }
            },{
                scope : this,
                type:'maximize',
                handler: this.maximizePanel
            }]
        });

        return grid;
    },

    maximizePanel : function(event, toolEl, owner, tool){
                    
        var panel = owner.up("panel");
        var tab = panel.up('container');

        if(tool.type == 'maximize'){

            Ext.invoke(tab.query('>panel'), 'hide');

            panel.setWidth(tab.getWidth() - 10);
            panel.setHeight(tab.getHeight() - 10);
            panel.setPosition(5, 5);
            panel.show();

            tool.setType('restore');
        }
        else {

            var panels = tab.query('>panel');
            Ext.invoke(tab.query('>panel'), 'show');

            tool.setType('maximize');   
        }
    },

    search : function(){

        var fdate = Ext.getCmp(this.id+'-fdate');
        var tdate = Ext.getCmp(this.id+'-tdate');
        var fdate_val = fdate.getValue();
        var tdate_val = tdate.getValue();

        if((fdate_val && tdate_val) && fdate_val.getTime() > tdate_val.getTime()){

            fdate.setValue(tdate_val);
            tdate.setValue(fdate_val);
        }        

        var params = Ext.getCmp('form-'+this.id).getValues();     

        var grids = this.tab.query('grid');   
        Ext.each(grids, function(grid, idx){ 

            this.getApplication().fireEvent('grid-search', grid, params);
        }, this);
        //var grid   = Ext.getCmp('grid-'+this.id);

        //
    },

    /**
     * makeExcutionGridColumns
     *
     * Privacy SQL 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeQueryExecuteGridColumns : function(){

        return [
            { text: 'IP',  dataIndex: 'ipaddr', width : 115, sortable: true, menuDisabled : true },
            { text: 'LOGIN ID', dataIndex: 'login_id', sortable: true, menuDisabled : true  },
            { text: '쿼리', dataIndex: 'sql_str', flex: 1, sortable: true, menuDisabled : true  },
            { text: '수행건수', dataIndex: 'cnt', sortable: true, menuDisabled : true  }
        ];
    },

    /**
     * makeResultCountGridColumns
     *
     * Privacy SQL 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeResultCountGridColumns : function(){

        return [
            { text: 'IP',  dataIndex: 'ipaddr', width : 115, sortable: true, menuDisabled : true },
            { text: 'LOGIN ID', dataIndex: 'login_id', sortable: true, menuDisabled : true  },
            { text: '쿼리', dataIndex: 'sql_str', flex: 1, sortable: true, menuDisabled : true  },
            { text: '결과건수', dataIndex: 'cnt', sortable: true, menuDisabled : true  }
        ];
    }
});