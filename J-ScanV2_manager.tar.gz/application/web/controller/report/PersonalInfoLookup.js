Ext.define('WhiteSQL.controller.report.PersonalInfoLookup', {
    extend: 'Lib.TabController',
    grid : {},
    chart : {},
    /**
     *
     * 탭 생성
     *
     * @return component Ext.container.Container
     */
    initTab : function(){

        Ext.syncRequire('WhiteSQL.chart.theme.ThemeGray');

        var me = this;
        this.setTab(Ext.create('Lib.Tab', {
            id : this.getTabId(),
            title : '보고서 - 개인 정보 조회 보고서',
            items : [
                this.initSearch(),
                this.initMainContainer()
            ]
        }));
    },

    initMainContainer : function(){

        return {
            id : 'report-cumulative-total-panel-container',
            width : '100%',
            flex : 1,
            xtype : 'container',
            autoScroll : true,
            layout: {
                type: 'table',
                columns: 4,
                tableAttrs: {
                    style: {
                        width: '100%'
                    }
                },
                tdAttrs: {
                   style:{
                       width: '25%'
                   }
                }
            },
            defaults : {
                xtype : 'panel',
                layout : 'fit',
                margin : '5 5 0 0',
                cls : 'hangul',
                height : 300,
                tools: [{
                    scope : this,
                    type:'save',
                    tooltip: '이미지로 저장',
                    handler : function(event, toolEl, panelHeader, btn){

                        var chart = btn.up('panel').down('chart');
                        chart.save({
                             type: 'image/png'
                        });
                    }
                },
                {
                    scope : this,
                    type:'maximize',
                    handler: function(event, toolEl, owner, tool){

                        var container = Ext.getCmp("report-cumulative-total-panel-container");
                        var panel = owner.up("panel");

                        if(tool.type == 'maximize'){

                            var panels = container.query('>panel');
                            Ext.invoke(panels, 'hide');
                            panel.setWidth(container.getWidth() - 30);
                            panel.setHeight(container.getHeight() - 5);
                            panel.show();

                            tool.setType('restore');
                        }
                        else {

                            var panels = container.query('>panel');
                            Ext.invoke(panels, 'restoreSize');
                            Ext.invoke(panels, 'show');
                            tool.setType('maximize');
                        }
                    }
                }],
                listeners : {
                    boxready : function(panel){

                        var width = panel.getWidth();
                        var height = panel.getHeight();

                        Ext.applyIf(panel, {
                            originalWidth : width,
                            originalHeight : height,
                            restoreSize : function(){

                                this.setWidth(this.originalWidth);
                                this.setHeight(this.originalHeight);
                            }
                        });
                    }
                }
            },
            listeners : {
                scope : this,
                boxready : function(container){

                    this.initMainPanels(container);

                    var viewport = Ext.getCmp('WhiteSQL-Layout');
                    viewport.doLayout();

                }
            }
        };
    },

    initMainPanels : function(container){

        container.add([{
            title:'IP별 조회 누적 총량',
            height : 400,
            items : this.initGrid('IPQuantity'),
            tools: [{
                scope : this,
                type:'save',
                tooltip: '엑셀로 저장',
                handler : function(event, toolEl, panelHeader, btn){

                    var grid = btn.up('panel').down('grid');
                    grid.save();
                }
            },
            {
                scope : this,
                type:'maximize',
                handler: function(event, toolEl, owner, tool){

                    var container = Ext.getCmp("report-cumulative-total-panel-container");
                    var panel = owner.up("panel");

                    if(tool.type == 'maximize'){

                        var panels = container.query('>panel');
                        Ext.invoke(panels, 'hide');
                        panel.setWidth(container.getWidth() - 30);
                        panel.setHeight(container.getHeight() - 5);
                        panel.show();

                        tool.setType('restore');
                    }
                    else {

                        var panels = container.query('>panel');
                        Ext.invoke(panels, 'restoreSize');
                        Ext.invoke(panels, 'show');
                        tool.setType('maximize');
                    }
                }
            }]
        },{
            title:'IP별 조회 누적 총량',
            margin : '5 5 0 0',
            height : 400,
            items : this.initChart('IPQuantity')
        },{
            title:'LoginID별 조회 누적 총량',
            height : 400,
            items : this.initGrid('LoginIDQuantity'),
            tools: [{
                scope : this,
                type:'save',
                tooltip: '엑셀로 저장',
                handler : function(event, toolEl, panelHeader, btn){

                    var grid = btn.up('panel').down('grid');
                    grid.save();
                }
            },
            {
                scope : this,
                type:'maximize',
                handler: function(event, toolEl, owner, tool){

                    var container = Ext.getCmp("report-cumulative-total-panel-container");
                    var panel = owner.up("panel");

                    if(tool.type == 'maximize'){

                        var panels = container.query('>panel');
                        Ext.invoke(panels, 'hide');
                        panel.setWidth(container.getWidth() - 30);
                        panel.setHeight(container.getHeight() - 5);
                        panel.show();

                        tool.setType('restore');
                    }
                    else {

                        var panels = container.query('>panel');
                        Ext.invoke(panels, 'restoreSize');
                        Ext.invoke(panels, 'show');
                        tool.setType('maximize');
                    }
                }
            }]
        },{
            title:'LoginID별 조회 누적 총량',
            margin : '5 0 0 0',
            height : 400,
            items : this.initChart('LoginIDQuantity')
        },{
            title:'IP별 조회 누적 횟수',
            height : 400,
            items : this.initGrid('IPCount'),
            tools: [{
                scope : this,
                type:'save',
                tooltip: '엑셀로 저장',
                handler : function(event, toolEl, panelHeader, btn){

                    var grid = btn.up('panel').down('grid');
                    grid.save();
                }
            },
            {
                scope : this,
                type:'maximize',
                handler: function(event, toolEl, owner, tool){

                    var container = Ext.getCmp("report-cumulative-total-panel-container");
                    var panel = owner.up("panel");

                    if(tool.type == 'maximize'){

                        var panels = container.query('>panel');
                        Ext.invoke(panels, 'hide');
                        panel.setWidth(container.getWidth() - 30);
                        panel.setHeight(container.getHeight() - 5);
                        panel.show();

                        tool.setType('restore');
                    }
                    else {

                        var panels = container.query('>panel');
                        Ext.invoke(panels, 'restoreSize');
                        Ext.invoke(panels, 'show');
                        tool.setType('maximize');
                    }
                }
            }]
        },{
            title:'IP별 조회 누적 횟수',
            margin : '5 5 0 0',
            height : 400,
            items : this.initChart('IPCount')
        },{
            title:'LoginID별 조회 누적 횟수',
            height : 400,
            items : this.initGrid('LoginIDCount'),
            tools: [{
                scope : this,
                type:'save',
                tooltip: '엑셀로 저장',
                handler : function(event, toolEl, panelHeader, btn){

                    var grid = btn.up('panel').down('grid');
                    grid.save();
                }
            },
            {
                scope : this,
                type:'maximize',
                handler: function(event, toolEl, owner, tool){

                    var container = Ext.getCmp("report-cumulative-total-panel-container");
                    var panel = owner.up("panel");

                    if(tool.type == 'maximize'){

                        var panels = container.query('>panel');
                        Ext.invoke(panels, 'hide');
                        panel.setWidth(container.getWidth() - 30);
                        panel.setHeight(container.getHeight() - 5);
                        panel.show();

                        tool.setType('restore');
                    }
                    else {

                        var panels = container.query('>panel');
                        Ext.invoke(panels, 'restoreSize');
                        Ext.invoke(panels, 'show');
                        tool.setType('maximize');
                    }
                }
            }]
        },{
            title:'LoginID별 조회 누적 횟수',
            margin : '5 0 0 0',
            height : 400,
            items : this.initChart('LoginIDCount')
        }]);
    },

    initChart : function(mode){

        if(mode == 'IPQuantity' || mode == 'IPCount'){

            var columns = { 'ip' : 'IP' },
                 xField = [ 'ip' ];
        }
        else if(mode == 'LoginIDQuantity' || mode == 'LoginIDCount'){

            var columns = { 'login_id' : 'Login ID' },
                 xField = [ 'login_id' ];
        }

        var yField = [],
            yTitle = [];

        var chart = Ext.create('Ext.chart.Chart', {
            width   : '100%',
            height  : '100%',
            animate : true,
            shadow  : true,
            theme   : 'ThemeGray',
            style   : 'background : #ffffff',
            store   : Ext.create('Ext.data.Store',{
                fields: [
                    {name : xField[0], type : 'string'}
                ]
            }),
            legend: false,
            series : [{
                type     : 'bar',
                xField   : xField,                
                yField   : yField,
                title    : yTitle,
                column   : true,
                stacked  : true,
                renderer : function (sprite, record, attributes, index, store) {
                    
                    var max_width = 25;
                    if(attributes.width > max_width){

                        return Ext.apply(attributes, {
                            x     : (attributes.x + (attributes.width / 2)) - (max_width / 2),
                            width : max_width,
                            value : '_'
                        });
                    }
                    else {

                        return attributes;
                    }
                },
                label: {
                    display: 'outside',
                    stackedDisplay : 'total',
                    'text-anchor': 'middle',
                    field : yField,
                    renderer: Ext.util.Format.numberRenderer('0'),
                    color: '#333'
                },
                tips: {
                    trackMouse: true,
                    width: 200,
                    renderer: function(storeItem, item) {

                        var series = item.series,
                            index = series.yField.indexOf(item.yField);
                            agent_name = series.title[index];

                        this.setTitle(item.value[0] + "(" + agent_name + ") : " + item.value[1].toString());
                    },
                    listeners : {
                        beforeShow: function(tip) {

                            return !(parseInt(tip.title.split(":")[1],0) < 1);
                        }
                    }
                }
            }],
            axes : [{
                type: 'Numeric',
                position: 'left',
                fields: yField,
                title: false,
                grid: true,
                minimum: 0,
                maximum: 1000,
                majorTickSteps : 4,
                minorTickSteps : 1,
                label: {
                    renderer: function(v) {
                        return Math.round(v);
                    }
                }
            }, {
                type: 'Category',
                position: 'bottom',
                fields: xField,
                minWidth : 200,
                title: false
            }]
        });

        this.chart[mode] = chart;

        return chart;
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */ 
    initGrid : function(mode){

        var columns = this['make'+mode+'GridColumns']();

        var grid = Ext.create('Lib.Grid', {
            url : '/report/summary/get'+mode+'GridData',
            frame : false,
            columns : columns,
            remoteSort : false
        });

        var me = this;
        me.grid[mode] = grid;

        grid.store.on('load', function(store, records, successful, eOpts){ 

            var chart = me.chart[mode],
                  cnt = store.getCount();
                 data = [],
                 series = chart.series.getAt(0),
                 axes = chart.axes.getAt(0),
                 xField = series.xField[0]
            ;

            if(cnt == 0){

                return;
            }

            var yField = [], yTitle = [], tmp = {}, fields = [];
            fields.push({name : xField, type : 'string'});
            Ext.Array.each(store.getRange(0, cnt), function(rec, idx){ 

                var row = rec.raw;

                if(yField.indexOf(row.agent_id) == -1){

                    yField.push(row.agent_id);
                    yTitle.push(row.agent_name);

                    fields.push({name : row.agent_id, type : 'int'});
                }

                if(!row[xField]){

                    return;
                }

                tmp[row[xField]] = tmp[row[xField]] || {};
                tmp[row[xField]][row.agent_id] = parseInt(row.value, 10);
            });

            chart.store.model.setFields(fields);

            series.yField = yField;
            series.label.field = yField;
            series.title = yTitle;
            axes.fields = yField;

            var data = [];
            Ext.Object.each(tmp, function(key, row){

                var obj = {};
                obj[xField] = key;
                data.push(Ext.Object.merge(obj, row));
            });

            tmp = null;

            //console.log(data);
            //chart.render();
            //chart.refresh();
            //chart.redraw();

            chart.store.loadData(data);

        }, grid);


        return grid;
    },

    /**
     * initSearch
     *
     * 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initSearch : function(){

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'hbox',
            frame : true,
            width : '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 5 5',
            defaults : {
                labelWidth: 80,
                margin : '0 10 0 0'
            },
            items : [
                {
                    xtype       : 'displayfield',
                    id          : 'server-name-'+this.getTabId(),
                    fieldLabel  : "서버",
                    fieldBodyCls: "align-top",
                    width       : 200,
                    value       : this.application.getServerName()
                },
                {
                    xtype       : 'displayfield',
                    fieldLabel  : "기간",
                    fieldBodyCls: "align-top",
                    width       : 80
                },
                {
                    xtype: 'datefield',
                    format: 'Y-m-d',
                    id : this.id+'-fdate',
                    name : this.id+'-fdate',
                    editable : false,
                    width: 120,
                    value  : Ext.Date.subtract(new Date(), Ext.Date.MONTH, 1)

                },
                {
                    xtype: 'datefield',
                    format: 'Y-m-d',
                    id : this.id+'-tdate',
                    name : this.id+'-tdate',
                    editable : false,
                    width: 120,
                    value  : new Date()
                },
                {
                    xtype : 'textfield',
                    emptyText : '소스IP',
                    id : this.id+'-ip',
                    name : this.id+'-ip'
                },
                {
                    xtype : 'textfield',
                    emptyText : '로그인ID',
                    id : this.id+'-login-id',
                    name : this.id+'-login-id'
                },
                {
                    xtype:'button',
                    icon : '/images/find.png',
                    text: '검색',
                    scope : this,
                    handler : this.search
                }
            ]
        };
        return form;
    },

    renderCategoryDate : function(val){

        return val;
    },  

    renderCategoryDaily : function(val){

        return val + '일';
    },  

    renderCategoryWeekly : function(val){

        return val;
    }, 

    renderCategoryHourly : function(val){

        return val + '-' + (parseInt(val, 10) + 1);
    }, 

    search : function(){

        var fdate = Ext.getCmp(this.id+'-fdate');
        var tdate = Ext.getCmp(this.id+'-tdate');
        var fdate_val = fdate.getValue();
        var tdate_val = tdate.getValue();

        if((fdate_val && tdate_val) && fdate_val.getTime() > tdate_val.getTime()){

            fdate.setValue(tdate_val);
            tdate.setValue(fdate_val);
        }        

        var params = Ext.getCmp('form-'+this.id).getValues();
        var tmp = {};
        Ext.Object.each(params, function(k, v){ 
            k = k.replace(this.id+'-', '');
            tmp[k] = v;
        }, this);
        params = tmp;

        var panels = this.getTab().query('grid');

        Ext.Array.each(panels, function(panel, key){

            this.getApplication().fireEvent('grid-search', panel, params); 

        }, this);
    },

    /**
     * makeIPQuantityGridColumns
     *
     * Privacy SQL 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeIPQuantityGridColumns : function(){

        return [
            { text: '서버',  dataIndex: 'agent_name', flex: 1, sortable: true, menuDisabled : true, draggable : false },
            { text: 'IP',  dataIndex: 'ip', flex: 1, sortable: true, menuDisabled : true, draggable : false },
            { text: '조회 누적 총량',  dataIndex: 'value', flex: 1, sortable: true, menuDisabled : true, draggable : false }
        ];
    },

    /**
     * makeLoginIDQuantityGridColumns
     *
     * Privacy SQL 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeLoginIDQuantityGridColumns : function(){

        return [
            { text: '서버',  dataIndex: 'agent_name', flex: 1, sortable: true, menuDisabled : true, draggable : false },
            { text: 'Login ID',  dataIndex: 'login_id', flex: 1, sortable: true, menuDisabled : true, draggable : false },
            { text: '조회 누적 총량',  dataIndex: 'value', flex: 1, sortable: true, menuDisabled : true, draggable : false }
        ];
    },

    /**
     * makeIPCountGridColumns
     *
     * Privacy SQL 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeIPCountGridColumns : function(){

        return [
            { text: '서버',  dataIndex: 'agent_name', flex: 1, sortable: true, menuDisabled : true, draggable : false },
            { text: 'IP',  dataIndex: 'ip', flex: 1, sortable: true, menuDisabled : true, draggable : false },
            { text: '조회 누적 횟수',  dataIndex: 'value', flex: 1, sortable: true, menuDisabled : true, draggable : false }
        ];
    },

    /**
     * makeLoginIDCountGridColumns
     *
     * Privacy SQL 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeLoginIDCountGridColumns : function(){

        return [
            { text: '서버',  dataIndex: 'agent_name', flex: 1, sortable: true, menuDisabled : true, draggable : false },
            { text: 'Login ID',  dataIndex: 'login_id', flex: 1, sortable: true, menuDisabled : true, draggable : false },
            { text: '조회 누적 횟수',  dataIndex: 'value', flex: 1, sortable: true, menuDisabled : true, draggable : false }
        ];
    }
});