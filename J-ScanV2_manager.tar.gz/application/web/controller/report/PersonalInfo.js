Ext.define('WhiteSQL.controller.report.PersonalInfo', {
    extend: 'Lib.TabController',

    /**
     *
     * 탭 생성
     *
     * @return component Ext.container.Container
     */
    initTab : function(){

        Ext.syncRequire('WhiteSQL.chart.theme.ThemeGray');

        this.setTab(Ext.create('Lib.Tab', {
            id : this.getTabId(),
            layout : 'vbox',
            title : '보고서 - User Report',
            items : [
                this.initSearch(),
                this.initPanel('IP별 개인정보 테이블 접근 수', [
                    this.initChart('PersonalInfo'),
                    this.initGrid('PersonalInfo')
                ]),
                this.initPanel('IP별 일반정보 테이블 접근 수', [
                    this.initChart('ImportantInfo'),
                    this.initGrid('ImportantInfo')
                ]),
            ]
        }));
    },

    /**
     * initSearch
     *
     * 그리드 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initSearch : function(){

        var required = '<span style="color:red;font-weight:bold" data-qtip="Required">*</span>';

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'hbox',
            frame : true,
            width : '100%',
            bodyPadding: '5 5 5 5',
            defaults : {
                labelWidth: 80,
                margin : '0 10 0 0'
            },
            items : [
                {
                    xtype       : 'displayfield',
                    id          : 'server-name-'+this.getTabId(),
                    fieldLabel  : "서버",
                    fieldBodyCls: "align-top",
                    width       : 200,
                    value       : this.application.getServerName()
                },
                {
                    xtype       : 'displayfield',
                    fieldLabel  : "기간",
                    fieldBodyCls: "align-top",
                    width       : 80
                },
                {
                    xtype: 'datefield',
                    format: 'Y-m-d',
                    id : this.id+'-fdate',
                    name : this.id+'-fdate',
                    editable : false,
                    width: 120,
                    value  : Ext.Date.subtract(new Date(), Ext.Date.MONTH, 1)
                },
                {
                    xtype: 'datefield',
                    format: 'Y-m-d',
                    id : this.id+'-tdate',
                    name : this.id+'-tdate',
                    editable : false,
                    width: 120,
                    value  : new Date()
                },
                {
                    xtype:'button',
                    icon : '/images/find.png',
                    text: '검색',
                    scope : this,
                    handler : this.search
                }
            ]
        };
        return form;
    },

    initPanel : function(title, items){

        return {
            xtype  : 'panel',
            layout : 'vbox',
            title  : title,
            frame : true,
            margin : '5 0 0 0',
            tools: [{
                scope : this,
                type:'save',
                tooltip: '엑셀로 저장',
                handler : function(event, toolEl, panelHeader, btn){

                    var grid = btn.up('panel').down('grid');
                    grid.save();
                }
            },{
                scope : this,
                type:'maximize',
                handler: this.maximizePanel
            }],
            width  : '100%',
            flex   : 1,
            items  : items
        };
    },

    maximizePanel : function(event, toolEl, owner, tool){
                    
        var panel = owner.up("panel");
        var tab = panel.up('container');

        if(tool.type == 'maximize'){

            Ext.invoke(tab.query('>panel'), 'hide');

            panel.setWidth(tab.getWidth() - 10);
            panel.setHeight(tab.getHeight() - 10);
            panel.setPosition(5, 5);
            panel.show();

            tool.setType('restore');
        }
        else {

            var panels = tab.query('>panel');
            Ext.invoke(tab.query('>panel'), 'show');

            tool.setType('maximize');   
        }
    },

    initChart : function(mode){

        var columns = { 'ipaddr' : 'IP' , 'view' : '조회', 'add' : '추가', 'mod' : '수정', 'del' : '삭제', 'etc' : '기타' };
        
        var keys = Ext.Object.getKeys(columns);
        var values = Ext.Object.getValues(columns);

        var chart = Ext.create('Ext.chart.Chart', {
            flex    : 1,
            width   : '100%',
            height  : '100%',
            animate : true,
            shadow  : true,
            theme   : 'ThemeGray',
            style : 'background : #ffffff',
            store   : Ext.create('Ext.data.Store',{
                fields: [
                    {name : 'ipaddr', type : 'string'},
                    {name : 'view', type : 'int'},
                    {name : 'add',  type : 'int'},
                    {name : 'mod',  type : 'int'},
                    {name : 'del',  type : 'int'},
                    {name : 'etc',  type : 'int'}
                ]
            }),
            legend: {
                position: 'right',
                minWidth:100
            },
            series: [{
                type     : 'bar',
                xField   : keys.slice(0, 1),                
                yField   : keys.slice(1),
                title    : values.slice(1),
                column   : true,
                stacked  : true,
                renderer : function (sprite, record, attributes, index, store) {
                    
                    var max_width = 25;
                    if(attributes.width > max_width){

                        return Ext.apply(attributes, {
                            x     : (attributes.x + (attributes.width / 2)) - (max_width / 2),
                            width : max_width
                        });
                    }
                    else {

                        return attributes;
                    }
                },
                tips: {
                    trackMouse: true,
                    width: 100,
                    renderer: function(storeItem, item) {

                        this.setTitle(columns[item.yField] + " : "+ item.value[1].toString());
                    }
                }
            }],
            axes: [{
                type: 'Numeric',
                position: 'left',
                fields: keys.slice(1),
                title: false,
                grid: true,
                minimum: 0,
                maximum: 1000,
                majorTickSteps : 4,
                minorTickSteps : 1,
                label: {
                    renderer: function(v) {
                        return Math.round(v);
                    }
                }
            }, {
                type: 'Category',
                position: 'bottom',
                fields: keys.slice(0, 1),
                minWidth : 200,
                title: false
            }]
        });

        return chart;
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */ 
    initGrid : function(mode){

        var columns = this.makeGridColumns();

        var grid = Ext.create('Lib.Grid', {
            url : '/report/summary/getAccessGridData/'+mode,
            frame : false,
            columns : columns,
            width : '100%',
            remoteSort : false,
            flex : 1
        });

        grid.store.on('load', function(store, records, successful, eOpts){ 

            var chart = this.previousNode('chart'),
                  cnt = store.getCount();
                 data = [];

            if(cnt > 0){

                data = store.getRange(0, store.getCount()).map(function(rec){ return rec.raw });
            }

            chart.store.loadData(data);

        }, grid);
        return grid;
    },

    search : function(){

        var fdate = Ext.getCmp(this.id+'-fdate');
        var tdate = Ext.getCmp(this.id+'-tdate');
        var fdate_val = fdate.getValue();
        var tdate_val = tdate.getValue();

        if((fdate_val && tdate_val) && fdate_val.getTime() > tdate_val.getTime()){

            fdate.setValue(tdate_val);
            tdate.setValue(fdate_val);
        }        

        var params = Ext.getCmp('form-'+this.id).getValues();
        var tmp = {};
        Ext.Object.each(params, function(k, v){ 
            k = k.replace(this.id+'-', '');
            tmp[k] = v;
        }, this);
        params = tmp;

        var panels = this.getTab().query('grid');

        Ext.Array.each(panels, function(panel, key){

            this.getApplication().fireEvent('grid-search', panel, params); 

        }, this);
    },

    /**
     * makeGridColumns
     *
     * 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeGridColumns : function(){

        return [
            { text : 'IP',  dataIndex: 'ipaddr', flex: 1, sortable: true, menuDisabled : true },
            { text : '전체', dataIndex: 'cnt', flex: 1, sortable: true, menuDisabled : true  },
            { text : '조회', dataIndex: 'view', flex: 1, sortable: true, menuDisabled : true  },
            { text : '추가', dataIndex: 'add', flex: 1, sortable: true, menuDisabled : true  },
            { text : '수정', dataIndex: 'mod', flex: 1, sortable: true, menuDisabled : true  },
            { text : '삭제', dataIndex: 'del', flex: 1, sortable: true, menuDisabled : true  },
            { text : '기타', dataIndex: 'etc', flex: 1, sortable: true, menuDisabled : true  }
        ];
    }
});