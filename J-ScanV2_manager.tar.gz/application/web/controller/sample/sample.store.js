var OGR00_stOGRENCITURU = new Ext.data.Store({
    id: OGR00_stOGRENCITURU,
    listeners: {
        load: function (store, recs, opt) {
            Ext.Ajax.request({
                loadMask: true,
                url: '/OGR00.dwa',
                timeout: 60000,
                params: {
                    id: 'OGR00_stOGRENCITURU',
                    cmd: 'afterLoad'
                },
                success: function (resp) {
                    eval(resp.responseText);
                },
                failure: AjaxError
            });
            Ext.MessageBox.hide();
        },
        exception: function (misc) {
            alert('Store exception');
        },
        baseParams: {
            async: false
        },
        beforeload: function (st, op) {
            Ext.MessageBox.show({
                msg: 'İşlem yapılıyor, lütfen bekleyiniz...',
                progressText: 'Lütfen bekleyiniz...',
                width: 300,
                wait: true,
                waitConfig: {
                    interval: 100
                }
            });
        }
    },
    restful: true,
    proxy: OGR00_prOGRENCITURU,
    reader: OGR00_rdOGRENCITURU,
    writer: OGR00_wrOGRENCITURU,
    autoLoad: false,
    fields: [{
        name: 'KOD'
    }, {
        name: 'AD'
    }]
});