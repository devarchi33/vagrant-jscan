Ext.define('WhiteSQL.controller.monitoring.Realtime-Filter', {
    extend: 'Ext.app.Controller',
    winId : null,
    
    /**
     * init
     * 
     * 컨트롤러 초기화 메소드.
     * 
     * @access public
     *
     * @return 
     */
    init:function(context){

        //기본 탭아이디 생성
        this.winId = 'window-'+this.id;
        this.realtime_ctrl = this.getController('monitoring.Realtime');
    },

    initWindow : function(){

        this.window = Ext.create('Ext.window.Window', {
            id : this.winId,
            stateful: true,
            stateId: 'state-'+this.winId,
            title : '필터 적용',
            layout : 'fit',
            bodyStyle:"background-color:#FFFFFF",
            width : 500,
            height: 327,
            overflowY: 'auto',
            autoScroll : true,
            modal : true,
            plain: true,
            fixed : true,
            shadow : false,
            autoShow : true,
            constrain : true,
            items : this.initForm()
        });
    },

    initForm : function(){

        return {
            xtype : 'form',
            id : 'form-'+this.winId,
            layout: 'vbox',
            width : '100%',
            height: '100%',
            padding: '5 5 5 5',
            border : false,
            type : 'json',
            defaults : {
                labelWidth: 100,
                width : '100%',
                anchor : '100%',
                xtype : 'textfield',
                labelPad : 5,
                labelClsExtra : 'x-panel-header-default'
            },
            items:[
                this.initTextIpAddress(),
                this.initLoginId(),
                this.initClassName(),
                this.initSQLType(),
                this.initPolicyType(),
                this.initPrivacySQL(),
                this.initExecuteYn(),
                this.initExecuteTime(),
                this.initResultCount(),
                this.initReqSQLText()
            ],
            // // Reset and Submit buttons
            //buttons: this.initButtons(),
            listeners : {
                scope : this,
                boxready : function(form){

                    try { 

                        var filter = this.realtime_ctrl.filter;
                        if(filter.ipaddr){

                            ip = filter.ipaddr.split(".");
                        }
                        else {

                            ip = ['', '', '', ''];
                        }

                        var bindData = {
                            'filter-server-ip-1'  : ip[0],
                            'filter-server-ip-2'  : ip[1],
                            'filter-server-ip-3'  : ip[2],
                            'filter-server-ip-4'  : ip[3],
                            'filter-login-id'     : filter.login_id,
                            'filter-class-name'   : filter.class_name,
                            'filter-sql-type'     : filter.sql_type,
                            'filter-execute-time' : filter.execute_time,
                            'filter-result-count' : filter.result_count,
                            'filter-req-sqltext'  : filter.req_sqltext
                        };

                        if(filter.whitesql) Ext.getCmp('filter-whitesql').toggle();
                        if(filter.convertsql) Ext.getCmp('filter-convertsql').toggle();
                        if(filter.blocksql) Ext.getCmp('filter-blocksql').toggle();
                        if(filter.privacysql) Ext.getCmp('filter-privacysql').toggle();
                        if(filter.execute_yn) Ext.getCmp('filter-execute-yn').toggle();
                    }
                    catch(e){

                        var bindData = {};
                    }

                    form.getForm().setValues(bindData);
                    //console.log('boxready');
                }
            }
        }
    },

    /**
     * initTextIpAddress
     *
     * 아이피 주소 입력 폼 생성
     *
     * @access public
     *
     * @return component Ext.container.Container
     */
    initTextIpAddress : function(){

        return {
            xtype: 'container',
            layout : 'hbox',
            width : '100%',
            margin: '0 0 5 0',
            defaults : {
                xtype : 'numberfield',
                allowBlank: false,
                maxLength : 3,
                maxValue: 255,
                minValue: 0,
                enforceMaxLength : true,
                hideTrigger: true,
                keyNavEnabled: false,
                mouseWheelEnabled: false
            },
            items : [
                {
                    xtype : 'displayfield',
                    width: 100,
                    margin: '0 5 0 0',
                    cls : 'x-panel-header-default',
                    value : 'Ip'
                },
                {
                    width: 30,
                    id   : 'filter-server-ip-1',
                    name : 'filter-server-ip-1'
                },
                {
                    xtype : 'text',
                    margin: '0 5 0 5',
                    text : '.'
                },
                {
                    width: 30,
                    id   : 'filter-server-ip-2',
                    name : 'filter-server-ip-2'
                },
                {
                    xtype : 'text',
                    margin: '0 5 0 5',
                    text : '.'
                },
                {
                    width: 30,
                    id   : 'filter-server-ip-3',
                    name : 'filter-server-ip-3'
                },
                {
                    xtype : 'text',
                    margin: '0 5 0 5',
                    text : '.'
                },
                {
                    width: 30,
                    id   : 'filter-server-ip-4',
                    name : 'filter-server-ip-4'
                }
            ]
        };
    },

    /**
     * initLoginId
     *
     * 서버명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initLoginId : function(){

        return {
            xtype : 'textfield',
            fieldLabel: '로그인 아이디',
            id: 'filter-login-id',
            name: 'filter-login-id',
            listeners : {
                scope : this,
                change : function(textfield, newValue, oldValue) {

                    this.realtime_ctrl.filter.login_id = newValue;
                }
            }
        };
    },

    /**
     * initLoginId
     *
     * 서버명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initClassName : function(){

        return {
            xtype : 'textfield',
            fieldLabel: '클래스명',
            id: 'filter-class-name',
            name: 'filter-class-name',
            listeners : {
                scope : this,
                change : function(textfield, newValue, oldValue) {

                    this.realtime_ctrl.filter.class_name = newValue;
                }
            }
        };
    },    /**
     * initLoginId
     *
     * 서버명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initSQLType : function(){

        return {
            xtype : 'textfield',
            fieldLabel: '쿼리 유형',
            id: 'filter-sql-type',
            name: 'filter-sql-type',
            listeners : {
                scope : this,
                change : function(textfield, newValue, oldValue) {

                    this.realtime_ctrl.filter.sql_type = newValue;
                }
            }
        };
    },

    /**
     * initPolicyType
     *
     * 정책유형 필터
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initPolicyType : function(){

        return {
            xtype : 'container',
            layout : 'hbox',
            margin: '0 0 5 0',
            defaults : {
                enableToggle : true,
                margin: '0 5 0 0',
                scope : this
            },
            items : [
                {
                    xtype : 'displayfield',
                    width: 100,
                    margin: '0 5 0 0',
                    cls : 'x-panel-header-default',
                    value : '정책별 필터링'
                },
                {
                    xtype: 'button',
                    icon : '/images/whitesql.png',
                    id: 'filter-whitesql',
                    name: 'filter-whitesql',
                    text: 'White SQL',
                    handler: function(btn) {
                            
                        this.realtime_ctrl.filter.whitesql = btn.pressed;
                    }
                },{
                    xtype: 'button',
                    icon : '/images/sql_convert.png',
                    id: 'filter-convertsql',
                    name: 'filter-convertsql',
                    text: '변환 SQL',
                    handler: function(btn) {

                        this.realtime_ctrl.filter.convertsql = btn.pressed;
                    }
                },{
                    xtype: 'button',
                    icon : '/images/block.png',
                    id: 'filter-blocksql',
                    name: 'filter-blocksql',
                    text: '차단 SQL',
                    handler: function(btn) {

                        this.realtime_ctrl.filter.blocksql = btn.pressed;
                    }
            }]
        };
    },

    /**
     * initLoginId
     *
     * 서버명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initPrivacySQL : function(){

        return {
            xtype : 'container',
            layout : 'hbox',
            margin: '0 0 5 0',
            items : [
                {
                    xtype : 'displayfield',
                    width: 100,
                    margin: '0 5 0 0',
                    cls : 'x-panel-header-default',
                    value : 'Privacy SQL 여부'
                },
                {
                    xtype: 'button',
                    icon : '/images/whitesql.png',
                    text: '필터켬',
                    id: 'filter-privacysql',
                    name: 'filter-privacysql',
                    enableToggle : true,
                    scope : this,
                    handler: function(btn) {

                        this.realtime_ctrl.filter.privacysql = btn.pressed;
                    }
                }
            ]
        };
    },


    /**
     * initExecuteYn
     *
     * 서버명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initExecuteYn : function(){

        return {
            xtype : 'container',
            layout : 'hbox',
            margin: '0 0 5 0',
            items : [
                {
                    xtype : 'displayfield',
                    width: 100,
                    margin: '0 5 0 0',
                    cls : 'x-panel-header-default',
                    value : '수행 여부'
                },
                {
                    xtype: 'button',
                    icon : '/images/whitesql.png',
                    text: '필터켬',
                    id: 'filter-execute-yn',
                    name: 'filter-execute-yn',
                    enableToggle : true,
                    scope : this,
                    handler: function(btn) {

                        this.realtime_ctrl.filter.execute_yn = btn.pressed;
                    }
                }
            ]
        };
    },


    /**
     * initLoginId
     *
     * 서버명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initExecuteTime : function(){

        return {
            xtype : 'textfield',
            fieldLabel: '수행시간',
            id: 'filter-execute-time',
            name: 'filter-execute-time',
            listeners : {
                scope : this,
                change : function(textfield, newValue, oldValue) {

                    this.realtime_ctrl.filter.execute_time = newValue;
                }
            }
        };
    },


    /**
     * initLoginId
     *
     * 서버명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initResultCount : function(){

        return {
            xtype : 'textfield',
            fieldLabel: '조회건수',
            id: 'filter-result-count',
            name: 'filter-result-count',
            listeners : {
                scope : this,
                change : function(textfield, newValue, oldValue) {

                    this.realtime_ctrl.filter.result_count = newValue;
                }
            }
        };
    },


    /**
     * initLoginId
     *
     * 서버명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initReqSQLText : function(){

        return {
            xtype : 'textfield',
            fieldLabel: '요청쿼리',
            id: 'filter-req-sqltext',
            name: 'filter-req-sqltext',
            listeners : {
                scope : this,
                change : function(textfield, newValue, oldValue) {

                    this.realtime_ctrl.filter.req_sqltext = newValue;
                }
            }
        };
    }
});