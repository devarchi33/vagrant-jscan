Ext.namespace('Ext.WhiteSQL');
//set up config path for your app

Ext.Loader.setConfig({
    enabled: true,
    paths: {
        'CodeMirror' : '/js/codemirror',
        'Lib'        : '/web/lib',
        'Helper'     : '/web/helper'
    }
});

Ext.application({
    appFolder: '/web',
    name: 'WhiteSQL',
    MainTab : null,
    selectedServerId : 'root',
    chart:[],
    chartPlay : true,
    lastRequestTime : null,
    launch: function() {

        Ext.syncRequire('Helper.Common');
        Ext.syncRequire('Lib.Override');
        Ext.syncRequire('Lib.Event');
        Ext.syncRequire('Lib.Grid');

        this.serverTime = this.getCurrentServerTime();

        this.initLayout();
    },

    initLayout : function(){

        Ext.syncRequire('WhiteSQL.chart.theme.ThemeGray');

        this.Layout = Ext.create('Ext.container.Viewport', {
            renderTo: Ext.getBody(),
            xtype : 'container',
            layout: 'vbox',
            items: this.initMainContainer()
        });
    },

    initMainContainer : function(){

        return {
            id : 'dashboard-panel-container',
            width : '100%',
            xtype : 'container',
            autoScroll : true,
            padding : '5 5 5 5',
            layout: {
                type: 'table',
                columns: 2,
                tableAttrs: {
                    style: {
                        width: '100%'
                    }
                },
                tdAttrs: {
                   style:{
                       width: '50%'
                   }
                }
            },
            flex : 1,
            defaults : {
                xtype : 'panel',
                layout : 'fit',
                margin : '5 5 0 0',
                cls : 'hangul',
                height : 300,
                tools: [{
                    scope : this,
                    type:'maximize',
                    handler: function(event, toolEl, owner, tool){

                        var container = Ext.getCmp("dashboard-panel-container");
                        var panel = owner.up("panel");

                        if(tool.type == 'maximize'){

                            var panels = container.query('>panel');
                            Ext.invoke(panels, 'hide');
                            panel.setWidth(container.getWidth() - 30);
                            panel.setHeight(container.getHeight() - 5);
                            panel.show();

                            tool.setType('restore');
                        }
                        else {

                            var panels = container.query('>panel');
                            Ext.invoke(panels, 'restoreSize');
                            Ext.invoke(panels, 'show');
                            tool.setType('maximize');
                        }
                    }
                }],
                listeners : {
                    boxready : function(panel){

                        var width = panel.getWidth();
                        var height = panel.getHeight();

                        Ext.applyIf(panel, {
                            originalWidth : width,
                            originalHeight : height,
                            restoreSize : function(){
                                
                                this.setWidth(this.originalWidth);
                                this.setHeight(this.originalHeight);
                            }
                        });
                    }
                }
            },
            listeners : {
                scope : this,
                boxready : function(container){

                    this.initMainPanels(container);
                }
            }
        };
    },

    initMainPanels : function(container){

        var serverTime = this.getCurrentServerTime();
        var serverList = this.getServerList();

        var minimum = 0, maximum = 10;

        var fDate = new Date(
            parseInt(serverTime[0], 10),
            parseInt(serverTime[1], 10) - 1,
            parseInt(serverTime[2], 10),
            parseInt(serverTime[3], 10),
            parseInt(serverTime[4], 10),
            parseInt(serverTime[5], 10)
        );
        
        var tDate = Ext.Date.add(fDate, Ext.Date.SECOND, 20);

        container.add([{
            title : 'SQL 수행 누적 건수(0시 ~ 현재)',
            items : this.initChartServerExecCount(),
            width : '100%',
            colspan : 2,
            margin : '0 5 0 0'
        }, {
            title : '실행 SQL 건수',
            height : 400,
            items : this.initRealTimeChart('exec_count_per_sec', serverList, serverTime, fDate, tDate)
        }, {
            title : '평균 수행 시간',
            height : 400,
            margin : '5 0 0 0',
            items : this.initRealTimeChart('avg_req_time_per_sec', serverList, serverTime, fDate, tDate)
        }, {
            title : '쿼리 수행 건수 Top 10',
            items : this.initGrid('ExecQueryCount')
        }, {
            title : '데이터 조회 건수 Top 10',
            margin : '5 0 0 0',
            items : this.initGrid('ExecResultCount')
        }, {
            title : '위험 수준별 실시간 건수',
            items : this.initChartSecurityLevel()
        }, {
            title : '이벤트 리스트 최근 20건',
            margin : '5 0 0 0',
            items : this.initGrid('EventList')
        }]);

        Ext.TaskManager.start({
            scope : this,
            run: function(){

                this.loadRealTimeData('exec_count_per_sec');   
                this.loadRealTimeData('avg_req_time_per_sec');
            },
            interval: 1000 //1 second
        });

        Ext.TaskManager.start({
            scope : this,
            run: function(){

                this.loadData();
            },
            interval: 5000 //5 second
        });

        Ext.TaskManager.start({
            scope : this,
            run: function(){

                this.loadEventData();
            },
            interval: 5000 //5 second
        });
    },

    loadEventData : function(){

        Ext.Ajax.request({
            url: '/monitoring/dashboard/getEventDataTop20',
            type : 'json',
            params: {
                'server' : WhiteSQL.app.serverId
            },
            scope : this,
            success: function(res){

                var data = Ext.JSON.decode(res.responseText);
                Ext.getCmp('grid-'+this.id+'-EventList').getStore().loadData(data);
            }
        });
    },

    loadRealTimeData : function(cmd){

        var chart = this.chart['chart-'+cmd];

        var chartStore = chart.getStore();

        if(chart.up('panel').isHidden()) return;

        Ext.Ajax.request({
            url: '/monitoring/realtime/getChartData/'+cmd,
            type : 'json',
            scope : this,
            success: function(response){

                var res = Ext.JSON.decode(response.responseText);

                if(res.result == "fail"){

                    Ext.Msg.alert('경고', res.message, function(){

                        this.chartPlay = true;
                    }, this);

                    this.chartPlay = false;                    
                    return;
                }

                this.updateChartTime(chart, res.server_time);
                this.updateChartAxis(chart, res.data);

                chartStore.loadData(res.data);
            }
        });
    },    

    loadData : function(){
        
        // var chart = this.chart['chart-'+cmd];

        // var chartStore = chart.getStore();

        // if(chart.up('panel').isHidden()) return;

        Ext.Ajax.request({
            url: '/monitoring/dashboard/getData',
            type : 'json',
            params: {
                'server' : WhiteSQL.app.serverId
            },
            scope : this,
            success: function(res){

                var result = Ext.JSON.decode(res.responseText);

                Ext.getCmp('ChartEventCount').getStore().loadData(result.event_count);
                Ext.getCmp('ChartServerExecCount').getStore().loadData(result.server_exec_count);
                
                Ext.getCmp('grid-'+this.id+'-ExecResultCount').getStore().loadData(result.exec_result_count);
                Ext.getCmp('grid-'+this.id+'-ExecQueryCount').getStore().loadData(result.exec_count);
            }
        });
    },

    updateChartAxis : function(chart, data){

        var axis = chart.axes.get(0);
        var defaultMax = axis.defaultMaximum;
        var max = 0;
        Ext.Array.each(data, function(row){

            Ext.Object.each(row, function(idx, v){

                if(idx == 'date') return;
                if(max < v) max = v;
            });
        });

        if(axis.maximum < max){

            axis.maximum = max;
        }
        else if(axis.maximum > defaultMax && max < defaultMax){

            axis.maximum = defaultMax;
        }
    },

    getServerList : function(){

        var serverList = [];

        Ext.Ajax.request({
            url  : '/monitoring/realtime/getServerList',
            type : 'json',
            async: false,
            success: function(res){

                var result = Ext.JSON.decode(res.responseText);

                serverList = result;
            }
        });

        return serverList;
    },

    getCurrentServerTime : function(){

        var serverTime = [];

        Ext.Ajax.request({
            url  : '/monitoring/realtime/getCurrentServerTime',
            type : 'json',
            async: false,
            success: function(res){

                var result = Ext.JSON.decode(res.responseText);

                serverTime = result;
            }
        });

        return serverTime;
    },

    initChartServerExecCount : function(){

        var chart = Ext.create('Ext.chart.Chart', {
            id      : 'ChartServerExecCount',
            animate : true,
            shadow  : false,
            theme   : 'ThemeGray',
            store   : Ext.create('Ext.data.Store',{
                fields: [
                    {name : 'agent_name',  type : 'string'},
                    {name : 'cnt_table',   type : 'int'},
                    {name : 'cnt_conv',    type : 'int'},
                    {name : 'cnt_exec',    type : 'int'},
                    {name : 'cnt_fail',    type : 'int'},
                    {name : 'cnt_personal_info',  type : 'int'}
                ]
            }),
            axes: [{
                type: 'Numeric',
                position: 'left',
                fields: ['cnt_table', 'cnt_conv', 'cnt_exec', 'cnt_fail', 'cnt_personal_info'],
                title: false,
                grid: true,
                minimum: 0,
                majorTickSteps : 5,
                minorTickSteps : 1,
                label: {
                    renderer: function(v) {
                        return Math.round(v);
                    }
                }
            }, {
                type: 'Category',
                position: 'bottom',
                fields: ['agent_name'],
                minWidth : 200,
                title: false
            }],
            series: [{
                type: 'bar',
                xField: 'agent_name',
                yField: ['cnt_table', 'cnt_conv', 'cnt_exec', 'cnt_fail', 'cnt_personal_info'],
                title: ['주요정보', '변경', '실행', '실패', '개인정보'],
                column: true,
                renderer: function (sprite, record, attributes, index, store) {
                    
                    var max_width = 25;
                    if(attributes.width > max_width){

                        return Ext.apply(attributes, {
                            x     : (attributes.x + (attributes.width / 2)) - (max_width / 2),
                            width : max_width
                        });
                    }
                    else {

                        return attributes;
                    }
                },
                tips: {
                    trackMouse: true,
                    width: 200,
                    renderer: function(storeItem, item) {

                        this.setTitle(item.yField + " : "+ item.value[1].toString());
                    }
                }
            }]
        });

        return chart;
    },    

    initChartSecurityLevel : function(){

        var events = { 'notice' : '알림', 'attention' : '주의', 'alert' : '경보', 'danger' : '위험', 'serious' : '심각' };

        var chart = Ext.create('Ext.chart.Chart', {
            id      : 'ChartEventCount',
            animate : true,
            shadow  : false,
            theme   : 'ThemeGray',
            store   : Ext.create('Ext.data.Store',{
                fields: [
                    {name : 'agent_name', type : 'string'},
                    {name : 'notice',   type : 'int'},
                    {name : 'attention',  type : 'int'},
                    {name : 'alert',   type : 'int'},
                    {name : 'danger',   type : 'int'},
                    {name : 'serious',  type : 'int'}
                ]
            }),
            axes: [{
                type: 'Numeric',
                position: 'left',
                fields: ['notice', 'attention', 'alert', 'danger', 'serious'],
                title: false,
                grid: true,
                minimum: 0,
                label: {
                    renderer: function(v) {
                        return Math.round(v);
                    }
                }
            }, {
                type: 'Category',
                position: 'bottom',
                fields: ['agent_name'],
                minWidth : 200,
                title: false
            }],
            series: [{
                type: 'bar',
                xField: 'agent_name',                
                yField: ['notice', 'attention', 'alert', 'danger', 'serious'],
                title: Ext.Object.getValues(events),
                column: true,
                stacked: true,
                renderer: function (sprite, record, attributes, index, store) {
                    
                    var max_width = 25;
                    if(attributes.width > max_width){

                        return Ext.apply(attributes, {
                            x     : (attributes.x + (attributes.width / 2)) - (max_width / 2),
                            width : max_width
                        });
                    }
                    else {

                        return attributes;
                    }
                },
                tips: {
                    trackMouse: true,
                    width: 100,
                    renderer: function(storeItem, item) {

                        this.setTitle(events[item.yField] + " : "+ item.value[1].toString());
                    }
                }
            }]
        });

        return chart;
    },

    /**
     * initRealTimeChart
     * 
     * 실시간 차트를 초기화 한다.
     * 
     * @access public
     *
     * @return component Ext.chart.Chart
     */
     
    initRealTimeChart : function(id, serverList, serverTime, fDate, tDate){

        var servers = Ext.Object.getKeys(serverList);
        var xField = 'date';
        var fields = [{name : xField, type : 'string'}];
        var series = [];

        if(id == 'exec_count_per_sec'){

            var minimum = 0, maximum = 10;   
            var type = 'integer';
        }
        else {

            var minimum = 0.0000, maximum = 0.0100;
            var type = 'float';
        }

        Ext.Array.each(servers, function(yField){

            fields.push({name : yField, type : type});

            series.push({
                smooth: false,
                type: 'line',
                axis: ['left', 'bottom'],
                xField: xField,
                yField: yField,
                title : serverList[yField],
                label: {
                    display: 'none',
                    field: yField,
                    renderer: function(v) { return v >> 0; },
                    'text-anchor': 'middle'
                },
                highlight: {
                    size: 7,
                    radius: 7
                },
                tips: {
                    trackMouse: true,
                    width : 250,
                    renderer: function(storeItem, item) {
                        
                        var date = storeItem.get('date');
                        var server = serverList[item.series.yField];
                        var value = storeItem.get(item.series.yField);
                        
                        this.setTitle('[' + date + '] ' + server + ' : ' + value);
                    }
                },
                style : { 
                    'stroke-width': 5
                },
                markerConfig: {
                    radius: 3,
                    size: 1
                }
            });
        });

        //데이터 스토어를 생성한다.
        var store = Ext.create('Ext.data.Store',{
            id : 'store-'+this.id+'-'+id,
            fields: fields
        });

        
        //차트 컴포넌트 생성
        var chartId = 'chart-'+id;
        var chart = Ext.create('Ext.chart.Chart', {
            id          : chartId,
            border      : true,
            maximizable : true,
            animate     : false,
            style       : 'background:#fff',
            shadow      : false,
            mask        : true,
            store       : store,
            markerIndex : 0,
            legend      : true,
            theme       : 'ThemeGray',
            axes        : [{
                type           : 'Numeric',
                minimum        : minimum,
                maximum        : maximum,
                defaultMinimum : minimum,
                defaultMaximum : maximum,                
                decimals       : 6,
                position       : 'left',
                fields         : ['value']
            }, {
                type        : 'Time',
                position    : 'bottom',
                fields      : 'date',
                dateFormat  : 'm.d H:i:s',
                groupBy     : 'year,month,day',
                aggregateOp : 'sum',
                constrain   : true,
                step        : [Ext.Date.SECOND, 1],
                fromDate    : fDate,
                toDate      : tDate,
                grid        : true
            }],
            series: series
        });

        this.chart[chartId] = chart;

        return chart;
    },

    updateChartTime : function(chart, server_time){

        timeAxis = chart.axes.get(1);

        markerIndex = chart.markerIndex || 0;

        server_time = new Date(
            parseInt(server_time[0], 10),
            parseInt(server_time[1], 10) - 1,
            parseInt(server_time[2], 10),
            parseInt(server_time[3], 10),
            parseInt(server_time[4], 10),
            parseInt(server_time[5], 10)
        );

        gap = (server_time.getTime() - timeAxis.toDate.getTime()) / 1000;

        if(gap < 0) return;

        markerIndex = 1;

        timeAxis.fromDate = Ext.Date.subtract(Ext.Date.clone(server_time), Ext.Date.SECOND, 20);
        timeAxis.toDate = Ext.Date.clone(server_time);
        
        chart.markerIndex = markerIndex;
    },

    initGrid : function(mode, title){

        var columns = this['make'+mode+'GridColumns']();

        var fields = [];
        Ext.each(columns, function(obj){

            fields.push(obj.dataIndex);
        });

        var grid = Ext.create('Ext.grid.Panel', {
            id : 'grid-'+this.id+'-'+mode,
            border : false,
            width : '100%',
            height : '100%',
            columns : columns,
            store: Ext.create('Ext.data.Store', {
                fields:fields,
                remoteSort : false
            })
        });

        return grid;
    },
    makeExecResultCountGridColumns : function(){

        return [
            { text: '서버',  dataIndex: 'agent_name', sortable: true, menuDisabled : true, draggable : false },
            { text: 'IP',  dataIndex: 'ip', sortable: true, menuDisabled : true, draggable : false },
            { text: 'SQL유형',  dataIndex: 'sql_type', sortable: true, menuDisabled : true, draggable : false },
            { text: '참조 테이블', dataIndex: 'ref_tables', flex: 1, sortable: true, menuDisabled : true, draggable : false, renderer : function(value){
                
                if(value){

                    var tables = Ext.JSON.decode(value);
                    tables = tables.map(function(obj){ return (obj.db ? obj.db + "." : '') + obj.table; });
                    tables = tables.join(", ");
                    return tables;
                }

                return value;
            }},
            { text: '조회건수', dataIndex: 'result_count', sortable: true, menuDisabled : true, draggable : false }
        ];
    },

    makeExecQueryCountGridColumns : function(){
        
        return [
            { text: '서버',      dataIndex: 'agent_name', sortable: true, menuDisabled : true, draggable : false },
            { text: 'IP',       dataIndex: 'ip', sortable: true, menuDisabled : true, draggable : false },
            { text: 'SQL유형',   dataIndex: 'sql_type', sortable: true, menuDisabled : true, draggable : false },
            { text: '참조 테이블', dataIndex: 'ref_tables', flex: 1, sortable: true, menuDisabled : true, draggable : false, renderer : function(value){
                
                if(value){
                    
                    var tables = Ext.JSON.decode(value);
                    tables = tables.map(function(obj){ return (obj.db ? obj.db + "." : '') + obj.table; });
                    tables = tables.join(", ");
                    return tables;
                }

                return value;
            }},
            { text: '수행건수',   dataIndex: 'exec_count', sortable: true, menuDisabled : true, draggable : false }
        ];
    },

    makeEventListGridColumns : function(){
        return [
            { text: '서버',  dataIndex: 'agent_name', sortable: true, menuDisabled : true, draggable : false},
            { text: '위험수준',  dataIndex: 'event_level', sortable: true, menuDisabled : true, draggable : false},
            { text: '이벤트',  dataIndex: 'event_msg', flex : 1, sortable: true, menuDisabled : true, draggable : false}
        ];
    }   
});