Ext.define('WhiteSQL.controller.monitoring.Realtime2', {
    extend: 'Lib.TabController',
    chart:[],
    chartPlay : true,
    lastRequestTime : null,
    filter : {},
    /**
     *
     * 탭 생성
     *
     * @return component Ext.container.Container
     */
    initTab : function(){

        Ext.syncRequire('WhiteSQL.chart.theme.ThemeGray');

    var serverList = {"1":"jboss_13", "2":"jboss_22", "3":"jboss_23", "4":"jboss_26"};

    var data = [
        {"1":0, "2":0, "3":0, "4":0, "date":"2014-04-16 10:17:33"},
        {"1":0, "2":0, "3":0, "4":0, "date":"apr 16 2014 10:17:34"},
        {"1":0, "2":0, "3":0, "4":0, "date":"04-16-2014 10:17:35"},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 36)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 37)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 38)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 39)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 40)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 41)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 42)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 43)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 44)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 45)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 46)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 47)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 48)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 49)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 50)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 51)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 52)},
        {"1":0, "2":0, "3":0, "4":0, "date":new Date(2014, 3, 16, 10, 17, 53)}
    ];

        var minimum = 0, maximum = 10;
        var fDate = new Date(2014, 3, 16, 10, 17, 33);
        var tDate = new Date(2014, 3, 16, 10, 17, 53);

        this.setTab(Ext.create('Lib.Tab', {
            id : this.tabId,
            title : 'RealTime',
            layout : 'border',
            padding : '0px 0px 0px 0px',
            items : [
                {
                    xtype : 'container',
                    layout : 'hbox',
                    padding : '10 10 0 5',
                    region : 'center',
                    style : 'background : #ffffff',
                    items : [
                        this.initRealTimeChart('chart1', serverList, fDate, tDate),
                        this.initRealTimeChart('chart2', serverList, fDate, tDate)
                    ]
                }
            ]
        }));

        var chartStore1 = this.chart[0].getStore();
        var chartStore2 = this.chart[1].getStore();
        chartStore1.loadData(data);
    },

    /**
     * initRealTimeChart
     * 
     * 실시간 차트를 초기화 한다.
     * 
     * @access public
     *
     * @return component Ext.chart.Chart
     */
    initRealTimeChart : function(id, serverList, fDate, tDate){

        var servers = Ext.Object.getKeys(serverList);
        var xField = 'date';
        var fields = [
            {name : xField, type : 'date'}
        ];

        console.log(JSON.stringify(fields));
        var series = [];

        if(id == 'chart1'){

            var minimum = 0, maximum = 10;   
            var title = '실행 SQL 건수';
        }
        else {

            var minimum = 0.0000, maximum = 0.0100;
            var title = '평균 수행 시간';
        }

        Ext.Array.each(servers, function(yField){

            fields.push({name : yField, type : 'float'});

            series.push({
                smooth: false,
                type: 'line',
                axis: ['left', 'bottom'],
                xField: xField,
                yField: yField,
                title : serverList[yField],
                label: {
                    display: 'none',
                    field: yField,
                    renderer: function(v) { return v >> 0; },
                    'text-anchor': 'middle'
                },
                highlight: {
                    size: 7,
                    radius: 7
                },
                tips: {
                    trackMouse: true,
                    width : 250,
                    renderer: function(storeItem, item) {
                        
                        var date = storeItem.get('date');
                        var server = serverList[item.series.yField];
                        var value = storeItem.get(item.series.yField);
                        
                        this.setTitle('[' + date + '] ' + server + ' : ' + value);
                    }
                },
                style : { 
                    'stroke-width': 5
                },
                markerConfig: {
                    radius: 3,
                    size: 1
                }
            });
        });
        console.log(JSON.stringify(fields));
        //데이터 스토어를 생성한다.
        var store = Ext.create('Ext.data.Store',{
            id : 'store-'+this.id+'-'+id,
            fields: fields
        });

        
        //차트 컴포넌트 생성
        var chart = Ext.create('Ext.chart.Chart', {
            id          : 'chart-'+this.id+'-'+id,
            border      : true,
            maximizable : true,
            animate     : true,
            flex        : 1,
            height      : '100%',
            style       : 'background:#fff',
            shadow      : false,
            mask        : true,
            store       : store,
            markerIndex : 0,
            legend      : true,
            theme       : 'ThemeGray',
            axes        : [{
                type           : 'Numeric',
                minimum        : minimum,
                maximum        : maximum,
                defaultMinimum : minimum,
                defaultMaximum : maximum,                
                decimals       : 6,
                position       : 'left',
                fields         : ['value'],
                title          : title
            }, {
                type        : 'Time',
                position    : 'bottom',
                fields      : 'date',
                dateFormat  : 'm.d H:i:s',
                constrain   : true,
                step        : [Ext.Date.SECOND, 1],
                fromDate    : fDate,
                toDate      : tDate,
                grid        : true
            }],
            series: series
        });
        
        this.chart.push(chart);

        return chart;
    }
});