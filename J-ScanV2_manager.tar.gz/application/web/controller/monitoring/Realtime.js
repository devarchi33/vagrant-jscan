Ext.define('WhiteSQL.controller.monitoring.Realtime', {
    extend   : 'Lib.TabController',
    chart    : [],
    chartPlay: true,
    filter   : {},
    /**
     *
     * 탭 생성
     *
     * @return component Ext.container.Container
     */
    initTab  : function () {

        Ext.syncRequire('WhiteSQL.chart.theme.ThemeGray');

        this.setTab(Ext.create('Lib.Tab', {
            id   : this.tabId,
            title: 'RealTime',
            items: [
                {
                    tbar: [
                        {
                            xtype       : 'displayfield',
                            id          : 'server-name-' + this.getTabId(),
                            fieldLabel  : "서버",
                            fieldBodyCls: "align-top",
                            width       : 200,
                            value       : this.application.getServerName()
                        },
                        this.initBtnPause()
                        //this.initBtnFilter()
                    ]
                },
                this.initMainContainer()
            ]
        }));
    },

    initMainContainer: function () {

        return {
            id        : 'realtime-panel-container',
            width     : '100%',
            xtype     : 'container',
            autoScroll: true,
            layout    : {
                type      : 'table',
                columns   : 2,
                tableAttrs: {
                    style: {
                        width: '100%'
                    }
                },
                tdAttrs   : {
                    style: {
                        width: '50%'
                    }
                }
            },
            flex      : 1,
            defaults  : {
                xtype    : 'panel',
                layout   : 'fit',
                margin   : '5 5 0 0',
                cls      : 'hangul',
                height   : 300,
                tools    : [{
                    scope  : this,
                    type   : 'maximize',
                    handler: function (event, toolEl, owner, tool) {

                        var container = Ext.getCmp("realtime-panel-container");
                        var panel = owner.up("panel");

                        if (tool.type == 'maximize') {

                            var panels = container.query('>panel');
                            Ext.invoke(panels, 'hide');
                            panel.setWidth(container.getWidth() - 30);
                            panel.setHeight(container.getHeight() - 5);
                            panel.show();

                            tool.setType('restore');
                        }
                        else {

                            var panels = container.query('>panel');
                            Ext.invoke(panels, 'restoreSize');
                            Ext.invoke(panels, 'show');
                            tool.setType('maximize');
                        }
                    }
                }],
                listeners: {
                    boxready: function (panel) {

                        var width = panel.getWidth();
                        var height = panel.getHeight();

                        Ext.applyIf(panel, {
                            originalWidth : width,
                            originalHeight: height,
                            restoreSize   : function () {

                                this.setWidth(this.originalWidth);
                                this.setHeight(this.originalHeight);
                            }
                        });
                    }
                }
            },
            listeners : {
                scope   : this,
                boxready: function (container) {

                    this.initMainPanels(container);
                }
            }
        };
    },

    initMainPanels: function (container) {

        var serverTime = this.getCurrentServerTime();
        var serverList = this.getServerList();

        var minimum = 0, maximum = 10;

        var fDate = new Date(
            parseInt(serverTime[0], 10),
            parseInt(serverTime[1], 10) - 1,
            parseInt(serverTime[2], 10),
            parseInt(serverTime[3], 10),
            parseInt(serverTime[4], 10),
            parseInt(serverTime[5], 10)
        );

        var tDate = Ext.Date.add(fDate, Ext.Date.SECOND, 20);

        container.add([{
            title : '실행 SQL 건수',
            height: 300,
            items : this.initChart('exec_count_per_sec', serverList, serverTime, fDate, tDate)
        }, {
            title : '평균 수행 시간',
            margin: '5 0 0 0',
            height: 300,
            items : this.initChart('avg_req_time_per_sec', serverList, serverTime, fDate, tDate)
        }, {
            title  : 'SQL 실시간 로그',
            width  : '100%',
            height : '100%',
            flex   : 1,
            colspan: 2,
            margin : '5 0 0 0',
            items  : this.initGrid()
        }]);

        var tab = Ext.getCmp(this.tabId);

        Ext.TaskManager.start({
            scope   : this,
            run     : function () {

                if (tab.isVisible() == false) return;
                if (this.chartPlay == false) return;

                this.loadChartData('exec_count_per_sec');
            },
            interval: 1000 //1 second
        });

        Ext.TaskManager.start({
            scope   : this,
            run     : function () {

                if (tab.isVisible() == false) return;
                if (this.chartPlay == false) return;

                this.loadChartData('avg_req_time_per_sec');
            },
            interval: 1000 //1 second
        });

        Ext.TaskManager.start({
            scope   : this,
            run     : function () {

                if (tab.isVisible() == false) return;
                if (this.chartPlay == false) return;

                this.loadSQLLog();
            },
            interval: 1000 //1 second
        });
    },

    loadChartData: function (cmd) {

        var chart = this.chart['chart-' + cmd];
        var chartStore = chart.getStore();

        if (chart.up('panel').isHidden()) return;

        Ext.Ajax.request({
            url    : '/monitoring/realtime/getChartData/' + cmd,
            type   : 'json',
            params : {
                'server': WhiteSQL.app.serverId
            },
            scope  : this,
            success: function (response) {

                var res = Ext.JSON.decode(response.responseText);

                if (res.result == "fail") {

                    Ext.Msg.alert('경고', res.message, function () {

                        this.chartPlay = true;
                    }, this);

                    this.chartPlay = false;
                    return;
                }

                this.updateChartTime(chart, res.server_time);
                this.updateChartAxis(chart, res.data);

                chartStore.loadData(res.data);
            }
        });
    },

    loadSQLLog: function () {

        var grid = Ext.getCmp('grid-' + this.id),
            limit = 50,
            gridStore = grid.getStore();

        Ext.Ajax.request({
            url    : '/monitoring/realtime/getSQLLog',
            type   : 'json',
            params : {
                'server': WhiteSQL.app.serverId
            },
            scope  : this,
            success: function (response) {

                var res = Ext.JSON.decode(response.responseText);

                if (res.result == "fail") {

                    Ext.Msg.alert('경고', res.message, function () {

                        this.chartPlay = true;
                    }, this);

                    this.chartPlay = false;
                    return;
                }

                if (res.data.length > 0) {

                    gridStore.loadData(res.data);
                }
            }
        });
    },

    updateChartAxis: function (chart, data) {

        var axis = chart.axes.get(0);
        var defaultMax = axis.defaultMaximum;
        var max = 0;
        Ext.Array.each(data, function (row) {

            Ext.Object.each(row, function (idx, v) {

                if (idx == 'date') return;
                if (max < v) max = v;
            });
        });

        if (axis.maximum < max) {

            axis.maximum = max;
        }
        else if (axis.maximum > defaultMax && max < defaultMax) {

            axis.maximum = defaultMax;
        }
    },

    initBtnPause: function () {

        this.btnPause = Ext.create('Ext.button.Button', {
            id     : 'btn-' + this.id + '-Pause',
            icon   : '/images/icon_pause.png',
            cls    : 'x-btn-toolbar-custom',
            scope  : this,
            handler: function (btn) {

                if (this.chartPlay == true) {

                    this.chartPlay = false;
                    btn.setIcon('/images/icon_play.png');
                }
                else {

                    this.chartPlay = true;

                    this.loadChartData('exec_count_per_sec');
                    this.loadChartData('avg_req_time_per_sec');
                    this.loadSQLLog();

                    btn.setIcon('/images/icon_pause.png');
                }
            }
        });

        return this.btnPause;
    },

    initBtnFilter: function () {

        return Ext.create('Ext.button.Button', {
            id     : 'btn-' + this.id + '-Filter',
            icon   : '/images/icon_filter.png',
            cls    : 'x-btn-toolbar-custom',
            type   : 'gear',
            scope  : this,
            handler: function (btn) {

                this.getApplication().openWindow('monitoring.Realtime-Filter', this);
            }
        });
    },

    /**
     * initChart
     *
     * 실시간 차트를 초기화 한다.
     *
     * @access public
     *
     * @return component Ext.chart.Chart
     */

    initChart: function (id, serverList, serverTime, fDate, tDate) {

        var servers = Ext.Object.getKeys(serverList);
        var xField = 'date';
        var fields = [{name: xField, type: 'string'}];
        var series = [];

        if (id == 'exec_count_per_sec') {

            var minimum = 0, maximum = 10;
            var type = 'integer';
        }
        else {

            var minimum = 0.0000, maximum = 0.0100;
            var type = 'float';
        }

        Ext.Array.each(servers, function (yField) {

            fields.push({name: yField, type: type});

            series.push({
                smooth      : false,
                type        : 'line',
                axis        : ['left', 'bottom'],
                xField      : xField,
                yField      : yField,
                title       : serverList[yField],
                label       : {
                    display      : 'none',
                    field        : yField,
                    renderer     : function (v) {
                        return v >> 0;
                    },
                    'text-anchor': 'middle'
                },
                highlight   : {
                    size  : 7,
                    radius: 7
                },
                tips        : {
                    trackMouse: true,
                    width     : 250,
                    renderer  : function (storeItem, item) {

                        var date = storeItem.get('date');
                        var server = serverList[item.series.yField];
                        var value = storeItem.get(item.series.yField);

                        this.setTitle('[' + date + '] ' + server + ' : ' + value);
                    }
                },
                style       : {
                    'stroke-width': 5
                },
                markerConfig: {
                    radius: 3,
                    size  : 1
                }
            });
        });

        //데이터 스토어를 생성한다.
        var store = Ext.create('Ext.data.Store', {
            id    : 'store-' + this.id + '-' + id,
            fields: fields
        });


        //차트 컴포넌트 생성
        var chartId = 'chart-' + id;
        var chart = Ext.create('Ext.chart.Chart', {
            id         : chartId,
            border     : true,
            maximizable: true,
            animate    : true,
            flex       : 1,
            height     : '100%',
            style      : 'background:#fff',
            shadow     : false,
            mask       : true,
            store      : store,
            markerIndex: 0,
            legend     : true,
            theme      : 'ThemeGray',
            axes       : [{
                type          : 'Numeric',
                minimum       : minimum,
                maximum       : maximum,
                defaultMinimum: minimum,
                defaultMaximum: maximum,
                decimals      : 6,
                position      : 'left',
                fields        : ['value']
            }, {
                type       : 'Time',
                position   : 'bottom',
                fields     : 'date',
                dateFormat : 'm.d H:i:s',
                groupBy    : 'year,month,day',
                //label: {
                //    renderer: function(name) {
                //        return '';
                //    }
                //},
                aggregateOp: 'sum',
                constrain  : true,
                step       : [Ext.Date.SECOND, 1],
                fromDate   : fDate,
                toDate     : tDate,
                grid       : true
            }],
            series     : series
        });

        this.chart[chartId] = chart;

        return chart;
    },

    updateChartTime: function (chart, server_time) {

        timeAxis = chart.axes.get(1);

        markerIndex = chart.markerIndex || 0;

        server_time = new Date(
            parseInt(server_time[0], 10),
            parseInt(server_time[1], 10) - 1,
            parseInt(server_time[2], 10),
            parseInt(server_time[3], 10),
            parseInt(server_time[4], 10),
            parseInt(server_time[5], 10)
        );

        gap = (server_time.getTime() - timeAxis.toDate.getTime()) / 1000;

        if (gap < 0) return;

        markerIndex = 1;

        timeAxis.fromDate = Ext.Date.subtract(Ext.Date.clone(server_time), Ext.Date.SECOND, 20);
        timeAxis.toDate = Ext.Date.clone(server_time);

        chart.markerIndex = markerIndex;
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGrid: function () {

        var columns = this.makeGridColumns();

        var fields = [];
        Ext.each(columns, function (obj) {

            fields.push(obj.dataIndex);
        });

        var grid = Ext.create('Ext.grid.Panel', {
            id     : 'grid-' + this.id,
            border : false,
            width  : '100%',
            height : '100%',
            flex   : 1,
            columns: columns,
            store  : Ext.create('Ext.data.Store', {
                fields    : fields,
                remoteSort: false
            })
        });

        return grid;
    },

    getCurrentServerTime: function () {

        var serverTime = [];

        Ext.Ajax.request({
            url    : '/monitoring/realtime/getCurrentServerTime',
            type   : 'json',
            async  : false,
            success: function (res) {

                var result = Ext.JSON.decode(res.responseText);

                serverTime = result;
            }
        });

        return serverTime;
    },

    getServerList: function () {

        var serverList = [];

        Ext.Ajax.request({
            url    : '/monitoring/realtime/getServerList',
            type   : 'json',
            async  : false,
            success: function (res) {

                var result = Ext.JSON.decode(res.responseText);

                serverList = result;
            }
        });

        return serverList;
    },

    /**
     * makeGridColumns
     *
     * SQL 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeGridColumns: function () {

        return [
            {text: '서버', dataIndex: 'agent_name', sortable: true, menuDisabled: true, draggable: false, width: 80},
            {text: '시간', dataIndex: 'request_time', sortable: true, menuDisabled: true, draggable: false, width: 170},
            {text: 'IP', dataIndex: 'ipaddr', sortable: true, width: 80},
            {text: '로그인아이디', dataIndex: 'login_id', sortable: true, menuDisabled: true, draggable: false, width: 80},
            {text: '클래스', dataIndex: 'class_name', sortable: true, menuDisabled: true, draggable: false, width: 80},
            {text: '쿼리유형', dataIndex: 'sql_type', sortable: true, menuDisabled: true, draggable: false, width: 60},
            {
                text        : 'WhiteSQL여부',
                dataIndex   : 'whitesql_id',
                sortable    : true,
                menuDisabled: true,
                draggable   : false,
                width       : 60,
                renderer    : function (n) {
                    if (n) { return 'Yes'; }
                    else { return 'No'; }
                }
            },
            {
                text        : '변경SQL여부',
                dataIndex   : 'convsql_id',
                sortable    : true,
                menuDisabled: true,
                draggable   : false,
                width       : 60,
                renderer    : function (n) {
                    if (n) { return 'Yes'; }
                    else { return 'No'; }
                }
            },
            {
                text: '결과값 저장 여부', dataIndex: 'result_data_saved', width: 60, renderer: function (value) {
                return value == 1 ? 'Yes' : 'No';
            }
            },
            {text           : 'PrivacySQL여부',
                dataIndex   : 'privacy_type',
                sortable    : true,
                menuDisabled: true,
                draggable   : false,
                width       : 60
            },
            {
                text        : '수행여부',
                dataIndex   : 'execute_yn',
                sortable    : true,
                menuDisabled: true,
                draggable   : false,
                width       : 60,
                renderer    : function (n) {
                    if (n) { return 'Yes'; }
                    else { return 'No'; }
                }
            },
            {text           : '수행시간',
                dataIndex   : 'exec_elapsedtime',
                sortable    : true,
                menuDisabled: true,
                draggable   : false,
                width       : 60
            },
            {text: '조회건수', dataIndex: 'result_count', sortable: true, menuDisabled: true, draggable: false, width: 60},
            {text: '요청쿼리', dataIndex: 'sql_str', sortable: true, menuDisabled: true, draggable: false, flex: 1}
        ];
    }
});