Ext.define('WhiteSQL.controller.log.Event', {
    extend: 'Lib.TabController',

    /**
     *
     * 탭 생성
     *
     * @return component Ext.container.Container
     */
    initTab : function(){

        this.setTab(Ext.create('Lib.Tab', {
            id : this.tabId,
            title : 'Event Log',
            items : [
                this.initGridSearch(),
                this.initGrid()
            ]
        }));
    },

    /**
     * initGridSearch
     *
     * 그리드 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGridSearch : function(){

        var required = '<span style="color:red;font-weight:bold" data-qtip="Required">*</span>';

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'vbox',
            frame : true,
            width : '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 0',
            defaults : {
                labelWidth: 80
            },
            items:[
                {
                    xtype   : 'container',
                    layout  : 'hbox',
                    margin  : '0 0 5 0',
                    defaults: {
                        labelWidth: 80,
                        margin : '0 10 0 0'
                    },
                    items : [
                        {
                            xtype       : 'displayfield',
                            id          : 'server-name-'+this.getTabId(),
                            fieldLabel  : "서버",
                            fieldBodyCls: "align-top",
                            width       : 200,
                            labelWidth : 120,
                            value       : this.application.getServerName()
                        },
                        {
                            xtype       : 'displayfield',
                            fieldLabel  : "기간",
                            fieldBodyCls: "align-top",
                            width       : 80
                        },
                        {
                            xtype: 'datefield',
                            format: 'Y-m-d',
                            id : this.id+'-fdate',
                            name : this.id+'-fdate',
                            width: 120,
                            margin : '0 5 0 0',
                            value  : new Date()

                        },
                        {
                            xtype : 'text',
                            text : '~',
                            margin : '0 5 0 0'
                        },
                        {
                            xtype: 'datefield',
                            format: 'Y-m-d',
                            id : this.id+'-tdate',
                            name : this.id+'-tdate',
                            width: 120,
                            value  : new Date()
                        },
                        this.initComboBox('Event Level', 'EventLevel'),
                        this.initComboBox('Event Kind', 'EventKind')
                    ]
                },
                {
                    xtype:'container',
                    layout : 'hbox',
                    margin : '0 0 5 0',
                    defaults : {
                        labelWidth: 120,
                        margin : '0 5 0 0'
                    },
                    items : [
                        {
                            xtype:'textfield',
                            fieldLabel: 'Event Message',
                            name: this.id+'-message',
                            width : 734
                        },{
                            xtype:'button',
                            icon : '/images/find.png',
                            text: '검색',
                            scope : this,
                            handler : this.search
                        }
                    ]
                }

            ]
        };
        
        return form;
    },

    /**
     * initGrid
     *
     * 콤보박스 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initComboBox : function(label, mode){

        var store = new Ext.data.Store({
            proxy: {
                type  : 'ajax',
                url: '/log/event/get'+mode+'List',
                reader: {
                    type: 'json'
                }
            },
            fields: ['id','text']
        });

        // Simple ComboBox using the data store
        var combo = Ext.create('Ext.form.ComboBox', {
            name : this.id+'-'+mode,
            fieldLabel: label,
            emptyText : '전체',
            value: '',
            displayField : 'text',
            valueField: 'id',
            labelWidth: 80,
            store: store,
            editable : false,
            typeAhead: true
        });

        return combo;
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGrid : function(mode){

        var columns = this.makeGridColumns();

        var grid = Ext.create('Lib.Grid', {
            id : 'grid-'+this.id,
            url : '/log/event/getGridData',
            title : mode,
            columns : columns,
            listeners: {
                scope : this,
                cellclick: function(grid, cellEl, cellIdx, record, rowEl, rowIdx, evtObj) {

                    if(cellIdx == 0){

                        var log_id = record.data.eventlog_id;

                        this.getApplication().openWindow('log.Event-Detail', log_id);
                    }
                }
            }
        });

        return grid;
    },

    /**
     * makePrivacySQLGridColumns
     *
     * Privacy SQL 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeGridColumns : function(){

        return [
            // { text: '작업시간',  dataIndex: 'agent_name'},
            { dataIndex: 'eventlog_id', width : 25 , sortable: true, renderer : function(value){
                return '<img src="/images/view.png" history_id="'+value+'"/>';
            }, sortable: true, menuDisabled : true },
            { text: '실행시간',  dataIndex: 'event_time'},
            { text: '서버', dataIndex: 'agent_name' },
            { text: 'Event Level', dataIndex: 'event_level'},
            { text: 'Event Kind', dataIndex: 'event_kind' },
            { text: 'Event Message', dataIndex: 'event_msg', flex: 1 }
        ];
    },

    search : function(){

        var fdate = Ext.getCmp(this.id+'-fdate');
        var tdate = Ext.getCmp(this.id+'-tdate');
        var fdate_val = fdate.getValue();
        var tdate_val = tdate.getValue();

        if((fdate_val && tdate_val) && fdate_val.getTime() > tdate_val.getTime()){

            fdate.setValue(tdate_val);
            tdate.setValue(fdate_val);
        }        

        var params = Ext.getCmp('form-'+this.id).getValues();        
        var grid   = Ext.getCmp('grid-'+this.id);

        this.getApplication().fireEvent('grid-search', grid, params);
    }
});