Ext.define('WhiteSQL.controller.log.SQL-WhiteSQL', {
    extend: 'Ext.app.Controller',

    initWindow : function(log_id){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id+'-detail',
            application : this.application,
            title : 'White SQL',
            width : 900,
            height: 550,
            items : [
                this.initView(log_id)
            ]
        });
    },

    initView : function(log_id){

        var data = {};
        Ext.Ajax.request({
            url: '/log/sql/getDetailData/'+log_id,
            type : 'json',
            async:false,
            scope : this,
            success: function(res){

                data = Ext.JSON.decode(res.responseText);
            }
        });

        var form = {
            id : 'form-'+this.id+'-detail',
            xtype: 'container',
            layout: 'hbox',
            width : '100%',
            height: '100%',
            padding: '5 5 5 5',
            defaults : {
                labelWidth: 80,
                width : '50%',
                height: '100%',
                xtype : 'container',
                layout: 'vbox'
            },
            items:[
                {
                    items : [
                        this.initLabel('Request Time', data.request_time),
                        this.initLabel('Host Name', data.agent_name),
                        this.initLabel('SQL Type', data.sql_type),
                        this.initLabel('IP Address', data.ipaddr),
                        this.initLabel('Exec Result', data.execute_yn),
                        this.initLabel('Operation Mode', data.policy_type),
                        this.initLabel('Exec Time', data.exec_elapsedtime),
                        this.initLabel('Session ID', data.session_id),
                        this.initLabel('Session Time', data.session_createtime),
                        this.initLabel('Fail Code', data.fail_code, 1),
                        this.initLabel('Result Count', data.result_count),
                        {
                            xtype  : 'container',
                            layout : 'hbox',
                            items : [
                                this.initLabel('WhiteSQL', data.whitesql_id > 0 ? 'Yes' : 'No'),
                                {
                                    xtype: 'button',
                                    text : 'more..',
                                    margin : '0 0 0 5',
                                    listeners : {
                                        scope : this,
                                        click : function(){

                                            
                                        }
                                    }
                                }
                            ]
                        },
                        {
                            xtype  : 'container',
                            layout : 'hbox',
                            items : [
                                this.initLabel('변경SQL', data.convsql_id > 0 ? 'Yes' : 'No'),
                                {
                                    xtype: 'button',
                                    text : 'more..',
                                    margin : '0 0 0 5',
                                    listeners : {
                                        scope : this,
                                        click : function(){

                                            this.getApplication().openWindow('log.ConvertedSQL-Detail', 
                                                data.request_time.substring(0, 10), 
                                                data.agent_id, 
                                                data.uniqsql_id, 
                                                data.class_id
                                            );
                                        }
                                    }
                                }
                            ]
                        },
                        this.initLabel('Policy Type', function(policy_type){

                                return {
                                    '1' : 'SQL', '2' : 'SQL변경', '3' : 'IP', 
                                    '4' : 'LOGIN ID', '5' : '주요 TABLE', '6' : 'SQL 유형', 
                                    '7' : '개인정보 TABLE'
                                }[policy_type];

                        }(data.policy_type)),
                        {
                            xtype  : 'container',
                            layout : 'hbox',
                            items : [
                                this.initLabel('Policy Name', data.policy_name),
                                {
                                    xtype: 'button',
                                    text : 'more..',
                                    margin : '0 0 0 5',
                                    listeners : {
                                        scope : this,
                                        click : function(){

                                            var record = {};
                                            this.getApplication().openWindow('manage.SQLPolicy-Add', record);
                                        }
                                    }
                                }
                            ]
                        }      
                    ]
                },
                {
                    defaults : {
                        width : '100%',
                        xtype : 'panel',
                        bodyPadding : 5,
                        autoScroll:true
                    },
                    items : [
                        {
                            title : 'Query String',
                            html  : data.req_sqltext,
                            flex : 2,
                            margin : '0 0 5 0'
                        },
                        {
                            title : 'SQL Parameters',
                            html  : data.sqlparam,
                            flex : 1,
                            margin : '0 0 5 0'
                        },
                        {
                            title : 'Class Trace',
                            html  : data.class_text,
                            flex : 2
                        }
                    ]
                }
            ]
        };

        return form;
    },

    initLabel : function(fieldLabel, value){

        return {
            labelWidth: 100,
            anchor : '100%',
            xtype : 'displayfield',
            labelPad : 5,
            labelClsExtra : 'x-panel-header-default',
            labelStyle : 'font-weight:bold',
            fieldLabel: fieldLabel,
            value : value
        };
    }
});