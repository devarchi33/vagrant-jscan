Ext.define('WhiteSQL.controller.log.Event-Detail', {
    extend: 'Ext.app.Controller',

    initWindow : function(log_id){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id+'-detail',
            application : this.application,
            title : 'Detail Log',
            width : 900,
            height: 550,
            items : [
                this.initView(log_id)
            ]
        });
    },

    initView : function(log_id){

        var data = {};
        Ext.Ajax.request({
            url: '/log/event/getGridData/'+log_id,
            type : 'json',
            async:false,
            scope : this,
            success: function(res){

                var result = Ext.JSON.decode(res.responseText);
                data = result.list[0];
            }
        });

        var form = {
            id : 'form-'+this.id+'-detail',
            xtype: 'container',
            layout: 'vbox',
            width : '100%',
            height: '100%',
            padding: '5 5 5 5',
            defaults : {
                labelWidth: 100,
                width : '100%',
                anchor : '100%',
                xtype : 'displayfield',
                labelPad : 5,
                labelClsExtra : 'x-panel-header-default',
                labelStyle : 'font-weight:bold'
            },
            items:[
                {
                    fieldLabel: '발생일시',
                    value : data.event_time
                },{
                    fieldLabel: '호스트명',
                    value : data.agent_name
                },{
                    fieldLabel: '이벤트수준',
                    value : data.event_level
                },{
                    fieldLabel: '이벤트유형',
                    value : data.event_kind
                },{
                    fieldLabel: 'Source IP',
                    value : data.ipaddr
                },{
                    fieldLabel: '이벤트 메시지',
                    value : data.event_msg
                },{
                    xtype : 'fieldset',
                    layout : 'vbox',
                    title: '상세내용',
                    flex  : 1, 
                    padding : 10,
                    defaults : {
                        labelWidth: 100,
                        width : '100%',
                        anchor : '100%',
                        xtype : 'displayfield',
                        labelPad : 5,
                        labelClsExtra : 'x-panel-header-default',
                        labelStyle : 'font-weight:bold'
                    },
                    items : [
                        {
                            xtype : 'fieldset',
                            title: '수행 SQL',
                            html  : data.sqltext,
                            flex : 1
                        },
                        {
                            fieldLabel: 'White SQL 여부',
                            value : (data.whitesql_id > 0 ? '예' : '아니오')
                        },{
                            fieldLabel: 'SQL 변경 여부',
                            value : (data.convsql_id > 0 ? '예' : '아니오')
                        },{
                            fieldLabel: '정책 유형',
                            value : data.policy_type,
                            hidden : (data.policy_type ? false : true)
                        },{
                            fieldLabel: '정책명',
                            value : data.policy_name,
                            hidden : (data.policy_name ? false : true)
                        },{
                            fieldLabel: '실행 결과',
                            value : (data.execute_yn > 0 ? '성공' : '실패')
                        },{
                            fieldLabel: '에러 코드',
                            value : (data.fail_code ? data.fail_code : '-')
                        }
                    ]
                }
            ]
        };

        return form;
    }
});