Ext.define('WhiteSQL.controller.log.SQL', {
    extend: 'Lib.TabController',

    /**
     *
     * 탭 생성
     *
     * @return component Ext.container.Container
     */
    initTab : function(){

        this.setTab(Ext.create('Lib.Tab', {
            id : this.tabId,
            title : 'SQL Log',
            items : [
                this.initGridSearch(),
                this.initGrid()
            ]
        }));
    },

    /**
     * initGridSearch
     *
     * 그리드 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGridSearch : function(){

        var required = '<span style="color:red;font-weight:bold" data-qtip="Required">*</span>';

        var times = [{id : '', text : '모든 시간'}];

        for(var i = 1 ; i < 25 ; i++){

            times.push({id : i, text : i+'시'});
        }

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'vbox',
            frame : true,
            width : '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 0',
            defaults : {
                labelWidth: 80
            },
            items:[
                {
                    xtype   : 'container',
                    layout  : 'hbox',
                    margin  : '0 0 5 0',
                    defaults: {
                        labelWidth: 80,
                        margin : '0 10 0 0'
                    },
                    items : [
                        {
                            xtype       : 'displayfield',
                            id          : 'server-name-'+this.getTabId(),
                            fieldLabel  : "서버",
                            fieldBodyCls: "align-top",
                            width       : 200,
                            value       : this.application.getServerName()
                        },
                        {
                            xtype: 'datefield',
                            format: 'Y-m-d',
                            id : this.id+'-fdate',
                            name : this.id+'-fdate',
                            editable : false,
                            width: 120,
                            margin : '0 5 0 0',
                            value  : new Date()
                        },
                        {
                            xtype: 'timefield',
                            format: 'H:i:s',
                            id : this.id+'-ftime',
                            name : this.id+'-ftime',
                            editable : false,
                            value : '00:00:00',
                            minValue: '00:00 AM',
                            maxValue: '24:00 PM',
                            increment: 60,
                            width: 120,
                            margin : '0 5 0 0'
                        },
                        {
                            xtype : 'text',
                            text : '~',
                            margin : '0 5 0 0'
                        },
                        {
                            xtype: 'datefield',
                            format: 'Y-m-d',
                            id : this.id+'-tdate',
                            name : this.id+'-tdate',
                            editable : false,
                            width: 120,
                            value  : new Date()
                        },
                        {
                            xtype: 'timefield',
                            format: 'H:59:59',
                            id : this.id+'-ttime',
                            name : this.id+'-ttime',
                            editable : false,
                            width: 120,
                            value: '23:59:59',
                            minValue: '00:00 AM',
                            maxValue: '24:00 PM',
                            increment: 60,
                            margin : '0 5 0 0'
                        },
                        this.initComboBox(this.id+'-search-time', times, '전체'),
                        {
                            xtype : 'textfield',
                            emptyText : '소스IP',
                            id : this.id+'-ip',
                            name : this.id+'-ip'
                        }
                    ]
                },
                {
                    xtype:'container',
                    layout : 'hbox',
                    margin : '5 0 5 0',
                    width : '100%',
                    defaults : {
                        labelWidth: 80,
                        margin : '0 5 0 0'
                    },
                    items : [
                        {
                            xtype       : 'displayfield',
                            fieldLabel  : "WhiteSQL",
                            fieldBodyCls: "align-top",
                            width       : 80
                        },
                        this.initComboBox(this.id+'-search-white-sql', [
                            {id : '', text : '전체'},
                            {id : 'whitesql_y', text : 'Yes'},
                            {id : 'whitesql_n', text : 'No'}
                        ], '전체'),
                        {
                            xtype       : 'displayfield',
                            fieldLabel  : "변경 SQL",
                            fieldBodyCls: "align-top",
                            width       : 80
                        },
                        this.initComboBox(this.id+'-search-conv-sql', [
                            {id : '', text : '전체'},
                            {id : 'convsql_y', text : 'Yes'},
                            {id : 'convsql_n', text : 'No'}
                        ], '전체'),
                        this.initComboBox(this.id+'-search-type', [
                            {id : 'sql_str', text : 'SQL'},
                            {id : 'class_name', text : '클래스'},
                            {id : 'sql_type', text : '쿼리유형'}
                        ], 'SQL'),
                        {
                            xtype:'textfield',
                            name: this.id+'-query',
                            emptyText : '검색내용',
                            flex : 1
                        },{
                            xtype:'button',
                            icon : '/images/find.png',
                            text: '검색',
                            scope : this,
                            handler : this.search
                        },
                        {
                            xtype:'button',
                            icon : '/images/export.png',
                            text: '엑셀받기',
                            scope : this,
                            handler : this.exportSQLLog
                        }
                    ]
                }

            ]
        };
        return form;
    },

    /**
     * initComboBox
     *
     * 콤보박스 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initComboBox : function(name, data, emptyText){

        var store = new Ext.data.Store({
            fields: ['id','text'],
            data : data
        });

        // Simple ComboBox using the data store
        var combo = Ext.create('Ext.form.ComboBox', {
            name : name,
            emptyText : emptyText,
            value: '',
            displayField : 'text',
            valueField: 'id',
            labelWidth: 80,
            width : 100,
            editable : false,
            store: store,
            typeAhead: true
        });

        return combo;
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGrid : function(mode){

        var columns = this.makeGridColumns();

        var grid = Ext.create('Lib.Grid', {
            id : 'grid-'+this.id,
            url : '/log/sql/getGridData',
            title : mode,
            columns : columns,
            listeners: {
                scope : this,
                cellclick: function(grid, cellEl, cellIdx, record, rowEl, rowIdx, evtObj) {

                    if(cellIdx == 0){

                        var sqllog_id = record.data.sqllog_id;

                        this.getApplication().openWindow('log.SQL-Detail', sqllog_id);
                    }
                }
            }
        });

        return grid;
    },

    /**
     * makePrivacySQLGridColumns
     *
     * Privacy SQL 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeGridColumns : function(){

        return [
            // { text: '작업시간',  dataIndex: 'agent_name'},
            { dataIndex: 'sqllog_id', width : 25 , sortable: true, renderer : function(value){
                return '<img src="/images/view.png" history_id="'+value+'"/>';
            }, sortable: true, menuDisabled : true },
            { text: '실행시간',  dataIndex: 'request_time', width : 170},
            { text: '서버', dataIndex: 'agent_name' },
            { text: '소스IP', dataIndex: 'ip'},
            { text: '로그인ID', dataIndex: 'login_id'},
            { text: '클래스', dataIndex: 'class_name' },
            { text: '쿼리유형', dataIndex: 'sql_type', width : 60},
            { text: 'WhiteSQL', dataIndex: 'whitesql_yn', width : 60, renderer : function(value){
                return value == 1 ? 'Yes' : 'No';
            }},
            { text: '변경SQL', dataIndex: 'convsql_yn', width : 60, renderer : function(value){
                return value == 1 ? 'Yes' : 'No';
            }},
            { text: '결과값 저장 여부', dataIndex: 'result_data_saved', width : 100, renderer : function(value){
                return value == 1 ? 'Yes' : 'No';
            }},
            { text: 'PrivacySQL', dataIndex: 'privacy_type', width : 100},
            { text: '쿼리', dataIndex: 'query', flex: 1 },            
            { text: '실행결과', dataIndex: 'execute_yn', width : 60},
            { text: '수행시간', dataIndex: 'exec_elapsedtime', width : 60},
            { text: '결과건수', dataIndex: 'result_count', width : 60},
            { text: '동작모드', dataIndex: 'agent_mode', width : 80}
        ];
    },

    search : function(){

        var fdate = Ext.getCmp(this.id+'-fdate');
        var tdate = Ext.getCmp(this.id+'-tdate');
        var fdate_val = fdate.getValue();
        var tdate_val = tdate.getValue();

        if((fdate_val && tdate_val) && fdate_val.getTime() > tdate_val.getTime()){

            fdate.setValue(tdate_val);
            tdate.setValue(fdate_val);
        }        

        var params = Ext.getCmp('form-'+this.id).getValues();        
        var grid   = Ext.getCmp('grid-'+this.id);

        this.getApplication().fireEvent('grid-search', grid, params);
    },

    exportSQLLog : function(){
        
        var params = Ext.getCmp('form-'+this.id).getValues();

        params.server = this.getApplication().serverId;
        location.href = "/log/sql/export?"+Ext.urlEncode(params);
    }
});