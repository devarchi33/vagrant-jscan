Ext.define('WhiteSQL.controller.log.ConvertedSQL-Detail', {
    extend: 'Ext.app.Controller',

    initWindow : function(ymd, agent_id, uniqsql_id, class_id){
                
        Ext.create('Lib.Window', {
            id : 'window-'+this.id+'-detail',
            application : this.application,
            title : 'Detail Log',
            width : 900,
            height: '100%',
            items : [
                this.initView(ymd, agent_id, uniqsql_id, class_id)
            ]
        });
    },

    initView : function(ymd, agent_id, uniqsql_id, class_id){

        var data = {};
        Ext.Ajax.request({
            url: '/log/converted_sql/getDetailViewData/'+ymd+'/'+agent_id+'/'+uniqsql_id+'/'+class_id,
            type : 'json',
            async:false,
            scope : this,
            success: function(res){

                try{

                    data = Ext.JSON.decode(res.responseText);
                }
                catch(e){

                    data = {};
                }
            }
        });

        var form = {
            id : 'form-'+this.id,
            xtype: 'container',
            layout: 'vbox',
            width : '100%',
            height: '100%',
            padding: '5 5 5 5',
            defaults : {
                labelWidth: 100,
                width : '100%',
                anchor : '100%',
                xtype : 'displayfield',
                labelPad : 5,
                labelClsExtra : 'x-panel-header-default'
            },
            items:[
                {
                    fieldLabel: '호스트명',
                    value : data.agent_name
                },{
                    xtype : 'fieldset',
                    title: 'Unique SQL',
                    width : '100%',
                    height : 100,
                    padding : 10,
                    autoScroll : true,
                    html : data.uniqsql,
                    flex : 1
                },
                this.initChart(ymd, agent_id, uniqsql_id, class_id),
                this.initGrid(ymd, agent_id, uniqsql_id, class_id),
                {
                    xtype : 'container',
                    layout : 'hbox',
                    margin : '5 0 0 0',
                    flex : 1,
                    defaults : {
                        xtype : 'fieldset',
                        width : '100%',
                        height : '100%',
                        flex  : 1, 
                        padding : 10,
                        autoScroll : true
                    },
                    items:[
                        {
                            id : this.id+'-org-sql',
                            title: '원본 SQL',
                            margin : '0 5 0 0'
                        },
                        {
                            id : this.id+'-pol-sql',
                            title: '정책 SQL',
                            margin : '0 0 0 5'
                        }
                    ]
                }
            ]
        };

        return form;
    },
    
    /**
     * initDetailGrid
     *
     * 상세보기 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGrid : function(ymd, agent_id, uniqsql_id, class_id){

        var columns = this.makeListColumns();

        var grid = Ext.create('Lib.Grid', {
            id       : 'grid-'+this.id,
            url      : '/log/converted_sql/getDetailListData/'+ymd+'/'+agent_id+'/'+uniqsql_id+'/'+class_id,
            columns  : columns,
            border   : true,
            listeners: {
                scope : this,
                itemclick: function(grid, record, item, index, e, eOpts) {

                    Ext.getCmp(this.id+'-org-sql').update(record.raw.org_sql);
                    Ext.getCmp(this.id+'-pol-sql').update(record.raw.pol_sql);
                }
            }
        });

        return grid;
    },

    initChart : function(ymd, agent_id, uniqsql_id, class_id){

        var chart = Ext.create('Ext.chart.Chart', {
            width : '100%',
            height : 150,
            style: 'background:#fff',
            border : true,
            animate: true,
            margin : '0 0 5 0',
            store: Ext.create('Ext.data.Store',{
                id : 'store-'+this.id+'-Detail',
                fields: ['time', 'value'],
                autoLoad: true,
                proxy: {
                    type: 'ajax',
                    url:'/log/converted_sql/getDetailChartData/'+ymd+'/'+agent_id+'/'+uniqsql_id+'/'+class_id,
                    reader: {
                        type: 'json'
                    }
                }
            }),
            shadow: true,
            theme: 'Category1',
            axes: [{
                type: 'Numeric',
                minimum: 0,
                position: 'left',
                fields: ['value'],
                minorTickSteps: 1,
                grid: {
                    odd: {
                        opacity: 1,
                        fill: '#ddd',
                        stroke: '#bbb',
                        'stroke-width': 0.5
                    }
                }
            }, {
                type: 'Category',
                position: 'bottom',
                fields: ['time']
            }],
            series: [{
                type: 'line',
                highlight: {
                    size: 7,
                    radius: 7
                },
                axis: 'left',
                xField: 'time',
                yField: 'value',
                markerConfig: {
                    type: 'cross',
                    size: 4,
                    radius: 4,
                    'stroke-width': 0
                }
            }]
        });

        return chart;
    },

    /**
     * makeListColumns
     *
     * 상세정보 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeListColumns : function(){

        return [
            { text: '번호', dataIndex: 'num' },
            { text: '실행시간', dataIndex: 'request_time', flex: 1 },
            { text: '변경', dataIndex: 'change_yn' },
            { text: 'IP', dataIndex: 'ip'},
            { text: '수행시간', dataIndex: 'exec_elapsedtime'},
            { text: '결과건수', dataIndex: 'result_count'}
        ];
    }
});