Ext.define('WhiteSQL.controller.log.ConvertedSQL', {
    extend: 'Lib.TabController',

    /**
     *
     * 탭 생성
     *
     * @return component Ext.container.Container
     */
    initTab : function(){

        this.setTab(Ext.create('Lib.Tab', {
            id : this.tabId,
            title : 'Converted SQL Log',
            items : [
                this.initGridSearch(),
                this.initGrid()
            ]
        }));
    },

    /**
     * initGridSearch
     *
     * 그리드 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGridSearch : function(){

        var required = '<span style="color:red;font-weight:bold" data-qtip="Required">*</span>';

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'vbox',
            frame : true,
            width : '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 0',
            defaults : {
                labelWidth: 80
            },
            items:[
                {
                    xtype   : 'container',
                    layout  : 'hbox',
                    margin  : '0 0 5 0',
                    defaults: {
                        labelWidth: 80,
                        margin : '0 10 0 0'
                    },
                    items : [
                        {
                            xtype       : 'displayfield',
                            id          : 'server-name-'+this.getTabId(),
                            fieldLabel  : "서버",
                            fieldBodyCls: "align-top",
                            width       : 200,
                            value       : this.application.getServerName()
                        },
                        {
                            xtype       : 'displayfield',
                            fieldLabel  : "기간",
                            fieldBodyCls: "align-top",
                            width       : 80
                        },
                        {
                            xtype: 'datefield',
                            format: 'Y-m-d',
                            id : this.id+'-fdate',
                            name : this.id+'-fdate',
                            width: 120,
                            margin : '0 5 0 0',
                            value  : new Date()

                        },
                        {
                            xtype : 'text',
                            text : '~',
                            margin : '0 5 0 0'
                        },
                        {
                            xtype: 'datefield',
                            format: 'Y-m-d',
                            id : this.id+'-tdate',
                            name : this.id+'-tdate',
                            width: 120,
                            value  : new Date()
                        }
                    ]
                },
                {
                    xtype:'container',
                    layout : 'hbox',
                    margin : '0 0 5 0',
                    defaults : {
                        labelWidth: 80,
                        margin : '0 5 0 0'
                    },
                    items : [
                        {
                            xtype:'textfield',
                            fieldLabel: '쿼리',
                            name: this.id+'-query',
                            width : 734
                        },{
                            xtype:'button',
                            icon : '/images/find.png',
                            text: '검색',
                            scope : this,
                            handler : this.search
                        },{
                            xtype:'button',
                            icon : '/images/detail_find.png',
                            text: '상세검색',
                            scope : this,
                            handler : this.search
                        }
                    ]
                }

            ]
        };
        return form;
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGrid : function(mode){

        var columns = this.makeListColumns();

        var grid = Ext.create('Lib.Grid', {
            id       : 'grid-'+this.id,
            url      : '/log/converted_sql/getListData',
            title    : mode,
            columns  : columns,
            listeners: {
                scope : this,
                cellclick: function(grid, cellEl, cellIdx, record, rowEl, rowIdx, evtObj) {

                    if(cellIdx == 0){

                        this.getApplication().openWindow('log.ConvertedSQL-Detail', 
                            record.raw.ymd, 
                            record.raw.agent_id, 
                            record.raw.uniqsql_id, 
                            record.raw.class_id
                        );
                    }
                }
            }
        });

        return grid;
    },

    search : function(){

        var fdate = Ext.getCmp(this.id+'-fdate');
        var tdate = Ext.getCmp(this.id+'-tdate');
        var fdate_val = fdate.getValue();
        var tdate_val = tdate.getValue();

        if((fdate_val && tdate_val) && fdate_val.getTime() > tdate_val.getTime()){

            fdate.setValue(tdate_val);
            tdate.setValue(fdate_val);
        }        

        var params = Ext.getCmp('form-'+this.id).getValues();        
        var grid   = Ext.getCmp('grid-'+this.id);

        this.getApplication().fireEvent('grid-search', grid, params);
    },

    /**
     * makeListColumns
         *
     * 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeListColumns : function(){

            // 'date_f as ymd',
            // 'sum_log.agent_id',
            // 'sum_log.uniqsql_id',
            // 'sum_log.class_id',

        return [
            // { text: '작업시간',  dataIndex: 'agent_name'},
            { dataIndex: 'sqllog_id', width : 25 , sortable: true, renderer : function(value){
                //console.log(value);
                return '<img src="/images/view.png" history_id="'+value+'"/>';
            }, sortable: true, menuDisabled : true },
            { text: '호스트명', dataIndex: 'agent_name' },
            { text: '날짜', dataIndex: 'ymd'},
            { text: '요청쿼리', dataIndex: 'query', flex: 1 },
            { text: '클래스명', dataIndex: 'class_string' },
            { text: '실행건수', dataIndex: 'sum_count'},
            { text: '평균실행시간', dataIndex: 'avg_elapsedtime'},
            { text: '결과건수', dataIndex: 'avg_result_count'}
        ];
    }
});