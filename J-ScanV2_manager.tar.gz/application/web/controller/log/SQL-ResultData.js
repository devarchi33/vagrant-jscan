Ext.define('WhiteSQL.controller.log.SQL-ResultData', {
    extend: 'Ext.app.Controller',

    initWindow : function(sqllog_id){

        this.window = Ext.create('Lib.Window', {
            id : 'window-'+this.id,
            application : this.application,
            title : '결과 데이터',
            width : 900,
            height: 400,
            buttons : this.initButtons(),
            items : this.initDetail(sqllog_id)
        });
    },

    initDetail : function(sqllog_id){

        var record = {};

        Ext.Ajax.request({
            url: '/log/sql/getResultData/'+sqllog_id,
            type : 'json',
            scope : this,
            async : false,
            success: function(res){
                
                record = Ext.JSON.decode(res.responseText);
            },
            failure: function(result, request){

                Ext.Msg.alert("Failed", result.responseText);
            }
        });

        return {
            xtype   : 'form',
            layout  : 'vbox',
            bodyPadding : '5 5 5 5',
            border  : false,
            autoScroll : true,
            flex : 1,
            items:[
                this.initFieldSet({
                    title : 'Result Data', 
                    items : {
                        value : record.data
                    }
                })
            ]
        }
    },

    initFieldSet : function(config){

        return Ext.apply({
            xtype : 'fieldset',
            width : '100%',
            defaults : {
                labelWidth: 100,
                labelStyle: 'color:#008000',
                width : '100%',
                anchor : '100%',
                xtype : 'displayfield',
                labelPad : 5
            }
        }, config);
    },

    /**
     * initButtons
     *
     * 버튼 생성
     *
     * @access public
     *
     * @return button array
     */
    initButtons : function(){

        return [{
            text : '닫기',
            handler : function(){

                this.up("window").destroy();
            }
        }];
    }
});