

Ext.namespace('Ext.WhiteSQL');
//set up config path for your app

Ext.Loader.setConfig({
    enabled: true,
    paths: {
        'CodeMirror' : '/js/codemirror',
        'Lib'        : '/web/lib',
        'Helper'     : '/web/helper'
    }
});

Ext.application({
    appFolder             : '/web',
    name                  : 'WhiteSQL',
    MainTab               : null,
    passedModuleCheck     : false,
    passedPHPINICheck     : false,
    passedPermissionCheck : false,
    launch : function() {

        Ext.syncRequire('Helper.Common');
        Ext.syncRequire('Lib.Fix-QuickTip');
        Ext.syncRequire('Lib.Event');

        this.initLayout();

        var host = Ext.getCmp('install-db-host');
        var user = Ext.getCmp('install-db-user');
        var pass = Ext.getCmp('install-db-pass');
        var name = Ext.getCmp('install-db-name');

        host.on('change' , this.disableSettingAdmin);
        user.on('change' , this.disableSettingAdmin);
        pass.on('change' , this.disableSettingAdmin);
        name.on('change' , this.disableSettingAdmin);
    },

    initLayout : function(){

        this.Layout = Ext.create('Ext.container.Viewport', {
            renderTo: Ext.getBody(),
            xtype : 'container',
            layout: 'vbox',
            items: [
                this.initHeader(),
                this.initSettingForm()
            ]
        });
    },

    initHeader : function(){
        return {
            xtype : 'panel',
            layout : 'hbox',
            height: 50,
            flex : 0,
            border: 0,
            width : '100%',
            items : [
                {
                    xtype : 'image',
                    width : 109,
                    height : 32,
                    margin : '7 10 0 5',
                    src : '/images/jdbSee_bi.gif',
                    html : 'logo'
                },
                {
                    flex : 1,
                    xtype : 'container',
                    height : 50,
                    html : ''
                }
            ]
        }
    },

    initSettingForm : function(){

        return {
            xtype       : 'form',
            id          : 'install',
            layout      : 'vbox',
            width       : '100%',
            height      : '100%',
            flex        : 1,
            activeItem  : 0, // index or id
            bodyPadding : 10,
            border      : false,
            type        : 'json',
            autoScroll  :true,
            url         : '/install/install/save',
            items:[
                this.initPermissionCheck(),
                this.initPHPINICheck(),
                this.initModuleCheck(),
                this.initSettingDatabase(),
                this.initSettingAdmin(),
                this.initSettingSystem()
            ],
            // Reset and Submit buttons
            buttons: this.initButtons()
        }
    },


    /**
     * initPermissionCheck
     *
     * PHP INI CHECK
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    initPermissionCheck : function(){

        items = [];
        Ext.Ajax.request({
            url     : '/install/install/getDirectoryPermission',
            type    : 'json',
            async   : false,
            scope   : this,
            success : function(res){

                var data = Ext.JSON.decode(res.responseText);
                var pass = 0;
                Ext.Object.each(data, function(label, value){

                    items.push({
                        fieldLabel : label,
                        value      : value ? "이상 없음" : "퍼미션 변경 요망"
                    });

                    if(value == true) pass++;
                });

                if(Ext.Object.getSize(data) == pass) this.passedPermissionCheck = true;
            }
        });

        return {
            xtype : 'fieldset',
            title: '디렉토리 퍼미션 체크',
            padding : 10,
            layout : 'vbox',
            width : '100%',
            defaults : {
                labelWidth: 180,
                width : '100%',
                anchor : '100%',
                xtype : 'displayfield',
                labelPad : 5,
                labelClsExtra : 'x-panel-header-default'
            },
            items : items
        };
    },   

    /**
     * initPHPINICheck
     *
     * PHP INI CHECK
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    initPHPINICheck : function(){

        items = [];
        Ext.Ajax.request({
            url     : '/install/install/getPHPINI',
            type    : 'json',
            async   : false,
            scope   : this,
            success : function(res){

                var data = Ext.JSON.decode(res.responseText);
                Ext.Object.each(data, function(label, value){

                    items.push({
                        fieldLabel : label,
                        value      : value
                    });

                    this.passedPHPINICheck = value;
                }, this);
            }
        });

        // var task = {
        //     run: function(){

        //         Ext.Ajax.request({
        //             url: '/server/resource/usage',
        //             type : 'json',
        //             success: function(res){

        //                 var result = Ext.JSON.decode(res.responseText);
        //                 Ext.getCmp('resource-usage-cpu').updateProgress(result.cpu / 100, result.cpu + '%');
        //                 Ext.getCmp('resource-usage-memory').updateProgress(result.mem / 100, result.mem + '%');
        //                 Ext.getCmp('resource-usage-disk').updateProgress(result.disk / 100, result.disk + '%');
        //             }
        //         });
        //     },
        //     interval: 1000 //1 second
        // };
        // Ext.TaskManager.start(task);
        return {
            xtype : 'fieldset',
            title: 'php.ini 셋팅 확인',
            padding : 10,
            layout : 'vbox',
            width : '100%',
            defaults : {
                labelWidth: 180,
                width : '100%',
                anchor : '100%',
                xtype : 'displayfield',
                labelPad : 5,
                labelClsExtra : 'x-panel-header-default'
            },
            items : items
        };
    },   

    /**
     * initModuleCheck
     *
     * PHP INI CHECK
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    initModuleCheck : function(){

        items = [];
        Ext.Ajax.request({
            url     : '/install/install/getModule',
            type    : 'json',
            async   : false,
            scope   : this,
            success : function(res){

                var data = Ext.JSON.decode(res.responseText);
                var pass = 0;
                var cnt  = 0;
                Ext.Object.each(data, function(label, value){

                    items.push({
                        fieldLabel : label,
                        value      : value == true ? "설치됨" : "설치를 하셔야 합니다."
                    });

                    if(value == true) pass++;
                });
                
                if(Ext.Object.getSize(data) == pass) this.passedModuleCheck = true;
            }
        });

        return {
            xtype : 'fieldset',
            title: '설치된 모듈 확인',
            padding : 10,
            layout : 'vbox',
            width : '100%',
            defaults : {
                labelWidth: 180,
                width : '100%',
                anchor : '100%',
                xtype : 'displayfield',
                labelPad : 5,
                labelClsExtra : 'x-panel-header-default'
            },
            items : items
        };
    },   

     /**
     * initSettingDatabase
     *
     * 데이터 베이스 정보 입력
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    initSettingDatabase : function(){

        return {
            xtype         : 'fieldset',
            id            : 'fieldset-setting-database',
            title         : '데이터 베이스 정보 입력',
            padding       : 10,
            layout        : 'vbox',
            width         : '100%',
            disabled      : true,
            maskOnDisable : true,
            defaults      : {
                labelWidth: 180,
                width : '100%',
                anchor : '100%',
                labelPad : 5,
                labelClsExtra : 'x-panel-header-default'
            },
            items : [
                this.initField('install-db-host', 'textfield', 'DB Host', 'localhost'),
                this.initField('install-db-user', 'textfield', 'DB User ID', 'root'),
                this.initField('install-db-pass', 'password', 'DB User Password', ''),
                this.initField('install-db-name', 'textfield', 'DB Name', 'WhiteSQL'),
                this.initDatabaseButtons()
            ],
            listeners : {
                scope    : this,
                boxready : function(fieldset){

                    if(this.passedModuleCheck == true && this.passedPermissionCheck == true){

                        fieldset.setDisabled(false);
                    }
                }
            }
        };
    },

    /**
     * initDatabaseButtons
     *
     * database 버튼 생성
     *
     * @access public
     *
     * @return button array
     */
    initDatabaseButtons : function(){

        return {
            xtype : 'container',
            layout : 'hbox',
            defaults : {
                xtype : 'button'
            },
            items : [{
                text: '연결확인',
                handler: function() {
                    
                    fieldset = this.up('fieldset');
                    textfields = fieldset.query('textfield');
                    params = {};
                    textfields.forEach(function(textfield){ 

                        k = textfield.getId();
                        v = textfield.getValue();
                        params[k] = v; 
                    });

                    Ext.Ajax.request({
                        url     : '/install/install/checkDatabaseConnection',
                        type    : 'json',
                        async   : false,
                        scope   : this,
                        params  : params,
                        method  : 'post',
                        success : function(res){

                            res = Ext.JSON.decode(res.responseText);
                            Ext.Msg.alert('DB 연결 시도', res.message);

                            if(res.result == 'success'){

                                Ext.getCmp('fieldset-setting-admin').setDisabled(false);
                                Ext.getCmp('fieldset-setting-system').setDisabled(false);
                            }
                        }
                    });
                }
            }]
        };
    },

    /**
     * initSettingAdmin
     *
     * 관리자 정보 입력
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    initSettingAdmin : function(){

        return {
            xtype         : 'fieldset',
            id            : 'fieldset-setting-admin',
            title         : '관리자 정보 입력',
            padding       : 10,
            layout        : 'vbox',
            width         : '100%',
            disabled      : true,
            maskOnDisable : true,
            defaults      : {
                labelWidth: 180,
                width : '100%',
                anchor : '100%',
                labelPad : 5,
                labelClsExtra : 'x-panel-header-default'
            },
            items : [
                this.initField('install-admin-id', 'textfield', 'Admin ID', 'admin'),
                this.initField('install-admin-name', 'textfield', 'Admin Name', '슈퍼관리자'),
                this.initField('install-admin-pass', 'password', 'Admin Password', ''),
                this.initField('install-admin-pass-confirm', 'password', 'Admin Password Confirm', ''),
                this.initField('install-admin-email', 'email', 'Super Admin Email', '')
            ]
        };
    },    

    /**
     * disableSettingAdmin
     *
     * 관리자 정보 입력
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    disableSettingAdmin : function(){

        Ext.getCmp('fieldset-setting-admin').setDisabled(true);
        Ext.getCmp('fieldset-setting-system').setDisabled(true);
        Ext.getCmp('button-install').setDisabled(true);
    },

    /**
     * initSettingSystem
     *
     * 시스템 설정 정보 입력
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    initSettingSystem : function(){

        return {
            xtype         : 'fieldset',
            id            : 'fieldset-setting-system',
            title         : '시스템 설정 정보 입력',
            padding       : 10,
            layout        : 'vbox',
            width         : '100%',
            disabled      : true,
            maskOnDisable : true,
            defaults      : {
                labelWidth: 180,
                width : '100%',
                anchor : '100%',
                labelPad : 5,
                labelClsExtra : 'x-panel-header-default'
            },
            items : [
                this.initField('system-manager-log-port', 'numberfield', 'Manager Log Port', 20222),
                this.initField('system-manager-listen-port', 'numberfield', 'Manager Listen Port', 20224),
                this.initField('system-state-check-period', 'numberfield', 'System State Check Period', 5),
                this.initField('system-agent-health-check-period', 'numberfield', 'Agent Health Check Period', 10),
                this.initField('system-log-file-size', 'numberfield', 'Log File Size', 1048576),
                this.initField('system-max-agent-num', 'numberfield', 'Maximum Agent Number', 5)
            ]
        };
    },    
    
    /**
     * initField
     *
     * 입력 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    initField : function(id, type, label, value){

        inputType = 'text';
        vtype = null;

        if(!value || typeof value == 'undefined') value = "";

        if(type == 'password'){

            inputType = type;
            type = 'textfield';
        }
        else if(type == 'email'){

            vtype = type;
            type = 'textfield';
        }

        return {
            xtype             : type,
            vtype             : vtype,
            fieldLabel        : label,
            //fieldSubTpl       : new Ext.XTemplate('<img src="images/module.png"/>'),
            inputType         : inputType,
            id                : id,
            name              : id,
            value             : value,
            allowBlank        : false,
            hideTrigger       : true,
            keyNavEnabled     : false,
            mouseWheelEnabled : false
        };
    },

    /**
     * initButtons
     *
     * 버튼 생성
     *
     * @access public
     *
     * @return button array
     */
    initButtons : function(){

        return [
            {
                id: 'button-reset',
                text: '설정 초기화',
                handler: function() {

                    this.up('form').getForm().reset();
                }
            }, 
            {
                id: 'button-install',
                text: '설치하기',
                formBind: true, //only enabled once the form is vali
                disabled : true,
                handler: this.install
            }
        ];
    },

    /**
     * install
     *
     * 설치 하기 서브밋 전송
     *
     * @access public
     *
     * @return button array
     */
    install : function(btn, event){

        form = this.up('form');

        if (form.isValid()) {

            form.submit({
                scope : this,
                waitMsg : '처리중 입니다.',
                success: function(form, action) {

                    var res = Ext.JSON.decode(action.response.responseText);

                    Ext.Msg.alert('Status', res.message, function(){

                        document.location.replace("/");
                    });
                },
                failure: function(form, action) {

                    var res = Ext.JSON.decode(action.response.responseText);

                    Ext.Msg.alert('Failed', res.message);
                }
            });
        }
    }
});