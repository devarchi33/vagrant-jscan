Ext.define('WhiteSQL.controller.main.Login', {
    extend: 'Ext.app.Controller',
    
    /**
     * init
     * 
     * 컨트롤러 초기화 메소드.
     * 
     * @access public
     *
     * @return 
     */
    init:function(){

        this.LoginLayout = Ext.create('Ext.container.Viewport', {
            renderTo: Ext.getBody(),
            layout : 'fit',
            width : '100%',
            height : '100%',
            style: "background-color:#121B20",
            items: this.initLoginForm()
        });
    },

    /**
     * login
     *
     * 로그인
     *
     * @access public
     *
     */
    initLoginForm : function(){

        this.login_form = Ext.create('Ext.form.Panel', {
            url : '/main/login/action',
            type : 'json',
            width: 1243,
            height: 995,
            bodyStyle: "background-image:url(/images/login/sql_login.jpg)",
            border: false,
            style: 'margin:0 auto',
            defaults : {
                width : 240,
                height : 30,
                layout : 'absolute',
                x : 580,
                border:false
            },
            items : [{                   
                y : 542,
                items : {
                    xtype : 'textfield',
                    anchor : '100%',
                    id : 'login-id',
                    name : 'login-id',
                    allowBlank : false,
                    height : 30,
                    border :false,
                    listeners : {
                        scope:this,  
                        specialkey: this.login
                    }
                }
            },{
                y : 572,
                items : {
                    xtype : 'textfield',
                    anchor : '100%',
                    id : 'login-pw',
                    name : 'login-pw',
                    allowBlank : false,
                    height : 30,
                    border : false,
                    listeners : {
                        scope:this,  
                        specialkey: this.login
                    }
                }
            }]
        });

        return this.login_form;
    },

    login : function(textfield, event){

        if(event.getKey() != event.ENTER){  

            return false;
        } 

        if (this.login_form.isValid()) {

            this.login_form.submit({
                scope : this,
                params : { server : this.getApplication().serverId },
                success: function(form, action) {

                    var result = Ext.JSON.decode(action.response.responseText);

                    document.location.reload();
                },
                failure: function(form, action) {

                    var result = Ext.JSON.decode(action.response.responseText);

                    Ext.Msg.alert('Failed', result.message);
                }
            });
        }
    }
});