Ext.chart.Legend.override({
    minWidth:0,    
    minHeight:0,
    getBBox:function () {
        var me = this;

        if (me.width < me.minWidth)
            me.width = me.minWidth;


        if (me.height < me.minHeight)
            me.height = me.minHeight;

        return {
            x:Math.round(me.x) - me.boxStrokeWidth / 2,
            y:Math.round(me.y) - me.boxStrokeWidth / 2,
            width:me.width,
            height:me.height
        };
    }
});

Ext.define('WhiteSQL.controller.main.Home', {
    extend     : 'Lib.TabController',
    alignMode  : 'tile',
    viewType   : 'now',
    panelStore : {},
    eventColor : {
        notice    : '#00BF00',
        attention : '#DBDB00',
        alert     : '#FF8000',
        danger    : '#800000',
        serious   : '#ff0000'
    },
    /**
     *
     * 탭 생성
     *
     * @return component Ext.container.Container
     */
    initTab : function(){

        Ext.syncRequire('WhiteSQL.chart.theme.ThemeBlue');

        var tab = Ext.create('Lib.Tab', {
            id : this.tabId,
            title : 'Home',
            closable: false,
            items : [
                {
                    dockedItems: [
                        {
                            xtype: 'toolbar',
                            dock: 'top',
                            defaults : {
                                toggleGroup: 'timeButton',
                                scope : this,
                                cls : 'hangul',
                                xtype : 'button',
                                enableToggle : true,
                                handler: this.setViewType
                            },
                            items: [
                                {
                                    id : 'home-button-view-now',
                                    icon : '/images/icon_realtime16x16.png',
                                    text : '실시간',
                                    pressed : true
                                },
                                {
                                    id : 'home-button-view-day',
                                    icon : '/images/icon_day16x16.png',
                                    text : '1일'
                                },
                                {
                                    id   : 'home-button-view-week',
                                    icon : '/images/icon_week16x16.png',
                                    text : '1주일'
                                    
                                },
                                {
                                    id   : 'home-button-view-month',
                                    icon : '/images/icon_month16x16.png',
                                    text : '1개월'
                                },
                                {
                                    xtype : 'text',
                                    id    : 'home-view-type-period',
                                    text  : this.getDatePeriod('now'),
                                    style : {
                                        padding: '0px 0px 0px 0px'
                                    }
                                }
                            ]
                        }
                    ]
                },
                this.initMainContainer()
            ]
        });

        this.setTab(tab);

        var task = {
            scope : this,
            run: function(){

                if(this.viewType != 'now') return;
                if(tab.isVisible() == false) return;

                this.loadMainRealTime();
            },
            interval: 1000 //1 second
        };
        Ext.TaskManager.start(task);

        Ext.util.Observable.observe(WhiteSQL.getApplication(), {
            scope : this,
            'server-tree-selected' : function(){

                this.loadMainRealTime();
            }
        });
        
    },

    getDatePeriod : function(mode){

        var date, from, to = null;

        if(mode == 'now'){

            from = Ext.Date.format(new Date(), 'Y-m-d 00:00:00'),
            to = '현재';
        }
        else if(mode == 'day'){

            date = Ext.Date.format(Ext.Date.subtract(new Date(), Ext.Date.DAY, 1), 'Y-m-d'),
            from = date+' 00:00:00', to = date+' 23:59:59';
        }
        else if(mode == 'week'){

            date = Ext.Date.subtract(new Date(), Ext.Date.DAY, 1),
            from = Ext.Date.format(Ext.Date.subtract(new Date(), Ext.Date.DAY, 7), 'Y-m-d 00:00:00'),
            to = Ext.Date.format(date, 'Y-m-d 23:59:59');
        }
        else if(mode == 'month'){

            date = Ext.Date.subtract(new Date(), Ext.Date.DAY, 1),
            from = Ext.Date.format(Ext.Date.subtract(new Date(), Ext.Date.MONTH, 1), 'Y-m-d 00:00:00'),
            to = Ext.Date.format(date, 'Y-m-d 23:59:59');
        }

        return '[' + from + ' ~ ' + to + ']';
    },

    initMainContainer : function(){

        return {
            id : 'main-panel-container',
            xtype : 'container',
            autoScroll : true,
            padding : '0 20 0 0',
            layout: {
                type: 'table',
                columns: 2,
                tableAttrs: {
                    style: {
                        width: '100%'
                    }
                },
                tdAttrs: {
                   style:{
                       width: '25%',
                       'vertical-align' : 'top'
                   }
                }
            },
            flex : 1,
            defaults : {
                xtype : 'panel',
                layout : 'fit',
                cls : 'hangul',
                tools: [{
                    scope : this,
                    type:'maximize',
                    handler: function(event, toolEl, owner, tool){

                        var container = Ext.getCmp("main-panel-container");
                        var panel = owner.up("panel");

                        if(tool.type == 'maximize'){

                            var panels = container.query('>panel');
                            Ext.invoke(panels, 'hide');
                            panel.setWidth(container.getWidth() - 30);
                            panel.setHeight(container.getHeight() - 5);
                            panel.show();

                            tool.setType('restore');
                        }
                        else {

                            var panels = container.query('>panel');
                            Ext.invoke(panels, 'restoreSize');
                            Ext.invoke(panels, 'show');
                            tool.setType('maximize');
                        }
                    }
                }],
                listeners : {
                    boxready : function(panel){

                        var width = panel.getWidth();
                        var height = panel.getHeight();

                        Ext.applyIf(panel, {
                            originalWidth : width,
                            originalHeight : height,
                            restoreSize : function(){

                                this.setWidth(this.originalWidth);
                                this.setHeight(this.originalHeight);
                            }
                        });
                    }
                }
            },
            listeners : {
                scope : this,
                boxready : function(container){

                    this.initMainPanels(container);
                }
            }
        };
    },

    initMainPanels : function(container){

        container.add([
        {
            title:'서버별 현황',
            margin : '5 0 0 0',
            width : '100%',
            colspan : 2,
            items : this.initGrid('Total')
        },{
            margin : '5 5 0 0',
            title:'전체 이벤트 발생 건수',
            items : this.initChartEvent()
        },{
            margin : '5 0 0 0',
            title:'정책 유형별 쿼리 수',
            items : this.initChartPolicy()
        },
        {
            colspan : 2,
            header  : false,
            border  : false,
            width : '100%',
            margin : '5 0 0 0',
            items   : {
                xtype : 'container',
                layout : 'hbox',
                items : [
                    this.initChartMuchLookupIP(),
                    this.initChartMostAccessIp(),                    
                    this.initPersonalInfoAccessIP()
                ]
            }
        },{
            margin : '5 5 0 0',
            title:'데이터 조회 건수 Top 10',
            items : this.initGrid('ExecResultCount')
        },{
            margin : '5 0 0 0',
            title:'쿼리 수행 건수 Top 10',
            items : this.initGrid('ExecQueryCount')
        }]);
    },

    setViewType : function(button){
        
        var viewType = button.id.split('-')[3];
        var period = this.getDatePeriod(viewType);
        Ext.getCmp('home-view-type-period').setText(period);

        this.viewType = viewType;

        Ext.getCmp('main-panel-container').setLoading(true);
        
        if(this.viewType == 'now') return;

        this.loadMainRealTime();
    },

    initChartEvent : function(){

        var store = Ext.create('Ext.data.Store',{
            fields: [
                {name : 'event', type : 'string'},
                {name : 'value', type : 'int'}
            ],
            listeners : {
                datachanged : function(store){

                    form.removeAll();
                    Ext.Array.each(store.getRange(), function(record, idx){ 
                        
                        form.add({
                            fieldLabel: record.data.event,
                            value : record.data.value
                        });
                    });
                }
            }
        });

        var color = [
            '#00BF00',
            '#DBDB00',
            '#FF8000',
            '#800000',
            '#ff0000'
        ];

        var chart = Ext.create('Ext.chart.Chart', {
            flex : 1,
            height : 260,
            animate: true,
            shadow: false,
            store: store,
            theme : 'ThemeBlue',
            axes: [{
                type: 'Numeric',
                position: 'left',
                fields: 'value',
                title: false,
                grid: true,
                minimum: 0,
                majorTickSteps : 5,
                minorTickSteps : 1,
                label: {
                    renderer: function(v) {
                        return Math.round(v);
                    }
                }
            }, {
                type: 'Category',
                position: 'bottom',
                fields: 'event',
                minWidth : 200,
                minorTickSteps : 1,
                title: false
            }],
            series: [{
                type: 'bar',
                style: {
                    opacity: 0.7
                },
                highlight : {
                    fill : '#ffffff',
                    stroke : '#cccccc', 
                    lineWidth : 1
                },
                xField: 'event',                
                yField: 'value',
                column: true,
                renderer: Ext.Function.bind(function(sprite, record, attributes, index, store) {
                        
                    var max_width = 25;
                    if(attributes.width > max_width){

                        return Ext.apply(attributes, {
                            x     : (attributes.x + (attributes.width / 2)) - (max_width / 2),
                            width : max_width,
                            fill  : color[index]
                        });
                    }
                    else {

                        return attributes;
                    }
                }, this),
                tips: {
                    trackMouse: true,
                    width: 150,
                    renderer: function(storeItem, item) {

                        this.setTitle(item.value[0] + " : "+ item.value[1].toString());
                    }
                }
            }]
        });
        
        var form = Ext.create('Ext.form.Panel', {
            xtype : 'form',
            width : 170,
            height : 260,
            padding : '5 5 5 5',
            defaults : {
                labelWidth: 90,
                width      : '100%',
                anchor     : '100%',
                xtype      : 'displayfield',
                labelPad   : 5,
                labelStyle : 'color:#008000',
                margin     : 5,
                fieldStyle : {
                    "text-align": 'right',
                }
            }
        });

        this.panelStore.ChartEvent = chart.store;

        return {
            xtype : 'panel',
            layout : 'hbox',
            border : false,
            flex   : 1,
            items : [
                chart,
                form
            ]
        };
    },

    initChartPolicy : function(){

        var store = Ext.create('Ext.data.Store',{
            fields: [
                {name : 'event', type : 'string'},
                {name : 'value', type : 'int'},
                {name : 'size', type : 'int'}
            ],
            listeners : {
                datachanged : function(store){

                    form.removeAll();
                    Ext.Array.each(store.getRange(), function(record, idx){ 
                        
                        form.add({
                            fieldLabel: record.data.event,
                            value : record.data.value
                        });
                    });
                }
            }
        });

        var chart = Ext.create('Ext.chart.Chart', {
            xtype : 'chart',
            flex : 1,
            height : 260,
            id : 'ChartPolicy',
            style: 'background:#fff',
            animate: true,
            shadow: false,
            store: store,
            series: [{
                type: 'pie',
                animate: true,
                angleField: 'size', //bind angle span to visits
                //lengthField: 'value', //bind pie slice length to views,
                highlight: {
                    segment: {
                        margin: 20
                    }
                },
                label: {
                    field: 'event',   //bind label text to name
                    display: 'middle', //rotate labels (also middle, out).
                    font: '14px Arial',
                    contrast: true,
                    renderer: function(value, label, record) {

                        return record.data.size > 0 ? value : '';
                    }
                },                                
                style: {
                    'stroke-width' : 1,
                    'stroke'       : '#fff',
                    opacity: 0.8
                },
                tips: {
                    trackMouse: true,
                    width: 140,
                    height: 28,
                    renderer: function(storeItem, item) {

                        this.setTitle(storeItem.get('event') + ' : ' + storeItem.get('value'));
                    }
                },
                //add renderer
                renderer: function(sprite, record, attr, index, store) {

                    var color = [ "#FFB347", "#FFD247","#FFF047", "#EFFF47", "#FF9447", "#FF7647", "#FF5747"][index];
                        
                    return Ext.apply(attr, {
                        fill: color
                    });
                }
            }]
        });
        
        var form = Ext.create('Ext.form.Panel', {
            xtype : 'form',
            width : 150,
            height : 260,
            padding : '5 5 5 5',
            defaults : {
                labelWidth: 90,
                width      : '100%',
                anchor     : '100%',
                xtype      : 'displayfield',
                labelPad   : 5,
                labelStyle : 'color:#008000',
                margin     : 5,
                fieldStyle : {
                    "text-align": 'right',
                }
            }
        });

        this.panelStore.ChartPolicy = store;

        return {
            xtype : 'panel',
            layout : 'hbox',
            border : false,
            flex   : 1,
            items : [
                chart,
                form
            ]
        };
    },

    initChartMuchLookupIP : function(){

        var store = Ext.create('Ext.data.Store',{
            fields: [
                {name : 'ip', type : 'string'},
                {name : 'value', type : 'int'}
            ],
            listeners : {
                datachanged : function(store){

                    form.removeAll();
                    Ext.Array.each(store.getRange().sort(function(a, b){

                        return b.data.value - a.data.value;

                    }), function(record, idx){ 
                        
                        form.add({
                            fieldLabel: record.data.ip,
                            value : record.data.value
                        });
                    });
                }
            }
        });

        var chart = Ext.create('Ext.chart.Chart', {
            flex : 1,
            height : 200,
            animate: true,
            shadow: false,
            store: store,
            theme : 'ThemeBlue',
            axes: [{
                type: 'Numeric',
                position: 'bottom',
                fields: ['value'],
                label: {
                    renderer: Ext.util.Format.numberRenderer('0,0')
                },
                minimum: 0
            }, {
                type: 'Category',
                position: 'left',
                fields: ['ip'],
                hidden : true
            }],
            series: [{
                type: 'bar',
                axis: 'bottom',
                label: {
                    display: 'outside',
                    field: 'ip',
                    orientation: 'horizontal',
                    color: '#333',
                    contrast: true
                },
                xField: 'ip',
                yField: ['value'],
                tips: {
                    trackMouse: true,
                    width: 150,
                    renderer: function(storeItem, item) {

                        this.setTitle(item.value[0] + " : "+ item.value[1].toString());
                    }
                }
            }]
        });
        
        var form = Ext.create('Ext.form.Panel', {
            xtype : 'form',
            width : 170,
            height : 200,
            defaults : {
                labelWidth: 90,
                width : '100%',
                anchor : '100%',
                xtype : 'displayfield',
                labelPad : 5,
                labelStyle: 'color:#008000',
                margin : 5,
                fieldStyle : {
                    "text-align": 'right',
                }
            }
        });

        this.panelStore.MuchLookupIP = chart.store;

        return {
            xtype : 'panel',
            layout : 'hbox',
            bodyPadding : '5 5 5 5',
            margin : '0 5 0 0',
            flex   : 1,
            title  : '다량 조회 IP',
            items : [
                chart,
                form
            ]
        };
    },

    initChartMostAccessIp : function(){


        var store = Ext.create('Ext.data.Store',{
            fields: [
                {name : 'ip', type : 'string'},
                {name : 'value', type : 'int'}
            ],
            listeners : {
                datachanged : function(store){

                    form.removeAll();
                    Ext.Array.each(store.getRange().sort(function(a, b){

                        return b.data.value - a.data.value;

                    }), function(record, idx){ 
                        
                        form.add({
                            fieldLabel: record.data.ip,
                            value : record.data.value
                        });
                    });
                }
            }
        });

        var chart = Ext.create('Ext.chart.Chart', {
            flex : 1,
            height : 200,
            animate: true,
            style: 'background:#fff',
            shadow: false,
            store: store,
            theme : 'ThemeBlue',
            axes: [{
                type: 'Numeric',
                position: 'bottom',
                fields: ['value'],
                label: {
                    renderer: Ext.util.Format.numberRenderer('0,0')
                },
                minimum: 0
            }, {
                type: 'Category',
                position: 'left',
                fields: ['ip'],
                hidden : true
            }],
            series: [{
                type: 'bar',
                axis: 'bottom',
                label: {
                    display: 'outside',
                    field: 'ip',
                    orientation: 'horizontal',
                    color: '#333',
                    contrast: true
                },
                xField: 'ip',
                yField: ['value'],
                // renderer: Ext.Function.bind(function(sprite, record, attributes, index, store) {

                //     var max_width = 25;
                //     if(attributes.width > max_width){

                //         return Ext.apply(attributes, {
                //             x     : (attributes.x + (attributes.width / 2)) - (max_width / 2),
                //             width : max_width,
                //             fill  : this.eventColor[record.raw.event]
                //         });
                //     }
                //     else {

                //         return attributes;
                //     }
                // }, this),
                tips: {
                    trackMouse: true,
                    width: 150,
                    renderer: function(storeItem, item) {

                        this.setTitle(item.value[0] + " : "+ item.value[1].toString());
                    }
                }
            }]
        });
        
        var form = Ext.create('Ext.form.Panel', {
            xtype : 'form',
            width : 170,
            height : 200,
            padding : '5 5 5 5',
            defaults : {
                labelWidth : 90,
                width      : '100%',
                anchor     : '100%',
                xtype      : 'displayfield',
                labelPad   : 5,
                labelStyle : 'color:#008000',
                margin     : 5,
                fieldStyle : {
                    "text-align": 'right',
                }
            }
        });

        this.panelStore.MostAccessIp = chart.store;

        return {
            xtype : 'panel',
            layout : 'hbox',
            bodyPadding : '5 5 5 5',
            margin : '0 5 0 0',
            flex   : 1,
            title  : '최다 접근아이피',
            items : [
                chart,
                form
            ]
        };
    },

    initPersonalInfoAccessIP : function(){


        var store = Ext.create('Ext.data.Store',{
            fields: [
                {name : 'ip', type : 'string'},
                {name : 'value', type : 'int'}
            ],
            listeners : {
                datachanged : function(store){

                    form.removeAll();
                    Ext.Array.each(store.getRange().sort(function(a, b){

                        return b.data.value - a.data.value;

                    }), function(record, idx){ 
                        
                        form.add({
                            fieldLabel: record.data.ip,
                            value : record.data.value
                        });
                    });
                }
            }
        });

        var chart = Ext.create('Ext.chart.Chart', {
            flex : 1,
            height : 200,
            animate: true,
            style: 'background:#fff',
            shadow: false,
            store: store,
            theme : 'ThemeBlue',
            axes: [{
                type: 'Numeric',
                position: 'bottom',
                fields: ['value'],
                label: {
                    renderer: Ext.util.Format.numberRenderer('0,0')
                },
                minimum: 0
            }, {
                type: 'Category',
                position: 'left',
                fields: ['ip'],
                hidden : true
            }],
            series: [{
                type: 'bar',
                axis: 'bottom',
                label: {
                    display: 'outside',
                    field: 'ip',
                    orientation: 'horizontal',
                    color: '#333',
                    contrast: true
                },
                xField: 'ip',
                yField: ['value'],
                tips: {
                    trackMouse: true,
                    width: 150,
                    renderer: function(storeItem, item) {

                        this.setTitle(item.value[0] + " : "+ item.value[1].toString());
                    }
                }
            }]
        });
        
        var form = Ext.create('Ext.form.Panel', {
            xtype : 'form',
            width : 170,
            height : 200,
            padding : '5 5 5 5',
            defaults : {
                labelWidth: 90,
                width : '100%',
                anchor : '100%',
                xtype : 'displayfield',
                labelPad : 5,
                labelStyle: 'color:#008000',
                margin : 5,
                fieldStyle : {
                    "text-align": 'right',
                }
            }
        });

        this.panelStore.PersonalInfoAccessIP = chart.store;

        return {
            xtype : 'panel',
            layout : 'hbox',
            bodyPadding : '5 5 5 5',
            flex   : 1,
            title  : '개인 정보 접근 IP',
            items : [
                chart,
                form
            ]
        };
    },

    initGrid : function(mode){

        var columns = this['make'+mode+'GridColumns']();

        var fields = [];
        Ext.each(columns, function(obj){

            fields.push(obj.dataIndex);
        });

        var grid = Ext.create('Ext.grid.Panel', {
            id : 'grid-'+this.id+'-'+mode,
            flex : 1,
            border : false,
            columns : columns,
            store: Ext.create('Ext.data.Store', {
                fields:fields
            }),
            viewConfig: {
                emptyText: 'There are no records to display'
            }
        });

        this.panelStore['grid-'+this.id+'-'+mode] = grid.store;
        return grid;
    },

    makeTotalGridColumns : function(){

        // notice : ':#00BF00',
        // attention : ':#ffff00',
        // alert : ':#FF8000',
        // danger : ':#800000',
        // serious : ':#ff0000'
        var column = function(config){

            return Ext.applyIf(config, {
                text: '', 
                dataIndex: 'empty',
                sortable: true, 
                menuDisabled : true, 
                draggable : false, 
                //resizable : false,
                align: 'right' 
            })
        };

        var eventColumn = Ext.Function.bind(function(event_name){

            var events = { 'notice' : '알림', 'attention' : '주의', 'alert' : '경고', 'danger' : '위험', 'serious' : '심각' };
            var config = { 
                text: '<span style="color:'+this.eventColor[event_name]+';">●</span>' + events[event_name],  
                dataIndex: event_name, 
                renderer : function(value){

                    return 0;
                }
            };
            return column(config);
        }, this);

        return [
            column({ text: '서버',  dataIndex: 'agent_name', flex: 1, align: 'left'}),
            column({ dataIndex: 'status', width : 25, renderer : function(value){

                if(value == 1){

                    return '<img src="/images/host_en.png" width="16" height="16"/>';
                }
                else {

                    return '<img src="/images/host_dis.png" width="16" height="16"/>';   
                }
            }}),
            column({ text: '상태',  width: 70, dataIndex: 'status', align: 'left', renderer : function(value){

                return value == 1 ? 
                    '<span style="color:#00BF00">정상</a>' : 
                    '<span style="color:#ff0000">확인요망</span>';
            }}),
            column({ text: '라이센스',  dataIndex: 'license_status' , align: 'center', renderer : function(value){

                return value == 0 ? 
                    '<span style="color:#00BF00">정상</a>' : 
                    '<span style="color:#ff0000">에러</span>';
            }}),
            column({ dataIndex: 'agent_mode', width : 25, renderer : function(value){

                var status = { 0: 'bypass', 1: 'logging', 2 : 'monitoring' };

                return '<img src="/images/mode_'+status[value]+'.png" width="16" height="16"/>';
            }}),
            column({ text: '동작모드', width: 80, dataIndex: 'agent_mode', align: 'left', renderer : function(value){

                var status = { 0: 'bypass', 1: 'logging', 2 : 'monitoring' };

                return status[value];
            }}),
            column({ text: '위험수준', dataIndex: 'event_level', width : 80 }),
            column({ text: '수행건수', dataIndex: 'cnt_exec', width : 80 }),
            column({ text: '개인정보건수', dataIndex: 'cnt_personal_info', width : 80 }),
            column({ text: '주요정보건수', dataIndex: 'cnt_table', width : 80 }),
            column({ text: '실패건수', dataIndex: 'cnt_fail', width : 80 }),
            column({ text: '쿼리변경건수', dataIndex: 'cnt_conv', width : 80 }),
        ];
    },

    makeExecResultCountGridColumns : function(){

        return [
            { text: '서버',  dataIndex: 'agent_name', sortable: true, menuDisabled : true, draggable : false },
            { text: 'IP',  dataIndex: 'ip', sortable: true, menuDisabled : true, draggable : false },
            { text: 'SQL유형',  dataIndex: 'sql_type', sortable: true, menuDisabled : true, draggable : false },
            { text: '참조 테이블', dataIndex: 'ref_tables', flex: 1, sortable: true, menuDisabled : true, draggable : false, renderer : function(value){
                
                if(value){

                    var tables = Ext.JSON.decode(value);
                    tables = tables.map(function(obj){ return (obj.db ? obj.db + "." : '') + obj.table; });
                    tables = tables.join(", ");
                    return tables;
                }

                return value;
            }},
            { text: '조회건수', dataIndex: 'result_count', sortable: true, menuDisabled : true, draggable : false }
        ];
    },

    makeExecQueryCountGridColumns : function(){

        return [
            { text: '서버',      dataIndex: 'agent_name', sortable: true, menuDisabled : true, draggable : false },
            { text: 'IP',       dataIndex: 'ip', sortable: true, menuDisabled : true, draggable : false },
            { text: 'SQL유형',   dataIndex: 'sql_type', sortable: true, menuDisabled : true, draggable : false },
            { text: '참조 테이블', dataIndex: 'ref_tables', flex: 1, sortable: true, menuDisabled : true, draggable : false, renderer : function(value){
                
                if(value){
                    
                    var tables = Ext.JSON.decode(value);
                    tables = tables.map(function(obj){ return (obj.db ? obj.db + "." : '') + obj.table; });
                    tables = tables.join(", ");
                    return tables;
                }

                return value;
            }},
            { text: '수행건수',   dataIndex: 'exec_count', sortable: true, menuDisabled : true, draggable : false }
        ];
    },

    loadMainRealTime : function(){

        Ext.Ajax.request({
            url: '/main/home/getMainPanelData',
            type : 'json',
            params: {
                'server' : WhiteSQL.app.serverId,
                'type' : this.viewType
            },
            scope : this,
            success: function(res){

                var result = Ext.JSON.decode(res.responseText);

                this.panelStore.ChartEvent.loadData(result.event_count);
                this.panelStore.ChartPolicy.loadData(result.sql_policy);

                this.panelStore.MuchLookupIP.loadData(result.much_lookup_ip.sort(function(a, b){

                    return a.value - b.value;
                }));

                this.panelStore.MostAccessIp.loadData(result.most_access_ip.sort(function(a, b){

                    return a.value - b.value;
                }));
                this.panelStore.PersonalInfoAccessIP.loadData(result.personal_info_access_ip.sort(function(a, b){

                    return a.value - b.value;
                }));

                this.panelStore['grid-'+this.id+'-ExecResultCount'].loadData(result.exec_result_count);
                this.panelStore['grid-'+this.id+'-ExecQueryCount'].loadData(result.exec_count);
                this.panelStore['grid-'+this.id+'-Total'].loadData(result.total_grid);

                Ext.getCmp('main-panel-container').setLoading(false);
            }
        });
    }
});