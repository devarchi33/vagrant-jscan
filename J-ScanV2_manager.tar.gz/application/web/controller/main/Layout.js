Ext.define('WhiteSQL.controller.main.Layout', {
    extend: 'Ext.app.Controller',
    
    /**
     * init
     * 
     * 컨트롤러 초기화 메소드.
     * 
     * @access public
     *
     * @return 
     */
    init:function(){

        this.userInfo = this.getUserInfo();

        this.initLayout();

        Ext.Ajax.request({
            url: '/main/home/checkLicense',
            type : 'json',
            scope : this,
            success: function(res){

                var res = Ext.JSON.decode(res.responseText);

                if(res.result != "success"){

                    Ext.Msg.alert('info', '라이센스 만료 예정 에이전트가 존재합니다.');
                }
            }
        });

        this.viewTab('main.Home');
    },

    initLayout : function(){

        this.Layout = Ext.create('Ext.container.Viewport', {
            id       : 'WhiteSQL-Layout',
            renderTo : Ext.getBody(),
            layout   : 'border',
            border   : false,
            padding  : 5,
            items: [
                this.initHeader(), //this.initTopMenu()
                this.initSide(),
                this.initMainTab(),
                Ext.create('Ext.form.Panel', {
                    id : 'hidden-form',
                    url : '/excel/down',
                    standardSubmit: true,
                    renderTo : Ext.getBody(),
                    items    : [
                        {
                            xtype : 'hidden',  //should use the more standard hiddenfield
                            name  : 'params'
                        }
                    ]
                })
                //this.initFooter()
            ],
            listeners : {
                scope : this,
                boxready : function(){

                    this.runStatus();
                }
            }
        });
    },
    initSide : function(){

        return {
            xtype            : 'panel',
            region           : 'west',
            width            : 200,
            id               : 'side-bar',
            layout           : 'border',
            animCollapse     : false,
            collapsible      : false,
            hideCollapseTool : true,
            collapsed        : false,
            bodyBorder       : false,
            title            : 'Server    &    Usage',
            header           : false,
            border           : 0,
            split            : true,
            maxWidth         : 300,
            minWidth         : 200,
            items : [
                this.initTreeTab(),
                this.initResourceUsage()
            ]
        };
    },
    initFooter : function(){

        var columns = [
            { dataIndex: 'work_history_id', width : 25 , sortable: true, renderer : function(value){
                return '<img src="/images/view.png" history_id="'+value+'"/>';
            }, sortable: true, menuDisabled : true },
            { text: '작업시간', dataIndex: 'work_time', width : 120 },
            { text: '서버명',  dataIndex: 'agent_name', width : 150 },
            { text: '쿼리', dataIndex: 'work_message', flex: 1}
        ];

        var mode = '';

        return {
            xtype       : 'whitesql_grid',
            id          : 'grid-footer-history',
            url         : '/history/work/getGridData',
            hideHeaders : true,
            border      : false,
            width       : '100%',
            region      : 'south',
            split       : true,
            height      : 50,
            maxHeight   : 300,
            minHeight   : 50,
            columns     : columns,
            listeners   : {
                scope : this,
                cellclick: function(grid, cellEl, cellIdx, record, rowEl, rowIdx, evtObj) {

                    if(cellIdx == 0){

                        var his_id = record.data.work_history_id;

                        this.getApplication().openWindow('history.Work-Detail', his_id);
                    }
                }
            }
        };
    },
    initHeader : function(){

        return {
            xtype  : 'container',
            region : 'north',
            layout : 'hbox',
            // height : 45,
            margin : '0 0 5 0',
            style  : {"background":"#205081"},
            border : 0,
            width  : '100%',
            items  : [
                this.initLogo(),
                this.initUserInfo(),
                this.initTopMenu()
                //this.initEventSum(),
            ]
        }
    },
    initEventSum : function(){

        return {
            xtype  : 'container',
            layout : 'hbox',
            margin : '15 10 0 5',
            height : 22,
            defaults : {
                xtype : 'textfield',
                style : 'font-size:13pt;line-height:20px;',
                width  : 50,
                height : 16,
                margin : '0 3 0 0'
            },
            items : [{
                xtype  : 'image',
                width  : 16,
                height : 16,
                margin : '3 3 0 5',
                src    : '/images/light_green.png',
                html   : 'logo'
            },{
                id : 'event-level-1',
                xtype : 'label',
                text : '0'
            },{
                xtype  : 'image',
                width  : 16,
                height : 16,
                margin : '3 3 0 5',
                src    : '/images/light_yellow.png',
                html   : 'logo'
            },{
                id : 'event-level-2',
                xtype : 'label',
                text : '0'
            },{
                xtype  : 'image',
                width  : 16,
                height : 16,
                margin : '3 3 0 5',
                src    : '/images/light_red.png',
                html   : 'logo'
            },{
                id : 'event-level-3',
                xtype : 'label',
                text : '0'
            },{
                xtype  : 'image',
                width  : 16,
                height : 16,
                margin : '3 3 0 5',
                src    : '/images/light_red.png',
                html   : 'logo'
            },{
                id : 'event-level-4',
                xtype : 'label',
                text : '0'
            },{
                xtype  : 'image',
                width  : 16,
                height : 16,
                margin : '3 3 0 5',
                src    : '/images/light_red.png',
                html   : 'logo'
            },{
                id : 'event-level-5',
                xtype : 'label',
                text : '0'
            }]
        };
    },
    initLogo : function(){

        return {
            xtype  : 'container',
            layout : 'hbox',
            flex   : 1,
            items  : {
                xtype  : 'image',
                width  : 87,
                height : 30,
                margin : '7 10 0 5',
                src    : '/images/jscon_200-60_white.png'
            }
        };
    },

    initUserInfo : function(){

        return {
            xtype : 'text',
            textStyle : {
                fill : '#ffffff'
            },
            margin: '15 10 0 5',
            text  : 'J-SCAN V2 로그인 유저 : ' + this.userInfo.user_name
        };
    },

    initBtnLogout : function(){
        return {
            xtype: 'button',
            icon : '/images/icon_logout24x24.png',
            text : 'logout',
            listeners : {
                scope : this,
                click : function(){

                    if(!this.getApplication().syncPolicies){

                        if(confirm('동기화하지 않은 정책이 존재합니다. 로그아웃 하시겠습니까?')){

                            this.logout();
                        }
                    }
                    else {

                        this.logout();
                    }
                }
            }
        }
    },

    logout : function(){

        Ext.Ajax.request({
            url: '/main/login/destroy',
            type : 'json',
            scope : this,
            success: function(res){

                var result = Ext.JSON.decode(res.responseText);

                document.location.reload();
            }
        });
    },

    initTopMenu : function(){

        return {
            xtype    : 'toolbar',
            style    : {"background":"#205081"},
            id       : 'top_menu',
            border   : false,
            defaults : {
                pressed      : true,
                allowDepress : false,
                arrowAlign   : 'right',
                text         : 'medium',
                scale        : 'medium',
                iconAlign    : 'left',
                padding      : 5,
                width        : 100,
                height       : 40,
                border       : true,
                cls          : 'btn',
            },
            items : [
                (this.userInfo.user_level == 10 ? {
                    xtype: 'splitbutton',
                    icon : '/images/icon_gear24x24.png',
                    text : 'Manage',
                    menu : [
                        this.initBtnServer(),
                        this.initBtnUser()
                    ]
                } : null),
                {
                    xtype: 'splitbutton',
                    icon : '/images/icon_monitoring24x24.png',
                    text : 'Monitoring',
                    width : 110,
                    menu : [
                        this.initBtnRealTime(),
                        this.initBtnDashBoard()
                    ]
                },
                {
                    xtype: 'splitbutton',
                    icon : '/images/icon_log24x24.png',
                    text : 'Log',
                    menu : [
                        /*this.initBtnConvertedSQLLog()*/,
                        this.initBtnSQLLog(),
                        this.initBtnEventLog()
                    ]
                },
                {
                    xtype: 'splitbutton',
                    icon : '/images/icon_history24x24.png',
                    text : 'History',
                    menu : [
                        this.initBtnPolicyHistory(),
                        this.initBtnWorkHistory()
                    ]
                },
                {
                    xtype: 'splitbutton',
                    icon : '/images/icon_report24x24.png',
                    text : 'Report',
                    menu : [
                        this.initBtnEventReport(),
                        this.initBtnExecutionReport(),
                        this.initBtnPersonalInfoLookup(),
                        this.initBtnTop20Report(),
                        this.initBtnPersonalInfoReport()
                    ]
                },
                {
                    xtype: 'button',
                    icon : '/images/icon_help24x24.png',
                    text : 'Help',
                    handler : function(btn){

                        document.location.href = "/help/help.pdf";
                    }
                },
                this.initBtnLogout()
            ]
        };
    },
    initTreeTab : function(){

        return {
            id    : 'tree-tab',
            xtype : 'tabpanel',
            flex  : 1,
            region: 'center',
            defaults : {
                padding : 5
            },
            items : [
                this.initServerTree(),
                this.initDatabaseTree()
            ],
            listeners : {
                beforetabchange : function(tabs, newTab, oldTab){

                    newTab.store.reload();
                }
            }
        };
    },
    initMainTab : function(){

        return {
            id    : 'main-tab',
            xtype : 'tabpanel',
            flex  : 1,
            region: 'center',
            defaults : {
                padding : 5
            }
        };
    },
    initServerTree : function(){

        this.ServerTree = Ext.create('Ext.tree.Panel', {
            id              : 'server-tree',
            width           : '100%',
            height          : '100%',
            autoScroll      : true,
            animate         : false,
            title           : 'Agent',
            region          : 'center',
            enableDD        : false,//이동이 가능하도록 할것인가 말것인가.
            containerScroll : true,
            store           : Ext.create('Ext.data.TreeStore', {
                id : 'store-server-tree',
                clearOnLoad : true,
                proxy: {
                    type  : 'ajax',
                    url   : '/manage/server',
                    reader: {
                        type: 'json',
                        root: 'data'
                    }
                }
            }),
            root: {
                expanded: true,
                text    :'All Servers'
            },
            listeners : {
                scope : this,
                boxready : function(){
                    
                    this.initServerTreeEvent();
                    this.initServerContextMenu();
                }
            }
        });

        return this.ServerTree;
    },

    initDatabaseTree : function(){

        this.DatabaseTree = Ext.create('Ext.tree.Panel', {
            id              : 'database-tree',
            width           : '100%',
            height          : '100%',
            autoScroll      : true,
            animate         : false,
            title           : 'Database',
            region          : 'center',
            enableDD        : false,//이동이 가능하도록 할것인가 말것인가.
            containerScroll : true,
            store           : Ext.create('Ext.data.TreeStore', {
                id : 'store-database-tree',
                clearOnLoad : true,
                proxy: {
                    type  : 'ajax',
                    url   : '/manage/server/databases',
                    reader: {
                        type: 'json',
                        root: 'data'
                    }
                }
            }),
            root: {
                expanded: true,
                text    :'All Databases'
            },
            listeners : {
                scope : this,
                boxready : function(){

                    this.initDatabaseTreeEvent();
                    this.initDatabaseContextMenu();
                }
            }
        });

        return this.DatabaseTree;
    },

    initServerTreeEvent : function(){

        Ext.util.Observable.observe(this.ServerTree, {
            scope : this,
            select : function( view, record, index, eOpts){

                this.serverId = record.raw.id;
                this.getApplication().fireEvent('server-tree-selected', record.raw);
            }
        });
    },

    initDatabaseTreeEvent : function(){

        Ext.util.Observable.observe(this.ServerTree, {
            scope : this,
            select : function( view, record, index, eOpts){

                this.databaseId = record.raw.id;
                this.getApplication().fireEvent('database-tree-selected', record.raw);
            }
        });
    },

    initResourceUsage : function(){

        var usage = Ext.create("Ext.panel.Panel", {
            id : 'resource-usage',
            title  : 'Usage',
            layout : 'vbox',
            collapsible  : true,
            split        : true,
            animCollapse : false,
            region       : 'south',
            bodyPadding : 5,
            defaults : {
                width : '100%'
            },
            items : [
                {
                    id : 'resource-usage-cpu',
                    xtype: 'progressbar',
                    margin : '0 0 2 0'
                },
                {
                    id : 'resource-usage-memory',
                    xtype: 'progressbar',
                    margin : '0 0 2 0'
                },
                {
                    id : 'resource-usage-disk',
                    xtype: 'progressbar'
                }
            ]
        });

        return usage;
    },

    initBtnHome : function(){

        return {
            icon : '/images/home.png',
            text : 'Home',
            scope : this,
            handler : function(btn){

                this.viewTab('main.Home');
            }
        };
    },

    initBtnServer : function(){

        return {
            icon : '/images/host_groups.png',
            text : 'Server',
            scope : this,
            handler : function(btn){

                this.viewTab('manage.Server');
            }
        };
    },

    initBtnUser : function(){

        return {
            icon : '/images/user.png',
            text : 'User',
            scope : this,
            handler : function(btn){

                this.viewTab('manage.User');
            }
        };
    },

    initBtnRealTime : function(){
        return {
            icon : '/images/event_mon.png',
            text : 'RealTime',
            scope : this,
            handler : function(btn){

                this.viewTab('monitoring.Realtime');
            }
        }
    },

    initBtnReport : function(){
        return {
            icon : '/images/event_mon.png',
            text : 'Report',
            scope : this,
            handler : function(btn){

                this.viewTab('monitoring.Report');
            }
        }
    },

    initBtnDashBoard : function(){

        return {
            icon : '/images/sql_mon.png',
            text : 'DashBoard',
            scope : this,
            handler : function(btn){

                window.open('/monitoring/dashboard', '_blank');
            }
        }
    },

    initBtnContextWhiteSQL : function(){

        return {
            icon    : '/images/whitesql.png',
            id      : 'btn-context-white-sql',
            text    : 'White SQL',
            scope   : this,
            handler : function(btn){

                this.getApplication().openWindow('manage.WhiteSQL');
            }
        }
    },

    initBtnContextNewSQL : function(){

        return {
            icon    : '/images/whitesql.png',
            id      : 'btn-context-new-sql',
            text    : 'New SQL',
            scope   : this,
            handler : function(btn){

                this.getApplication().openWindow('manage.NewSQL');
            }
        }
    },

    initBtnContextPrivacyTable: function(){

        return {
            icon    : '/images/whitesql.png',
            id      : 'btn-context-privacy-table',
            text    : 'Privacy Table',
            scope   : this,
            handler : function(btn){

                this.getApplication().openWindow('manage.PrivacyTable');
            }
        }
    },

    initBtnContextSQLPolicy : function(){

        return {
            icon : '/images/sql_pol.png',
            id      : 'btn-context-sql-policy',
            text : 'SQL Policy',
            scope : this,
            handler : function(btn){

                this.getApplication().openWindow('manage.SQLPolicy');
            }
        }
    },

    initBtnConvert : function(){

        return {
            icon : '/images/sql_convert.png',
            text : 'SQL Convert',
            scope : this,
            handler : function(btn){

                this.getApplication().openWindow('manage.SQLConvert');
            }
        }
    },

    initBtnBlock : function(){

        return {
            icon : '/images/block.png',
            text : 'Block Policies',
            scope : this,
            handler : function(btn){

                this.getApplication().openWindow('manage.BlockPolicy');
            }
        }
    },

    initBtnConvertedSQLLog : function(){

        return {
            icon : '/images/sql_hier_log.png',
            text : 'Converted SQL Log',
            scope : this,
            handler : function(btn){

                this.viewTab('log.ConvertedSQL');
            }
        };
    },

    initBtnSQLLog : function(){

        return {
            icon : '/images/sql_log.png',
            text : 'SQL Log',
            scope : this,
            handler : function(btn){

                this.viewTab('log.SQL');
            }
        };
    },

    initBtnEventLog : function(){

        return {
            icon : '/images/event_log.png',
            text : 'Event Log',
            scope : this,
            handler : function(btn){

                this.viewTab('log.Event');
            }
        };
    },

    initBtnPolicyHistory : function(){

        return {
            icon : '/images/policy_history.png',
            text : 'Policy History',
            scope : this,
            handler : function(btn){

                this.viewTab('history.Policy');
            }
        };
    },

    initBtnWorkHistory : function(){

        return {
            icon : '/images/work_history.png',
            text : 'Work History',
            scope : this,
            handler : function(btn){

                this.viewTab('history.Work');
            }
        };
    },

    initBtnEventReport : function(){

        return {
            icon : '/images/report.png',
            text : 'Event Report',
            scope : this,
            handler : function(btn){

                this.viewTab('report.Event');
            }
        };
    },

    initBtnExecutionReport : function(){

        return {
            icon : '/images/report.png',
            text : 'Query Execution Report',
            scope : this,
            handler : function(btn){

                this.viewTab('report.Execution');
            }
        };
    },

    initBtnPersonalInfoLookup : function(){

        return {
            icon : '/images/report.png',
            text : 'Personal Info Lookup Report',
            scope : this,
            handler : function(btn){

                this.viewTab('report.PersonalInfoLookup');
            }
        };
    },

    initBtnTop20Report : function(){

        return {
            icon : '/images/report.png',
            text : 'Top 20',
            scope : this,
            handler : function(btn){

                this.viewTab('report.Top20');
            }
        };
    },

    initBtnPersonalInfoReport : function(){

        return {
            icon : '/images/report.png',
            text : 'User Report',
            scope : this,
            handler : function(btn){

                this.viewTab('report.PersonalInfo');
            }
        };
    },

    initBtnContextAddGroup : function(){

        return {
            id : 'btn-context-add-group',
            text: 'Add Group',
            scope : this,
            handler : function(){

                this.getApplication().addGroup();
            }
        };
    },

    initBtnContextModGroup : function(){

        return {
            id : 'btn-context-rename-group',
            icon : '/images/edit.png',
            text: 'Rename Group',
            scope : this,
            handler : function(){

                var node = this.ServerTree.getSelectionModel().getSelection()[0];
                this.getApplication().modGroup(node);
            }
        };
    },

    initBtnContextDelGroup : function(){

        return {
            id : 'btn-context-delete-group',
            icon : '/images/delete.png',
            text: 'Delete Group',
            handler : function(){

                var node = this.ServerTree.getSelectionModel().getSelection()[0];
                this.getApplication().delGroup(node);
            }
        };
    },

    initBtnContextDelServer : function(){

        return {
            id : 'btn-context-delete-server',
            icon : '/images/delete.png',
            text: 'Delete Server',
            handler : function(){

                var node = this.ServerTree.getSelectionModel().getSelection()[0];
                this.getApplication().delServer(node);
            }
        };
    },

    initBtnContextViewServers : function(){

        return {
            id : 'btn-context-view-servers',
            icon : '/images/host_groups.png',
            text: 'View Servers',
            handler : function(){

                this.viewTab('manage.Server');
            }
        };
    },

    initBtnContextAddServer : function(){

        return {
            icon : '/images/server_add.png',
            id : 'btn-context-add-server',
            text: 'Add Server',
            handler : function(){

                var record = this.ServerTree.getSelectionModel().getSelection()[0];
                this.getApplication().openWindow('manage.Server-Add', record);
            }
        };
    },

    initBtnContextModServer : function(){

        return {
            id : 'btn-context-edit-server',
            icon : '/images/edit.png',
            text: 'Edit Server',
            handler : function(){

                var record = this.ServerTree.getSelectionModel().getSelection()[0];
                this.getApplication().openWindow('manage.Server-Add', record);
            }
        };
    },

    initBtnContextSetServerMode : function(){

        return {
            id : 'btn-context-set-server-mode',
            text: 'Mode',
            icon : '/images/mode.png',
            menu : [
                {
                    text : 'Bypass',
                    icon : '/images/mode_bypass.png',
                    scope : this,
                    handler : function(btn){ 

                        this.changeServerMode('bypass');
                    }
                },
                {
                    text : 'Logging',
                    icon : '/images/mode_logging.png',
                    scope : this,
                    handler : function(btn){ 

                        this.changeServerMode('logging');
                    }
                },
                {
                    text : 'Monitoring',
                    icon : '/images/mode_monitoring.png',
                    scope : this,
                    handler : function(btn){ 

                        this.changeServerMode('monitoring');
                    }
                }
                // {
                //     text : 'Protect',
                //     icon : '/images/mode_protect.png',
                //     scope : this,
                //     handler : function(btn){ 

                //         this.changeServerMode('protect');
                //     }
                // }
            ]
        };
    },

    initBtnContextSyncPolicy : function(){

        return {
            id : 'btn-context-sync-policy',
            icon : '/images/policy_sync.png',
            text : 'Sync Policies',
            scope : this,
            handler : function(btn){

                this.getApplication().syncPolicy();
            }
        }
    },

    initBtnContextModDatabase : function(){

        return {
            id : 'btn-context-edit-database',
            icon : '/images/edit.png',
            text: 'Edit Database',
            handler : function(){

                var record = this.DatabaseTree.getSelectionModel().getSelection()[0];
                this.getApplication().openWindow('manage.Database-Edit', record);
            }
        };
    },

    initDatabaseContextMenu : function(){

        this.databaseContextMenu = Ext.create('Ext.menu.Menu', {
            id : 'database-context-menu',
            margin: '0 0 10 0',
            defaults : {
                hidden : true,
                scope : this
            },
            items: [
                this.initBtnContextModDatabase()
                // this.initBtnContextPrivacyTable(),
                // this.initBtnContextWhiteSQL(),
                // this.initBtnContextSQLPolicy(),
                // this.initBtnContextSyncPolicy()
            ]
        });

        //데이터베이스트리 이벤트를 잡아 내서 node위에서 right click을 했을 경우만 
        //context메뉴를 보여준다.
        this.DatabaseTree.getEl().on('contextmenu',  function(e){ 

            e.preventDefault();

            if(this.userInfo.user_level < 5) return;

            //메뉴가 show되기전 모든 메뉴를 숨긴다.
            Ext.each(Ext.ComponentQuery.query('[id^="btn-context"]'), function(cmp) { cmp.hide() });

            var tr = Ext.get(e.target).up('tr');

            if(!tr) return;

            var record_id = tr.getAttribute('data-recordid');

            if(record_id == 'root'){

                return;
            }

            Ext.getCmp('btn-context-edit-database').show();

            this.databaseContextMenu.showBy(tr, 'tr');

        }, this);

        return this.databaseContextMenu;
    },

    initServerContextMenu : function(){

        this.serverContextMenu = Ext.create('Ext.menu.Menu', {
            id : 'server-context-menu',
            margin: '0 0 10 0',
            defaults : {
                hidden : true,
                scope : this
            },
            items: [
                this.initBtnContextAddGroup(),
                this.initBtnContextViewServers(),
                this.initBtnContextModGroup(),
                this.initBtnContextDelGroup(),
                this.initBtnContextAddServer(),
                this.initBtnContextModServer(),
                this.initBtnContextDelServer(),
                this.initBtnContextSetServerMode(),              
                this.initBtnContextNewSQL(),
                this.initBtnContextPrivacyTable(),
                this.initBtnContextWhiteSQL(),
                this.initBtnContextSQLPolicy(),
                this.initBtnContextSyncPolicy()
            ]
        });

        //서버트리의 이벤트를 잡아 내서 node위에서 right click을 했을 경우만 
        //context메뉴를 보여준다.
        this.ServerTree.getEl().on('contextmenu', function(e){ 

            e.preventDefault();

            if(this.userInfo.user_level < 5) return;

            //메뉴가 show되기전 모든 메뉴를 숨긴다.
            Ext.each(Ext.ComponentQuery.query('[id^="btn-context"]'), function(cmp) { cmp.hide() });

            var tr = Ext.get(e.target).up('tr');

            if(!tr) return;

            var record_id = tr.getAttribute('data-recordid');

            //각 노드의 특성에 해당하는 메뉴를 보여준다.
            if(record_id == 'root'){

                Ext.getCmp('btn-context-add-group').show();
                Ext.getCmp('btn-context-view-servers').show();
            }
            else if(record_id.indexOf('group') > -1){

                Ext.getCmp('btn-context-rename-group').show();
                Ext.getCmp('btn-context-delete-group').show();
                Ext.getCmp('btn-context-add-server').show();
            }
            else if(record_id.indexOf('server') > -1){

                Ext.getCmp('btn-context-edit-server').show();
                Ext.getCmp('btn-context-delete-server').show();

                Ext.getCmp('btn-context-set-server-mode').setDisabled(true);
                Ext.getCmp('btn-context-sql-policy').setDisabled(true);
                Ext.getCmp('btn-context-white-sql').setDisabled(true);
                Ext.getCmp('btn-context-new-sql').setDisabled(true);
                Ext.getCmp('btn-context-sync-policy').setDisabled(true);

                Ext.getCmp('btn-context-set-server-mode').show();
                Ext.getCmp('btn-context-sql-policy').show();
                Ext.getCmp('btn-context-white-sql').show();
                Ext.getCmp('btn-context-new-sql').show();
                Ext.getCmp('btn-context-privacy-table').show();
                Ext.getCmp('btn-context-sync-policy').show();

                Ext.Ajax.request({
                    url: '/manage/server/getServerInfo',
                    type : 'json',
                    params : {
                        server : this.getApplication().serverId
                    },
                    scope : this,
                    async : false,
                    success: function(res){

                        var result = Ext.JSON.decode(res.responseText);

                        //동작모드(0:bypass, 1:logging, 2:monitoring, 3:protect)

                        var mode  = '';
                        if(result.agent_mode == '0'){

                            mode = 'Bypass';
                        }
                        else if(result.agent_mode == '1'){

                            mode = 'Logging';
                        }
                        else if(result.agent_mode == '2'){

                            mode = 'Monitoring';
                        }

                        var cmp = Ext.getCmp('btn-context-set-server-mode');
                        Ext.Array.each(cmp.menu.items.items, function(item, idx){  

                            item.setText(item.text.replace("(selected)", ""));

                            if(mode == item.text){

                                item.setText(item.text + "(selected)");
                            }
                        });

                        cmp.setText(cmp.text.replace(/ - [a-zA-Z]+/, ""));

                        if(mode){

                            cmp.setText(cmp.text + " - " + mode);
                        }
                        
                        if(result.status == "1"){

                            Ext.getCmp('btn-context-set-server-mode').setDisabled(false);
                            Ext.getCmp('btn-context-sql-policy').setDisabled(false);
                            Ext.getCmp('btn-context-white-sql').setDisabled(false);
                            Ext.getCmp('btn-context-new-sql').setDisabled(false);
                            Ext.getCmp('btn-context-privacy-table').setDisabled(false);
                            Ext.getCmp('btn-context-sync-policy').setDisabled(false);
                        }
                    }
                });
            }

            this.serverContextMenu.showBy(tr, 'tr');

        }, this);

        return this.serverContextMenu;
    },

    viewTab : function(id){

        tabpanel = Ext.getCmp('main-tab');
        var tab = tabpanel.getComponent('tab-'+id);

        if(tab){

            //이미 생성된 탭이 있으면 탭을 다시 보여준다.
            tab.show();
        }
        else {

            this.getApplication().initController(id);
            tabpanel.setActiveTab('tab-'+id);
        }
    },

    changeServerMode : function(mode){

        var node = this.ServerTree.getSelectionModel().getSelection()[0];

        var data = node.raw;

        var msg = Ext.Msg.wait('처리중 입니다.');

        Ext.Ajax.timeout = 300000;

        Ext.Ajax.request({
            url: '/manage/server/changeServerMode',
            type : 'json',
            params : {
                server : data.id,
                mode : mode
            },
            scope : this,
            success: function(res){
                
                msg.hide();

                var result = Ext.JSON.decode(res.responseText);

                layout = this.getController('main.Layout');
                tree = layout.ServerTree;

                var node = tree.getSelectionModel().getSelection()[0];
                var parentId = node.data.parentId;
                var parentNode = tree.getStore().getNodeById(parentId);

                tree.getStore().reload({node : parentNode});

                Ext.Msg.alert('Status', result.message);
            },
            failure: function(result, request, a,b,c,d,e){

                msg.hide();

                if(result.timedout == true){

                    Ext.Msg.alert("Failed", "요청한 시간이 지나 작업이 중단되었습니다.");
                }
                else {

                    Ext.Msg.alert("Failed", result.responseText);   
                }
            }
        });
    },

    runStatus : function(){

        var sideBar = Ext.getCmp('side-bar'),
            cmpCPU = Ext.getCmp('resource-usage-cpu'),
            cmpMEM = Ext.getCmp('resource-usage-memory'),
            cmpDSK = Ext.getCmp('resource-usage-disk'),
            cmpServerTree = Ext.getCmp('server-tree'),
            serverStore = cmpServerTree.getStore(),
            serverRootNode = cmpServerTree.getRootNode(),
            oldStatus = {},
            task = {
            scope : this,
            run: function(){

                if(sideBar.getCollapsed()) return;

                Ext.Ajax.request({
                    url: '/server/status',
                    type : 'json',
                    success: function(res){

                        var result     = Ext.JSON.decode(res.responseText),
                            usg        = result.usage,
                            servers    = result.servers,
                            databases  = result.databases;

                        cmpCPU.updateProgress(usg.cpu / 100,  'CPU : '+usg.cpu + '%');
                        cmpMEM.updateProgress(usg.mem / 100,  'MEM : '+usg.mem + '%');
                        cmpDSK.updateProgress(usg.disk / 100, 'DISK : '+usg.disk + '%');

                        if(cmpServerTree.isHidden()){

                            return;
                        }

                        Ext.each(servers, function(server){

                            if(!oldStatus[server.agent_id]){

                                oldStatus[server.agent_id] = server.status;
                                return;
                            }

                            if(server.status == oldStatus[server.agent_id]){
                                
                                return;
                            }

                            var node = serverRootNode.findChild('id', 'server-'+server.agent_id, true);

                            if(!node){

                                return;
                            }
                            
                            var parentId = node.data.parentId,
                                parentNode = serverStore.getNodeById(parentId);

                            serverStore.reload({node : parentNode});

                            oldStatus[server.agent_id] = server.status;
                        });
                    }
                });
            },
            interval: 1000 //1 second
        };
        Ext.TaskManager.start(task);
    },

    getUserInfo : function(){

        var result;
        Ext.Ajax.request({
            url: '/main/login/getUserInfo',
            type : 'json',
            async : false,
            success: function(res){

                result = Ext.JSON.decode(res.responseText);
            }
        });

        return result;
    }
});