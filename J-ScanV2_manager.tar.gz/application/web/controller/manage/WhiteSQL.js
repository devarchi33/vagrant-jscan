Ext.define('WhiteSQL.controller.manage.WhiteSQL', {
    extend: 'Ext.app.Controller',
    
    /**
     *
     * 윈도우 생성
     *
     * @return component Ext.container.Container
     */
    initWindow : function(){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id,
            title : 'White SQL',
            width : 1200,
            height: 800,
            bodyPadding : '5 5 5 5',
            layout : 'fit',
            items : [
                {
                    xtype : 'panel',
                    layout: 'border',
                    width : '100%',
                    border: 0,
                    flex  : 1,
                    items : [
                        {
                            xtype : 'panel',
                            layout: 'vbox',
                            border : false,
                            region: 'center',
                            width : '100%',
                            flex  : 1,
                            items : [
                                this.initGridSearch(),
                                this.initGrid()
                            ]
                        },
                        this.initQueryField()
                    ]
                }
            ]
        });
    },

    /**
     * initGridSearch
     *
     * 그리드 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGridSearch : function(){

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'vbox',
            frame : true,
            width : '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 0',
            items:[
                {
                    xtype   : 'container',
                    layout  : 'hbox',
                    margin  : '0 0 5 0',
                    width : '100%',
                    defaults: {
                        height : 26,
                        margin : '0 10 0 0'
                    },
                    items : [
                        {
                            margin : '5 2 0 0',
                            xtype : 'image',
                            width : 16,
                            height : 16,
                            src   : '/images/host_en.png'
                        },
                        {
                            xtype : 'text',
                            margin : '5 0 0 0',
                            id    : 'server-name-'+this.id,
                            width : 100,
                            text  : this.application.getServerName()
                        },
                        this.initComboBox(),
                        {
                            xtype : 'textfield',
                            id    : this.id+'-search-keyword',
                            name  : this.id+'-search-keyword',
                            flex  : 1,
                        },
                        {
                            xtype:'button',
                            icon : '/images/find.png',
                            text: '검색',
                            scope : this,
                            handler : this.search
                        },
                        {
                            xtype:'button',
                            icon : '/images/checkbox_yes.png',
                            text: '전체선택',
                            scope : this,
                            handler : this.checkAll
                        },
                        {
                            xtype: 'buttongroup',
                            items : [
                                {
                                    xtype:'button',
                                    icon : '/images/on.png',
                                    text: '사용',
                                    scope : this,
                                    handler : this.onWhiteSQL
                                },
                                {
                                    xtype:'button',
                                    icon : '/images/off.png',
                                    text: '미사용',
                                    scope : this,
                                    handler : this.offWhiteSQL
                                },
                                {
                                    xtype:'button',
                                    icon : '/images/confirm.png',
                                    text: '승인',
                                    scope : this,
                                    handler : this.approval
                                }
                            ]
                        },
                        {
                            xtype: 'buttongroup',
                            items : [
                                {
                                    xtype:'button',
                                    icon : '/images/policy_sync.png',
                                    text: '동기화',
                                    scope : this,
                                    handler : this.syncPolicy
                                },
                                {
                                    xtype:'button',
                                    icon : '/images/delete.png',
                                    text: '삭제',
                                    scope : this,
                                    handler : this.delSQL
                                }
                            ]
                        },
                        {
                            xtype: 'buttongroup',
                            items : [
                                // {
                                //     xtype:'button',
                                //     icon : '/images/import.png',
                                //     text: '불러오기',
                                //     scope : this,
                                //     handler : this.importSQL
                                // },
                                {
                                    xtype:'button',
                                    icon : '/images/export.png',
                                    text: '엑셀받기',
                                    scope : this,
                                    handler : this.exportSQL
                                }
                            ]
                        }
                    ]
                }
            ]
        };
        return form;
    },

    /**
     * initComboBox
     *
     * 콤보박스 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initComboBox : function(label, mode){

        var store = new Ext.data.Store({
            data : [{
                id : 'class_string', text : '클래스명'
            },{
                id : 'sqltext', text : '쿼리'
            }],
            fields: ['id','text']
        });

        // Simple ComboBox using the data store
        var combo = Ext.create('Ext.form.ComboBox', {
            id   : this.id+'-search-mode',
            name : this.id+'-search-mode',
            emptyText : '선택',
            displayField : 'text',
            editable : false,
            valueField: 'id',
            value : 'class_string',
            store: store
        });

        return combo;
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGrid : function(mode){

        var selModel = Ext.create('Ext.selection.CheckboxModel', {
            mode : 'multi'
        });

        var columns = this.makeListColumns();

        var grid = Ext.create('Lib.Grid', {
            id : 'grid-'+this.id,
            url : '/manage/white_sql/getListData',
            title : mode,
            columns : columns,
            selModel : selModel,
            listeners: {
                scope : this,
                itemclick : function(grid, record) {
                    
                    Ext.Ajax.request({
                        url    : '/manage/white_sql/getQueryData/'+record.raw.whitesql_id,
                        type   : 'json',
                        async  : false,
                        scope  : this,
                        success: function(res){

                            var data = Ext.JSON.decode(res.responseText);

                            Ext.getCmp(this.id+'-org-sql').update(data.uniq_sqltext);
                        }
                    });
                }
            }
        });

        return grid;
    },

    /**
     * search
     *
     * 검색 수행
     *
     * @access public
     *
     */
    search : function(){

        var params = Ext.getCmp('form-'+this.id).getValues();        
        var grid   = Ext.getCmp('grid-'+this.id);

        this.getApplication().fireEvent('grid-search', grid, params);
    },

    initQueryField : function(){

        return {
            xtype       : 'panel',
            layout      : 'vbox',
            region      : 'south',
            split       : true,
            collapsible : true,
            header      : false,
            width       : '100%',
            height      : 150,
            border      : false,
            bodyBorder  : false,
            defaults    : {
                xtype      : 'fieldset',
                height     : '100%',
                flex       : 1, 
                padding    : 10,
                autoScroll : true,
            },
            items:[
                {
                    region :'east',
                    split  : true,
                    width  : '100%',
                    id     : this.id+'-org-sql',
                    title  : '쿼리'
                }
            ]
        };
    },

    /**
     * makeDetailListColumns
     *
     * 상세정보 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeListColumns : function(){   

        return [
            Ext.create('Ext.grid.RowNumberer'),
            { text: '클래스명', dataIndex: 'class_string', width : 300},
            { text: '쿼리', dataIndex: 'uniq_sqltext' , flex: 1 },
            { text: '사용여부', dataIndex: 'on_off', width : 60, 
                renderer: function(value,metaDate,record,rowIndex,colIndex, store, view){

                    return value == 1 ? '사용' : '미사용'
                }
            },
            { text: '승인', dataIndex: 'approval_yn', width : 70, 
                renderer: function(value,metaDate,record,rowIndex,colIndex, store, view){

                    if(value == 1){
                        return Ext.DomHelper.createHtml({
                            tag         : 'a',
                            class       : 'btn-approval',
                            html        : '승인',
                            style       : 'padding-left : 20px; background:url(/images/confirm.png) no-repeat; cursor:pointer',
                            approval_yn : value
                        });
                    }
                    else {

                        return "미승인";
                    }
                }
            },
            { text: '승인유저', dataIndex: 'approval_user_name', width : 100 },
            { text: '승인시간', dataIndex: 'approval_time', width : 130 }
            // { text: '상태', dataIndex: 'state', width : 80, renderer:function(value){ 
                
            //     switch(value){
            //         case "A":
            //             return "추가";
            //             break;
            //         case "M":
            //             return "수정";
            //             break;
            //         case "D":
            //             return "삭제";
            //             break;
            //         case "N":
            //             return "동기화완료";
            //             break;
            //     }
            // } }
        ];
    },

    checkAll : function(){

        var grid = Ext.getCmp('grid-'+this.id),
            selModel = grid.getSelectionModel(),
            total = grid.store.getCount();

        if(total == 0){

            return;                
        }


        if(this.chkStatus){

            selModel.deselectRange(0, total - 1);
            this.chkStatus = 0;
        }
        else {

            selModel.selectRange(0, total - 1);
            this.chkStatus = 1;
        }
    },

    importSQL : function(){

        this.getApplication().openWindow('manage.WhiteSQL-Import');
    },

    exportSQL : function(){
        
        var params      = Ext.getCmp('form-'+this.id).getValues();
        
        params.serverId = this.getApplication().serverId;
        location.href   = "/manage/white_sql/export?"+Ext.urlEncode(params);
    },

    delSQL : function(){

        var grid = Ext.getCmp('grid-'+this.id);
        
        var sel  = grid.getSelectionModel().getSelection();
        
        var ids  = [];
        Ext.each(sel, function(record) {

            ids.push(record.raw.whitesql_id);
        });

        if(ids.length < 1){

            Ext.Msg.alert('Status', '삭제하실 SQL을 선택하세요');
            return;
        }
        else {

            ids = ids.join(",");
        }
        // Send the id

        Ext.MessageBox.confirm('Confirm', '정말 삭제하시겠습니까?', Ext.Function.bind(function(confirm){

            if(confirm == 'yes'){
   
                Ext.Ajax.request({
                    url    : '/manage/white_sql/del',
                    type   : 'json',
                    params : {
                        ids : ids
                    },
                    scope : this,
                    success: function(res){
                        
                        var result = Ext.JSON.decode(res.responseText);

                        Ext.Msg.alert('Status', result.message);

                        this.search();

                        this.getApplication().fireEvent('grid-footer-history-reload');
                    },
                    failure: function(result, request){

                        Ext.Msg.alert("Failed", result.responseText);
                    }
                });
            }   
        }, this));
    },

    approval : function(){

        this.setSQLState('/manage/white_sql/approval', {approval_yn : 1});
    },

    unapproval : function(){

        this.setSQLState('/manage/white_sql/approval', {approval_yn : 0});
    },

    onWhiteSQL : function(){

        this.setSQLState('/manage/white_sql/setUsable', {on_off : 1});
    },

    offWhiteSQL : function(){

        this.setSQLState('/manage/white_sql/setUsable', {on_off : 0});
    },

    setSQLState : function(url, data_params){

        var grid = Ext.getCmp('grid-'+this.id);
        
        var sel  = grid.getSelectionModel().getSelection();
        
        var ids  = [];
        Ext.each(sel, function(record) {

            ids.push(record.raw.whitesql_id);
        });

        if(ids.length < 1){

            Ext.Msg.alert('Status', 'SQL을 선택하세요');
            return;
        }
        else {

            ids = ids.join(",");
        }
        // Send the id

        Ext.MessageBox.confirm('Confirm', '정말 진행하시겠습니까?', Ext.Function.bind(function(confirm){

            if(confirm == 'yes'){
   
                Ext.Ajax.request({
                    url    : url,
                    type   : 'json',
                    params : Ext.Object.merge({ ids : ids }, data_params),
                    scope : this,
                    success: function(res){
                        
                        var result = Ext.JSON.decode(res.responseText);

                        Ext.Msg.alert('Status', result.message);

                        Ext.each(sel, function(record) {

                            record.set(Ext.Object.merge(data_params, {state : 'M'}));
                        });

                        this.search();
                    },
                    failure: function(result, request){

                        Ext.Msg.alert("Failed", result.responseText);
                    }
                });
            }   
        }, this));
    },

    syncPolicy : function(){

        app = this.getApplication();
        app.syncPolicy('WhiteSQL');       
        app.on('policy-sync-complete', function(){

            this.search();
        }, this);
    }
});