Ext.define('WhiteSQL.controller.manage.SQLPolicy', {
    extend: 'Ext.app.Controller',

    /**
     *
     * 윈도우 생성
     *
     * @return component Ext.container.Container
     */
    initWindow : function(){

        var app = this.getApplication();

        Ext.create('Lib.Window', {
            id : 'window-'+this.id,
            title : 'SQL Policy',
            width : 900,
            height: 600,
            bodyPadding : '5 5 5 5',
            layout : 'fit',
            bodyStyle : 'background-color:#ffffff',
            items : [
                {
                    xtype : 'panel',
                    layout: 'vbox',
                    border : false,
                    region: 'center',
                    width : '100%',
                    flex  : 1,
                    items : [
                        this.initGridSearch(),
                        this.initGrid()
                    ]
                }
            ],
            listeners : {
                scope : this,
                close : function(){

                    if(!app.syncPolicies){

                        Ext.MessageBox.confirm('Confirm', '동기화하지 않은 정책이 존재합니다. 동기화 할까요?', Ext.Function.bind(function(confirm){

                            if(confirm == 'yes'){
                                
                                app.syncPolicy();
                            }

                        }, this));
                    }
                }
            }
        });
    },

    /**
     * initGridSearch
     *
     * 그리드 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGridSearch : function(){

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'vbox',
            frame : true,
            width : '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 0',
            items:[
                {
                    xtype   : 'container',
                    layout  : 'hbox',
                    width : '100%',
                    margin  : '0 0 5 0',
                    defaults: {
                        height : 26,
                        margin : '0 10 0 0'
                    },
                    items : [
                        {
                            margin : '5 2 0 0',
                            xtype : 'image',
                            width : 16,
                            height : 16,
                            src   : '/images/host_en.png'
                        },
                        {
                            xtype : 'text',
                            margin : '5 0 0 0',
                            id    : 'server-name-'+this.id,
                            width : 100,
                            text  : this.application.getServerName()
                        },
                        this.initComboBox(),
                        {
                            xtype: 'textfield',
                            id   : this.id+'-search-keyword',
                            name : this.id+'-search-keyword',
                            flex : 1
                        },
                        {
                            xtype:'button',
                            icon : '/images/find.png',
                            text: '검색',
                            scope : this,
                            handler : this.search
                        },
                        {
                            xtype:'button',
                            icon : '/images/checkbox_yes.png',
                            text: '전체선택',
                            scope : this,
                            handler : this.checkAll
                        },
                        {
                            xtype: 'buttongroup',
                            items : [
                                {
                                    xtype:'button',
                                    icon : '/images/on.png',
                                    text: '사용',
                                    scope : this,
                                    handler : this.onPolicy
                                },
                                {
                                    xtype:'button',
                                    icon : '/images/off.png',
                                    text: '미사용',
                                    scope : this,
                                    handler : this.offPolicy
                                }
                            ]
                        },
                        {
                            xtype: 'buttongroup',
                            items : [
                                {
                                    xtype:'button',
                                    icon : '/images/add.png',
                                    text: '추가',
                                    scope : this,
                                    handler : this.addPolicy
                                },
                                {
                                    xtype:'button',
                                    icon : '/images/policy_sync.png',
                                    text: '동기화',
                                    scope : this,
                                    handler : this.syncPolicy
                                },
                                {
                                    xtype:'button',
                                    icon : '/images/delete.png',
                                    text: '삭제',
                                    scope : this,
                                    handler : this.delPolicy
                                }
                            ]
                        }
                        // {
                        //     xtype: 'buttongroup',
                        //     items : [
                        //         {
                        //             xtype:'button',
                        //             icon : '/images/import.png',
                        //             text: '불러오기',
                        //             scope : this,
                        //             handler : this.importSQL
                        //         },
                        //         {
                        //             xtype:'button',
                        //             icon : '/images/export.png',
                        //             text: '내보내기',
                        //             scope : this,
                        //             handler : this.exportSQL
                        //         }
                        //     ]
                        // }
                    ]
                }
            ]
        };
        return form;
    },

    /**
     * initComboBox
     *
     * 콤보박스 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initComboBox : function(label, mode){

        var store = new Ext.data.Store({
            data : [{
                id : '',
                text : '전체'
            },{
                id : 'policy_name', text : '정책명'
            },{
                id : 'policy_type', text : '유형'
            }],
            fields: ['id','text']
        });

        // Simple ComboBox using the data store
        var combo = Ext.create('Ext.form.ComboBox', {
            id   : this.id+'-search-mode',
            name : this.id+'-search-mode',
            emptyText : '선택',
            displayField : 'text',
            editable : false,
            valueField: 'id',
            value : 'policy_name',
            store: store
        });

        return combo;
    },

    checkAll : function(){

        var grid = Ext.getCmp('grid-'+this.id),
            selModel = grid.getSelectionModel(),
            total = grid.store.getCount();

        if(total == 0){

            return;                
        }

        if(this.chkStatus){

            selModel.deselectRange(0, total - 1);
            this.chkStatus = 0;
        }
        else {

            selModel.selectRange(0, total - 1);
            this.chkStatus = 1;
        }
    },


    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGrid : function(mode){

        var selModel = Ext.create('Ext.selection.CheckboxModel', {
            mode : 'multi'
        });

        var columns = this.makeListColumns();

        var grid = Ext.create('Lib.Grid', {
            id : 'grid-'+this.id,
            url : '/manage/policy/getListData',
            title : mode,
            selModel : selModel,
            columns : columns
        });

        return grid;
    },

    /**
     * search
     *
     * 검색 수행
     *
     * @access public
     *
     */
    search : function(){

        var params = Ext.getCmp('form-'+this.id).getValues();        
        var grid   = Ext.getCmp('grid-'+this.id);

        this.getApplication().fireEvent('grid-search', grid, params);
    },


    /**
     * makeDetailListColumns
     *
     * 상세정보 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeListColumns : function(){   

        return [
            { text: '사용여부', dataIndex: 'on_off', width : 60, 
                renderer: function(value,metaDate,record,rowIndex,colIndex, store, view){

                    return value == 1 ? '사용' : '미사용'
                }
            },
            { text: '유형', dataIndex: 'policy_type', width : 120, renderer : function(value){

                var tmp = {'1' : 'SQL', '2' : 'SQL변경', '3' : 'IP', '4' : 'LOGIN ID', '5' : '주요 테이블', '6' : 'SQL 유형', '7' : '개인정보 테이블'};
                
                return tmp[value];
            }},
            { text: '정책', dataIndex: 'policy_name', flex : 1},
            { text: '등록자', dataIndex: 'user_name', width : 100},
            { text: '생성일시', dataIndex: 'reg_time', width : 130},
            { text: '상태', dataIndex: 'state', width : 80, renderer:function(value){ 
                
                switch(value){
                    case "A":
                        return "추가";
                        break;
                    case "M":
                        return "수정";
                        break;
                    case "D":
                        return "삭제";
                        break;
                    case "N":
                        return "동기화완료";
                        break;
                }
            }},
            {
                xtype : 'actioncolumn',
                width : 50,
                items : [
                    {
                        icon:'/images/edit.png',
                        tooltip : 'Modify',
                        scope : this,
                        handler : function (grid, rowIndex, colIndex, item, e, record) {
                            
                            this.modPolicy(record);
                        },
                        isDisabled: function(view, rowIndex, colIndex, item, record) {

                            // Returns true if 'editable' is false (, null, or undefined)
                            return record.get('state') == 'D';
                        }
                    },
                    {
                        icon:'/images/delete.png',
                        tooltip : 'Delete',
                        scope : this,
                        handler : function (grid, rowIndex, colIndex, item, e, record) {
                            //do your delete record function here
                            var me = this;
                            setTimeout(function(){
                                me.delPolicy();
                            }, 500);
                            
                        },
                        isDisabled: function(view, rowIndex, colIndex, item, record) {

                            // Returns true if 'editable' is false (, null, or undefined)
                            return record.get('state') == 'D';
                        }
                    }
                ]
            }
        ];
    },

    delPolicy : function(){

        var grid = Ext.getCmp('grid-'+this.id);

        var sel = grid.getSelectionModel().getSelection();

        var ids = [];
        Ext.each(sel, function(record) {

            ids.push(record.raw.policy_id);
        });

        if(ids.length < 1){

            Ext.Msg.alert('Status', '삭제하실 Policy SQL을 선택하세요');
            return;
        }
        else {

            ids = ids.join(",");
        }
        // Send the id

        Ext.MessageBox.confirm('Confirm', '정말 삭제하시겠습니까?', Ext.Function.bind(function(confirm){

            if(confirm == 'yes'){
   
                Ext.Ajax.request({
                    url: '/manage/policy/del',
                    type : 'json',
                    params : {
                        ids : ids
                    },
                    scope : this,
                    success: function(res){
                        
                        var result = Ext.JSON.decode(res.responseText);

                        Ext.Msg.alert('Status', result.message);

                        this.search();

                        this.getApplication().syncPolicies = false;
                    },
                    failure: function(result, request){

                        Ext.Msg.alert("Failed", result.responseText);
                    }
                });
            }   
        }, this));
    },

    addPolicy : function(){

        this.getApplication().openWindow('manage.SQLPolicy-Add');
    },

    modPolicy : function(record){

        this.getApplication().openWindow('manage.SQLPolicy-Add', record);
    },

    importSQL : function(){

        this.getApplication().openWindow('manage.SQLPolicy-Import');
    },

    exportSQL : function(){
        
        var params = Ext.getCmp('form-'+this.id).getValues();

        params.serverId = this.getApplication().serverId;
        location.href = "/manage/policy/export?"+Ext.urlEncode(params);
    },

    onPolicy : function(){

        this.setPolicyState('/manage/policy/setUsable', {on_off : 1});
    },

    offPolicy : function(){

        this.setPolicyState('/manage/policy/setUsable', {on_off : 0});
    },

    setPolicyState : function(url, data_params){

        var grid = Ext.getCmp('grid-'+this.id);
        
        var sel  = grid.getSelectionModel().getSelection();
        
        var ids  = [];
        Ext.each(sel, function(record) {

            ids.push(record.raw.policy_id);
        });

        if(ids.length < 1){

            Ext.Msg.alert('Status', 'SQL을 선택하세요');
            return;
        }
        else {

            ids = ids.join(",");
        }
        // Send the id

        Ext.MessageBox.confirm('Confirm', '정말 진행하시겠습니까?', Ext.Function.bind(function(confirm){

            if(confirm == 'yes'){
   
                Ext.Ajax.request({
                    url    : url,
                    type   : 'json',
                    params : Ext.Object.merge({ ids : ids }, data_params),
                    scope : this,
                    success: function(res){
                        
                        var result = Ext.JSON.decode(res.responseText);

                        Ext.Msg.alert('Status', result.message);

                        Ext.each(sel, function(record) {

                            record.set(Ext.Object.merge(data_params, {state : 'M'}));
                        });

                        this.getApplication().fireEvent('grid-footer-history-reload');
                    },
                    failure: function(result, request){

                        Ext.Msg.alert("Failed", result.responseText);
                    }
                });
            }   
        }, this));
    },

    syncPolicy : function(){

        app = this.getApplication();
        app.syncPolicy();       
        app.on('policy-sync-complete', function(){

            this.search();

        }, this);
    }
}); 