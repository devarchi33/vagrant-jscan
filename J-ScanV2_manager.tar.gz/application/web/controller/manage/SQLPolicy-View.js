Ext.require('CodeMirror.codemirror');
Ext.require('CodeMirror.mode.sql.sql');
Ext.define('WhiteSQL.controller.manage.SQLPolicy-View', {
    extend: 'Ext.app.Controller',

    initWindow : function(policy_id){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id,
            application : this.application,
            title : '정책 보기',
            width : 900,
            height: 600,
            buttons : this.initButtons(),
            items : this.initDetail(policy_id)
        });
    },

    initDetail : function(policy_id){

        var record = {};

        Ext.Ajax.request({
            url: '/manage/policy/get/'+policy_id,
            type : 'json',
            scope : this,
            async : false,
            success: function(res){
                
                record = Ext.JSON.decode(res.responseText);
            },
            failure: function(result, request){

                Ext.Msg.alert("Failed", result.responseText);

                var win = button.up("window");
                win.destroy();
            }
        });

        var properties = {};
        if(record.policy_properties){

            properties = Ext.JSON.decode(record.policy_properties);
        }

        policy_type = record.policy_type;

        return {
            xtype   : 'form',
            layout  : 'vbox',
            bodyPadding : '5 5 5 5',
            border  : false,
            autoScroll : true,
            flex : 1,
            items:[
                this.initFieldSet({
                    title  : '정책 기본 정보', 
                    hidden : false,
                    items  : [{
                        fieldLabel : '정책유형',
                        value : function(type){

                            return [
                                'SQL', 'SQL 변경', 'IP', 'LOGIN ID', 
                                '주요 TABLE', 'SQL 유형', '개인정보TABLE'
                            ][type - 1];

                        }(record.policy_type)
                    },{
                        fieldLabel : '정책명',
                        value : record.policy_name
                    },{
                        fieldLabel : '정책켜기',
                        value : (record.on_off == 1 ? "켜짐" : "꺼짐")
                    },{
                        fieldLabel : '차단여부',
                        value : (record.block == 1 ? "차단함" : "차단안함")
                    },{
                        fieldLabel : '알람레벨',
                        value : function(level){


                            return [
                                '알림', '주의', '경보', '위험', '심각' 
                            ][level - 1];

                        }(record.alarm_level)
                    },{
                        fieldLabel : '정책등록일',
                        value : record.reg_time
                    }]
                }),
                this.initFieldSet({
                    title : '정책 정보 - SQL', 
                    hidden : (policy_type == 1 || policy_type == 2 ? false : true),
                    items : {
                        value : properties.target
                    }
                }),
                this.initFieldSet({
                    title : '정책 정보 - SQL 변경', 
                    hidden : (policy_type == 2 ? false : true),
                    items : {
                        value : properties.convert
                    }
                }),
                this.initFieldSet({
                    title : '정책 정보 - 아이피', 
                    hidden : (policy_type == 3 ? false : true),
                    items : {
                        value : properties.target
                    }
                }),
                this.initFieldSet({
                    title : '정책 정보 - 주요 테이블', 
                    hidden : (policy_type == 5 ? false : true),
                    items : {
                        value : properties.target
                    }
                }),
                this.initFieldSet({
                    title : '정책 정보 - 로그인아이디', 
                    hidden : (policy_type == 4 ? false : true),
                    items : {
                        value : properties.target
                    }
                }),
                this.initFieldSet({
                    title : '정책 정보 - 쿼리유형', 
                    hidden : (policy_type == 6 ? false : true),
                    items : {
                        value : properties.target
                    }
                }),
                this.initFieldSet({
                    title : '정책 정보 - 개인정보 테이블', 
                    hidden : (policy_type == 7 ? false : true),
                    items : {
                        value : properties.target
                    }
                })
            ]
        }
    },

    initFieldSet : function(config){

        return Ext.apply({
            xtype : 'fieldset',
            width : '100%',
            defaults : {
                labelWidth: 100,
                labelStyle: 'color:#008000',
                width : '100%',
                anchor : '100%',
                xtype : 'displayfield',
                labelPad : 5
            }
        }, config);
    },

    /**
     * initButtons
     *
     * 버튼 생성
     *
     * @access public
     *
     * @return button array
     */
    initButtons : function(){

        return [{
            text : '닫기',
            handler : function(){

                this.up("window").destroy();
            }
        }];
    }
});