Ext.define('WhiteSQL.controller.manage.PrivacyTable-Add', {
    extend: 'Ext.app.Controller',
    mode : 'add',
    initWindow : function(record){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id,
            application : this.application,
            title : record ? '개인정보 테이블 수정' : '개인정보 테이블 추가',
            width : 600,
            height: 200,
            buttons : this.initButtons(),
            items : this.initDetail(record)
        });
    },

    initDetail : function(record){

        var bindData = {};
        
        if(record) {

            data = record.raw;
            
            this.mode = 'mod';

            bindData = {
                'add-privacy-table-id'  : data.privacytbl_id,
                'add-privacy-table-name': data.privacytbl_name,
                'add-privacy-table'     : data.privacytbl
            };
        }
        else {

            this.mode = 'add';
            this.old_privacytbl_name = '';
        }
        
        return {
            xtype   : 'form',
            layout  : 'vbox',
            bodyPadding : '5 5 5 5',
            border  : false,
            autoScroll : true,
            flex : 1,
            items:[
                this.initFieldSet({
                    title  : '개인정보 테이블 정보', 
                    hidden : false,
                    id     : 'fieldset-default-info',
                    items  : [
                        this.initPrivacyTableId(),
                        this.initPrivacyTableName(),
                        this.initPrivacyTable()
                    ]
                })
            ],
            listeners : {
                boxready : function(form){

                    form.getForm().setValues(bindData);
                }
            }
        }
    },

    initFieldSet : function(config){

        return Ext.apply({
            xtype : 'fieldset',
            width : '100%',
            defaults : {
                labelWidth: 100,
                labelStyle: 'color:#008000',
                width     : '100%',
                anchor    : '100%',
                xtype     : 'textfield',
                labelPad  : 5
            }
        }, config);
    },

    /**
     * initButtons
     *
     * 버튼 생성
     *
     * @access public
     *
     * @return button array
     */
    initButtons : function(){

        return [{
            text: '리셋',
            handler: function() {
                this.up('form').getForm().reset();
            }
        }, 
        {
            text: '저장',
            formBind: true, //only enabled once the form is valid
            //disabled: true,
            scope : this,
            handler : this.save
        },
        {
            text : '닫기',
            handler : function(){

                this.up("window").destroy();
            }
        }];
    },

    /**
     * initPrivacyTableId
     *
     * 서버아이디 설정 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.HiddenField
     */
    initPrivacyTableId : function(){

        return {
            xtype: 'hiddenfield',
            id   : 'add-privacy-table-id',
            name : 'add-privacy-table-id'
        };
    },

    /**
     * initPrivacyTableName
     *
     * 개인정보 테이블명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initPrivacyTableName : function(){

        return {
            xtype     : 'textfield',
            fieldLabel: '테이블명칭',
            id        : 'add-privacy-table-name',
            name      : 'add-privacy-table-name',
            allowBlank: false
        };
    },

    /**
     * initPrivacyTable
     *
     * 개인정보 테이블명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initPrivacyTable : function(){

        var store = new Ext.data.Store({
            proxy: {
                type  : 'ajax',
                url: '/manage/privacy_table/getUniqSQLTableListByQuery',
                reader: {
                    type: 'json'
                }
            },
            fields: [
                { name : 'id', type : 'string' },
                { name : 'text', type : 'string' }
            ],
            autoLoad : true
        });

        // Simple ComboBox using the data store
        return {
            xtype           : 'combobox',
            fieldLabel      : '테이블',
            id              : 'add-privacy-table',
            name            : 'add-privacy-table',
            displayField    : 'text',
            emptyText       : '개인 정보 테이블 입력',
            disableKeyFilter: true,
            valueField      : 'text',
            validateBlank   : true,
            allowBlank      : false,
            blankText       : '개인 정보 테이블을 입력해주세요.',
            store           : store,
            hideTrigger     : true,
            minChars        : 1,
            triggerAction   : 'query',
            typeAhead       : true
        };
    },

    save : function(button, event){

        var frm    = button.up('window').down('form');
        var valid  = true;
        frm.query('field').forEach(function(field){
            if(!field.isVisible(true)) return;
            if(!field.isValid()) valid = false;
        });

        if(!valid){

            return;
        }

        var params = frm.getValues();

        params.agent_id = WhiteSQL.app.serverId;

        Ext.Ajax.request({
            url: '/manage/privacy_table/save',
            type : 'json',
            params : params,
            scope : this,
            success: function(res){
                
                var result = Ext.JSON.decode(res.responseText);

                Ext.Msg.alert('Status', result.message);

                var ctrl = this.getController('manage.PrivacyTable');
                ctrl.search();

                var win = button.up("window");
                win.destroy();
            },
            failure: function(result, request){

                Ext.Msg.alert("Failed", result.responseText);

                var win = button.up("window");
                win.destroy();
            }
        });
    } 
});