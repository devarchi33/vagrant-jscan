Ext.define('WhiteSQL.controller.manage.Database-Edit', {
    extend: 'Ext.app.Controller',
    winId : null,
    editMode : false,
    
    /**
     * init
     * 
     * 컨트롤러 초기화 메소드.
     * 
     * @access public
     *
     * @return 
     */
    init:function(){

        //기본 탭아이디 생성
        this.winId = 'window-'+this.id;
    },

    /**
     *
     * 윈도우 생성
     *
     * @return component Ext.container.Container
     */
    initWindow : function(record){

        this.window = Ext.create('Ext.window.Window', {
            id : this.winId,
            stateful: true,
            stateId: 'state-'+this.winId,
            title : 'Edit Database',
            layout : 'fit',
            bodyStyle:"background-color:#FFFFFF",
            width : 500,
            height : 200,
            modal : true,
            plain: true,
            fixed : true,
            shadow : false,
            autoShow : true,
            constrain : true,
            items : this.initDetail(record)
        });

        return this.window;
    },

    initDetail : function(record){

        var bindData = {};
    
        if(record) {

            var data = record.raw;

            this.old_database_name = data.dbname;

            Ext.apply(bindData, {
                'add-database-name': data.dbname,
                'add-database-id'  : data.dbconn_id,
                'add-database-ip'  : data.ipaddr,
                'add-database-port': data.port,
                'add-database-sid' : data.sid
            });
        }
        
        Ext.applyIf(bindData, {
            'add-database-id' : ''
        });

        return {
            xtype : 'form',
            id : 'form-'+this.winId,
            layout: 'vbox',
            width : '100%',
            height: '100%',
            padding: '5 5 5 5',
            border : false,
            url : '/manage/server/modDatabase',
            type : 'json',
            defaults : {
                labelWidth: 100,
                width : '100%',
                anchor : '100%',
                xtype : 'textfield',
                labelPad : 5,
                labelClsExtra : 'x-panel-header-default'
            },
            items:[
                this.initDatabaseId(),
                this.initDatabaseName(),
                this.initDatabaseIP(),
                this.initDatabasePort(),
                this.initDatabaseSID()
            ],
            // Reset and Submit buttons
            buttons: this.initButtons(),
            listeners : {
                boxready : function(form){

                    form.getForm().setValues(bindData);
                }
            }
        }
    },

    /**
     * initDatabaseId
     *
     * 서버아이디 설정 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.HiddenField
     */
    initDatabaseId : function(){

        return {
            xtype            : 'hiddenfield',
            id               : 'add-database-id',
            name             : 'add-database-id'
        };
    },

    /**
     * initDatabaseName
     *
     * 서버명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initDatabaseName : function(){

        return {
            xtype : 'textfield',
            fieldLabel: 'DB명',
            id: 'add-database-name',
            name: 'add-database-name',
            allowBlank: false,
            validator : Ext.Function.pass(function(context, value){

                if(context.old_database_name == value) {

                    this.clearInvalid();
                    this.textValid = true;
                    return true;
                }
                else {

                    return this.textValid;
                }
            }, this),
            listeners : {
                scope : this,
                change : function(textfield, newValue, oldValue) {

                    if(this.old_database_name == newValue) {

                        textfield.clearInvalid();
                        textfield.textValid = true;

                        return;
                    }

                    Ext.Ajax.request({
                        url: '/manage/server/checkDatabaseName',
                        type : 'json',
                        params : {
                            text : newValue
                        },
                        scope: textfield,
                        success: function(res){
                            
                            var res = Ext.JSON.decode(res.responseText);

                            if(res.result == "success"){

                                textfield.clearInvalid();
                                textfield.textValid = true;
                            }
                            else {

                                textfield.markInvalid(res.message);
                                textfield.textValid = '이미 존재하는 DB명입니다.';
                            }
                        },
                        failure: function(result, request){

                            textfield.markInvalid('network error');
                            textfield.textValid = false;
                        }
                    });
                }
            }
        };
    
        if(textfield.old_database_name){

            textfield.clearInvalid();
            textfield.textValid = true;
        }
        
        return textfield;
    },

    /**
     * initDatabaseIP
     *
     * 아이피 주소 입력 폼 생성
     *
     * @access public
     *
     * @return component Ext.container.Container
     */
    initDatabaseIP : function(){

        return {
            xtype            : 'displayfield',
            fieldLabel       : 'DB IP',
            id               : 'add-database-ip',
            name             : 'add-database-ip',
            allowBlank       : false,
            hideTrigger      : true,
            keyNavEnabled    : false,
            mouseWheelEnabled: false
        };
    },


    /**
     * initDatabasePort
     *
     * 포트 입력 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    initDatabasePort : function(){

        return {
            xtype            : 'displayfield',
            fieldLabel       : 'DB Port',
            id               : 'add-database-port',
            name             : 'add-database-port',
            allowBlank       : false,
            hideTrigger      : true,
            keyNavEnabled    : false,
            mouseWheelEnabled: false
        };
    },

    /**
     * initDatabaseSID
     *
     * DB SID 입력 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initDatabaseSID : function(){

        return {
            xtype            : 'displayfield',
            fieldLabel       : 'DB SID',
            id               : 'add-database-sid',
            name             : 'add-database-sid',
            hideTrigger      : true,
            keyNavEnabled    : false,
            mouseWheelEnabled: false
        };
    },

    /**
     * initButtons
     *
     * 버튼 생성
     *
     * @access public
     *
     * @return button array
     */
    initButtons : function(){

        return [{
            text: '리셋',
            handler: function() {
                this.up('form').getForm().reset();
            }
        }, 
        {
            text: '저장',
            formBind: true, //only enabled once the form is valid
            disabled: true,
            scope : this,
            handler: this.save
        },
        {
            text : '닫기',
            handler : function(){

                this.up("window").destroy();
            }
        }];
    },

    /**
     * save
     *
     * 저장
     *
     * @access public
     *
     */
    save : function(){

        form = Ext.getCmp('form-'+this.winId);
        if (form.isValid()) {

            form.submit({
                scope : this,
                waitMsg : '처리중 입니다.',
                success: function(form, action) {

                    var result = Ext.JSON.decode(action.response.responseText);

                    Ext.Msg.alert('Status', result.message);

                    var cmpDBTree = Ext.getCmp('database-tree');

                    cmpDBTree.getStore().reload({node : cmpDBTree.getRootNode()});

                    this.window.destroy();
                },
                failure: function(form, action) {

                    Ext.Msg.alert('Failed', action.response.responseText);
                }
            });
        }
    }
});