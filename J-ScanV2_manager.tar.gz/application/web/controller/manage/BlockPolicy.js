Ext.define('WhiteSQL.controller.manage.BlockPolicy', {
    extend: 'Ext.app.Controller',
    
    /**
     *
     * 윈도우 생성
     *
     * @return component Ext.container.Container
     */
    initWindow : function(){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id,
            title : '차단 정책',
            width : 1200,
            height: 800,
            bodyPadding : '5 5 5 5',
            layout : 'fit',
            items : [
                {
                    xtype : 'panel',
                    layout: 'border',
                    width : '100%',
                    border: 0,
                    flex  : 1,
                    items : [
                        {
                            xtype : 'panel',
                            layout: 'vbox',
                            border : false,
                            region: 'center',
                            width : '100%',
                            flex  : 1,
                            items : [
                                this.initGridSearch(),
                                this.initGrid()
                            ]
                        },
                        this.initQueryField()
                    ]
                }
            ]
        });
    },

    /**
     * initGridSearch
     *
     * 그리드 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGridSearch : function(){

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'vbox',
            frame : true,
            width : '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 0',
            items:[
                {
                    xtype   : 'container',
                    layout  : 'hbox',
                    margin  : '0 0 5 0',
                    width : '100%',
                    defaults: {
                        height : 26,
                        margin : '0 10 0 0'
                    },
                    items : [
                        {
                            margin : '5 2 0 0',
                            xtype : 'image',
                            width : 16,
                            height : 16,
                            src   : '/images/host_en.png'
                        },
                        {
                            xtype : 'text',
                            margin : '5 0 0 0',
                            id    : 'server-name-'+this.id,
                            width : 100,
                            text  : this.application.getServerName()
                        },
                        this.initComboBox(),
                        {
                            xtype : 'textfield',
                            id    : this.id+'-search-keyword',
                            name  : this.id+'-search-keyword',
                            flex  : 1,
                        },
                        {
                            xtype:'button',
                            icon : '/images/find.png',
                            text: '검색',
                            scope : this,
                            handler : this.search
                        },
                        {
                            xtype: 'buttongroup',
                            items : [
                                {
                                    xtype:'button',
                                    icon : '/images/on.png',
                                    text: '사용',
                                    scope : this,
                                    handler : this.onWhiteSQL
                                },
                                {
                                    xtype:'button',
                                    icon : '/images/off.png',
                                    text: '미사용',
                                    scope : this,
                                    handler : this.offWhiteSQL
                                }
                            ]
                        },
                        {
                            xtype: 'buttongroup',
                            items : [
                                {
                                    xtype:'button',
                                    icon : '/images/policy_sync.png',
                                    text: '동기화',
                                    scope : this,
                                    handler : this.syncPolicy
                                },
                                {
                                    xtype:'button',
                                    icon : '/images/delete.png',
                                    text: '삭제',
                                    scope : this,
                                    handler : this.delSQL
                                }
                            ]
                        }
                    ]
                }
            ]
        };
        return form;
    },

    /**
     * initComboBox
     *
     * 콤보박스 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initComboBox : function(label, mode){

        var store = new Ext.data.Store({
            data : [{
                id : 'policy_type', text : '유형'
            },{
                id : 'sqltext', text : '쿼리'
            }],
            fields: ['id','text']
        });

        // Simple ComboBox using the data store
        var combo = Ext.create('Ext.form.ComboBox', {
            id   : this.id+'-search-mode',
            name : this.id+'-search-mode',
            emptyText : '선택',
            displayField : 'text',
            valueField: 'id',
            value : 'policy_type',
            store: store
        });

        return combo;
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGrid : function(mode){

        var selModel = Ext.create('Ext.selection.CheckboxModel', {
            mode : 'multi'
        });

        var columns = this.makeListColumns();

        var grid = Ext.create('Lib.Grid', {
            id : 'grid-'+this.id,
            url : '/manage/white_sql/getListData',
            title : mode,
            columns : columns,
            selModel : selModel,
            listeners: {
                scope : this,
                itemclick : function(grid, record) {
                    
                    Ext.Ajax.request({
                        url    : '/manage/white_sql/getQueryData/'+record.raw.whitesql_id,
                        type   : 'json',
                        async  : false,
                        scope  : this,
                        success: function(res){

                            var data = Ext.JSON.decode(res.responseText);

                            Ext.getCmp(this.id+'-org-sql').update(data.orig_sqltext);
                        }
                    });
                }
            }
        });

        return grid;
    },

    /**
     * search
     *
     * 검색 수행
     *
     * @access public
     *
     */
    search : function(){

        var params = Ext.getCmp('form-'+this.id).getValues();        
        var grid   = Ext.getCmp('grid-'+this.id);

        this.getApplication().fireEvent('grid-search', grid, params);
    },

    initQueryField : function(){

        return {
            xtype       : 'panel',
            layout      : 'vbox',
            region      : 'south',
            split       : true,
            collapsible : true,
            header      : false,
            width       : '100%',
            height      : 150,
            border      : false,
            bodyBorder  : false,
            defaults    : {
                xtype      : 'fieldset',
                height     : '100%',
                flex       : 1, 
                padding    : 10,
                autoScroll : true,
            },
            items:[
                {
                    region :'east',
                    split  : true,
                    width  : '100%',
                    id     : this.id+'-org-sql',
                    title  : '쿼리'
                }
            ]
        };
    },

    /**
     * makeDetailListColumns
     *
     * 상세정보 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeListColumns : function(){   

        return [
            Ext.create('Ext.grid.RowNumberer'),
            { text: 'On/Off', dataIndex: 'on_off', width : 300},
            { text: '유형', dataIndex: 'orig_sqltext' , flex: 1 },
            { text: '정책', dataIndex: 'on_off', width : 60 },
            { text: '생성일시', dataIndex: 'reg_date', width : 100 },
            { text: '승인시간', dataIndex: 'approval_time', width : 130 }
        ];
    },

    delSQL : function(){

        var grid = Ext.getCmp('grid-'+this.id);
        
        var sel  = grid.getSelectionModel().getSelection();
        
        var ids  = [];
        Ext.each(sel, function(record) {

            ids.push(record.raw.whitesql_id);
        });

        if(ids.length < 1){

            Ext.Msg.alert('Status', '삭제하실 SQL을 선택하세요');
            return;
        }
        else {

            ids = ids.join(",");
        }
        // Send the id

        Ext.MessageBox.confirm('Confirm', '정말 삭제하시겠습니까?', Ext.Function.bind(function(confirm){

            if(confirm == 'yes'){
   
                Ext.Ajax.request({
                    url    : '/manage/white_sql/del',
                    type   : 'json',
                    params : {
                        ids : ids
                    },
                    scope : this,
                    success: function(res){
                        
                        var result = Ext.JSON.decode(res.responseText);

                        Ext.Msg.alert('Status', result.message);

                        this.search();

                        this.getApplication().fireEvent('grid-footer-history-reload');
                    },
                    failure: function(result, request){

                        Ext.Msg.alert("Failed", result.responseText);
                    }
                });
            }   
        }, this));
    },

    onWhiteSQL : function(){

        this.setSQLState('/manage/white_sql/setUsable', {on_off : 1});
    },

    offWhiteSQL : function(){

        this.setSQLState('/manage/white_sql/setUsable', {on_off : 0});
    },

    setSQLState : function(url, data_params){

        var grid = Ext.getCmp('grid-'+this.id);
        
        var sel  = grid.getSelectionModel().getSelection();
        
        var ids  = [];
        Ext.each(sel, function(record) {

            ids.push(record.raw.whitesql_id);
        });

        if(ids.length < 1){

            Ext.Msg.alert('Status', 'SQL을 선택하세요');
            return;
        }
        else {

            ids = ids.join(",");
        }
        // Send the id

        Ext.MessageBox.confirm('Confirm', '정말 진행하시겠습니까?', Ext.Function.bind(function(confirm){

            if(confirm == 'yes'){
   
                Ext.Ajax.request({
                    url    : url,
                    type   : 'json',
                    params : Ext.Object.merge({ ids : ids }, data_params),
                    scope : this,
                    success: function(res){
                        
                        var result = Ext.JSON.decode(res.responseText);

                        Ext.Msg.alert('Status', result.message);

                        Ext.each(sel, function(record) {

                            record.set(Ext.Object.merge(data_params, {state : 'M'}));
                        });

                        this.getApplication().fireEvent('grid-footer-history-reload');
                    },
                    failure: function(result, request){

                        Ext.Msg.alert("Failed", result.responseText);
                    }
                });
            }   
        }, this));
    },

    syncPolicy : function(){

        app = this.getApplication();
        app.syncPolicy();       
        app.on('policy-sync-complete', function(){

            this.search();
        }, this);
    }
});