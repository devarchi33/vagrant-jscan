Ext.require('CodeMirror.codemirror');
Ext.require('CodeMirror.mode.sql.sql');

Ext.define('WhiteSQL.controller.manage.SQLConvert-Edit', {
    extend: 'Ext.app.Controller',

    initWindow : function(convsql_id){

        this.orig_edit = null;
        this.conv_edit = null;
        this.convsql_id = convsql_id;
        this.conv_sqltext = null;
        this.conv_usable = null;

        this.window = Ext.create('Lib.Window', {
            id : 'window-'+this.id+'-detail',
            application : this.application,
            title : 'SQL Convert 수정',
            width : 1000,
            height: 800,
            bodyPadding : '5 5 5 5',
            layout : 'vbox',
            buttons : [{
                id : 'btnSetUsable',
                text: '미사용',
                scope : this,
                handler: this.setUsable         
            },{
                text: '저장',
                scope : this,
                handler: this.modSQLConvert
            }],
            items : [
                this.initQueryField()
            ]
        });

        Ext.Ajax.request({
            url: '/manage/sql_convert/getQueryData/'+convsql_id,
            type : 'json',
            async : false,
            scope : this,
            success: function(res){
                
                var data = Ext.JSON.decode(res.responseText);

                this.conv_usable = data.on_off == 1 ? true : false;

                var origSql = Ext.getCmp(this.id+'-orig-sql');
                var convSql = Ext.getCmp(this.id+'-conv-sql');

                origSql.setValue(data.orig_sqltext);
                convSql.setValue(data.conv_sqltext);
                
                origTextArea = origSql.getEl().query('textarea')[0];
                convTextArea = convSql.getEl().query('textarea')[0];

                this.orig_edit = CodeMirror.fromTextArea(origTextArea, {
                    mode: 'text/x-plsql',
                    indentWithTabs: true,
                    smartIndent: true,
                    lineNumbers: true,
                    lineWrapping : true,
                    matchBrackets : true,
                    autofocus: true,
                    readOnly : true
                });
                
                this.orig_edit.setSize(origSql.getWidth(), origSql.getHeight());

                this.conv_edit = CodeMirror.fromTextArea(convTextArea, {
                    mode: 'text/x-plsql',
                    indentWithTabs: true,
                    smartIndent: true,
                    lineNumbers: true,
                    lineWrapping : true,
                    matchBrackets : true,
                    autofocus: true
                });

                this.conv_edit.setSize(convSql.getWidth(), convSql.getHeight());

                var title = this.window.title;
                title += " - " + (this.conv_usable == true ? "사용" : "미사용");
                this.window.setTitle(title);

                Ext.getCmp('btnSetUsable').setText(this.conv_usable == true ? "미사용" : "사용");
            },
            failure: function(result, request){

                Ext.Msg.alert("Failed", result.responseText);
            }
        });
    },

    initQueryField : function(){

        return {
            xtype      : 'panel',
            layout     : 'border',
            header     : false,
            width      : '100%',
            flex       : 1,
            border     : false,
            bodyBorder : false,
            collapsible: true,
            bodyStyle  :{"background-color":"#ffffff"}, 
            defaults   : {
                xtype     : 'panel',
                layout    : 'vbox',
                height    : '100%',
                flex      : 1, 
                autoScroll: true,
                border    :false
            },
            items:[
                {
                    region  :'west',
                    split   : true,
                    minWidth: 200,
                    title   : '원본쿼리',
                    items   : [{
                        xtype: 'textareafield',
                        id   : this.id+'-orig-sql',
                        width: '100%',
                        flex : 1,
                        listeners : {
                            scope : this,
                            resize: function(win, width, height){

                                if(this.orig_edit) this.orig_edit.setSize(width, height);
                            }
                        }
                    }]
                },
                {
                    region  :'center',
                    minWidth: 200,
                    title   : '변경쿼리',
                    items   : [{
                        xtype: 'textareafield',
                        id   : this.id+'-conv-sql',
                        width: '100%',
                        flex : 1,
                        listeners : {
                            scope : this,
                            resize: function(win, width, height){
                                
                                if(this.conv_edit) this.conv_edit.setSize(width, height);
                            }
                        }
                    }]
                }
            ]
        };
    },

    modSQLConvert : function(){

        Ext.Ajax.request({
            url: '/manage/sql_convert/mod',
            type : 'json',
            params : {
                id : this.convsql_id,
                text : this.conv_edit.getValue()
            },
            scope : this,
            success: function(res){
                
                var result = Ext.JSON.decode(res.responseText);

                Ext.Msg.alert('Status', result.message);
                this.window.destroy();

                this.getApplication().fireEvent('grid-footer-history-reload');
            },
            failure: function(result, request){

                Ext.Msg.alert("Failed", result.responseText);
            }
        });
    },

    setUsable : function(btn){

        var usable = this.conv_usable;

        Ext.Ajax.request({
            url: '/manage/sql_convert/setUsable',
            type : 'json',
            params : {
                ids : this.convsql_id,
                on_off : usable ? 0 : 1
            },
            scope : this,
            success: function(res){
                
                var result = Ext.JSON.decode(res.responseText);

                if(this.conv_usable = null || this.conv_usable == false){

                    this.conv_usable = true;
                }
                else {

                    this.conv_usable = false;
                }

                btn.setText(this.conv_usable == true ? '미사용' : '사용');
                this.window.setTitle('SQL Convert 수정 - '+ (this.conv_usable == true ? '사용' : '미사용'));

                this.getApplication().fireEvent('grid-footer-history-reload');
            },
            failure: function(result, request){

                Ext.Msg.alert("Failed", result.responseText);
            }
        });
    }
});