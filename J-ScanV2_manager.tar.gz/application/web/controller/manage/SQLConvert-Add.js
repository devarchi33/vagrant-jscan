Ext.define('WhiteSQL.controller.manage.SQLConvert-Add', {
    extend: 'Ext.app.Controller',

    initWindow : function(log_id){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id+'-detail',
            application : this.application,
            title : 'SQL Convert 추가',
            width : 900,
            height: 800,
            bodyPadding : '5 5 5 5',
            layout : 'vbox',
            buttons : [{
                text: '추가',
                scope : this,
                handler: this.addSQLConvert         
            }],
            items : [
                {
                    xtype : 'panel',
                    layout: 'border',
                    width : '100%',
                    border: 0,
                    flex  : 1,
                    items : [
                        {
                            xtype : 'panel',
                            layout: 'vbox',
                            border : false,
                            region: 'center',
                            width : '100%',
                            flex  : 1,
                            items : [
                                this.initGridSearch(),
                                this.initGrid()
                            ]
                        },
                        this.initQueryField()
                    ]
                }
            ]
        });
    },

    /**
     * initGridSearch
     *
     * 그리드 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGridSearch : function(){

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'vbox',
            frame : true,
            width : '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 0',
            defaults : {
                labelWidth: 80
            },
            items:[
                {
                    xtype   : 'container',
                    layout  : 'hbox',
                    margin  : '0 0 5 0',
                    defaults: {
                        labelWidth: 80,
                        height : 26,
                        margin : '0 10 0 0'
                    },
                    items : [
                        this.initComboBox(),
                        {
                            xtype: 'textfield',
                            id   : this.id+'-search-keyword',
                            name : this.id+'-search-keyword',
                            width: 300
                        },
                        {
                            xtype:'button',
                            icon : '/images/find.png',
                            text: '검색',
                            scope : this,
                            handler : this.search
                        },
                        {
                            xtype: 'buttongroup',
                            items : [
                                {
                                    xtype:'button',
                                    icon : '/images/export.png',
                                    text: '내보내기',
                                    scope : this,
                                    handler : this.search
                                }
                            ]
                        }
                    ]
                }
            ]
        };
        return form;
    },

    /**
     * initComboBox
     *
     * 콤보박스 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initComboBox : function(label, mode){

        var store = new Ext.data.Store({
            data : [{
                id : 'class_string', text : '클래스명'
            },{
                id : 'sqltext', text : '쿼리'
            }],
            fields: ['id','text']
        });

        // Simple ComboBox using the data store
        var combo = Ext.create('Ext.form.ComboBox', {
            id   : this.id+'-search-mode',
            name : this.id+'-search-mode',
            emptyText : '선택',
            displayField : 'text',
            valueField: 'id',
            value : 'class_string',
            store: store
        });

        return combo;
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGrid : function(mode){

        var selModel = Ext.create('Ext.selection.CheckboxModel', {
            mode : 'multi'
        });

        var columns = this.makeListColumns();

        var grid = Ext.create('Lib.Grid', {
            id : 'grid-'+this.id,
            url : '/manage/white_sql/getListData/1',
            title : mode,
            selModel : selModel,
            columns : columns,
            listeners: {
                scope : this,
                itemclick: function(grid, record, item, index, e, eOpts) {
                    
                    if(e.ctrlKey == true || e.shiftKey == true) return;

                    Ext.Ajax.request({
                        url    : '/manage/white_sql/getQueryData/'+record.raw.whitesql_id,
                        type   : 'json',
                        async  : false,
                        scope  : this,
                        success: function(res){

                            var data = Ext.JSON.decode(res.responseText);

                            Ext.getCmp(this.id+'-orig-sql').update(data.orig_sqltext);
                        }
                    });
                }
            }
        });

        return grid;
    },

    /**
     * makeDetailListColumns
     *
     * 상세정보 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeListColumns : function(){   

        return [
            { text: '클래스명', dataIndex: 'class_string'},
            { text: '쿼리', dataIndex: 'orig_sqltext' , flex: 1 }
        ];
    },

    /**
     * search
     *
     * 검색 수행
     *
     * @access public
     *
     */
    search : function(){

        var params = Ext.getCmp('form-'+this.id).getValues();        
        var grid   = Ext.getCmp('grid-'+this.id);

        this.getApplication().fireEvent('grid-search', grid, params);
    },

    initQueryField : function(){

        return {
            xtype : 'panel',
            layout : 'vbox',
            region: 'south',
            split : true,
            collapsible : true,
            header : false,
            width : '100%',
            height : 150,
            border : false,
            bodyBorder : false,
            defaults : {
                xtype : 'fieldset',
                height : '100%',
                flex  : 1, 
                padding : 10,
                autoScroll : true,
            },
            items:[
                {
                    region:'east',
                    split : true,
                    width : '100%',
                    id : this.id+'-orig-sql',
                    title: '쿼리'
                }
            ]
        };
    },

    addSQLConvert : function(button, event){

        var grid = Ext.getCmp('grid-'+this.id);

        var sel = grid.getSelectionModel().getSelection();

        var ids = [];
        Ext.each(sel, function(record) {

            ids.push(record.raw.whitesql_id);
        });

        if(ids.length < 1){

            Ext.Msg.alert('Status', '추가하실 White SQL을 선택하세요');
            return;
        }
        else {

            ids = ids.join(",");
        }

        Ext.Ajax.request({
            url: '/manage/sql_convert/add',
            type : 'json',
            params : {
                ids : ids.toString(),
                serverId : this.getApplication().serverId
            },
            scope : this,
            success: function(res){
                
                var result = Ext.JSON.decode(res.responseText);

                Ext.Msg.alert('Status', result.message);

                var ctrl = this.getController('manage.SQLConvert');
                ctrl.search();

                this.getApplication().fireEvent('grid-footer-history-reload');

                var win = button.up("window");
                win.destroy();
            },
            failure: function(result, request){

                Ext.Msg.alert("Failed", result.responseText);

                var win = button.up("window");
                win.destroy();
            }
        });
    } 
});