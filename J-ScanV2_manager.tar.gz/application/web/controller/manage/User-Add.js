Ext.define('WhiteSQL.controller.manage.User-Add', {
    extend: 'Ext.app.Controller',
    winId : null,
    
    /**
     * init
     * 
     * 컨트롤러 초기화 메소드.
     * 
     * @access public
     *
     * @return 
     */
    init:function(){

        //기본 탭아이디 생성
        this.winId = 'window-'+this.id;
    },

    onLaunch : function(){

        this.fireEvent('loaded');
    },

    /**
     *
     * 윈도우 생성
     *
     * @return component Ext.container.Container
     */
    initWindow : function(record){

        this.mode = record ? 'edit' : 'add';

        this.window = Ext.create('Ext.window.Window', {
            id : this.winId,
            stateful: true,
            stateId: 'state-'+this.winId,
            title : (this.mode == 'add' ? 'Add' : 'Edit') + ' User',
            layout : 'fit',
            bodyStyle:"background-color:#FFFFFF",
            width : 800,
            height: 300,
            overflowY: 'auto',
            autoScroll : true,
            modal : true,
            plain: true,
            fixed : true,
            shadow : false,
            autoShow : true,
            constrain : true,
            items : this.initDetail(record)
        });

        return this.window;
    },

    initDetail : function(record){

        var user_level;

        try{

            user_level = record.raw.user_level;
        }
        catch(e) {

            user_level = 0;
        }

        this.form = Ext.create('Ext.form.Panel', {
            id : 'form-'+this.winId,
            layout: 'border',
            width : '100%',
            height: '100%',
            border:false,
            padding: '5 5 5 5',
            bodyStyle:"background-color:#FFFFFF",
            url : '/manage/user/'+(this.mode == 'add' ? 'add' : 'mod'),
            type : 'json',
            items:[
                {
                    layout : 'vbox',
                    region :'center',
                    width : 500,
                    height: '100%',
                    border : false,
                    margin : '0 5 0 0',
                    defaults : {
                        labelWidth: 100,
                        width : '100%',
                        anchor : '100%',
                        xtype : 'textfield',
                        labelPad : 5,
                        labelClsExtra : 'x-panel-header-default'
                    },
                    items : [
                        this.initHidden('user_id'),
                        this.initHidden('manage_server'),
                        this.mode == 'add' ? this.initTextUserID() : this.initViewUserID(),
                        this.initTextUserPass(),
                        this.initTextUserPassConfirm(),
                        this.initTextUserName(),
                        user_level == 10 ? this.initHidden('user_level') : this.initComboBox(),
                        this.initTextEmail(),
                        this.initTextDescription()
                    ]
                },
                this.initTreeGrid(record)
            ],
            // Reset and Submit buttons
            buttons: this.initButtons(),
            listeners : {
                scope : this,
                boxready : function(){

                    //record가 있다면 form에 data binding 
                    if(record){
                        
                        level = record.raw.user_level;
                        record.raw.user_level = parseInt(level, 10);
                        //this.form.loadRecord(record);
                        this.form.getForm().setValues(record.raw);
                        //this.combo.setValue(parseInt(record.raw.user_level, 10));
                        this.setServerTree(level);
                    }
                    else {

                        this.setServerTree(1);
                    }

                }
            }
        });

        return this.form;
    },

    initTreeGrid : function(record){

        var store = Ext.create('Ext.data.TreeStore', {
            model: 'Task',
            proxy: {
                type: 'ajax',
                //the store will get the content from the .json file
                url: '/server/server_tree/getServerListNoneGroup'
            },
            fields: [
                {name: 'name',     type: 'string'},
                {name: 'ip',     type: 'string'},
                {name: 'port', type: 'string'},
                {name: 'security_mode',     type: 'string'},
                {name: 'security_level',     type: 'string'}
            ],
            folderSort: true
        });

        var selModel = Ext.create('Ext.selection.CheckboxModel', {
            id : 'selModel',
            mode : 'multi'
        });

        var task = new Ext.util.DelayedTask(function(){

            if(!record) return false;

            servers = record.raw.servers;

            if(!servers) return false;

            servers = Ext.JSON.decode(servers);

            selectionModel = this.tree.getSelectionModel();
            store = selectionModel.getStore();
            range = store.getRange();

            if(range.length == 0) return false;

            Ext.each(range, function(rec){

                selected = Ext.Array.findBy(servers, function(v){
                    
                    idx = 'server-' + v;

                    if(idx == rec.raw.id){

                        return true;
                    }
                    else {

                        return null;
                    }
                });
                
                if(selected != null){

                    selectionModel.select(rec, true);
                }
            });
        }, this);

        //Ext.ux.tree.TreeGrid is no longer a Ux. You can simply use a tree.TreePanel
        this.tree = Ext.create('Ext.tree.Panel', {
            title: 'Select the servers that manage by id',
            height: '100%',
            id : 'add-user-manage-server',
            flex : 1,
            margin : '0 0 0 5',
            region :'east',
            split : true,
            collapsible: true,
            collapsed : true,
            disabled : true,
            border:true,
            useArrows: true,
            rootVisible: false,
            store: store,
            selModel : selModel,
            multiSelect: true,
            stripeRows: true,
            //the 'columns' property is now 'headers'
            columns: [{
                xtype: 'treecolumn', //this is so we know which column will show the tree
                text: 'Server Name',
                flex: 2,
                sortable: true,
                dataIndex: 'name'
            },{
                text: 'IP Address',
                flex: 1,
                dataIndex: 'ip',
                sortable: true
            },{
                text: 'Port',
                flex: 1,
                dataIndex: 'port',
                sortable: true
            }],
            listeners : {
                scope : this,
                boxready : function(){

                    task.delay(500);
                }
            }
        });

        return this.tree;
    },

    /**
     * initTextUserName
     *
     * 유저명 입력 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initTextUserName : function(){

        return {
            xtype            : 'textfield',
            fieldLabel       : '유저명',
            id               : 'add-user-name',
            name             : 'user_name',
            allowBlank       : false,
            hideTrigger      : true,
            keyNavEnabled    : false,
            mouseWheelEnabled: false
        };
    },


    /**
     * initComboBox
     *
     * 콤보박스 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initComboBox : function(){

        var store = new Ext.data.Store({
            proxy: {
                type  : 'ajax',
                url: '/manage/user/getUserLevelList',
                reader: {
                    type: 'json'
                }
            },
            fields: [
                { name : 'id', type : 'int' },
                { name : 'text', type : 'string' }
            ],
            autoLoad : true
        });

        // Simple ComboBox using the data store
        this.combo = Ext.create('Ext.form.ComboBox', {
            id              : 'add-user-level',
            name            : 'user_level',
            fieldLabel      : '유저 권한',
            displayField    : 'text',
            emptyText       : '유저 권한 선택',
            disableKeyFilter: true,
            editable        : false,
            valueField      : 'id',
            validateBlank   : true,
            allowBlank      : false,
            blankText       : '비어있다.',
            store           : store,
            value           : 1,
            typeAhead       : true,
            listeners : {
                scope  : this,
                change : function(combobox, newValue, oldValue, e) {
                    
                    this.setServerTree(newValue);
                }
            }
        });

        return this.combo;
    },

    /**
     * initViewUserID
     *
     * 유저 아이디 텍스트 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    initViewUserID : function(){

        return {
            xtype     : 'displayfield',
            vtype     : 'alphanum',
            id        : 'add-user-loginid',
            name      : 'user_loginid',
            fieldLabel: '유저 ID'
        };
    },

    /**
     * initTextUserID
     *
     * 유저 아이디 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    initTextUserID : function(){

        var textfield = Ext.create('Ext.form.field.Text', {
            fieldLabel: '유저 ID',
            id        : 'add-user-loginid',
            name      : 'user_loginid',
            allowBlank: false,
            validator : function(value){

                if(this.old_user_loginid == value) {

                    this.clearInvalid();
                    this.textValid = true;
                    return true;
                }
                else {

                    return this.textValid;
                }                
            },
            listeners : {
                change : function(textfield, newValue, oldValue) {

                    if(this.old_user_loginid == newValue) {

                        this.clearInvalid();
                        this.textValid = true;

                        return;
                    }

                    Ext.Ajax.request({
                        url: '/manage/user/checkLoginID',
                        type : 'json',
                        params : {
                            text : newValue
                        },
                        scope: textfield,
                        success: function(res){
                            
                            var res = Ext.JSON.decode(res.responseText);

                            if(res.result == "success"){

                                this.clearInvalid();
                                this.textValid = true;
                            }
                            else {

                                this.markInvalid(res.message);
                                this.textValid = '이미 존재하는 아이디입니다.';
                            }
                        },
                        failure: function(result, request){

                            this.markInvalid('network error');
                            this.textValid = false;
                        }
                    });
                }
            }
        });
    
        if(textfield.old_user_loginid){

            textfield.clearInvalid();
            textfield.textValid = true;
        }
        
        return textfield;
    },

    /**
     * initTextUserPass
     *
     * 유저 패스워드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    initTextUserPass : function(){

        return {
            xtype            : 'textfield',
            fieldLabel       : '패스워드',
            id               : 'add-user-pass',
            name             : 'user_pass',
            inputType        : 'password' ,
            allowBlank       : this.mode == 'add' ? false : true,
            hideTrigger      : true,
            keyNavEnabled    : false,
            mouseWheelEnabled: false,            
            validator: function() {

                var confirm = Ext.getCmp('add-user-pass-confirm');

                if(this.getValue() == confirm.getValue()){
                    
                    confirm.clearInvalid();
                    this.clearInvalid();
                    return true;
                }
                else {

                    return "Passwords do not match!";
                }
            }
        };
    },

    /**
     * initTextUserPassConfirm
     *
     * 유저 패스워드 확인 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    initTextUserPassConfirm : function(){

        return {
            xtype            : 'textfield',
            fieldLabel       : '패스워드 확인',
            id               : 'add-user-pass-confirm',
            name             : 'user_pass_confirm',
            inputType        : 'password' ,
            allowBlank       : this.mode == 'add' ? false : true,
            hideTrigger      : true,
            keyNavEnabled    : false,
            mouseWheelEnabled: false,            
            validator: function() {

                var pass = Ext.getCmp('add-user-pass');
                
                if(this.getValue() == pass.getValue()){

                    pass.clearInvalid();
                    this.clearInvalid();
                    return true;
                }
                else {

                    return "Passwords do not match!";
                }
            }
        };
    },

    /**
     * initTextEmail
     *
     * 이메일 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    initTextEmail : function(){

        return {
            xtype            : 'textfield',
            vtype            : 'email',
            fieldLabel       : '이메일',
            id               : 'add-user-email',
            name             : 'user_email',
            allowBlank       : false,
            hideTrigger      : true,
            keyNavEnabled    : false,
            mouseWheelEnabled: false
        };
    },

    /**
     * initTextDescription
     *
     * 유저 설명 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    initTextDescription : function(){

        return {
            xtype            : 'textfield',
            fieldLabel       : '설명',
            id               : 'add-user-description',
            name             : 'description',
            allowBlank       : true,
            hideTrigger      : true,
            keyNavEnabled    : false,
            mouseWheelEnabled: false
        };
    },

    // /**
    //  * initRadioUseYn
    //  *
    //  * 유저 사용 설정 컴포넌트 생성
    //  *
    //  * @access public
    //  *
    //  * @return component Ext.form.field.Number
    //  */
    // initRadioUseYn : function(){

    //     return {
    //         xtype      : 'fieldcontainer',
    //         fieldLabel : '사용여부',
    //         id         : 'add-user-use-yn',
    //         name       : 'use_yn',
    //         defaultType: 'radiofield',
    //         defaults   : {
    //             padding : '0px 10px 0px 0px'
    //         },
    //         layout: 'hbox',
    //         items: [
    //             {
    //                 boxLabel  : '사용',
    //                 name      : 'use_yn',
    //                 inputValue: '1',
    //                 id        : 'add-user-use-yn-y',
    //                 checked   : true
    //             }, {
    //                 boxLabel  : '미사용',
    //                 name      : 'use_yn',
    //                 inputValue: '0',
    //                 id        : 'add-user-use-yn-n'
    //             }
    //         ]
    //     };
    // },

    initHidden : function(name){

        var id = 'add-'+name.replace('_', '-');

        return {
            xtype            : 'hiddenfield',
            hidden           : true, 
            hideLabel        : true,
            id               : id,
            name             : name
        };
    },

    /**
     * initButtons
     *
     * 버튼 생성
     *
     * @access public
     *
     * @return button array
     */
    initButtons : function(){

        return [{
            text: '리셋',
            handler: function() {
                this.up('form').getForm().reset();
            }
        }, 
        {
            text    : '저장',
            formBind: true, //only enabled once the form is valid
            disabled: true,
            scope   : this,
            handler : this.save
        },
        {
            text : '닫기',
            handler : function(){

                this.up("window").destroy();
            }
        }];
    },

    /**
     * setServerTree
     *
     * 서버트리 선택을 권한에 따라 enable 시킨다.
     *
     * @access public
     *
     */
    setServerTree : function(value){

        if(parseInt(value, 10) < 10){

            this.tree.expand();
            this.tree.enable();
        }
        else {

            this.tree.collapse();
            this.tree.disable();
        }
    },

    /**
     * save
     *
     * 저장
     *
     * @access public
     *
     */
    save : function(){

        if (this.form.isValid()) {

            this.textValid = true;

            var sel = this.tree.getSelectionModel().getSelection();

            var ids = [];
            Ext.each(sel, function(record) {

                if(record.raw.id.indexOf('server-') > -1){

                    ids.push(record.raw.id.replace('server-', ''));
                }
                
            });

            Ext.getCmp('add-manage-server').setValue(ids);

            this.form.submit({
                scope : this,
                waitMsg : '처리중 입니다.',
                params : { 
                    server : this.getApplication().serverId
                },
                success: function(form, action) {

                    var result = Ext.JSON.decode(action.response.responseText);

                    Ext.Msg.alert('Status', result.message);

                    var ctrl = this.getController('manage.User');
                    ctrl.search();

                    this.getApplication().fireEvent('grid-footer-history-reload');

                    this.window.destroy();
                },
                failure: function(form, action) {

                    Ext.Msg.alert('Failed', action.response.responseText);
                }
            });
        }
    }
});