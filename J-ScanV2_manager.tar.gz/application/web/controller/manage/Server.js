Ext.define('WhiteSQL.controller.manage.Server', {
    extend: 'Lib.TabController',
    
    /**
     *
     * 탭 생성
     *
     * @return component Ext.container.Container
     */
    initTab : function(){

        this.setTab(Ext.create('Lib.Tab', {
            id : this.tabId,
            title : 'Server',
            items : [
                this.initGridSearch(),
                this.initTreeGrid()
            ]
        }));

        this.getApplication().on('server-modified', function(data){

            model = this.tree.getSelectionModel();
            store = this.tree.getStore();
            node  = store.getById('root');

            //트리 노드를 리로드한다.
            store.reload({node : node});

        }, this);
    },

    /**
     * initGridSearch
     *
     * 그리드 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGridSearch : function(){

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'vbox',
            frame : true,
            width : '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 0',
            defaults : {
                labelWidth: 80
            },
            items:[
                {
                    xtype   : 'container',
                    layout  : 'hbox',
                    margin  : '0 0 5 0',
                    defaults: {
                        labelWidth: 80,
                        height : 26,
                        margin : '0 10 0 0'
                    },
                    items : [
                         {
                            xtype: 'buttongroup',
                            items : [
                                {
                                    xtype:'button',
                                    icon : '/images/add.png',
                                    text: '서버 추가',
                                    scope : this,
                                    handler : this.addServer
                                },
                                {
                                    xtype:'button',
                                    icon : '/images/edit.png',
                                    text: '수정',
                                    scope : this,
                                    handler : this.modServer
                                },
                                {
                                    xtype:'button',
                                    icon : '/images/delete.png',
                                    text: '삭제',
                                    scope : this,
                                    handler : this.delServer
                                }
                            ]
                        }
                    ]
                }
            ]
        };
        return form;
    },

    initTreeGrid : function(){

        var selModel = Ext.create('Ext.selection.CheckboxModel', {
            mode : 'multi'
        });

        var store = Ext.create('Ext.data.TreeStore', {
            model: 'Task',
            proxy: {
                type: 'ajax',
                //the store will get the content from the .json file
                url: '/manage/server/getServerList'
            },
            fields: [
                {name : 'name',     type: 'string'},
                {name : 'ip',     type: 'string'},
                {name : 'port', type: 'string'},
                {name : 'agent_mode',     type: 'string'},
                {name : 'privacy_flag',     type: 'string'},
                {name : 'license_check_nm',     type: 'string'},
                {name : 'license_expiredate',     type: 'string'},
                {name : 'sync_flag',     type: 'string'}
            ],
            folderSort: true
        });

        //Ext.ux.tree.TreeGrid is no longer a Ux. You can simply use a tree.TreePanel
        this.tree = Ext.create('Ext.tree.Panel', {
            id : 'grid-'+this.id,
            title: 'View Servers',
            width: '100%',
            flex : 1,
            renderTo: Ext.getBody(),
            useArrows: true,
            rootVisible: false,
            store: store,
            selModel : selModel,
            multiSelect: true,
            stripeRows: true,
            //the 'columns' property is now 'headers'
            columns: [{
                xtype: 'treecolumn', //this is so we know which column will show the tree
                text: 'Server Name',
                flex: 2,
                sortable: true,
                dataIndex: 'name'
            },{
                text: 'IP Address',
                flex: 1,
                dataIndex: 'ip',
                sortable: true
            },{
                text: 'Port',
                flex: 1,
                dataIndex: 'port',
                sortable: true
            },{
                text: '동작모드',
                flex: 1,
                dataIndex: 'agent_mode',
                sortable: true
            },{
                text: '개인정보체크',
                flex: 1,
                dataIndex: 'privacy_flag',
                renderer:function(value, record){

                    if(value === "1") return "사용";
                    else if(value === "0") return "미사용";
                },
                sortable: true
            },{
                text: '라이센스',
                flex: 1,
                dataIndex: 'license_check_nm',
                sortable: true
            },{
                text: '라이센스만료기한',
                flex: 1,
                dataIndex: 'license_expiredate',
                sortable: true
            },{
                text: '동기화',
                flex: 1,
                dataIndex: 'sync_flag',
                sortable: true
            }]
        });

        return this.tree;
    },

    delServer : function(){

        var grid = Ext.getCmp('grid-'+this.id);

        var sel = grid.getSelectionModel().getSelection();

        var server = [];
        var group = [];

        Ext.each(sel, function(record) {

            if(record.data.id.indexOf('server-') > -1){

                server.push(record);
            }
            else if(record.data.id.indexOf('group-') > -1){

                group.push(record);
            }
        });

        if(server.length < 1 && group.length < 1){

            Ext.Msg.alert('Status', '삭제하실 Server 또는 Group을 선택하세요');
            return;
        }
        else if((server.length + group.length) > 1){

            Ext.Msg.alert('Status', '삭제시엔 하나만 선택하세요');
            return;
        }
        
        if(server.length == 1){

            this.getApplication().delServer(server[0]);
            return;
        }
        else if(group.length == 1){

            this.getApplication().delGroup(group[0]);
            return;
        }
    },

    addServer : function(){

        this.getApplication().openWindow('manage.Server-Add');
    },

    modServer : function(){

        var grid = Ext.getCmp('grid-'+this.id);

        var sel = grid.getSelectionModel().getSelection();

        var server = [];
        var group = [];

        Ext.each(sel, function(record) {

            if(record.data.id.indexOf('server-') > -1){

                server.push(record);
            }
            else if(record.data.id.indexOf('group-') > -1){

                group.push(record);
            }
        });

        if(server.length < 1 && group.length < 1){

            Ext.Msg.alert('Status', '수정하실 Server 또는 Group을 선택하세요');
            return;
        }
        else if((server.length + group.length) > 1){

            Ext.Msg.alert('Status', '수정시엔 하나만 선택하세요');
            return;
        }
        
        if(server.length == 1){

            this.getApplication().openWindow('manage.Server-Add', server[0]);
            return;
        }
        else if(group.length == 1){

            this.getApplication().modGroup(group[0]);
            return;
        }
    }
});