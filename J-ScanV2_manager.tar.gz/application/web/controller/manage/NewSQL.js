Ext.define('WhiteSQL.controller.manage.NewSQL', {
    extend: 'Ext.app.Controller',
    
    /**
     *
     * 윈도우 생성
     *
     * @return component Ext.container.Container
     */
    initWindow : function(){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id,
            title : 'New SQL',
            width : 1200,
            height: 800,
            bodyPadding : '5 5 5 5',
            layout : 'fit',
            items : [
                {
                    xtype : 'panel',
                    layout: 'border',
                    width : '100%',
                    border: 0,
                    flex  : 1,
                    items : [
                        {
                            xtype : 'panel',
                            layout: 'vbox',
                            border : false,
                            region: 'center',
                            width : '100%',
                            flex  : 1,
                            items : [
                                this.initGridSearch(),
                                this.initGrid()
                            ]
                        },
                        this.initQueryField()
                    ]
                }
            ]
        });
    },

    /**
     * initGridSearch
     *
     * 그리드 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGridSearch : function(){

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'vbox',
            frame : true,
            width : '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 0',
            items:[
                {
                    xtype   : 'container',
                    layout  : 'hbox',
                    margin  : '0 0 5 0',
                    width : '100%',
                    defaults: {
                        height : 26,
                        margin : '0 10 0 0'
                    },
                    items : [
                        {
                            margin : '5 2 0 0',
                            xtype : 'image',
                            width : 16,
                            height : 16,
                            src   : '/images/host_en.png'
                        },
                        {
                            xtype : 'text',
                            margin : '5 0 0 0',
                            id    : 'server-name-'+this.id,
                            width : 100,
                            text  : this.application.getServerName()
                        },
                        this.initComboBox(),
                        {
                            xtype : 'textfield',
                            id    : this.id+'-search-keyword',
                            name  : this.id+'-search-keyword',
                            flex  : 1,
                        },
                        {
                            xtype:'button',
                            icon : '/images/find.png',
                            text: '검색',
                            scope : this,
                            handler : this.search
                        },
                        {
                            xtype: 'buttongroup',
                            items : [
                                {
                                    xtype:'button',
                                    icon : '/images/export.png',
                                    text: '엑셀받기',
                                    scope : this,
                                    handler : this.exportSQL
                                }
                            ]
                        }
                    ]
                }
            ]
        };
        return form;
    },

    /**
     * initComboBox
     *
     * 콤보박스 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initComboBox : function(label, mode){

        var store = new Ext.data.Store({
            data : [{
                id : 'class_string', text : '클래스명'
            },{
                id : 'sqltext', text : '쿼리'
            }],
            fields: ['id','text']
        });

        // Simple ComboBox using the data store
        var combo = Ext.create('Ext.form.ComboBox', {
            id   : this.id+'-search-mode',
            name : this.id+'-search-mode',
            emptyText : '선택',
            displayField : 'text',
            editable : false,
            valueField: 'id',
            value : 'class_string',
            store: store
        });

        return combo;
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGrid : function(mode){

        var columns = this.makeListColumns();

        var grid = Ext.create('Lib.Grid', {
            id : 'grid-'+this.id,
            url : '/manage/new_sql/getListData',
            title : mode,
            columns : columns,
            listeners: {
                scope : this,
                itemclick : function(grid, record) {
                    
                    Ext.Ajax.request({
                        url    : '/manage/new_sql/getQueryData/'+record.raw.newsql_id,
                        type   : 'json',
                        async  : false,
                        scope  : this,
                        success: function(res){

                            var data = Ext.JSON.decode(res.responseText);

                            Ext.getCmp(this.id+'-org-sql').update(data.orig_sqltext);
                        }
                    });
                }
            }
        });

        return grid;
    },

    /**
     * search
     *
     * 검색 수행
     *
     * @access public
     *
     */
    search : function(){

        var params = Ext.getCmp('form-'+this.id).getValues();        
        var grid   = Ext.getCmp('grid-'+this.id);

        Ext.getCmp(this.id+'-org-sql').update('');

        this.getApplication().fireEvent('grid-search', grid, params);
    },

    initQueryField : function(){

        return {
            xtype       : 'panel',
            layout      : 'vbox',
            region      : 'south',
            split       : true,
            collapsible : true,
            header      : false,
            width       : '100%',
            height      : 150,
            border      : false,
            bodyBorder  : false,
            defaults    : {
                xtype      : 'fieldset',
                height     : '100%',
                flex       : 1, 
                padding    : 10,
                autoScroll : true,
            },
            items:[
                {
                    region :'east',
                    split  : true,
                    width  : '100%',
                    id     : this.id+'-org-sql',
                    title  : '쿼리'
                }
            ]
        };
    },

    /**
     * makeDetailListColumns
     *
     * 상세정보 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeListColumns : function(){   

        return [
            Ext.create('Ext.grid.RowNumberer'),
            { text: '클래스명', dataIndex: 'class_string', width : 300},
            { text: '쿼리유형', dataIndex: 'sql_type', width : 100},
            { text: '쿼리', dataIndex: 'uniq_sqltext' , flex: 1 },
            { text: '등록일', dataIndex: 'reg_date', width : 120}
        ];
    },

    exportSQL : function(){
        
        var params      = Ext.getCmp('form-'+this.id).getValues();
        
        params.serverId = this.getApplication().serverId;
        location.href   = "/manage/new_sql/export?"+Ext.urlEncode(params);
    }
});