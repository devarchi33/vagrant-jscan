Ext.define('WhiteSQL.controller.manage.Server-Add', {
    extend  : 'Ext.app.Controller',
    winId   : null,
    editMode: false,

    /**
     * init
     *
     * 컨트롤러 초기화 메소드.
     *
     * @access public
     *
     * @return
     */
    init: function() {

        //기본 탭아이디 생성
        this.winId = 'window-' + this.id;
    },

    /**
     *
     * 윈도우 생성
     *
     * @return component Ext.container.Container
     */
    initWindow: function(record) {

        try {

            this.editMode = (record.data.parentId != 'root');

        } catch (e) {

            this.editMode = false;
        }

        this.window = Ext.create('Ext.window.Window', {
            id       : this.winId,
            stateful : true,
            stateId  : 'state-' + this.winId,
            title    : (this.editMode ? 'Edit' : 'Add') + ' Server',
            layout   : 'fit',
            bodyStyle: "background-color:#FFFFFF",
            width    : 700,
            height   : 450,
            modal    : true,
            plain    : true,
            fixed    : true,
            shadow   : false,
            autoShow : true,
            constrain: true,
            items    : this.initDetail(record)
        });

        return this.window;
    },

    initDetail: function(record) {

        var bindData = {};

        if (record) {

            var data = record.raw;

            if (data.id.indexOf('server') > -1) {

                Ext.Ajax.request({
                    url    : '/manage/server/getServerInfo',
                    type   : 'json',
                    async : false,
                    params : {
                        server : data.id
                    },
                    success: function(res) {

                        res = Ext.JSON.decode(res.responseText);
                        Ext.apply(data, res);
                    }
                });

                ip = data.ip.split(".");

                if (ip.length < 4) {

                    ip = ['', '', '', ''];
                }

                this.old_server_name = data.name;

                Ext.apply(bindData, {
                    'add-server-id'                : data.id,
                    'add-server-group-id'          : data.group_id,
                    'add-server-name'              : data.name,
                    'add-server-ip-1'              : ip[0],
                    'add-server-ip-2'              : ip[1],
                    'add-server-ip-3'              : ip[2],
                    'add-server-ip-4'              : ip[3],
                    'add-server-port'              : data.port,
                    'add-server-logging-yn'        : data.rs_logging_yn,
                    'add-server-license-check'     : data.license_check,
                    'add-server-privacy-flag'      : data.privacy_flag,
                    'add-server-license-expiredate': data.license_expiredate,
                    'add-server-license-key'       : data.license_key,
                    'add-server-license-status'    : data.license_status == 1 ? '에러' : '정상',
                    'add-server-type'              : data.server_type,
                    'add-server-db-sid'            : data.sid,
                    'add-server-db-user'           : data.db_user_id,
                    'add-server-db-pass'           : data.db_passwd,
                    'add-server-db-kind'           : data.db_kind
                });
            }
            else {

                Ext.apply(bindData, {
                    'add-server-group-id': data.id.replace("group-", "")
                });
            }
        }

        Ext.applyIf(bindData, {
            'add-server-id'          : '',
            'add-server-port'        : 20225,
            'add-server-type'        : '1',
            'add-server-logging-yn'  : '0',
            'add-server-privacy-flag': '0'
        });

        return {
            xtype    : 'form',
            id       : 'form-' + this.winId,
            layout   : 'vbox',
            width    : '100%',
            height   : '100%',
            padding  : '5 5 5 5',
            border   : false,
            url      : '/manage/server/' + (bindData['add-server-id'] ? 'modServer' : 'addServer'),
            type     : 'json',
            defaults : {
                labelWidth   : 100,
                width        : '100%',
                anchor       : '100%',
                xtype        : 'textfield',
                labelPad     : 5,
                labelClsExtra: 'x-panel-header-default'
            },
            items    : [
                this.initTextServerId(),
                this.initTextServerName(),
                this.initServerGroup(),
                this.initServerType(),
                this.initDBKind(),
                this.initAgentIP(),
                this.initAgentPort(),

                //서버타입이 Agent 모드일때 활성화
                this.initPrivacyFlag(),
                this.initResultSave(),

                //서버타입이 DB Mon일때 활성화
                this.initDBSID(),
                this.initDBUser(),
                this.initDBPass(),

                this.initLicenseType(),
                this.initLicenseKey(),
                this.initLicenseExpireDay(),
                this.initLicenseStatus()
            ],
            // Reset and Submit buttons
            buttons  : this.initButtons(),
            listeners: {
                boxready: function(form) {

                    form.getForm().setValues(bindData);
                }
            }
        }
    },

    /**
     * initTextServerId
     *
     * 서버아이디 설정 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.HiddenField
     */
    initTextServerId: function() {

        return {
            xtype: 'hiddenfield',
            id   : 'add-server-id',
            name : 'add-server-id'
        };
    },

    /**
     * initTextServerName
     *
     * 서버명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initTextServerName: function() {

        return {
            xtype     : 'textfield',
            fieldLabel: '서버명',
            id        : 'add-server-name',
            name      : 'add-server-name',
            allowBlank: false,
            validator : Ext.Function.pass(function(context, value) {

                if (context.old_server_name == value) {

                    this.clearInvalid();
                    this.textValid = true;
                    return true;
                }
                else {

                    return this.textValid;
                }
            }, this),
            listeners : {
                scope : this,
                change: function(textfield, newValue, oldValue) {

                    if (this.old_server_name == newValue) {

                        textfield.clearInvalid();
                        textfield.textValid = true;

                        return;
                    }

                    Ext.Ajax.request({
                        url    : '/manage/server/checkServerName',
                        type   : 'json',
                        params : {
                            text: newValue
                        },
                        scope  : textfield,
                        success: function(res) {

                            var res = Ext.JSON.decode(res.responseText);

                            if (res.result == "success") {

                                textfield.clearInvalid();
                                textfield.textValid = true;
                            }
                            else {

                                textfield.markInvalid(res.message);
                                textfield.textValid = '이미 존재하는 서버명입니다.';
                            }
                        },
                        failure: function(result, request) {

                            textfield.markInvalid('network error');
                            textfield.textValid = false;
                        }
                    });
                }
            }
        };

        if (textfield.old_server_name) {

            textfield.clearInvalid();
            textfield.textValid = true;
        }

        return textfield;
    },

    /**
     * initAgentIP
     *
     * 아이피 주소 입력 폼 생성
     *
     * @access public
     *
     * @return component Ext.container.Container
     */
    initAgentIP: function() {

        return {
            xtype   : 'container',
            layout  : 'hbox',
            width   : '100%',
            margin  : '0 0 5 0',
            defaults: {
                xtype            : 'numberfield',
                allowBlank       : false,
                maxLength        : 3,
                maxValue         : 255,
                minValue         : 0,
                enforceMaxLength : true,
                hideTrigger      : true,
                keyNavEnabled    : false,
                mouseWheelEnabled: false
            },
            items   : [
                {
                    xtype : 'displayfield',
                    width : 100,
                    margin: '0 5 0 0',
                    cls   : 'x-panel-header-default',
                    id    : 'add-server-ip',
                    value : 'Agent IP'
                },
                {
                    width: 30,
                    id   : 'add-server-ip-1',
                    name : 'add-server-ip-1'
                },
                {
                    xtype : 'text',
                    margin: '0 5 0 5',
                    text  : '.'
                },
                {
                    width: 30,
                    id   : 'add-server-ip-2',
                    name : 'add-server-ip-2'
                },
                {
                    xtype : 'text',
                    margin: '0 5 0 5',
                    text  : '.'
                },
                {
                    width: 30,
                    id   : 'add-server-ip-3',
                    name : 'add-server-ip-3'
                },
                {
                    xtype : 'text',
                    margin: '0 5 0 5',
                    text  : '.'
                },
                {
                    width: 30,
                    id   : 'add-server-ip-4',
                    name : 'add-server-ip-4'
                }
            ]
        };
    },

    /**
     * initServerGroup
     *
     * 콤보박스 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initServerGroup: function() {

        var store = new Ext.data.Store({
            proxy   : {
                type  : 'ajax',
                url   : '/manage/server/getGroupList',
                reader: {
                    type: 'json'
                }
            },
            fields  : [
                {name: 'id', type: 'string'},
                {name: 'text', type: 'string'}
            ],
            autoLoad: true
        });

        // Simple ComboBox using the data store
        return {
            xtype           : 'combobox',
            id              : 'add-server-group-id',
            name            : 'add-server-group-id',
            fieldLabel      : '그룹',
            displayField    : 'text',
            emptyText       : '그룹 선택',
            disableKeyFilter: true,
            editable        : false,
            valueField      : 'id',
            validateBlank   : true,
            allowBlank      : false,
            blankText       : '그룹을 선택 해주세요.',
            store           : store,
            typeAhead       : true
        };
    },


    /**
     * initServerType
     *
     * 서버 타입 설정
     *
     * @access public
     *
     * @return component Ext.form.RadioGroup
     */
    initServerType: function() {

        return {
            xtype      : 'radiogroup',
            fieldLabel : 'Agent 구분',
            defaultType: 'radiofield',
            id         : 'add-server-type',
            padding    : '0px 10px 5px 0px',
            layout     : 'hbox',
            items      : [
                {
                    boxLabel  : 'Agent',
                    name      : 'add-server-type',
                    inputValue: '1',
                    margin    : '0px 10px 0px 0px'
                }, {
                    boxLabel  : 'DB Mon',
                    name      : 'add-server-type',
                    inputValue: '2'
                }
            ],
            listeners  : {
                scope : this,
                change: function(radio, newVal, oldVal) {

                    this.selectServerType(newVal['add-server-type']);
                }
            }
        };
    },

    /**
     * initDBKind
     *
     * 디비 종류 설정
     *
     * @access public
     *
     * @return component Ext.form.RadioGroup
     */
    initDBKind: function() {

        var store = new Ext.data.Store({
            proxy   : {
                type  : 'ajax',
                url   : '/manage/server/getDBKind',
                reader: {
                    type: 'json'
                }
            },
            fields  : [
                {name: 'id', type: 'string'},
                {name: 'text', type: 'string'}
            ],
            autoLoad: true
        });

        // Simple ComboBox using the data store
        return {
            xtype           : 'combobox',
            id              : 'add-server-db-kind',
            name            : 'add-server-db-kind',
            fieldLabel      : 'DB 종류',
            displayField    : 'text',
            emptyText       : '데이터베이스 종류 선택',
            disableKeyFilter: true,
            editable        : false,
            valueField      : 'id',
            validateBlank   : true,
            blankText       : '데이터베이스 종를 선택해주세요',
            store           : store,
            typeAhead       : true,
            hidden          : true,
            listeners       : {
                change: function(combo) {

                    var value = combo.getValue();
                    record = combo.findRecordByValue(value);

                    if (!record) return;

                    Ext.getCmp('add-server-port').setValue(record.raw.port);
                }
            }
        };
    },

    /**
     * initPrivacyFlag
     *
     * 개인정보보호 사용 설정 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.RadioGroup
     */
    initPrivacyFlag: function() {

        return {
            xtype      : 'radiogroup',
            fieldLabel : '개인정보보호',
            defaultType: 'radiofield',
            id         : 'add-server-privacy-flag',
            name       : 'add-server-privacy-flag',
            padding    : '0px 10px 5px 0px',
            hidden     : true,
            layout     : 'hbox',
            items      : [
                {
                    boxLabel  : '사용',
                    name      : 'add-server-privacy-flag',
                    inputValue: '1'
                }, {
                    boxLabel  : '미사용',
                    name      : 'add-server-privacy-flag',
                    inputValue: '0',
                    checked   : true
                }
            ]
        };
    },

    /**
     * initResultSave
     *
     * 결과값 저장
     *
     * @access public
     *
     * @return component Ext.form.RadioGroup
     */
    initResultSave: function() {

        return {
            xtype      : 'radiogroup',
            fieldLabel : '결과값 저장 여부',
            defaultType: 'radiofield',
            id         : 'add-server-logging-yn',
            padding    : '0px 10px 5px 0px',
            layout     : 'hbox',
            hidden     : true,
            items      : [
                {
                    boxLabel  : '저장',
                    name      : 'add-server-logging-yn',
                    inputValue: '1'
                }, {
                    boxLabel  : '저장안함',
                    name      : 'add-server-logging-yn',
                    inputValue: '0',
                    checked   : true
                }
            ]
        };
    },

    /**
     * initLicenseType
     *
     * 라이센스 타입 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initLicenseType: function() {

        var store = new Ext.data.Store({
            proxy   : {
                type  : 'ajax',
                url   : '/manage/server/getLicenseList',
                reader: {
                    type: 'json'
                }
            },
            fields  : [
                {name: 'id', type: 'string'},
                {name: 'text', type: 'string'}
            ],
            autoLoad: true
        });

        // Simple ComboBox using the data store
        return {
            xtype           : 'combobox',
            id              : 'add-server-license-check',
            name            : 'add-server-license-check',
            fieldLabel      : '라이센스',
            displayField    : 'text',
            emptyText       : '라이센스 선택',
            disableKeyFilter: true,
            editable        : false,
            valueField      : 'id',
            validateBlank   : true,
            allowBlank      : false,
            blankText       : '라이센스를 선택해주세요',
            store           : store,
            typeAhead       : true
        };
    },

    /**
     * initLicenseStatus
     *
     * 라이센스 상태 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initLicenseStatus: function() {

        // Simple ComboBox using the data store
        return {
            xtype     : 'displayfield',
            id        : 'add-server-license-status',
            name      : 'add-server-license-status',
            readOnly  : true,
            hidden    : this.editMode ? false : true,
            fieldLabel: '라이센스상태'
        };
    },

    /**
     * initLicenseExpireDay
     *
     * 라이센스 만료일 설정 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.DateField
     */
    initLicenseExpireDay: function() {

        return {
            xtype     : 'datefield',
            fieldLabel: '라이센스만료',
            id        : 'add-server-license-expiredate',
            name      : 'add-server-license-expiredate',
            readOnly  : true,
            hidden    : this.editMode ? false : true,
            allowBlank: true,
            format    : 'Y-m-d',
            value     : new Date()
        };
    },

    /**
     * initLicenseKey
     *
     * 라이센스 키 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initLicenseKey: function() {

        return {
            xtype     : 'textfield',
            fieldLabel: '라이센스키',
            id        : 'add-server-license-key',
            name      : 'add-server-license-key',
            allowBlank: true
        };
    },


    /**
     * initAgentPort
     *
     * 포트 입력 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.field.Number
     */
    initAgentPort: function() {

        return {
            xtype            : 'numberfield',
            fieldLabel       : 'Agent Port',
            id               : 'add-server-port',
            name             : 'add-server-port',
            allowBlank       : false,
            hideTrigger      : true,
            keyNavEnabled    : false,
            mouseWheelEnabled: false
        };
    },

    /**
     * initDBSID
     *
     * DB SID 입력 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initDBSID: function() {

        return {
            xtype            : 'textfield',
            fieldLabel       : 'DB SID',
            id               : 'add-server-db-sid',
            name             : 'add-server-db-sid',
            hideTrigger      : true,
            keyNavEnabled    : false,
            mouseWheelEnabled: false,
            hidden           : true
        };
    },

    /**
     * initDBUser
     *
     * DB User ID 입력 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initDBUser: function() {

        return {
            xtype            : 'textfield',
            fieldLabel       : 'DB User',
            id               : 'add-server-db-user',
            name             : 'add-server-db-user',
            hideTrigger      : true,
            keyNavEnabled    : false,
            mouseWheelEnabled: false,
            hidden           : true
        };
    },


    /**
     * initDBPass
     *
     * DB Pass 입력 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initDBPass: function() {

        return {
            xtype            : 'textfield',
            fieldLabel       : 'DB Pass',
            id               : 'add-server-db-pass',
            name             : 'add-server-db-pass',
            hideTrigger      : true,
            keyNavEnabled    : false,
            mouseWheelEnabled: false,
            hidden           : true
        };
    },

    /**
     * initButtons
     *
     * 버튼 생성
     *
     * @access public
     *
     * @return button array
     */
    initButtons: function() {

        return [{
            text   : '리셋',
            handler: function() {
                this.up('form').getForm().reset();
            }
        },
            {
                text    : '저장',
                formBind: true, //only enabled once the form is valid
                disabled: true,
                scope   : this,
                handler : this.save
            },
            {
                text   : '닫기',
                handler: function() {

                    this.up("window").destroy();
                }
            }];
    },

    /**
     * selectServerType
     *
     * 서버타입 선택에 따른 입력 컴포넌트 디스플레이
     *
     * @access public
     *
     * @return
     */
    selectServerType: function(serverType) {

        var DBMon = ['#add-server-db-sid', '#add-server-db-user', '#add-server-db-pass', '#add-server-db-kind'],
            Agent = ['#add-server-privacy-flag', '#add-server-logging-yn'];

        Ext.invoke(Ext.ComponentQuery.query(Ext.Array.merge(Agent, DBMon).join(",")), 'hide');

        if (parseInt(serverType, 10) == 2) {

            Ext.invoke(Ext.ComponentQuery.query(DBMon.join(",")), 'show');
            Ext.getCmp('add-server-ip').setValue('DB IP');
            Ext.getCmp('add-server-port').setFieldLabel('DB Port');
        }
        else {

            Ext.invoke(Ext.ComponentQuery.query(Agent.join(",")), 'show');
            Ext.getCmp('add-server-ip').setValue('Agent IP');
            Ext.getCmp('add-server-port').setFieldLabel('Agent Port');
        }
    },

    /**
     * save
     *
     * 저장
     *
     * @access public
     *
     */
    save: function() {

        form = Ext.getCmp('form-' + this.winId);
        if (form.isValid()) {

            form.submit({
                scope  : this,
                waitMsg: '처리중 입니다.',
                success: function(form, action) {

                    var result = Ext.JSON.decode(action.response.responseText);

                    Ext.Msg.alert('Status', result.message);

                    var cmpServerTree = Ext.getCmp('server-tree'),
                        cmpDBTree = Ext.getCmp('database-tree');

                    if (result.mode == 'add') {

                        var node = cmpServerTree.getSelectionModel().getSelection()[0];
                        cmpServerTree.getStore().reload({node: node});

                        //database 트리 리프레시
                        cmpDBTree.getStore().reload({node: cmpDBTree.getRootNode()});

                        //하단 히스토리 그리드 리프레시
                        this.getApplication().fireEvent('server-added');
                    }
                    else {


                        var values = form.getValues();
                        var groupId = 'group-' + values['add-server-group-id'];

                        model = cmpServerTree.getSelectionModel();
                        store = cmpServerTree.getStore();
                        node = store.getById(groupId);
                        data = node.getData();

                        //트리 노드를 리로드한다.
                        store.reload({node: node});

                        var parentId = data.parentId;

                        //지정한 그룹 아이디와 parentId가 다른 경우 기존 그룹도 리프레시 해준다.
                        if (groupId !== parentId) {

                            var selNode = cmpServerTree.getSelectionModel().getSelection();
                            if (selNode.length > 0) {

                                selNode[0].remove();
                            }
                        }

                        //database 트리 리프레시
                        cmpDBTree.getStore().reload({node: cmpDBTree.getRootNode()});
                        this.getApplication().fireEvent('server-modified', {'group_id': groupId});
                    }

                    this.window.destroy();
                },
                failure: function(form, action) {

                    var result = Ext.JSON.decode(action.response.responseText);

                    Ext.Msg.alert('Failed', result.message);
                }
            });
        }
    }
});