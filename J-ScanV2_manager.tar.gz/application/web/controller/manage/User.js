Ext.define('WhiteSQL.controller.manage.User', {
    extend: 'Lib.TabController',

    /**
     *
     * 탭 생성
     *
     * @return component Ext.container.Container
     */
    initTab : function(){

        this.setTab(Ext.create('Lib.Tab', {
            id : this.getTabId(),
            title : 'User',
            items : [
                this.initGridSearch(),
                this.initGrid()
            ]
        }));
    },

    /**
     * initGridSearch
     *
     * 그리드 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGridSearch : function(){

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'vbox',
            frame : true,
            width : '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 0',
            defaults : {
                labelWidth: 80
            },
            items:[
                {
                    xtype   : 'container',
                    layout  : 'hbox',
                    margin  : '0 0 5 0',
                    defaults: {
                        labelWidth: 80,
                        height : 26,
                        margin : '0 10 0 0'
                    },
                    items : [
                        this.initComboBox(),
                        {
                            xtype: 'textfield',
                            id   : this.id+'-search-keyword',
                            name : this.id+'-search-keyword',
                            width: 400
                        },
                        {
                            xtype:'button',
                            icon : '/images/find.png',
                            text: '검색',
                            scope : this,
                            handler : this.search
                        },
                        {
                            xtype: 'buttongroup',
                            items : [
                                {
                                    xtype:'button',
                                    icon : '/images/add.png',
                                    text: '추가',
                                    scope : this,
                                    handler : this.addUser
                                },
                                {
                                    xtype:'button',
                                    icon : '/images/edit.png',
                                    text: '수정',
                                    scope : this,
                                    handler : this.modUser
                                },
                                {
                                    xtype:'button',
                                    icon : '/images/delete.png',
                                    text: '삭제',
                                    scope : this,
                                    handler : this.delUser
                                }
                            ]
                        }
                    ]
                }
            ]
        };
        return form;
    },

    /**
     * initGrid
     *
     * 콤보박스 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initComboBox : function(label, mode){

        var store = new Ext.data.Store({
            fields: ['id','text'],
            data : [
                {id : "", text : "전체"},
                {id : "user_name", text : "Name"},
                {id : "user_loginid", text : "Login ID"},
                {id : "user_email", text : "Email"}
            ]
        });

        // Simple ComboBox using the data store
        var combo = Ext.create('Ext.form.ComboBox', {
            name : this.id+'-search-mode',
            fieldLabel: label,
            emptyText : '선택',
            value: '',
            displayField : 'text',
            valueField: 'id',
            editable : false,
            labelWidth: 80,
            store: store,
            typeAhead: true
        });

        return combo;
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */ 
    initGrid : function(mode){

        var selModel = Ext.create('Ext.selection.CheckboxModel', {
            mode : 'multi'
        });

        var columns = this.makeGridColumns();

        var grid = Ext.create('Lib.Grid', {
            id : 'grid-'+this.id,
            url : '/manage/user/getGridData',
            title : mode,
            columns : columns,
            selModel : selModel,
            listeners: {
                scope : this,
                cellclick: function(grid, cellEl, cellIdx, record, rowEl, rowIdx, e) {

                    if(e.ctrlKey == true || e.shiftKey == true) return;

                    if(cellIdx == 1){

                        this.getApplication().openWindow('manage.User-Add', record);
                    }
                }
            }
        });

        return grid;
    },

    search : function(){

        var params = Ext.getCmp('form-'+this.id).getValues();        
        var grid   = Ext.getCmp('grid-'+this.id);

        this.getApplication().fireEvent('grid-search', grid, params);
    },

    /**
     * makePrivacySQLGridColumns
     *
     * Privacy SQL 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeGridColumns : function(){

        return [
            // { text: '작업시간',  dataIndex: 'agent_name'},
            { dataIndex: 'user_id', width : 25 , sortable: true, renderer : function(value){
                return '<img src="/images/user.png" user_id="'+value+'"/>';
            }, sortable: true, menuDisabled : true },
            { text: 'Login ID', dataIndex: 'user_loginid' },
            { text: 'Name',  dataIndex: 'user_name', flex: 1 },
            { text: 'Email', dataIndex: 'user_email'},
            { text: 'Level', dataIndex: 'user_level_nm' },
            { text: 'Last Login', dataIndex: 'user_lastdate'}
        ];
    },

    delUser : function(){

        var grid = Ext.getCmp('grid-'+this.id);

        var sel = grid.getSelectionModel().getSelection();

        var ids = [];
        Ext.each(sel, function(record) {

            ids.push(record.raw.user_id);
        });

        if(ids.length < 1){

            Ext.Msg.alert('Status', '삭제하실 User룰 선택하세요');
            return;
        }
        else {

            ids = ids.join(",");
        }
        // Send the id

        Ext.MessageBox.confirm('Confirm', '정말 삭제하시겠습니까?', Ext.Function.bind(function(confirm){

            if(confirm == 'yes'){
   
                Ext.Ajax.request({
                    url: '/manage/user/del',
                    type : 'json',
                    params : {
                        ids : ids
                    },
                    scope : this,
                    success: function(res){
                        
                        var result = Ext.JSON.decode(res.responseText);

                        Ext.Msg.alert('Status', result.message);

                        this.search();
                    },
                    failure: function(result, request){

                        Ext.Msg.alert("Failed", result.responseText);
                    }
                });
            }   
        }, this));
    },

    addUser : function(){

        this.getApplication().openWindow('manage.User-Add');
    },

    modUser : function(){

        var grid = Ext.getCmp('grid-'+this.id);

        var sel = grid.getSelectionModel().getSelection();

        var ids = [];
        Ext.each(sel, function(record) {

            ids.push(record);
        });

        if(ids.length < 1){

            Ext.Msg.alert('Status', '수정하실 User를 선택하세요');
            return;
        }
        else if(ids.length > 1){

            Ext.Msg.alert('Status', '수정시엔 하나만 선택하세요');
            return;
        }
        else if(ids.length == 1){

            this.getApplication().openWindow('manage.User-Add', ids[0]);
            return;
        }
    }
});