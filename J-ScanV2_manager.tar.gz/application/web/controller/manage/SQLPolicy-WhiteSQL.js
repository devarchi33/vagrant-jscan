Ext.require('CodeMirror.codemirror');
Ext.require('CodeMirror.mode.sql.sql');
Ext.define('WhiteSQL.controller.manage.SQLPolicy-WhiteSQL', {
    extend: 'Ext.app.Controller',

    initWindow : function(whitesql_id){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id,
            application : this.application,
            title : 'WhiteSQL 보기',
            width : 900,
            height: 600,
            buttons : this.initButtons(),
            items : this.initDetail(whitesql_id)
        });
    },

    initDetail : function(whitesql_id){

        var record = {};

        Ext.Ajax.request({
            url: '/manage/white_sql/getQueryData/'+whitesql_id,
            type : 'json',
            scope : this,
            async : false,
            success: function(res){
                
                record = Ext.JSON.decode(res.responseText);
            },
            failure: function(result, request){

                Ext.Msg.alert("Failed", result.responseText);

                var win = button.up("window");
                win.destroy();
            }
        });

        console.log(record);

        return {
            xtype   : 'form',
            layout  : 'vbox',
            bodyPadding : '5 5 5 5',
            border  : false,
            autoScroll : true,
            flex : 1,
            items:[
                this.initFieldSet({
                    title : 'White SQL', 
                    items : {
                        value : record.orig_sqltext
                    }
                }),
                this.initFieldSet({
                    title : 'Uniq SQL', 
                    items : {
                        value : record.uniq_sqltext
                    }
                })
            ]
        }
    },

    initFieldSet : function(config){

        return Ext.apply({
            xtype : 'fieldset',
            width : '100%',
            defaults : {
                labelWidth: 100,
                labelStyle: 'color:#008000',
                width : '100%',
                anchor : '100%',
                xtype : 'displayfield',
                labelPad : 5
            }
        }, config);
    },

    /**
     * initButtons
     *
     * 버튼 생성
     *
     * @access public
     *
     * @return button array
     */
    initButtons : function(){

        return [{
            text : '닫기',
            handler : function(){

                this.up("window").destroy();
            }
        }];
    }
});