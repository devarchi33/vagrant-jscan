Ext.require('CodeMirror.codemirror');
Ext.require('CodeMirror.mode.sql.sql');
Ext.define('WhiteSQL.controller.manage.SQLPolicy-Add', {
    extend: 'Ext.app.Controller',
    mode : 'add',
    old_policy_type : '',
    initWindow : function(record){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id,
            application : this.application,
            title : record ? '정책 수정' : '정책 추가',
            width : 900,
            height: 600,
            buttons : this.initButtons(),
            items : this.initDetail(record)
        });
    },

    initDetail : function(record){

        var bindData = {};
        
        if(record) {

            data = record.raw;
            
            this.mode = 'mod';
            this.old_policy_type = data.policy_type;

            bindData = {
                'add-policy-id'          : data.policy_id,
                'add-policy-type'        : data.policy_type,
                'add-policy-name'        : data.policy_name,
                'add-policy-on-off'      : data.on_off,
                'add-policy-block-yn'    : data.block,
                'add-policy-alarm-level' : data.alarm_level
            };
            this.old_policy_name = data.policy_name;

            var properties = {};
            if(data.policy_properties){

                properties = Ext.JSON.decode(data.policy_properties);
            }

            switch(data.policy_type){

                case '1':

                    Ext.apply(bindData, {
                        'add-policy-uniqsql-id': properties.uniqsql_id,
                        'add-policy-newsql-id' : properties.newsql_id,
                        'add-policy-sql'       : properties.target
                    });
                    break;

                case '2':
                    
                    Ext.apply(bindData, {
                        'add-policy-uniqsql-id' : properties.uniqsql_id,
                        'add-policy-newsql-id'  : properties.newsql_id,
                        'add-policy-sql'        : properties.target,
                        'add-policy-sql-convert': properties.convert
                    });
                    break;

                case '3':

                    var ip = properties.target.split(".");

                    if(ip.length < 4){

                        ip = ['', '', '', ''];
                    }

                    Ext.apply(bindData, {
                        'add-policy-ip-1' : ip[0],
                        'add-policy-ip-2' : ip[1],
                        'add-policy-ip-3' : ip[2],
                        'add-policy-ip-4' : ip[3]
                    });

                    break;

                case '4':
                
                    Ext.apply(bindData, {
                        'add-policy-login-id' : properties.target
                    });
                    break;

                case '5':
                
                    Ext.apply(bindData, {
                        'add-policy-table'         : properties.target,
                        'add-policy-allow-ftime'   : properties.allow_ftime,
                        'add-policy-allow-ttime'   : properties.allow_ttime,
                        'add-policy-allow-quantity': properties.allow_quantity
                    });
                    break;

                case '6':
                
                    Ext.apply(bindData, {
                        'add-policy-sql-type' : properties.target
                    });
                    break;

                case '7':
                
                    Ext.apply(bindData, {
                        'add-policy-privacy-table' : properties.target,
                        'add-policy-allow-ftime'   : properties.allow_ftime,
                        'add-policy-allow-ttime'   : properties.allow_ttime,
                        'add-policy-allow-quantity': properties.allow_quantity
                    });
                    break;
            }
        }
        else {

            bindData = {
                'add-policy-type' : '7'
            };

            this.mode = 'add';
            this.old_policy_type = '';
            this.old_policy_name = '';
        }
        
        return {
            xtype   : 'form',
            layout  : 'vbox',
            bodyPadding : '5 5 5 5',
            border  : false,
            autoScroll : true,
            flex : 1,
            items:[
                this.initFieldSet({
                    title  : '정책 기본 정보', 
                    hidden : false,
                    id     : 'fieldset-default-info',
                    items  : [
                        this.initPolicyId(),
                        this.initUniqSQLId(),
                        this.initNewSQLId(),
                        this.initPolicyType(),
                        this.initPolicyName(),
                        this.initPolicyOnOff(),
                        this.initBlockYn(),
                        this.initAlarmLevel(),
                        this.initSelectSQL()
                    ]
                }),
                this.initFieldSet({
                    title : '정책 정보 - 쿼리유형', 
                    id    : 'fieldset-sql-type',
                    items : this.initSQLType()
                }),
                this.initFieldSet({
                    title : '정책 정보 - 아이피', 
                    id    : 'fieldset-ip',
                    items : this.initTextIpAddress()
                }),
                this.initFieldSet({
                    title : '정책 정보 - 로그인아이디', 
                    id    : 'fieldset-login-id',
                    items : this.initLoginIDField()
                }),
                this.initFieldSet({
                    title : '정책 정보 - 테이블명', 
                    id    : 'fieldset-table-name',
                    items : [
                        this.initTableName()
                    ]
                }),
                this.initFieldSet({
                    title : '정책 정보 - 개인정보 테이블', 
                    id    : 'fieldset-privacy-table',
                    items : [
                        this.initPrivacyTable()
                    ]
                }),
                this.initFieldSet({
                    title : '정책 조건', 
                    id    : 'fieldset-view-option',
                    items : [
                        this.initAllowQuantity(),
                        this.initAllowTime()
                    ]
                }),
                {
                    xtype : 'container',
                    layout : 'hbox',
                    width : '100%',
                    items : [
                        this.initFieldSet({
                            title : '정책 정보 - SQL', 
                            id    : 'fieldset-sql',
                            flex : 1,
                            items : this.initSQLField()
                        }),
                        this.initFieldSet({
                            title : '정책 정보 - SQL 변경', 
                            id    : 'fieldset-sql-convert',
                            margin : '0 0 0 5',
                            flex : 1,
                            items : this.initSQLConvertField()
                        })
                    ]
                }
            ],
            listeners : {
                boxready : function(form){

                    form.getForm().setValues(bindData);
                    var combo = form.down('#add-policy-type');
                    var record = combo.store.getById(bindData['add-policy-type']);
                    combo.select(record, true);
                }
            }
        }
    },

    initFieldSet : function(config){

        return Ext.apply({
            xtype : 'fieldset',
            width : '100%',
            hidden : true,
            defaults : {
                labelWidth: 100,
                labelStyle: 'color:#008000',
                width : '100%',
                anchor : '100%',
                xtype : 'textfield',
                labelPad : 5
            }
        }, config);
    },


    /**
     * initButtons
     *
     * 버튼 생성
     *
     * @access public
     *
     * @return button array
     */
    initButtons : function(){

        return [{
            text: '리셋',
            handler: function() {
                this.up('form').getForm().reset();
            }
        }, 
        {
            text: '저장',
            formBind: true, //only enabled once the form is valid
            // disabled: true,
            scope : this,
            handler : this.save
        },
        {
            text : '닫기',
            handler : function(){

                this.up("window").destroy();
            }
        }];
    },

    /**
     * initPolicyId
     *
     * 서버아이디 설정 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.HiddenField
     */
    initPolicyId : function(){

        return {
            xtype            : 'hiddenfield',
            id               : 'add-policy-id',
            name             : 'add-policy-id'
        };
    },

    /**
     * initUniqSQLId
     *
     * Unique SQL 설정 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.HiddenField
     */
    initUniqSQLId : function(){

        return {
            xtype            : 'hiddenfield',
            id               : 'add-policy-uniqsql-id',
            name             : 'add-policy-uniqsql-id'
        };
    },

    /**
     * initNewSQLId
     *
     * New SQL 설정 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.HiddenField
     */
    initNewSQLId : function(){

        return {
            xtype            : 'hiddenfield',
            id               : 'add-policy-newsql-id',
            name             : 'add-policy-newsql-id'
        };
    },

    initPolicyType : function(){

        return {
            xtype            : 'combobox',
            id               : 'add-policy-type',
            name             : 'add-policy-type',
            fieldLabel       : '정책 유형',
            displayField     : 'text',
            emptyText        : '정책 유형 선택',
            disableKeyFilter : true,
            editable         : false,
            valueField       : 'id',
            validateBlank    : true,
            allowBlank       : false,
            blankText        : '비어있다.',
            store            : Ext.create('Ext.data.Store', {
                fields: ['id', 'text'],
                data : [
                    {'id' : '1', 'text' : 'SQL'},
                    {'id' : '2', 'text' : 'SQL변경'},
                    {'id' : '3', 'text' : 'IP'},
                    {'id' : '4', 'text' : 'LOGIN ID'},
                    {'id' : '5', 'text' : '주요 TABLE'},
                    {'id' : '6', 'text' : 'SQL 유형'},
                    {'id' : '7', 'text' : '개인정보 TABLE'}
                ]
            }),
            typeAhead       : true,
            listeners : {
                scope  : this,
                select : function(combo){

                    this.showFieldSet(combo);
                },
                boxready : function(combo){

                    this.showFieldSet(combo);
                }
            }
        };
    },

    showFieldSet : function(combo){

        var value = combo.getValue();
        Ext.invoke(combo.up('window').query('fieldset:not(fieldset:first)'), "hide");

        if(Ext.getCmp('add-policy-sql').editor){

            Ext.getCmp('add-policy-sql').editor.setValue("");
        }

        if(Ext.getCmp('add-policy-sql-convert').editor){
        
            Ext.getCmp('add-policy-sql-convert').editor.setValue("");
        }

        
        Ext.getCmp('add-policy-sql').setDisabled(true);
        Ext.getCmp('add-policy-sql-convert').setDisabled(true);


        switch(value){

            case '1' : 
                Ext.getCmp('fieldset-sql').show();
                Ext.getCmp('add-policy-select-sql').show();
                break;
            case '2' : 

                Ext.invoke(Ext.ComponentQuery.query(
                    '#add-policy-select-sql, #fieldset-sql, #fieldset-sql-convert'
                ), 'show');
                break;
            case '3' : 
                Ext.getCmp('fieldset-ip').show();
                break;
            case '4' : 
                Ext.getCmp('fieldset-login-id').show();
                break;
            case '5' : 
                Ext.getCmp('fieldset-table-name').show();
                Ext.getCmp('fieldset-view-option').show();
                break;
            case '6' : 
                Ext.getCmp('fieldset-sql-type').show();
                break;
            case '7' : 
                Ext.getCmp('fieldset-privacy-table').show();
                Ext.getCmp('fieldset-view-option').show();
                break;
        }
    },

    initSQLType : function(){

        return {
            xtype            : 'combobox',
            id               : 'add-policy-sql-type',
            name             : 'add-policy-sql-type',
            fieldLabel       : '쿼리 유형',
            displayField     : 'text',
            emptyText        : '쿼리 유형 선택',
            disableKeyFilter : true,
            editable         : false,
            valueField       : 'id',
            validateBlank    : true,
            allowBlank       : false,
            value            : 'DELETE',
            store            : Ext.create('Ext.data.Store', {
                fields: ['id', 'text'],
                data : [
                    {'id' : 'DELETE', 'text' : 'DELETE'},
                    {'id' : 'CREATE', 'text' : 'CREATE'},
                    {'id' : 'ALTER', 'text' : 'ALTER'},
                    {'id' : 'DROP', 'text' : 'DROP'},
                    {'id' : 'TRUNCATE', 'text' : 'TRUNCATE'},
                    {'id' : 'GRANT', 'text' : 'GRANT'},
                    {'id' : 'REVOKE', 'text' : 'REVOKE'},
                    {'id' : 'EXPLAIN PLAN', 'text' : 'EXPLAIN PLAN'},
                    {'id' : 'RENAME', 'text' : 'RENAME'}
                ]
            }),
            typeAhead       : true
        };
    },

    /**
     * initPrivacyTable
     *
     * 개인정보 테이블명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initPrivacyTable : function(){

        var store = new Ext.data.Store({
            proxy: {
                type  : 'ajax',
                url: '/manage/privacy_table/getPrivacyTableListByQuery',
                reader: {
                    type: 'json'
                }
            },
            fields: [
                { name : 'id', type : 'string' },
                { name : 'text', type : 'string' }
            ],
            autoLoad : true
        });

        // Simple ComboBox using the data store
        return {
            xtype           : 'combobox',
            fieldLabel      : '테이블명',
            id              : 'add-policy-privacy-table',
            name            : 'add-policy-privacy-table',
            displayField    : 'text',
            emptyText       : '개인 정보 테이블 입력',
            disableKeyFilter: true,
            valueField      : 'text',
            validateBlank   : true,
            allowBlank      : false,
            blankText       : '개인 정보 테이블을 입력해주세요.',
            store           : store,
            hideTrigger     : true,
            minChars        : 1,
            triggerAction   : 'query',
            typeAhead       : true
        };
    },

    /**
     * initLoginIDField
     *
     * 로그인아이디 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initLoginIDField : function(){

        return {
            xtype : 'textfield',
            fieldLabel: '로그인 아이디',
            id: 'add-policy-login-id',
            name: 'add-policy-login-id',
            allowBlank: false
        };
    },

    /**
     * initTextServerName
     *
     * 서버명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initPolicyName : function(){

        return {
            xtype : 'textfield',
            fieldLabel: '정책명',
            id: 'add-policy-name',
            name: 'add-policy-name',
            allowBlank: false
        };
    },

    /**
     * initSQLField
     *
     * SQL 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initSQLField : function(){

        return {
            xtype        : 'textarea',
            id           : 'add-policy-sql',
            name         : 'add-policy-sql',
            header       : false,
            border       : true,
            width        : '100%',
            height       : 300,
            flex         : 1,
            bodyPadding  : 5,
            disabled     : this.mode == 'mod' ? false : true,
            maskOnDisable: true,
            listeners    : {
                boxready : function(editor, width, height){

                    textarea = editor.getEl().query('textarea')[0];

                    Ext.apply(this, {
                        editor : CodeMirror.fromTextArea(textarea, {
                            mode: 'text/x-mysql',
                            indentWithTabs: true,
                            smartIndent: true,
                            lineNumbers: true,
                            matchBrackets : true,
                            autofocus: true,
                            readOnly : true
                        }),
                        getEditor : function(){
                            return this.editor;
                        }
                    });
                },
                resize : function(editor, width, height){

                    this.editor.setSize(width, height);
                }
            }
        };
    },

    /**
     * initSQLField
     *
     * SQL 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initSQLConvertField : function(){

        return {
            xtype        : 'textarea',
            id           : 'add-policy-sql-convert',
            name         : 'add-policy-sql-convert',
            header       : false,
            border       : true,
            width        : '100%',
            height       : 300,
            flex         : 1,
            bodyPadding  : 5,
            disabled     : this.mode == 'mod' ? false : true,
            maskOnDisable: true,
            listeners    : {
                boxready : function(editor, width, height){

                    textarea = editor.getEl().query('textarea')[0];

                    Ext.apply(this, {
                        editor : CodeMirror.fromTextArea(textarea, {
                            mode: 'text/x-mysql',
                            indentWithTabs: true,
                            smartIndent: true,
                            lineNumbers: true,
                            matchBrackets : true,
                            autofocus: true
                        }),
                        getEditor : function(){
                            return this.editor;
                        }
                    });
                },
                resize : function(editor, width, height){

                    this.editor.setSize(width, height);
                }
            }
        };
    },

    /**
     * initTableName
     *
     * 테이블명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initTableName : function(){

        var store = new Ext.data.Store({
            proxy: {
                type  : 'ajax',
                url: '/manage/privacy_table/getUniqSQLTableListByQuery',
                reader: {
                    type: 'json'
                }
            },
            fields: [
                { name : 'id', type : 'string' },
                { name : 'text', type : 'string' }
            ],
            autoLoad : true
        });

        // Simple ComboBox using the data store
        return {
            xtype           : 'combobox',
            fieldLabel      : '테이블명',
            id              : 'add-policy-table',
            name            : 'add-policy-table',
            displayField    : 'text',
            emptyText       : '테이블명 입력',
            disableKeyFilter: true,
            valueField      : 'text',
            validateBlank   : true,
            allowBlank      : false,
            blankText       : '테이블명을 입력해주세요.',
            store           : store,
            hideTrigger     : true,
            minChars        : 1,
            triggerAction   : 'query',
            typeAhead       : true
        };
    },

    /**
     * initAllowQuantity
     *
     * 테이블명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initAllowQuantity : function(){

        return {
            xtype : 'textfield',
            fieldLabel: '1회 조회 허용량',
            id: 'add-policy-allow-quantity',
            name: 'add-policy-allow-quantity',
            allowBlank: false
        };
    },

    /**
     * initAllowTime
     *
     * 테이블명 입력 컴포넌트 생성`
     *
     * @access public
     *
     * @return component Ext.form.field.Text
     */
    initAllowTime : function(){

        return {
            xtype: 'container',
            layout : 'hbox',
            width : '100%',
            margin: '0 0 5 0',
            defaults : {
                xtype            : 'numberfield',
                allowBlank       : false,
                enforceMaxLength : true,
                hideTrigger      : true,
                keyNavEnabled    : false,
                mouseWheelEnabled: false
            },
            items : [
                {
                    fieldStyle: 'color:#008000',
                    xtype : 'displayfield',
                    width: 100,
                    margin: '0 5 0 0',
                    value : '조회 허용 시간'
                },
                {
                    xtype: 'timefield',
                    format: 'H:i:s',
                    id : 'add-policy-allow-ftime',
                    name : 'add-policy-allow-ftime',
                    editable : false,
                    value : '00:00:00',
                    minValue: '00:00 AM',
                    maxValue: '24:00 PM',
                    increment: 60,
                    width: 120,
                    margin : '0 5 0 0'
                },
                {
                    xtype : 'text',
                    text : '~',
                    margin : '0 5 0 0'
                },
                {
                    xtype: 'timefield',
                    format: 'H:59:59',
                    id : 'add-policy-allow-ttime',
                    name : 'add-policy-allow-ttime',
                    editable : false,
                    width: 120,
                    value: '23:59:59',
                    minValue: '00:00 AM',
                    maxValue: '24:00 PM',
                    increment: 60,
                    margin : '0 5 0 0'
                }
            ]
        };
    },

    /**
     * initBlockYn
     *
     * 차단여부 선택 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.RadioGroup
     */
    initBlockYn : function(){

        return {
            xtype : 'hiddenfield',
            id : 'add-policy-block-yn',
            name : 'add-policy-block-yn',
            value : "0"
        }
        // return {
        //     xtype         : 'radiogroup',
        //     fieldLabel    : '차단여부',
        //     allowBlank    : false,
        //     msgTarget     : 'side',
        //     autoFitErrors : false,
        //     id            : 'add-policy-block-yn',
        //     items: [
        //         {
        //             boxLabel  : '차단',
        //             name      : 'add-policy-block-yn',
        //             inputValue: 1
        //         }, {
        //             boxLabel  : '차단안함',
        //             name      : 'add-policy-block-yn',
        //             inputValue: 0
        //         }
        //     ]
        // };
    },
    /**
     * initPolicyOnOff
     *
     * 정책 켜기여부 선택 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.RadioGroup
     */
    initPolicyOnOff : function(){

        return {
            xtype         : 'radiogroup',
            fieldLabel    : '정책켜기',
            allowBlank    : false,
            msgTarget     : 'side',
            autoFitErrors : false,
            id            : 'add-policy-on-off',
            items: [
                {
                    boxLabel  : '켜기',
                    name      : 'add-policy-on-off',
                    inputValue: 1,
                    checked   : true
                }, {
                    boxLabel  : '끄기',
                    name      : 'add-policy-on-off',
                    inputValue: 0
                }
            ]
        };
    },

    /**
     * initSelectSQL
     *
     * SQL 선택 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.RadioGroup
     */
    initSelectSQL : function(){

        return {
            xtype : 'container',
            layout: 'hbox',
            width : '100%',
            margin: '0 0 5 0',
            hidden : true,
            id    : 'add-policy-select-sql',
            items : [
                {
                    xtype : 'displayfield',
                    width : 100,
                    labelStyle: 'color:#008000',
                    value : 'SQL 선택:'
                },
                {
                    xtype : 'button',
                    text : '선택 후 입력',
                    scope : this,
                    handler : function(){

                        this.getApplication().openWindow('manage.SQLPolicy-Search-SQL');
                    }
                }
            ]
        };
    },

    /**
     * initAlarmLevel
     *
     * 차단여부 선택 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.RadioGroup
     */
    initAlarmLevel : function(){

        return {
            xtype      : 'radiogroup',
            fieldLabel : '알람 레벨',
            allowBlank : false,
            msgTarget  : 'side',
            id         : 'add-policy-alarm-level',
            autoFitErrors: false,
            items: [
                {
                    boxLabel  : '알림',
                    name      : 'add-policy-alarm-level',
                    inputValue: 1,
                    checked   : true
                }, {
                    boxLabel  : '주의',
                    name      : 'add-policy-alarm-level',
                    inputValue: 2,
                }, {
                    boxLabel  : '경보',
                    name      : 'add-policy-alarm-level',
                    inputValue: 3,
                }, {
                    boxLabel  : '위험',
                    name      : 'add-policy-alarm-level',
                    inputValue: 4,
                }, {
                    boxLabel  : '심각',
                    name      : 'add-policy-alarm-level',
                    inputValue: 5
                }
            ]
        };
    },

    /**
     * initTextIpAddress
     *
     * 아이피 주소 입력 폼 생성
     *
     * @access public
     *
     * @return component Ext.container.Container
     */
    initTextIpAddress : function(){

        return {
            xtype: 'container',
            layout : 'hbox',
            width : '100%',
            margin: '0 0 5 0',
            defaults : {
                xtype : 'numberfield',
                allowBlank: false,
                maxLength : 3,
                maxValue: 255,
                minValue: 0,
                enforceMaxLength : true,
                hideTrigger: true,
                keyNavEnabled: false,
                mouseWheelEnabled: false
            },
            items : [
                {
                    fieldStyle: 'color:#008000',
                    xtype : 'displayfield',
                    width: 100,
                    margin: '0 5 0 0',
                    value : 'IP'
                },
                {
                    width: 30,
                    id   : 'add-policy-ip-1',
                    name : 'add-policy-ip-1'
                },
                {
                    xtype : 'text',
                    margin: '0 5 0 5',
                    text : '.'
                },
                {
                    width: 30,
                    id   : 'add-policy-ip-2',
                    name : 'add-policy-ip-2'
                },
                {
                    xtype : 'text',
                    margin: '0 5 0 5',
                    text : '.'
                },
                {
                    width: 30,
                    id   : 'add-policy-ip-3',
                    name : 'add-policy-ip-3'
                },
                {
                    xtype : 'text',
                    margin: '0 5 0 5',
                    text : '.'
                },
                {
                    width: 30,
                    id   : 'add-policy-ip-4',
                    name : 'add-policy-ip-4'
                }
            ]
        };
    },

    /**
     * search
     *
     * 검색 수행
     *
     * @access public
     *
     */
    search : function(){

        var params = {};
        params[this.id+'-search-mode'] = Ext.getCmp(this.id+'-search-mode').getValue();
        params[this.id+'-search-keyword'] = Ext.getCmp(this.id+'-search-keyword').getValue();
        var grid   = Ext.getCmp('grid-'+this.id);
        this.getApplication().fireEvent('grid-search', grid, params);
    },


    save : function(button, event){

        var frm    = button.up('window').down('form');
        var valid  = true;
        frm.query('field').forEach(function(field){
            if(!field.isVisible(true)) return;
            if(!field.isValid()) valid = false;
        });

        if(!valid){

            return;
        }

        var params = frm.getValues();

        frm.query('textarea').forEach(function(textarea){
            if(!textarea.isVisible(true)) return;
            params[textarea.id] = textarea.getEditor().getValue();
        });

        params.agent_id = WhiteSQL.app.serverId;

        Ext.Ajax.request({
            url: '/manage/policy/save',
            type : 'json',
            params : params,
            scope : this,
            success: function(res){
                
                var result = Ext.JSON.decode(res.responseText);

                Ext.Msg.alert('Status', result.message);

                var ctrl = this.getController('manage.SQLPolicy');
                ctrl.search();

                this.getApplication().fireEvent('grid-footer-history-reload');

                var win = button.up("window");
                win.destroy();

                this.getApplication().syncPolicies = false;
            },
            failure: function(result, request){

                Ext.Msg.alert("Failed", result.responseText);

                var win = button.up("window");
                win.destroy();
            }
        });
    } 
});