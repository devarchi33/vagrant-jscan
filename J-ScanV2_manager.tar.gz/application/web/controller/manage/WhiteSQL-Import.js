Ext.define('WhiteSQL.controller.manage.WhiteSQL-Import', {
    extend: 'Ext.app.Controller',

    initWindow : function(log_id){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id+'-import',
            application : this.application,
            title : 'White SQL 불러오기',
            width : 800,
            height: 300,
            bodyPadding : '5 5 5 5',
            layout : 'vbox',
            buttons : [{
                text: '불러오기',
                scope : this,
                handler: this.import         
            },{
                text: '리셋',
                scope : this,
                handler: this.reset         
            }],
            items : [
                this.initExplain1(),
                this.initExampleGrid(),
                this.initExplain2(),
                this.initUploadForm()
            ]
        });
    },

    initExplain1 : function(){

        var text = 'Import 하려는 Excel 파일이 아래의 양식과 맞지 않는 경우는 에러가 납니다.\n \n';
        text += 'consql_id, agent_id, uniqsql_id, class_id는 변경하시면 안되고 export시 숨겨져 있습니다. \n \n';

        return {
            xtype : 'text',
            text  : text,
            margin: '0 0 10 0'
        };
    },

    initExplain2 : function(){

        var text = '아래의 업로드 폼에서 엑셀파일(Export 받은 그대로의 양식)을 업로드하세요.';

        return {
            xtype : 'text',
            text  : text,
            margin: '0 0 10 0'
        };
    },

    initUploadForm : function(){

        return {
            xtype : 'form',
            id : 'form'+this.id,
            layout : 'vbox',
            width: '100%',
            height : 80,
            frame: true,
            bodyPadding: '10 10 0',

            defaults: {
                anchor: '100%',
                allowBlank: false,
                msgTarget: 'side',
                labelWidth: 150
            },

            items: [
                this.initComboBox(),
                this.initFileField()
            ]
        };
    },

    initFileField : function(){

        return {
            xtype: 'filefield',
            id: 'form-'+this.id,
            width : '100%',
            emptyText: 'Select an image',
            fieldLabel: 'Import Excel File',
            name: 'import-excel',
            buttonText: '',
            buttonConfig: {
                icon: '/images/excel.png'
            }
        };
    },

    /**
     * initGrid
     *
     * 콤보박스 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initComboBox : function(){

        var store = new Ext.data.Store({
            proxy: {
                type  : 'ajax',
                url: '/manage/white_sql/getServerList',
                reader: {
                    type: 'json'
                }
            },
            fields: ['id','text']
        });

        // Simple ComboBox using the data store
        return {
            xtype : 'combobox',
            id   : this.id+'-agent-id',
            name : this.id+'-agent-id',
            fieldLabel: 'Target Server',
            emptyText : '선택',
            value: '',
            displayField : 'text',
            valueField: 'id',
            store: store,
            typeAhead: true
        };
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initExampleGrid : function(mode){

        var columns = this.makeExampleGridColumns();

        var grid = Ext.create('Lib.Grid', {
            id : 'grid-example-'+this.id,
            title : 'Import Excel 양식',
            columns : columns
        });

        return grid;
    },

    /**
     * makeDetailListColumns
     *
     * 상세정보 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeExampleGridColumns : function(){   

        return [
            { text: 'whitesql_id', dataIndex: 'convsql_id', sortable: true, menuDisabled : true },
            { text: 'agent_id', dataIndex: 'agent_id', sortable: true, menuDisabled : true },
            { text: 'uniqsql_id', dataIndex: 'uniqsql_id', sortable: true, menuDisabled : true },
            { text: 'class_id', dataIndex: 'class_id', sortable: true, menuDisabled : true },
            { text: 'agent_name', dataIndex: 'agent_name', sortable: true, menuDisabled : true },
            { text: 'class_string', dataIndex: 'class_string', sortable: true, menuDisabled : true },
            { text: 'orig_sqltext', dataIndex: 'orig_sqltext', sortable: true, menuDisabled : true, flex : 1 }
        ];
    },

    import : function(button, event){

        var form = Ext.getCmp('form'+this.id);
        var win = Ext.getCmp('window-'+this.id+'-import');

        if(form.isValid()){

            form.submit({
                url: '/manage/white_sql/import',
                waitMsg: '데이터 처리 중 입니다.',
                success: function(fp, o) {

                    Ext.Msg.alert("Success", '성공적으로 Import 되었습니다.');
                    win.destroy();
                },
                failure : function(fp, o){

                    Ext.Msg.alert("Failed", o.result.error);
                }
            });
        }
    },

    reset : function(){

        var form = Ext.getCmp('form'+this.id);

        form.reset();
    }
});