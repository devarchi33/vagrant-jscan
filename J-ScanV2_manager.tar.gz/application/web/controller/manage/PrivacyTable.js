Ext.define('WhiteSQL.controller.manage.PrivacyTable', {
    extend: 'Ext.app.Controller',

    /**
     *
     * 윈도우 생성
     *
     * @return component Ext.container.Container
     */
    initWindow : function(){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id,
            title : 'Privacy Table',
            width : 1200,
            height: 800,
            bodyPadding : '5 5 5 5',
            layout : 'fit',
            bodyStyle : 'background-color:#ffffff',
            items : [
                {
                    xtype : 'panel',
                    layout: 'vbox',
                    border : false,
                    region: 'center',
                    width : '100%',
                    flex  : 1,
                    items : [
                        this.initGridSearch(),
                        this.initGrid()
                    ]
                }
            ]
        });
    },

    /**
     * initGridSearch
     *
     * 그리드 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGridSearch : function(){

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'vbox',
            frame : true,
            width : '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 0',
            items:[
                {
                    xtype   : 'container',
                    layout  : 'hbox',
                    width : '100%',
                    margin  : '0 0 5 0',
                    defaults: {
                        height : 26,
                        margin : '0 10 0 0'
                    },
                    items : [
                        {
                            margin : '5 2 0 0',
                            xtype : 'image',
                            width : 16,
                            height : 16,
                            src   : '/images/host_en.png'
                        },
                        {
                            xtype : 'text',
                            margin : '5 0 0 0',
                            id    : 'server-name-'+this.id,
                            width : 100,
                            text  : this.application.getServerName()
                        },
                        {
                            xtype: 'textfield',
                            id   : this.id+'-search-keyword',
                            name : this.id+'-search-keyword',
                            flex : 1
                        },
                        {
                            xtype:'button',
                            icon : '/images/find.png',
                            text: '검색',
                            scope : this,
                            handler : this.search
                        },
                        {
                            xtype: 'buttongroup',
                            items : [
                                {
                                    xtype:'button',
                                    icon : '/images/add.png',
                                    text: '추가',
                                    scope : this,
                                    handler : this.addPrivacyTable
                                },
                                {
                                    xtype:'button',
                                    icon : '/images/policy_sync.png',
                                    text: '동기화',
                                    scope : this,
                                    handler : this.syncPrivacyTable
                                },
                                {
                                    xtype:'button',
                                    icon : '/images/delete.png',
                                    text: '삭제',
                                    scope : this,
                                    handler : this.delPrivacyTable
                                }
                            ]
                        }
                    ]
                }
            ]
        };
        return form;
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGrid : function(mode){

        var selModel = Ext.create('Ext.selection.CheckboxModel', {
            mode : 'multi'
        });

        var columns = this.makeListColumns();

        var grid = Ext.create('Lib.Grid', {
            id : 'grid-'+this.id,
            url : '/manage/privacy_table/getListData',
            title : mode,
            selModel : selModel,
            columns : columns
        });

        return grid;
    },

    /**
     * search
     *
     * 검색 수행
     *
     * @access public
     *
     */
    search : function(){

        var params = Ext.getCmp('form-'+this.id).getValues();        
        var grid   = Ext.getCmp('grid-'+this.id);

        this.getApplication().fireEvent('grid-search', grid, params);
    },


    /**
     * makeDetailListColumns
     *
     * 상세정보 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeListColumns : function(){   

        return [
            { text: '테이블명칭', dataIndex: 'privacytbl_name', flex : 1},
            { text: '테이블', dataIndex: 'privacytbl', width : 200},
            { text: '등록자', dataIndex: 'user_name', width : 100},
            { text: '생성일시', dataIndex: 'reg_time', width : 130},
            { text: '상태', dataIndex: 'state', width : 80, renderer:function(value){ 
                
                switch(value){
                    case "A":
                        return "추가";
                        break;
                    case "M":
                        return "수정";
                        break;
                    case "D":
                        return "삭제";
                        break;
                    case "N":
                        return "동기화완료";
                        break;
                }
            }},
            {
                xtype : 'actioncolumn',
                width : 50,
                items : [
                    {
                        icon:'/images/edit.png',
                        tooltip : 'Modify',
                        scope : this,
                        handler : function (grid, rowIndex, colIndex, item, e, record) {
                            
                            this.modPrivacyTable(record);
                        },
                        isDisabled: function(view, rowIndex, colIndex, item, record) {

                            return record.get('state') == 'D';
                        }
                    },
                    {
                        icon:'/images/delete.png',
                        tooltip : 'Delete',
                        scope : this,
                        handler : function (grid, rowIndex, colIndex, item, e, record) {

                            //do your delete record function here
                            var me = this;
                            setTimeout(function(){
                                me.delPrivacyTable();
                            }, 500);
                        },
                        isDisabled: function(view, rowIndex, colIndex, item, record) {

                            // Returns true if 'editable' is false (, null, or undefined)
                            return record.get('state') == 'D';
                        }
                    }
                ]
            }
        ];
    },

    delPrivacyTable : function(){

        var grid = Ext.getCmp('grid-'+this.id);

        var sel = grid.getSelectionModel().getSelection();

        var ids = [];
        Ext.each(sel, function(record) {

            ids.push(record.raw.privacytbl_id);
        });

        if(ids.length < 1){

            Ext.Msg.alert('Status', '삭제하실 PrivacyTable SQL을 선택하세요');
            return;
        }
        else {

            ids = ids.join(",");
        }
        // Send the id

        Ext.MessageBox.confirm('Confirm', '정말 삭제하시겠습니까?', Ext.Function.bind(function(confirm){

            if(confirm == 'yes'){
   
                Ext.Ajax.request({
                    url: '/manage/privacy_table/del',
                    type : 'json',
                    params : {
                        agent_id : WhiteSQL.app.serverId,
                        ids : ids
                    },
                    scope : this,
                    success: function(res){
                        
                        var result = Ext.JSON.decode(res.responseText);

                        Ext.Msg.alert('Status', result.message);

                        this.search();

                        this.getApplication().fireEvent('grid-footer-history-reload');
                    },
                    failure: function(result, request){

                        Ext.Msg.alert("Failed", result.responseText);
                    }
                });
            }   
        }, this));
    },

    addPrivacyTable : function(){

        this.getApplication().openWindow('manage.PrivacyTable-Add');
    },

    modPrivacyTable : function(record){

        this.getApplication().openWindow('manage.PrivacyTable-Add', record);
    },
    
    setPrivacyTableState : function(url, data_params){

        var grid = Ext.getCmp('grid-'+this.id);
        
        var sel  = grid.getSelectionModel().getSelection();
        
        var ids  = [];
        Ext.each(sel, function(record) {

            ids.push(record.raw.privacytbl_id);
        });

        if(ids.length < 1){

            Ext.Msg.alert('Status', 'SQL을 선택하세요');
            return;
        }
        else {

            ids = ids.join(",");
        }
        // Send the id

        Ext.MessageBox.confirm('Confirm', '정말 진행하시겠습니까?', Ext.Function.bind(function(confirm){

            if(confirm == 'yes'){
   
                Ext.Ajax.request({
                    url    : url,
                    type   : 'json',
                    params : Ext.Object.merge({ ids : ids }, data_params),
                    scope : this,
                    success: function(res){
                        
                        var result = Ext.JSON.decode(res.responseText);

                        Ext.Msg.alert('Status', result.message);

                        Ext.each(sel, function(record) {

                            record.set(Ext.Object.merge(data_params, {state : 'M'}));
                        });

                        this.getApplication().fireEvent('grid-footer-history-reload');
                    },
                    failure: function(result, request){

                        Ext.Msg.alert("Failed", result.responseText);
                    }
                });
            }   
        }, this));
    },

    syncPrivacyTable : function(){

        var msg  = Ext.Msg.wait('처리중 입니다.');

        Ext.Ajax.timeout = 300000;

        Ext.Ajax.request({
            url: '/manage/privacy_table/syncPrivacyTable',
            type : 'json',
            params : {
                server : WhiteSQL.app.serverId
            },
            scope : this,
            success: function(res){
                
                msg.hide();

                var result = Ext.JSON.decode(res.responseText);

                Ext.Msg.alert('Status', result.message);

                this.search();
            },
            failure: function(result, request, a,b,c,d,e){

                msg.hide();

                if(result.timedout == true){

                    Ext.Msg.alert("Failed", "요청한 시간이 지나 작업이 중단되었습니다.");
                }
                else {

                    Ext.Msg.alert("Failed", result.responseText);   
                }
            }
        });
    }
}); 