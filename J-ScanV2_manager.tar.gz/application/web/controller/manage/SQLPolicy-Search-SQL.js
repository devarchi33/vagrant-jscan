Ext.define('WhiteSQL.controller.manage.SQLPolicy-Search-SQL', {
    extend: 'Ext.app.Controller',
    initWindow : function(record){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id,
            layout : 'vbox',
            application : this.application,
            title : '정책 정보 - SQL 검색',
            width : 600,
            height: 300,
            bodyPadding : 5,
            buttons : this.initButtons(),
            items : [
                this.initGridSearch(),
                this.initGrid()  
            ]
        });
    },

    /**
     * initButtons
     *
     * 버튼 생성
     *
     * @access public
     *
     * @return button array
     */
    initButtons : function(){

        return [
        {
            text : '닫기',
            handler : function(){

                this.up("window").destroy();
            }
        }];
    },

    /**
     * initGridSearch
     *
     * 그리드 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGridSearch : function(){

        return {
            xtype   : 'container',
            layout  : 'hbox',
            height : 26,
            width : '100%',
            margin  : '0 0 5 0',
            defaults: {
                height : 26,
                margin : '0 10 0 0'
            },
            items : [
                this.initComboBox(),
                {
                    xtype: 'textfield',
                    id   : this.id+'-search-keyword',
                    name : this.id+'-search-keyword',
                    width: 300
                },
                {
                    xtype:'button',
                    icon : '/images/find.png',
                    text: '검색',
                    scope : this,
                    handler : this.search
                }
            ]
        };
    },

    /**
     * initComboBox
     *
     * 콤보박스 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initComboBox : function(label, mode){

        var store = Ext.create('Ext.data.Store', {
            data : [{
                id : '',
                text : '전체'
            },{
                id : 'class_string', text : '클래스명'
            },{
                id : 'sqltext', text : '쿼리'
            }],
            fields: ['id','text']
        });

        // Simple ComboBox using the data store
        var combo = Ext.create('Ext.form.ComboBox', {
            id   : this.id+'-search-mode',
            name : this.id+'-search-mode',
            emptyText : '선택',
            editable:false,
            displayField : 'text',
            valueField: 'id',
            value : 'class_string',
            store: store
        });

        return combo;
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGrid : function(mode){

        var columns = this.makeListColumns();

        var grid = Ext.create('Lib.Grid', {
            id : 'grid-'+this.id,
            url : '/manage/policy/getWhiteSQLListData',
            title : mode,
            columns : columns,
            flex : 1,
            width : '100%',
            listeners: {
                scope : this,
                itemdblclick: function(grid, record, item, index, e, eOpts) {
                    
                    if(e.ctrlKey == true || e.shiftKey == true) return;
                    
                    Ext.getCmp('add-policy-uniqsql-id').setValue(record.raw.uniqsql_id);
                    Ext.getCmp('add-policy-newsql-id').setValue(record.raw.newsql_id);
                    Ext.getCmp('add-policy-sql').getEditor().setValue(record.data.orig_sqltext);
					Ext.getCmp('add-policy-sql').setDisabled(false)       

                    if(Ext.getCmp('add-policy-type').getValue() == "2"){

                    	Ext.getCmp('add-policy-sql-convert').setDisabled(false);
                        Ext.getCmp('add-policy-sql-convert').getEditor().setValue(record.data.orig_sqltext);
                    }

                    grid.up("window").destroy();
                }
            }
        });

        return grid;
    },

    /**
     * makeDetailListColumns
     *
     * 상세정보 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeListColumns : function(){   

        return [
            { text: '클래스명', dataIndex: 'class_string'},
            { text: '쿼리', dataIndex: 'orig_sqltext' , flex: 1 }
        ];
    }
});