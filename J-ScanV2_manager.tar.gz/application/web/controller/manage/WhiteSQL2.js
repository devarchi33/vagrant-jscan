Ext.define('WhiteSQL.controller.manage.WhiteSQL', {
    extend: 'Ext.app.Controller',
    
    /**
     *
     * 윈도우 생성
     *
     * @return component Ext.container.Container
     */
    initWindow : function(){

        Ext.create('Lib.Window', {
            id : 'window-'+this.id,
            title : 'White SQL',
            width : 1200,
            height: 800,
            bodyPadding : '5 5 5 5',
            layout : 'fit',
            items : [
                {
                    xtype : 'panel',
                    layout: 'border',
                    width : '100%',
                    border: 0,
                    flex  : 1,
                    items : [
                        {
                            xtype : 'panel',
                            layout: 'vbox',
                            border : false,
                            region: 'center',
                            width : '100%',
                            flex  : 1,
                            items : [
                                this.initGridSearch(),
                                this.initGrid()
                            ]
                        },
                        this.initQueryField()
                    ]
                }
            ]
        });
    },

    /**
     * initGridSearch
     *
     * 그리드 검색 폼 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGridSearch : function(){

        var form = {
            id : 'form-'+this.id,
            xtype: 'form',
            layout: 'vbox',
            frame : true,
            width : '100%',
            margin : '0 0 5 0',
            bodyPadding: '5 5 0',
            defaults : {
                labelWidth: 80
            },
            items:[
                {
                    xtype   : 'container',
                    layout  : 'hbox',
                    margin  : '0 0 5 0',
                    defaults: {
                        labelWidth: 80,
                        height : 26,
                        margin : '0 10 0 0'
                    },
                    items : [
                        {
                            xtype       : 'displayfield',
                            id          : 'server-name-'+this.id,
                            fieldLabel  : "서버",
                            fieldBodyCls: "align-top",
                            width       : 200,
                            value       : this.application.getServerName()
                        },
                        this.initComboBox(),
                        {
                            xtype:'textfield',
                            id   : this.id+'-search-keyword',
                            name : this.id+'-search-keyword',
                            width : 500
                        },
                        {
                            xtype:'button',
                            icon : '/images/find.png',
                            text: '검색',
                            scope : this,
                            handler : this.search
                        },
                        {
                            xtype: 'buttongroup',
                            items : [
                                {
                                    xtype:'button',
                                    icon : '/images/delete.png',
                                    text: '삭제',
                                    scope : this,
                                    handler : this.delSQL
                                }
                            ]
                        },
                        {
                            xtype: 'buttongroup',
                            items : [
                                {
                                    xtype:'button',
                                    icon : '/images/import.png',
                                    text: '불러오기',
                                    scope : this,
                                    handler : this.importSQL
                                },
                                {
                                    xtype:'button',
                                    icon : '/images/export.png',
                                    text: '내보내기',
                                    scope : this,
                                    handler : this.exportSQL
                                }
                            ]
                        }
                    ]
                }
            ]
        };
        return form;
    },

    /**
     * initComboBox
     *
     * 콤보박스 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.form.ComboBox
     */
    initComboBox : function(label, mode){

        var store = new Ext.data.Store({
            data : [{
                id : 'class_string', text : '클래스명'
            },{
                id : 'sqltext', text : '쿼리'
            }],
            fields: ['id','text']
        });

        // Simple ComboBox using the data store
        var combo = Ext.create('Ext.form.ComboBox', {
            id   : this.id+'-search-mode',
            name : this.id+'-search-mode',
            emptyText : '선택',
            displayField : 'text',
            valueField: 'id',
            value : 'class_string',
            store: store
        });

        return combo;
    },

    /**
     * initGrid
     *
     * 그리드 컴포넌트 생성
     *
     * @access public
     *
     * @return component Ext.grid.Panel
     */
    initGrid : function(mode){

        var selModel = Ext.create('Ext.selection.CheckboxModel', {
            mode : 'multi'
        });

        var columns = this.makeListColumns();

        var grid = Ext.create('Lib.Grid', {
            id : 'grid-'+this.id,
            url : '/manage/white_sql/getListData',
            title : mode,
            columns : columns,
            selModel : selModel,
            listeners: {
                scope : this,
                itemclick: function(grid, record, item, index, e, eOpts) {
                    
                    Ext.Ajax.request({
                        url    : '/manage/white_sql/getQueryData/'+record.raw.whitesql_id,
                        type   : 'json',
                        async  : false,
                        scope  : this,
                        success: function(res){

                            var data = Ext.JSON.decode(res.responseText);

                            Ext.getCmp(this.id+'-org-sql').update(data.orig_sqltext);
                        }
                    });
                }
            }
        });

        return grid;
    },

    /**
     * search
     *
     * 검색 수행
     *
     * @access public
     *
     */
    search : function(){

        var params = Ext.getCmp('form-'+this.id).getValues();        
        var grid   = Ext.getCmp('grid-'+this.id);

        this.getApplication().fireEvent('grid-search', grid, params);
    },

    initQueryField : function(){

        return {
            xtype : 'panel',
            layout : 'vbox',
            region: 'south',
            split : true,
            collapsible : true,
            header : false,
            width : '100%',
            height : 150,
            border : false,
            bodyBorder : false,
            defaults : {
                xtype : 'fieldset',
                height : '100%',
                flex  : 1, 
                padding : 10,
                autoScroll : true,
            },
            items:[
                {
                    region:'east',
                    split : true,
                    width : '100%',
                    id : this.id+'-org-sql',
                    title: '쿼리'
                }
            ]
        };
    },

    /**
     * makeDetailListColumns
     *
     * 상세정보 그리드 컬럼 정의
     *
     * @access public
     *
     * @return json object
     */
    makeListColumns : function(){   

        return [
            { text: '클래스명', dataIndex: 'class_string', width : 300},
            { text: '쿼리', dataIndex: 'orig_sqltext' , flex: 1 },
            { text: '승인', dataIndex: 'approval_yn', width : 100 },
            { text: '승인유저', dataIndex: 'approval_user_name', width : 100 },
            { text: '승인시간', dataIndex: 'approval_time', width : 100 },
        ];
    },

    importSQL : function(){

        this.getApplication().openWindow('manage.WhiteSQL-Import');
    },

    exportSQL : function(){
        
        var params = Ext.getCmp('form-'+this.id).getValues();

        params.serverId = this.getApplication().serverId;
        location.href = "/manage/white_sql/export?"+Ext.urlEncode(params);
    },

   delSQL : function(){

        var grid = Ext.getCmp('grid-'+this.id);

        var sel = grid.getSelectionModel().getSelection();

        var ids = [];
        Ext.each(sel, function(record) {

            ids.push(record.raw.whitesql_id);
        });

        if(ids.length < 1){

            Ext.Msg.alert('Status', '삭제하실 Convert SQL을 선택하세요');
            return;
        }
        else {

            ids = ids.join(",");
        }
        // Send the id

        Ext.MessageBox.confirm('Confirm', '정말 삭제하시겠습니까?', Ext.Function.bind(function(confirm){

            if(confirm == 'yes'){
   
                Ext.Ajax.request({
                    url: '/manage/white_sql/del',
                    type : 'json',
                    params : {
                        ids : ids
                    },
                    scope : this,
                    success: function(res){
                        
                        var result = Ext.JSON.decode(res.responseText);

                        Ext.Msg.alert('Status', result.message);

                        this.search();
                    },
                    failure: function(result, request){

                        Ext.Msg.alert("Failed", result.responseText);
                    }
                });
            }   
        }, this));
    }
});