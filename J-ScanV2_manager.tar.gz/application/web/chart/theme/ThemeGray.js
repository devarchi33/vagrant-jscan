Ext.define('Ext.chart.theme.ThemeGray', {
    extend : 'Ext.chart.theme.Base',
    baseColor: '#bce',
    fontColor : '#6F6F6F',
    font : '10px consolas',
    lineColor : '#c0c0c0',
    colors: ['#EEEEEE', '#E06363', '#98D5FF', '#D9B50F', '#305382', '#FFDDA6', '#C8EE9D', '#9197B5'],
    constructor: function(config) {

        this.callParent([Ext.apply(config, {
            axis: {
                fill: this.fontColor,
                stroke : this.lineColor,
                'stroke-width': 1
            },
            axisLabelTop: {
                fill: this.fontColor,
                font: this.font
            },
            axisLabelLeft: {
                fill: this.fontColor,
                font: this.font
            },
            axisLabelRight: {
                fill: this.fontColor,
                font: this.font
            },
            axisLabelBottom: {
                fill: this.fontColor,
                font: this.font
            },
            axisTitleTop: {
                fill: this.fontColor,
                font: this.font
            },
            axisTitleLeft: {
                fill: this.fontColor,
                font: '18px arial'
            },
            axisTitleRight: {
                fill: this.fontColor,
                font: this.font
            },
            axisTitleBottom: {
                fill: this.fontColor,
                font: this.font
            },
            series: {
                'stroke-width': 1
            },
            seriesLabel: {
                font: this.font,
                fill: '#333'
            },
            stroke : this.lineColor,
            marker: {
                stroke: '#555',
                fill: '#000',
                radius: 3,
                size: 3
            },
            seriesThemes: [{
                    fill: '#C6DBEF',
                    stroke: '#cccccc',
                    padding : 10
                }, {
                    fill: '#9ECAE1'
                }, {
                    fill: '#6BAED6'
                }, {
                    fill: '#4292C6'
                }, {
                    fill: '#2171B5'
                }, {                            
                    fill: '#084594'
            }],
            markerThemes: [{
                fill: '#084594',
                type: 'circle' 
            }, {
                fill: '#2171B5',
                type: 'cross'
            }, {
                fill: '#4292C6',
                type: 'plus'
            }],
            colors : this.colors                   
        })]);
    }
});
