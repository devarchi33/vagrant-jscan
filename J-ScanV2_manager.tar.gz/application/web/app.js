Ext.namespace('Ext.WhiteSQL');
//set up config path for your app

Ext.Loader.setConfig({
    enabled: true,
    paths: {
        'CodeMirror' : '/js/codemirror',
        'Lib'        : '/web/lib',
        'Overrides'        : '/web/overrides',
        'Constants'  : '/config/constants',
        'Helper'     : '/web/helper'
    }
});

Ext.application({
    appFolder: '/web',
    name: 'WhiteSQL',
    serverId : 'root',
    syncPolicies : true,
    launch: function() {

        //stop backspace
        Ext.EventManager.addListener(Ext.getBody(), 'keydown', function(e){

            if(e.getTarget().type != 'text' && e.getKey() == '8' ){

                e.preventDefault();
            }
        });

        var me = this;
        window.onbeforeunload = function(){

            if(!me.syncPolicies){

                var message = '동기화하지 않은 정책이 존재합니다.';
            }
            else{

                var message = 'J-Scan이 종료됩니다.';
            }

            return message;
        }

        Ext.syncRequire('Overrides.FixMenuBug');
        Ext.syncRequire('Helper.Common');
        Ext.syncRequire('Lib.Override');
        Ext.syncRequire('Lib.Event');
        Ext.syncRequire('Lib.Grid');
        Ext.syncRequire('Lib.Excel');

        Ext.Ajax.request({
            url: '/main/login/check',
            type : 'json',
            scope : this,
            success: function(res){
                
                if(Ext.JSON.decode(res.responseText).result != "success"){

                    Ext.require('Lib.Fix-QuickTip');
                    this.initController('main.Login');
                }
                else {

                    this.initController('main.Layout');
                }
            },
            failure: function(result, request){

                this.initController('main.Login');
            }
        });
    },

    initController : function(id){

        //컨트롤러 로드
        var ctrl = this.controllers.get(id);

        if(ctrl) {

            ctrl.init();
            return ctrl;
        }
        else {

            return this.getController(id);
        }
    },

    /**
     * getServerName
     *
     * server-tree에서 선택된 값을 가져온다.
     *
     * @access public
     *
     * @return string server_name
     */
    getServerName : function(){

        try{


            layout = this.getController("main.Layout");

            return layout.ServerTree.getSelectionModel().getSelection()[0].raw.text;
        }
        catch(e){

            return 'All Servers';
        }
    },

    openWindow : function(id){

        var ctrl = this.getController(id);

        arguments = Ext.toArray(arguments);

        arguments.shift();

        ctrl.initWindow.apply(ctrl, arguments);
    },

    modGroup : function(node){

        var data = node.raw;

        Ext.MessageBox.prompt('Rename Group', '그룹명', function(confirm, text){

            if(confirm == 'ok'){

                Ext.Ajax.request({
                    url: '/manage/server/modGroup',
                    type : 'json',
                    params : {
                        server : data.id,
                        text : text
                    },
                    scope : this,
                    success: function(res){
                        
                        var result = Ext.JSON.decode(res.responseText);

                        Ext.Msg.alert('Status', result.message, function(){

                            if(result.result == 'fail') {
                                
                                this.modGroup(node);
                            }

                        }, this);

                        if(result.result == 'fail') return;

                        this.refreshServerTree(node);
                    },
                    failure: function(result, request){

                        Ext.Msg.alert("Failed", result.responseText);
                    }
                });
            }

        }, this, false, data.text || data.name);
    },

    refreshServerTree : function(node){

        var tree = node.getOwnerTree(),
            rootNode = tree.getRootNode(),
            store = tree.getStore(),
            parentId = node.data.parentId,
            parentNode = store.getNodeById(parentId);

        store.reload({node : parentNode});

        if(node.getOwnerTree().id != 'server-tree'){

            var tree = Ext.getCmp('server-tree');
            rootNode = tree.getRootNode(),
            store = tree.getStore(),
            parentId = node.data.parentId,
            parentNode = store.getNodeById(parentId);
            
            store.reload({node : parentNode});

            tree.getView().refresh();
        }
    },

    delGroup : function(node){

        var data = node.raw;

        Ext.MessageBox.confirm('Confirm', '정말 삭제하시겠습니까?', function(confirm){

            if(confirm == 'yes'){

                Ext.Ajax.request({
                    url: '/manage/server/delGroup',
                    type : 'json',
                    params : {
                        server : data.id
                    },
                    scope : this,
                    success: function(res){
                        
                        var res = Ext.JSON.decode(res.responseText);

                        Ext.Msg.alert('Status', res.message);

                        if(res.result == 'fail') return;

                        this.refreshServerTree(node);
                    },
                    failure: function(res, request){

                        Ext.Msg.alert("Failed", res.responseText);
                    }
                });
            }
        }, this);
    },

    delServer : function(node){

        var data = node.raw;

        Ext.MessageBox.confirm('Confirm', '정말 삭제하시겠습니까?', function(confirm){

            if(confirm == 'yes'){

                Ext.Ajax.request({
                    url: '/manage/server/delServer',
                    type : 'json',
                    params : {
                        server : data.id
                    },
                    scope : this,
                    success: function(res){
                        
                        var result = Ext.JSON.decode(res.responseText);

                        Ext.Msg.alert('Status', result.message);
        
                        node.remove(true);
                    },
                    failure: function(result, request){

                        Ext.Msg.alert("Failed", result.responseText);
                    }
                });
            }
        }, this);
    },

    addGroup : function(){

        Ext.MessageBox.prompt('Add Group', '그룹명', function(confirm, text){
                    
            if(confirm == 'ok'){

                Ext.Ajax.request({
                    url: '/manage/server/addGroup',
                    type : 'json',
                    params : {
                        text : text
                    },
                    scope : this,
                    success: function(res){
                        
                        var result = Ext.JSON.decode(res.responseText);

                        Ext.Msg.alert('Status', result.message, function(){

                            if(result.result == 'fail') {
                                
                                this.addGroup();
                            }

                        }, this);

                        if(result.result == 'fail') return;

                        var tree = Ext.getCmp('server-tree');

                        tree.getRootNode().appendChild({
                            icon : "/images/host_group_en.png",
                            id : result.group_id,
                            expanded : true,
                            text : text
                        });
                    },
                    failure: function(res, request){

                        Ext.Msg.alert("Failed", res.responseText);
                    }
                });
            }
        }, this);
    },

    syncPolicy : function(cmd){

        if(typeof cmd == 'undefined'){

            cmd = 'Policies';
        }

        var tree = Ext.getCmp('server-tree');
        
        var node = tree.getSelectionModel().getSelection()[0];
        
        var data = node.raw;
        
        var msg  = Ext.Msg.wait('처리중 입니다.');

        Ext.Ajax.timeout = 300000;

        Ext.Ajax.request({
            url: '/manage/server/syncPolicy',
            type : 'json',
            params : {
                server : data.id,
                cmd : cmd
            },
            scope : this,
            success: function(res){
                
                msg.hide();

                var result = Ext.JSON.decode(res.responseText);

                Ext.Msg.alert('Status', result.message);

                this.syncPolicies = true;

                this.fireEvent('policy-sync-complete');
            },
            failure: function(result, request, a,b,c,d,e){

                msg.hide();

                if(result.timedout == true){

                    Ext.Msg.alert("Failed", "요청한 시간이 지나 작업이 중단되었습니다.");
                }
                else {

                    Ext.Msg.alert("Failed", result.responseText);   
                }
            }
        });
    }
});