<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * getPercentile
 *
 * 95% 신뢰구간의 범위를 구하여 배열로 리턴한다.
 * 
 * @access  public
 * @param   array $data 표본 데이터 배열
 * @return  array array('-percentile', '+percentile')
 * 
 * 
 */
function getPercentile($data){

    $deviation = getStandardDevition($data);
    $cnt = count($data);
    $sum = array_sum($data);

    $avg = $sum / $cnt;

    return array(
        ($avg - 1.96 * $deviation / sqrt($cnt)),
        ($avg + 1.96 * $deviation / sqrt($cnt))
    );
}

/**
 * removeOutliers
 *
 * 이상치 제거
 * 
 * @access  public
 * @param   array $data 표본 데이터 배열
 * @param   array $magnitude 크기(?) 아직 정당한 쓰임을 파악하지 못함 
 * @return  array 이상치를 제거한 데이터 배열
 * 
 * 
 */
function removeOutliers($data, $magnitude = 1) {

    $count = count($data);
    $mean = array_sum($data) / $count; // Calculate the mean
    $deviation = getStandardDevition($data);

    return array_filter($data, function($x) use ($mean, $deviation) { return ($x <= $mean + $deviation && $x >= $mean - $deviation); }); // Return filtered array of values that lie within $mean +- $deviation.
}

/**
 * getStandardDevitionSquare
 *
 * standard deviation square(표준 편차 제곱)
 * 
 * @access  public
 * @param   array $data 표본 데이터 배열
 * @param   array 크기
 * @return  array 이상치를 제거한 데이터 배열
 * 
 * 
 */
function getStandardDevitionSquare($x, $mean) {

    return pow($x - $mean, 2);
} 

/**
 * getStandardDevition
 *
 * standard deviation square(표준 편차 제곱)
 * 
 * @access  public
 * @param   array $data 표본 데이터 배열
 * @param   array 크기
 * @return  array 이상치를 제거한 데이터 배열
 * 
 * 
 */
function getStandardDevition($data, $magnitude = 1){

    $count = count($data);
    $mean = array_sum($data) / $count; // Calculate the mean
    $deviation = sqrt(array_sum(array_map("getStandardDevitionSquare", $data, array_fill(0, $count, $mean))) / $count) * $magnitude; // 크기에 의해 표준 편차와 시간을 계산

    return $deviation;
}
