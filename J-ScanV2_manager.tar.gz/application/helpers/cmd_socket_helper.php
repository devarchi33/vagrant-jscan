<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// ------------------------------------------------------------------------

/**
 * WhiteSQL 소캣 명령 핼퍼
 *
 * @package		WhiteSQL
 * @subpackage	Helpers
 * @category	Helpers
 * @author		정주원 <jjwcom@nate.com>
 */

// ------------------------------------------------------------------------

/**
 * cmdSocket
 *
 * 연결된 소켓으로 데몬에 정의된 명령을 내린다.
 * 
 * 참조 문서 \\192.168.0.10\rnd\1. 개발문서\jKeeper\jkeeper_객체포트정리.xlsx
 * 
 * CMD_DATA_BACKUP       : 구현전(추후 데몬에도 구현이 되야하는 상태)
 * CMD_DATA_RESTORE      : 구현전(추후 데몬에도 구현이 되야하는 상태)
 * CMD_POL_APPLY         : 정책 적용
 * CMD_WHITESQLPOL_APPLY : White SQL 정책 적용
 * CMD_WHITESQLPOL_INIT  : White SQL 정책 초기화
 * CMD_SQLCHANGEPOL_APPLY: White SQL 변경 정책 적용
 * CMD_AGENT_MODE        : Agent host 모니터링 모드 설정
 * 
 * 	(type):(mode_value):(group_id/agent_id):(log_flag)
 * 	A:1:0:0 or G:1:1:0 or H:2:1:0
 *	type(A:all, G:group, H:host)
 *	mode(0: bypass, 1: monitoring, 2: block)
 *	eGlobal mode(0:bypass, 1:collect, 2:monitoring)
 *  log_flag(Working일때 0:no logging, 1:logging)
 * 
 * CMD_AGENT_ADD         : Agent host 추가
 * CMD_AGENT_MOD         : Agent host 수정
 * CMD_AGENT_DEL         : Agent host 삭제
 * CMD_REG_UNIQSQL       : Unique SQL 등록
 * 
 * @access	public
 * @param	integer $nCmdType 데몬에 내릴 명령 flag
 * @param	string $sParams 데몬에 넘기는 parameter
 * @return	array 결과 배열
 * 
 * 
 */
if ( ! function_exists('cmdSocket'))
{
	function cmdSocket($nCmdType, $sParams=""){

        $CI =& get_instance();

        $CI->load->config('daemon', true);

        $nPort = $CI->config->item('system_manager_log_port', 'daemon');

        $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        $connect = socket_connect($socket, SOCKET_SERVER_IP, $nPort);

        if($connect){

    		$sData = "";
    		$sData .= pack('C', 1);  // version : fixed
    		$sData .= pack('C', $nCmdType);  // type : variable
    		$sData .= pack('v', strlen($sParams));  // real data length. ex) "abcde" = 5 : variable
    		$sData .= "IRUN";        // distingish code : fixed
    		$sData .= $sParams;      // real data : variable
            
    		@socket_write($socket, $sData);
    		
    		$sBuffer = @socket_read($socket, 12000);
            
            if(!$sBuffer){

                @socket_close($socket);

                $sMsg = '매니저 데몬에 동기화 되었으나 정상적으로 결과 메시지를 받지 못했습니다. - MSaver';
                debug(1, null, $sMsg);

                return array(
                    'result' => false,
                    'message' => $sMsg
                );
            }

            @socket_close($socket);

            $aResult = json_decode($sBuffer, true);
            debug(1, null, $aResult['msg']);

            return array(
                'result' => $aResult['result'] == false ? true : false,
                'message' => $aResult['msg']
            );
        }

		@socket_close($socket);

        $sMsg = '매니저 데몬에 연결 할 수 없습니다.';
        debug(1, null, $sMsg);

		return array(
            'result' => false,
            'message' => $sMsg
        );
	}
}

/**
 * syncPolicy
 *
 * 정책 데몬과 동기화한다.
 * 
 * @access  public
 * @param   string $sAgentIp 동기화할 Agent Ip
 * @return  array 결과 배열
 * 
 * 
 */
if ( ! function_exists('syncPolicy'))
{
    function syncPolicy($aAgent){
        
        $CI =& get_instance();
        $CI->load->database();

        $sSql = '
            SELECT * FROM tbl_policy_list WHERE agent_id = '.$aAgent['agent_id'].' AND 
            policy_type = '.POLICY_SQL_CONVERT.'
        ';
        $query = $CI->db->query($sSql);

        $aPolicyData = $query->result_array();

        $sXML = makePolicyXML($aAgent, $aPolicyData);

        $aResult = sendXMLToHost($aAgent['ipaddr'], $aAgent['port'], $sXML);

        if($aResult){

            // trans_result value
            // LICENCE_PASS. 정상 수신 및 라이센스 정상
            // COMPANY_FAIL : 회사 코드 오류
            // PRODUCT_FAIL : 제품 코드 오류
            // SYSTEM_FAIL. MAC Address 불일치
            if(@$aResult['trans_result'] == "LICENSE_PASS"){

                //정상                    
                saveLicenseCheck(
                    $aAgent['agent_id'], 
                    LICENSE_STATUS_NORMAL, 
                    $aResult['expiration_date']
                );

                return array(
                    'result' => true,
                    'message' => '동기화가 완료되었습니다.'
                );
            }
            else {

                //오류
                saveLicenseCheck(
                    $aAgent['agent_id'], 
                    LICENSE_STATUS_ERROR,
                    $aResult['expiration_date']
                );
                return array(
                    'result' => false,
                    'message' => '라이센스 상태 오류'
                );
            }
        }
            
        return array(
            'result' => false,
            'message' => '동기화 요청 하였으나 정상적인 응답을 받지 못하였습니다.'
        );
    }
}

/**
 * saveLicenseCheck
 *
 * 라이센스 저장
 * 
 * @access  public
 * @param   string $sAgentIp 동기화할 Agent Ip
 * @return  array 결과 배열
 * 
 * 
 */
if ( ! function_exists('saveLicenseCheck'))
{
    //라이선스 체크여부(1:데모라이센스, 2:정식라이센스)
    function saveLicenseCheck($nAgentId, $nStatus, $sExpireDate){

        $CI =& get_instance();
        $CI->load->database();

        if(!$sExpireDate) $sExpireDate = date("Y-m-d");

        $sSql = '
            UPDATE tbl_agent_info SET 
                license_status = "'.$nStatus.'",
                license_expiredate = "'.$sExpireDate.'",
                last_work_time = '.time().'
            WHERE agent_id = '.$nAgentId.'
        ';
        $CI->db->query($sSql);
    }
}


/**
 * sendXMLToHost
 *
 * 연결된 소켓으로 XML 문자열을 전송한다.
 * 
 * @access  public
 * @param   string $sHost 접속할 호스트
 * @param   integer $nPort 접속할 호스트의 포트 
 * @param   string $sXML 전송할 XML
 * @return  array 결과 배열
 * 
 * 
 */
if ( ! function_exists('sendXMLToHost'))
{
	function sendXMLToHost($sHost, $nPort, $sXML){
		
        $fp = @stream_socket_client("tcp://".$sHost.":".$nPort, $errno, $errstr);

        if (!$fp) {

            return array(
                'result' => false,
                'message' => '에이전트 데몬에 연결 할 수 없습니다.'
            );

        } else {

            $sXML .= pack('c', 0x03); //전송 종료 문자
            //$sXML = 'A';
            $nLen = strlen($sXML);
            
            //debug(1, null, "XML string length ".$nLen);

            fwrite($fp, $sXML, $nLen);
            fflush($fp);
            //debug(1, null, "sendXMLToHost start");

            $sResult = fread($fp, 4096);

            //debug(1, null, "sendXMLToHost result : ". $sResult);
            //debug(1, null, "sendXMLToHost end");

            fclose($fp);

            return json_decode($sResult, true);
        }
	}
}

/**
 * makePolicyXML
 *
 * 에이전트 정보와 정책정보를 참조하여 XML문자열을 만든다.
 * 
 * @access  public
 * @param   array $aAgent 에이전트정
 * @param   array $aPolicyData 정책정보
 * @return  string 결과 XML
 * 
 * 
 */
if ( ! function_exists('makePolicyXML'))
{
    function makePolicyXML($aAgent, $aPolicyData){

        $CI =& get_instance();
        $CI->load->database();

        $xml = new XmlWriter();
        $xml->openMemory();
        $xml->startDocument('1.0', 'UTF-8');
        $xml->startElement('root');
        $xml->startElement('agent_info');
        $xml->writeAttribute('type', 'all'); 

        //동작모드(0=bypass, 1=collect, 2=monitoring)
        $xml->startElement('mod');
        $xml->text($aAgent['agent_mode']);
        $xml->endElement();

        $xml->startElement('agent_id');
        $xml->text($aAgent['agent_id']);
        $xml->endElement();

        $xml->startElement('result_logging');
        $xml->text($aAgent['rs_logging_yn']);
        $xml->endElement();

        $xml->startElement('auth_check');
        $xml->text($aAgent['privacy_flag']);
        $xml->endElement();

        $xml->startElement('license_type');
        $xml->text($aAgent['license_check']);
        $xml->endElement();

        $xml->startElement('license_value');
        $xml->text($aAgent['license_key']);
        $xml->endElement();

        $xml->startElement('logging_mod');
        $xml->text("0");
        $xml->endElement();

        // end the document and output
        $xml->endElement();

        if($aPolicyData){

            $xml->startElement('policy_list');
            foreach($aPolicyData as $nIdx => $aRow){

                //debug(4, get_class($this), print_r($aRow, true));            

                $aProperties = json_decode($aRow['policy_properties'], true);

                $xml->startElement('policy');

                if($aRow['policy_type'] == POLICY_SQL){

                    $xml->writeAttribute('type', 'sql'); 
                }
                else if($aRow['policy_type'] == POLICY_SQL_CONVERT){

                    $xml->writeAttribute('type', 'sql_change'); 
                }

                $xml->startElement('id');
                $xml->text($aRow['policy_id']);
                $xml->endElement();
                $xml->startElement('onoff');
                $xml->text($aRow['on_off']);
                $xml->endElement();

                $sSql = 'SELECT * FROM tbl_uniqsql WHERE uniqsql_id = '.$aProperties['uniqsql_id'];
                $query = $CI->db->query($sSql);
                $aUniqSQL = array_pop($query->result_array());

                $xml->startElement('uniq_sql');
                $xml->writeCData(@$aUniqSQL['uniq_sqltext']);
                $xml->endElement();
                
                if($aRow['policy_type'] == POLICY_SQL_CONVERT){

                    $xml->startElement('change_sql');
                    $xml->writeCData($aProperties['convert']);
                    $xml->endElement();
                }

                $xml->endElement();
            }

            $xml->endElement();
        }
        $xml->endElement();
        
        $sXML = $xml->outputMemory(true);
        return $sXML;
    }
}
