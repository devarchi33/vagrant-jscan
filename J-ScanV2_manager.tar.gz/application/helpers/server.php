<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// ------------------------------------------------------------------------

/**
 * WhiteSQL 소캣 명령 핼퍼
 *
 * @package		WhiteSQL
 * @subpackage	Helpers
 * @category	Helpers
 * @author		정주원 <jjwcom@nate.com>
 */

// ------------------------------------------------------------------------

/**
 * cmd_socket
 *
 * 연결된 소켓으로 데몬에 정의된 명령을 내린다.
 * 
 * 참조 문서 \\192.168.0.10\rnd\1. 개발문서\jKeeper\jkeeper_객체포트정리.xlsx
 * 
 * CMD_DATA_BACKUP       : 구현전(추후 데몬에도 구현이 되야하는 상태)
 * CMD_DATA_RESTORE      : 구현전(추후 데몬에도 구현이 되야하는 상태)
 * CMD_POL_APPLY         : 정책 적용
 * CMD_WHITESQLPOL_APPLY : White SQL 정책 적용
 * CMD_WHITESQLPOL_INIT  : White SQL 정책 초기화
 * CMD_SQLCHANGEPOL_APPLY: White SQL 변경 정책 적용
 * CMD_AGENT_MODE        : Agent host 모니터링 모드 설정
 * 
 * 	(type):(mode_value):(group_id/agent_id):(log_flag)
 * 	A:1:0:0 or G:1:1:0 or H:2:1:0
 *	type(A:all, G:group, H:host)
 *	mode(0: bypass, 1: monitoring, 2: block)
 *	eGlobal mode(0:bypass, 1:collect, 2:monitoring)
 *  log_flag(Working일때 0:no logging, 1:logging)
 * 
 * CMD_AGENT_ADD         : Agent host 추가
 * CMD_AGENT_MOD         : Agent host 수정
 * CMD_AGENT_DEL         : Agent host 삭제
 * CMD_REG_UNIQSQL       : Unique SQL 등록
 * 
 * @access	public
 * @param	integer $nCmdType 데몬에 내릴 명령 flag
 * @param	string $sParams 데몬에 넘기는 parameter
 * @return	string $sBuffer 평소에는 빈값이지만 CMD_REG_UNIQSQL의 경우는 결과값을 리턴 받는다.
 * 
 * 
 */
if ( ! function_exists('cmd_socket'))
{
	function cmd_socket($nCmdType, $sParams=""){
		
		$rSocket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		
		socket_connect($rSocket, SOCKET_SERVER_IP, SOCKET_PORT_MANAGE);
		
		$sData = "";
		$sData .= pack('C', 1);  // version : fixed
		$sData .= pack('C', $nCmdType);  // type : variable
		$sData .= pack('v', strlen($sParams));  // real data length. ex) "abcde" = 5 : variable
		$sData .= "IRUN";        // distingish code : fixed
		$sData .= $sParams;      // real data : variable

		socket_write($rSocket, $sData);
		
		$sBuffer = "";
		if($nCmdType == CMD_REG_UNIQSQL) $sBuffer = socket_read($rSocket, 12000);

		socket_close($rSocket);
		return $sBuffer;
	}
}