<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * generateAuthCookie
 *
 * 쿠키를 만든다.
 * 
 * @access  public
 * @param   string $sType 데몬에 넘기는 day, week, month parameter
 * @return  array array('start_date', 'end_date')
 * 
 * 
 */
if ( ! function_exists('generateAuthCookie'))
{
    function generateAuthCookie($sLoginId, $sPassword){

        $nExpr = time() + 10 * DAY_IN_SECONDS;

        $sKey = substr($sPassword, 8, 4);

        $sHash = md5($sLoginId."|".$nExpr."|".$sKey);

        return $sCookie = base64_encode($sLoginId."|".$nExpr."|".$sHash);
    }

    function checkValidCookie(){

        $CI =& get_instance();

        $CI->load->helper('cookie');        

        $sCookie = get_cookie('whitesql_'.COOKIEHASH);

        if(!$sCookie){

            $result = "fail";
            $message = "쿠키 시간 만료";

            return compact('result', 'message');
        }

        $aCookie = parseCookie($sCookie);

        extract($aCookie);

        if($nExpr < time()){

            $result = "fail";
            $message = "쿠키 시간 만료";

            return compact('result', 'message');
        }

        $aUser = getUserInfo($sLoginId);

        if((time() - strtotime($aUser['user_lastdate'])) > 60){

            $result = "fail";
            $message = "쿠키 만료";

            return compact('result', 'message');
        }

        $sKey = substr($aUser['user_pass'], 8, 4);

        $sHash = md5($sLoginId."|".$nExpr."|".$sKey);

        if($sSaveHash != $sHash){

            $result = "fail";
            $message = "잘못된 정보";

            return compact('result', 'message');
        }

        $result = "success";
        $message = "";

        return compact('result', 'message');
    }

    function parseCookie($sCookie){

        list($sLoginId, $nExpr, $sSaveHash) = explode("|", base64_decode($sCookie));

        return compact('sLoginId', 'nExpr', 'sSaveHash');
    }

}

function getUserInfo($sLoginId = null){

    $CI =& get_instance();

    $CI->load->helper('cookie');   

    //모델을 로드한다.
    $CI->load->model('tbl_userinfo');

    if(is_null($sLoginId) === true){

        $sCookie = get_cookie('whitesql_'.COOKIEHASH);
        
        $aCookie = parseCookie($sCookie);

        extract($aCookie);
    }

    //해당 유저 정보가 있는지 확인한다.
    $CI->tbl_userinfo->setLoginId($sLoginId);
    
    return array_pop($CI->tbl_userinfo->get());
}

function updateLastLogin($nUserId = null){

    $CI =& get_instance(); 
    
    //모델을 로드한다.
    $CI->load->model('tbl_userinfo');

    //해당 유저 정보가 있는지 확인한다.
    $CI->tbl_userinfo->updateLastLogin($nUserId);
}

function getAllowServer($nGroupId = null){

    $aUser = getUserInfo();

    if($aUser['user_level'] < 10 && !$aUser['servers']){

        return array();
    }

    $CI =& get_instance();

    $CI->load->model('tbl_agent_info');
    $CI->tbl_agent_info->db->where('del_yn', '0');
    $CI->tbl_agent_info->joinAgentGroupInfo();

    if($nGroupId !== null){

        $CI->tbl_agent_info->setGroupId($nGroupId);
    }

    $aAllowServers = null;

    if($aUser['servers']){

        $aAllowServers = json_decode($aUser['servers'], true);
    }

    return $CI->tbl_agent_info->get($aAllowServers);
}

function getAllowGroup(){

    $aUser = getUserInfo();

    if($aUser['user_level'] < 10 && !$aUser['servers']){

        return array();
    }

    $CI =& get_instance();

    $CI->load->model('tbl_agentgroup_info');

    $CI->tbl_agentgroup_info->select(array('group_id', 'group_name'));
    return $CI->tbl_agentgroup_info->get();
}