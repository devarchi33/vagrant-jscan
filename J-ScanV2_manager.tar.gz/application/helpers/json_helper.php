<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * json_encode
 *
 * JSON 인코딩
 * 
 * @access  public
 * @param   string $string 인코딩 문자열
 * @return  array 
 * 
 * 
 */
if ( !function_exists('json_encode') ) {
    function json_encode( $array ) {

        global $g4;

        if ( !is_a($g4['load_json'], 'Services_JSON') ) {
            require_once( $g4['path'] . '/lib/class-json.php' );
            $g4['load_json'] = new Services_JSON();
        }

        return $g4['load_json']->encodeUnsafe( $array );
    }
}

/**
 * json_decode
 *
 * JSON 인코딩
 * 
 * @access  public
 * @param   string $string 인코딩 문자열
 * @return  array 
 * 
 * 
 */
if ( !function_exists('json_decode') ) {
    function json_decode( $string, $assoc_array = false ) {

        global $g4;

        if ( !is_a($g4['load_json'], 'Services_JSON') ) {
            require_once( $g4['path'] . '/lib/class-json.php' );
            $g4['load_json'] = new Services_JSON();
        }

        $res = $g4['load_json']->decode( $string );
        if ( $assoc_array )
            $res = _json_decode_object_helper( $res );
        return $res;
    }
    function _json_decode_object_helper($data) {
        if ( is_object($data) )
            $data = get_object_vars($data);
        return is_array($data) ? array_map(__FUNCTION__, $data) : $data;
    }
}
