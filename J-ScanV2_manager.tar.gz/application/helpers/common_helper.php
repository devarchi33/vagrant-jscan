<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// ------------------------------------------------------------------------
if ( ! function_exists('getServerList'))
{
	function getServerList($sServer){
		
        $CI =& get_instance();

		$aList = array();
        if($sServer == 'root'){
            
            return $aList;
        }
        else if(strpos($sServer, 'group') > -1){

            $CI->load->model('tbl_agent_info');

            $aList = $CI->tbl_agent_info->select(
                'GROUP_CONCAT(agent_id) as agent_list'
            )->setGroupId(str_replace("group-", "", $sServer))->get();
            
            if($aList) $aList = array_pop($aList);

            if(!$aList['agent_list']) return null;

            if($aList) $aList = explode(',', $aList['agent_list']);              
        }
        else if(strpos($sServer, 'server') > -1){
            
            array_push($aList, (int)str_replace("server-", "", $sServer));
        }

        if(!$aList) array_push($aList, 0);

        return $aList;
	}
}

/**
 * getDatePeriod
 *
 * day, week, month에 따라 기간을 가지고 온다.
 * 
 * @access  public
 * @param   string $sType 데몬에 넘기는 day, week, month parameter
 * @return  array array('start_date', 'end_date')
 * 
 * 
 */
if ( ! function_exists('getDatePeriod'))
{
    function getDatePeriod($sType, $sFlag = "+0 day"){

        $nTime = strtotime($sFlag);

        if($sType == 'now'){

            $nTime = time();
            $nStartDate = date("Y-m-d 00:00:00", $nTime);
            $nEndDate   = date("Y-m-d H:i:s", $nTime);
        }
        elseif($sType == 'day'){

            $nStartDate = date("Y-m-d 00:00:00", $nTime);
            $nEndDate   = date("Y-m-d 23:59:59", $nTime);
        }
        elseif($sType == 'week'){
            
            $nStartDate = date("Y-m-d 00:00:00", strtotime('-1 week', $nTime));
            $nEndDate   = date("Y-m-d 23:59:59", $nTime);
        }
        elseif($sType == 'month'){

            $nStartDate = date("Y-m-d 00:00:00", strtotime('-1 month', $nTime));
            $nEndDate   = date("Y-m-d 23:59:59", $nTime);
        }

        return array(
            'start_date' => $nStartDate,
            'end_date'   => $nEndDate
        );
    }
}

/**
 * getDateList
 *
 * sdate부터 edate까지의 날짜 목록을 배열로 리턴한다.
 * 
 * @access  public
 * @param   string $sType 데몬에 넘기는 day, week, month parameter
 * @return  array date list
 * 
 * 
 */
if ( ! function_exists('getDateList'))
{
    function getDateList($sSDate, $sEDate){

        $nSDate = strtotime($sSDate);
        $nEDate = strtotime($sEDate);

        $aDate = array();
        for($nDate = $nSDate; $nDate <= $nEDate ; $nDate = strtotime("+1 day", $nDate)){

            array_push($aDate, date("Y-m-d", $nDate));
        }

        return $aDate;
    }
}

if ( ! function_exists('writePolicyHistory'))
{
    function writePolicyHistory($nPolicyType, $nWorkType, $nPolicyId, $nAgentId, $sWorkMessage, $sWorkBefore = null, $sWorkAfter = null){

        $CI =& get_instance();

        $CI->load->model('tbl_policy_history');

        $CI->tbl_policy_history->add(array(
            'policy_type'  => (string)$nPolicyType,
            'policy_id'    => $nPolicyId,
            'agent_id'     => $nAgentId,
            'work_type'    => $nWorkType,
            'work_message' => $sWorkMessage,
            'work_before'  => $sWorkBefore,
            'work_after'   => $sWorkAfter
        ));
    }
}

if ( ! function_exists('writeWorkHistory'))
{
    function writeWorkHistory($sWorkType, $nAgentId, $sWorkMessage, $sWorkBefore = null, $sWorkAfter = null, $sWorkTarget = null){

        $CI =& get_instance();

        $CI->load->model('tbl_work_history');
        
        $CI->tbl_work_history->add(array(
            'agent_id'     => $nAgentId,
            'work_type'    => $sWorkType,
            'work_message' => $sWorkMessage,
            'work_before'  => $sWorkBefore,
            'work_after'   => $sWorkAfter,
            'work_target' => $sWorkTarget
        ));
    }
}

if ( ! function_exists('getPolicyType'))
{
    function getPolicyType($nType){

        $CI =& get_instance();
        $CI->load->config('system', true);
        $aType = $CI->config->item('policy_type', 'system');


        return @$aType[$nType] ? $aType[$nType] : '자동검사';
    }
}


if ( ! function_exists('getEventLevel'))
{
    function getEventLevel($nLevel){

        $CI =& get_instance();
        $CI->load->config('system', true);
        $aLevel = $CI->config->item('event_level', 'system');

        return @$aLevel[$nLevel] ? $aLevel[$nLevel] : '-';
    }
}

if ( ! function_exists('debug'))
{
    function debug($nLevel, $sSpace, $sMessage, $sFileName = null){

        // return;
        
        $bLogging = false;
        if(defined("DEBUG_SPACE") === true && defined("DEBUG_LEVEL") === true){

            if(DEBUG_SPACE == $sSpace && DEBUG_LEVEL == $nLevel){

                $bLogging = true;
            }
        }
        else if(defined("DEBUG_SPACE") === true && defined("DEBUG_LEVEL") === false){

            if(DEBUG_SPACE == $sSpace){

                $bLogging = true;
            }
        }
        else if(defined("DEBUG_LEVEL") === true && defined("DEBUG_SPACE") === false){

            if(DEBUG_LEVEL == $nLevel){

                $bLogging = true;
            }
        }
        else if(defined("DEBUG_LEVEL") === true && $sSpace == null){

            $bLogging = true;
        }

        if($bLogging === true){
            
            $sMessage = "[".date("Y-m-d H:i:s")."] ::".$sSpace.":: PID:".getmypid()." ".$sMessage." - [".date("Y-m-d H:i:s")." MEM : ".memory_get_usage()."B (".(memory_get_usage() / 1000)."KB)\n";

            if($sFileName){

                $sFileName = $sFileName.date(".Ymd");
                
                $fp = fopen(ROOTPATH."/log/daemon/".$sFileName, "a+");
                flock($fp, LOCK_EX);
                fwrite($fp, $sMessage);
                flock($fp, LOCK_UN);
                fclose($fp);
            }
            else {

                print $sMessage;
            }
        }

        unset($sFileName);
        unset($sMessage);
    }
}

if ( ! function_exists('startCheckTime'))
{
    function startCheckTime(){

        return microtime(true);
    }
}


if ( ! function_exists('endCheckTime'))
{
    function endCheckTime($time){

        return microtime(true) - $time;
    }
}