<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
|--------------------------------------------------------------------------
| 이벤트 레벨 배열
|--------------------------------------------------------------------------
|
| 레벨 배열은 고유의 인덱스를 가진다. 
|
| 심각(5), 위험(4), 경고(3), 주의(2), 알림(1)
*/

$config['skin'] = '';

/*
|--------------------------------------------------------------------------
| 이벤트 타입 배열
|--------------------------------------------------------------------------
|
| 레벨 배열은 고유의 인덱스를 가진다. 
|
| System(1), 정책(0)
*/
$config['event_type'][0] = "정책";
$config['event_type'][1] = "시스템";

/*
|--------------------------------------------------------------------------
| 이벤트 레벨 배열
|--------------------------------------------------------------------------
|
| 레벨 배열은 고유의 인덱스를 가진다. 
|
| 심각(5), 위험(4), 경고(3), 주의(2), 알림(1)
*/
$config['event_level'][EVENT_TYPE_NOTICE]		= "알림";
$config['event_level'][EVENT_TYPE_ATTENTION]	= "주의";
$config['event_level'][EVENT_TYPE_ALERT]		= "경고";
$config['event_level'][EVENT_TYPE_DANGER]		= "위험";
$config['event_level'][EVENT_TYPE_SERIOUS]		= "심각";

/*
|--------------------------------------------------------------------------
| 이벤트 레벨 컬럼 키
|--------------------------------------------------------------------------
|
| 디비의 컬럼키이다 
|
| 심각(serious), 위험(danger), 경고(alert), 주의(attention), 알림(notice)
*/
$config['event_level_key'][EVENT_TYPE_NOTICE]		= "notice";
$config['event_level_key'][EVENT_TYPE_ATTENTION]	= "attention";
$config['event_level_key'][EVENT_TYPE_ALERT]		= "alert";
$config['event_level_key'][EVENT_TYPE_DANGER]		= "danger";
$config['event_level_key'][EVENT_TYPE_SERIOUS]		= "serious";

/*
|--------------------------------------------------------------------------
| 이벤트 유형 배열
|--------------------------------------------------------------------------
|
| 유형 배열은 고유의 인덱스를 가진다. 
|
| None(0), New SQL(1), White SQL(2), Non-WhiteSQL(3), 주의SQL(4), SQL변경(5), 주의IP(6), 주의LogInID(7), 주요테이블(8), 주의SQL유형(9), 개인정보테이블(10), 의사사용자(11)
| 
*/
$config['event_kind'][EVENT_KIND_NONE]					= '기타';
$config['event_kind'][EVENT_KIND_NEWSQL]				= 'New SQL';
$config['event_kind'][EVENT_KIND_WHITE_SQL]				= 'White SQL';
$config['event_kind'][EVENT_KIND_NONE_WHITESQL]			= 'Non-WhiteSQL';
$config['event_kind'][EVENT_KIND_ATTENTION_SQL]			= '주의SQL';
$config['event_kind'][EVENT_KIND_SQL_CONVERT]			= 'SQL변경';
$config['event_kind'][EVENT_KIND_ATTENTION_IP]			= '주의IP';
$config['event_kind'][EVENT_KIND_ATTENTION_LOGIN_ID]	= '주의LogInID';
$config['event_kind'][EVENT_KIND_ATTENTION_TABLE]		= '주요테이블';
$config['event_kind'][EVENT_KIND_ATTENTION_SQL_TYPE]	= '주의SQL유형';
$config['event_kind'][EVENT_KIND_PERSONAL_INFO_TABLE]	= '개인정보테이블';
$config['event_kind'][EVENT_KIND_INTENTION_USER]		= '의사사용자';

/*
|--------------------------------------------------------------------------
| Policy Type(정책 타입) 배열
|--------------------------------------------------------------------------
|
| 정책 타입 설정 배열
*/
$config['policy_type'][POLICY_NONE_WHITE_SQL] 		= 'None White SQL';
$config['policy_type'][POLICY_SQL]					= 'SQL';
$config['policy_type'][POLICY_SQL_CONVERT]			= 'SQL 변경';
$config['policy_type'][POLICY_IP]					= 'IP';
$config['policy_type'][POLICY_LOGIN_ID]				= 'LOGIN ID';
$config['policy_type'][POLICY_TABLE]				= '주요 TABLE';
$config['policy_type'][POLICY_SQL_TYPE]				= 'SQL 유형';
$config['policy_type'][POLICY_PERSONAL_INFO_TABLE]	= '개인정보TABLE';

/*
|--------------------------------------------------------------------------
| Work Type(정책 타입) 타입 배열
|--------------------------------------------------------------------------
|
| 정책 타입 설정 배열
*/
$config['work_type']['add']  = 'Add';
$config['work_type']['mod']  = 'Mod';
$config['work_type']['del']  = 'Del';
$config['work_type']['sync'] = 'Sync';

/*
|--------------------------------------------------------------------------
| 모드 배열
|--------------------------------------------------------------------------
|
| server_mode 배열은 고유의 인덱스를 가진다. 
| 0 : bypass
| 1 : collect
| 2 : working
|
*/
$config['server_mode'][0] = "bypass";
$config['server_mode'][1] = "logging";
$config['server_mode'][2] = "monitoring";
$config['server_mode'][3] = "protect";

/*
|--------------------------------------------------------------------------
| 모드의 함축 표현 배열
|--------------------------------------------------------------------------
|
| 각 모드별로 트리에 표시할 용도로 함축 표현을 가진다.
|
*/
$config['mode_char'][0] = '[B]';
$config['mode_char'][1] = '[C]';
$config['mode_char'][2] = '[W]';

/*
|--------------------------------------------------------------------------
| 모드의 함축 표현 배열
|--------------------------------------------------------------------------
|
| 각 모드별로 트리에 표시할 용도로 함축 표현을 가진다.
|
*/
$config['user_level'][1] = '모니터링';
$config['user_level'][5] = '일반관리자';
$config['user_level'][10] = '슈퍼관리자';

/*
|--------------------------------------------------------------------------
| 라이센스 체크여부
|--------------------------------------------------------------------------
|
| 라이센스별 체크 여부 설정 배열
|
*/
$config['license'][LICENSE_DEMO]	= '데모라이센스';
$config['license'][LICENSE_FULL]	= '정식라이센스';

/*
|--------------------------------------------------------------------------
| 동기화
|--------------------------------------------------------------------------
|
| 라이센스별 체크 여부 설정 배열
|
*/
$config['sync_flag'][0] = '동기화대상';
$config['sync_flag'][1] = '동기화완료';

/*
|--------------------------------------------------------------------------
| 동기화
|--------------------------------------------------------------------------
|
| 라이센스별 체크 여부 설정 배열
|
*/
$config['privacy_flag'][0] = '체크';
$config['privacy_flag'][1] = '체크안함';


/*
|--------------------------------------------------------------------------
| 디비종류
|--------------------------------------------------------------------------
|
| 디비종류
|
*/
$config['db_kind'][DATABASE_KIND_ORACLE] = array(
    'name' => 'ORACLE', 
    'port' => 1521
);
$config['db_kind'][DATABASE_KIND_MSSQL] = array(
    'name' => 'MS-SQL',
    'port' => 1433
); 
$config['db_kind'][DATABASE_KIND_MYSQL] = array(
    'name' => 'MySQL',
    'port' => 3306
);
$config['db_kind'][DATABASE_KIND_POSTGRESQL] = array(
    'name' => 'PostgreSQL', 
    'port' => 5432
);

/* End of file system.php */
/* Location: ./application/config/system.php */