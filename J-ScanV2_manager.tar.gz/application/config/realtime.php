<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| REALTIME SETTINGS
| -------------------------------------------------------------------
| 이 파일은 실시간 분석에서 realtime 차트의 시간 구간을 어떻게 정할지 설정한다.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|
|	['start_second'] 이전 몇초부터 불러 올것인가.
|	['buffer_size'] 로그를 얼마나 메모리에 저장하고 있을것이낙.
|	
*/
$config['start_second'] = 5;
$config['buffer_size']  = 20000;

/* End of file daemon.php */
/* Location: ./application/config/daemon.php */