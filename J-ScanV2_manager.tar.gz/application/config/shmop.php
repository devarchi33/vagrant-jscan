<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| DAEMON CONNECTIVITY SETTINGS
| -------------------------------------------------------------------
| 이 파일은 분석 데이터를 공유메모리에 저장하기 위한 키설정을 모아두었다.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|   
| 분석 데이터를 공유메모리 메모리에 저장 하기 위한 키 
|	['cache_event_log'] 이벤트 개수
|	['cache_agent'] 쿼리 평균 수행 시간
|	['cache_sql_log'] 쿼리 평균 수행 결과 건수
|	
*/
$config['cache_event_log']	= 0x00002000;
$config['cache_agent']		= 0x00002001;
$config['cache_sql_log']	= 0x00002002;

/*
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|   
| 분석 데이터를 공유메모리 메모리에 저장 하기 위한 키 
|	['num_of_event'] 이벤트 개수
|	['avg_exec_time_of_the_query'] 쿼리 평균 수행 시간
|	['avg_num_of_query_exec_results'] 쿼리 평균 수행 결과 건수
|	['num_of_query_exec'] 쿼리 수행 건수
|	['num_of_query_exec_by_type'] 쿼리 유형별 수행 건수
|	['num_of_query_exec_by_policy'] 정책별 쿼리 수행 건수
|	['num_of_query_exec_by_type_per_sec'] 쿼리 유형별 초당 쿼리 수행 건수
|	['status_of_query_exec'] 쿼리 실행 현황
|	['num_of_query_exec_per_sec'] 서버별 초당 SQL 건수
|	['avg_response_time_per_sec'] 초당 평균 응답 시간
|	
*/
//$config['analysis']['']	= 0xff3;
$config['analysis']['num_of_event']							= 0x00002003;
$config['analysis']['avg_exec_time_of_the_query']			= 0x00002004;
$config['analysis']['avg_num_of_query_exec_results']		= 0x00002005;
$config['analysis']['num_of_query_exec']					= 0x00002006;
$config['analysis']['num_of_query_exec_by_type']			= 0x00002007;
$config['analysis']['num_of_query_exec_by_policy']			= 0x00002008;
$config['analysis']['num_of_query_exec_by_type_per_sec']	= 0x00002009;
$config['analysis']['status_of_query_exec']					= 0x00002010;
$config['analysis']['num_of_query_exec_per_sec']			= 0x00002011;
$config['analysis']['avg_response_time_per_sec']			= 0x00002012;
$config['analysis']['most_access_ip']						= 0x00002013;
$config['analysis']['much_lookup_ip']						= 0x00002014;
$config['analysis']['personal_info_access_ip']				= 0x00002015;

/*
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|   
| 로그분석기(MSaver)가 사용하는 해시 값
|	['uniq_sql'] 이벤트 개수
|	['class_trace'] 쿼리 평균 수행 시간
|	['db_conn'] 쿼리 평균 수행 결과 건수
|	
*/
$config['saver']['uniq_sql']	= 0x00002016;
$config['saver']['new_sql']		= 0x00002017;
$config['saver']['white_sql']	= 0x00002018;
$config['saver']['class_trace']	= 0x00002019;
$config['saver']['db_conn']		= 0x00002020;
$config['saver']['policy_list']	= 0x00002021;



/* End of file daemon.php */
/* Location: ./application/config/daemon.php */