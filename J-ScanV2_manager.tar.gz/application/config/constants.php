<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

define('WHITESQL_HOST', isset($_SERVER['HTTP_HOST']) == true ? $_SERVER['HTTP_HOST'] : '/');

/*
|--------------------------------------------------------------------------
| 쿠키설정에 대한 정보
|--------------------------------------------------------------------------
|
| 쿠키 보안과 시간 설정에 대한 상수 정의
|
*/
// 쿠키 만료 기간
define('COOKIE_EXPIRE', 0);
define('COOKIEHASH', md5(WHITESQL_HOST) );

/*
|--------------------------------------------------------------------------
| 모니터링 갱신 주기
|--------------------------------------------------------------------------
|
| 모니터링 기본 갱신 주기 설정
|
*/
define('DEFAULT_MONITORING_INTERVAL', 5);

/*
|--------------------------------------------------------------------------
| 각 시간단위를 초로 환산한 상수값을 설정
|--------------------------------------------------------------------------
|
| 읽기 편하도록 상수로 정의
|
*/
define('MINUTE_IN_SECONDS', 60);
define('HOUR_IN_SECONDS',   60 * MINUTE_IN_SECONDS);
define('DAY_IN_SECONDS',    24 * HOUR_IN_SECONDS);
define('WEEK_IN_SECONDS',   7 * DAY_IN_SECONDS);
define('YEAR_IN_SECONDS',   365 * DAY_IN_SECONDS);
	
/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
define('FILE_READ_MODE', 0644);
define('FILE_WRITE_MODE', 0666);
define('DIR_READ_MODE', 0755);
define('DIR_WRITE_MODE', 0777);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/

define('FOPEN_READ',							'rb');
define('FOPEN_READ_WRITE',						'r+b');
define('FOPEN_WRITE_CREATE_DESTRUCTIVE',		'wb'); // truncates existing file data, use with care
define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE',	'w+b'); // truncates existing file data, use with care
define('FOPEN_WRITE_CREATE',					'ab');
define('FOPEN_READ_WRITE_CREATE',				'a+b');
define('FOPEN_WRITE_CREATE_STRICT',				'xb');
define('FOPEN_READ_WRITE_CREATE_STRICT',		'x+b');

define('CURRENT_LOCALE', 'ko'); // 기본 언어
define('URL_BASE_DIR', ''); // 웹루트 내 하위 경로 설정


/*
|--------------------------------------------------------------------------
| 매니저 서버 정보
|--------------------------------------------------------------------------
|
| 소캣을 통해 데몬에게 명령을 내리는 매니저의 통신 정보
|
*/
//서버 IP
define('SOCKET_SERVER_IP', 'localhost'); 

//서버 통신 포트
define('SOCKET_PORT_MANAGE', 20224); 

/*
|--------------------------------------------------------------------------
| 소캣 명령
|--------------------------------------------------------------------------
|
| 소캣을 통해 데몬에게 명령을 내릴때 사용
|
*/
//정책 적용
define('CMD_POL_APPLY'         , 50);

//White SQL 정책 적용
define('CMD_WHITESQLPOL_APPLY' , 51);

//White SQL 정책 초기화
define('CMD_WHITESQLPOL_INIT'  , 52);

//White SQL 변경 정책 적용
define('CMD_SQLCHANGEPOL_APPLY', 53);

//Agent host 모니터링 모드 설정
define('CMD_AGENT_MODE'        , 60);

//Agent host 추가
define('CMD_AGENT_ADD'         , 61);

//Agent host 수정
define('CMD_AGENT_MOD'         , 62);

//Agent host 삭제
define('CMD_AGENT_DEL'         , 63);

//Unique SQL 등록
define('CMD_REG_UNIQSQL'       , 73);

/*
|--------------------------------------------------------------------------
| 정책 상수 
|--------------------------------------------------------------------------
| 
| 0:White SQL, 1:SQL, 2:SQL변경, 3:IP, 4:LOGIN_ID, 5:주요TABLE, 6:SQL유형, 7:개인정보TABLE
*/
//자동 검사
define('SYSTEM_DETECT', 0);

//None White SQL
define('POLICY_NONE_WHITE_SQL', 0);

//White SQL
define('POLICY_WHITE_SQL', 0);

//SQL
define('POLICY_SQL', 1);

//SQL Convert
define('POLICY_SQL_CONVERT', 2);

//IP
define('POLICY_IP', 3);

//LOGIN_ID
define('POLICY_LOGIN_ID', 4);

//주요TABLE
define('POLICY_TABLE', 5);

//SQL유형
define('POLICY_SQL_TYPE', 6);

//개인정보TABLE
define('POLICY_PERSONAL_INFO_TABLE', 7);

/*
|--------------------------------------------------------------------------
| Work history operation type 
|--------------------------------------------------------------------------
|
| Work 히스토리 동작 타입
*/
//add
define('WORK_HISTORY_ADD', 0);

//modify
define('WORK_HISTORY_MOD', 1);

//delete
define('WORK_HISTORY_DEL', 2);


/*
|--------------------------------------------------------------------------
| Policy history operation type 
|--------------------------------------------------------------------------
|
| Policy 히스토리 동작 타입
*/
//add
define('POLICY_HISTORY_ADD',  0);

//modify
define('POLICY_HISTORY_MOD',  1);

//delete
define('POLICY_HISTORY_DEL',  2);

//sync
define('POLICY_HISTORY_SYNC', 3);


/*
|--------------------------------------------------------------------------
| Agent mode 상수 정의
|--------------------------------------------------------------------------
|
*/
//Bypass
define('AGENT_MODE_BYPASS',  0);

//Logging
define('AGENT_MODE_LOGGING',  1);

//Monitoring
define('AGENT_MODE_MONITORING',  2);

//Protect
define('AGENT_MODE_PROTECT', 3);


/*
|--------------------------------------------------------------------------
| event type 상수 정의
|--------------------------------------------------------------------------
|
*/
//정책에 의한 차단(알림,주의,경보,위험,심각
define('EVENT_TYPE_POLICY',  0);

//System 문제발생
define('EVENT_TYPE_SYSTEM',  1);

/*
|--------------------------------------------------------------------------
| event level 상수 정의
|--------------------------------------------------------------------------
|
*/
//1:알림, 2:주의, 3:경보, 4:위험, 5:심각
define('EVENT_TYPE_NOTICE',  1);
define('EVENT_TYPE_ATTENTION',  2);
define('EVENT_TYPE_ALERT',  3);
define('EVENT_TYPE_DANGER',  4);
define('EVENT_TYPE_SERIOUS',  5);

define('EVENT_KIND_NONE', 0); //어느항목에도 소속되지 않음
define('EVENT_KIND_NEWSQL', 1); //New SQL
define('EVENT_KIND_WHITE_SQL', 2); //White SQL
define('EVENT_KIND_NONE_WHITESQL', 3); //Non-WhiteSQL
define('EVENT_KIND_ATTENTION_SQL', 4); //주의SQL
define('EVENT_KIND_SQL_CONVERT', 5); //SQL변경
define('EVENT_KIND_ATTENTION_IP', 6); //주의IPEVENT_KIND_NEWSQL
define('EVENT_KIND_ATTENTION_LOGIN_ID', 7); //주의LogInID
define('EVENT_KIND_ATTENTION_TABLE', 8); //주요테이블
define('EVENT_KIND_ATTENTION_SQL_TYPE', 9); //주의SQL유형
define('EVENT_KIND_PERSONAL_INFO_TABLE', 10); //개인정보테이블
define('EVENT_KIND_INTENTION_USER', 11); //의사사용자


/*
|--------------------------------------------------------------------------
| 라이센스 상수 정의
|--------------------------------------------------------------------------
|
*/
//1:데모라이센스, 2:정식라이센스
define('LICENSE_DEMO',  1);
define('LICENSE_FULL',  2);

/*
|--------------------------------------------------------------------------
| 라이센스 상태 상수 정의
|--------------------------------------------------------------------------
|
*/
//0:라이센스에러, 1:라이센스 정상
define('LICENSE_STATUS_ERROR',   1);
define('LICENSE_STATUS_NORMAL',  0);

/*
|--------------------------------------------------------------------------
| 에이전트 상태 상수 정의
|--------------------------------------------------------------------------
|
*/
//0:에이전트 연결 실패, 1:에이전트 연결
define('AGENT_DISCONNECTED',  0);
define('AGENT_CONNECTED',  1);


/*
|--------------------------------------------------------------------------
| 서버타입 상수 정의
|--------------------------------------------------------------------------
|
*/
//1:에이전트, 1:디비몬
define('SERVER_TYPE_AGENT',  1);
define('SERVER_TYPE_DBMON',  2);

/*
|--------------------------------------------------------------------------
|  데이터베이스 상수 정의
|--------------------------------------------------------------------------
|
*/
//1:oracle, 2:ms-sql, 3:mysql, 4:postgresql
define('DATABASE_KIND_ORACLE',  1);
define('DATABASE_KIND_MSSQL',  2);
define('DATABASE_KIND_MYSQL',  3);
define('DATABASE_KIND_POSTGRESQL',  4);

/* End of file constants.php */
/* Location: ./application/config/constants.php */