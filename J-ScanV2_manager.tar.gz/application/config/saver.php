<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| LOG SAVER SETTINGS
| -------------------------------------------------------------------
| 이 파일은 로그 세이버에 대한 설정이다.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|
|	['buffer_clear_time'] 로그를 몇 초에 한번 비우고 BULK INSERT를 실행할 것인가?
|	
*/
$config['buffer_clear_time'] = 2;

/* End of file daemon.php */
/* Location: ./application/config/daemon.php */