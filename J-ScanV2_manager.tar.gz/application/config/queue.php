<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| queue CONNECTIVITY SETTINGS
| -------------------------------------------------------------------
| 이 파일은 분석 메세지큐의 키설정을 모아두었다.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|   
| 분석 데이터를 공유메모리 메모리에 저장 하기 위한 키 
|	['mq_saver'] Log Receiver와 Log Saver간 로그전달 메시지큐
|	['mq_sync'] Log Saver과 UI상의 정책 동기화를 위한 메시지큐
|	['mq_policy_sender'] 에이전트에 정책전송을 위한 메시지 큐
|	['mq_anal'] 분석큐
|	
*/
$config['mq_saver']	= 0x00002000;
$config['mq_sync']	= 0x00002001;
$config['mq_policy_sender']	= 0x00002002;
$config['mq_anal']	= 0x00002003;
$config['mq_realtime']	= 0x00002004;


/* End of file queue.php */
/* Location: ./application/config/queue.php */