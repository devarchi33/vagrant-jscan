<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Toolbar
*
* Toolbar XML을 리턴하는 컨트롤러
*
* @uses     CI_Controller
* @category menu
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link     
*/
class Toolbar extends CI_Controller {

    /**
     * index
     * 
     * Toolbar 컨트롤러 index
     * 
     * @access public
     *
     * @return mixed Value.
     */
	public function index()
	{
      $this->output->set_content_type('application/xml');
      ?>
      <toolbar>
          <item id="toolbar_btnhome" type="button" text="Home" img="home.png" imgdis="home.png"/>
          <item id="toolbar_sep01" type="separator"/>
          <item id="toolbar_btnhost" type="button" text="Host" img="host_groups.png" imgdis="host_groups.png"/> 
          <item id="toolbar_sep02" type="separator"/>
          <item id="toolbar_btnsql_mon" type="button" text="SQL Monitoring" img="sql_mon.png" imgdis="sql_mon.png"/> 
          <item id="toolbar_btnevent_mon" type="button" text="Event Monitoring" img="event_mon.png" imgdis="event_mon.png"/> 
          <item id="toolbar_sep03" type="separator"/>
          <item id="toolbar_btnwhitesql" type="button" text="White SQL" img="whitesql.png" imgdis="whitesql.png"/> 
          <item id="toolbar_btnsql_policy" type="button" text="SQL Policy" img="sql_pol.png" imgdis="sql_pol.png"/> 
          <item id="toolbar_btnsql_convert" type="button" text="SQL Convert" img="sql_convert.png" imgdis="sql_convert.png"/> 
          <item id="toolbar_sep04" type="separator"/>
          <item id="toolbar_btnsql_log_wizard" type="button" text="SQL Log Wizard" img="sql_hier_log.png" imgdis="sql_hier_log.png"/> 
          <item id="toolbar_btnsql_log" type="button" text="SQL Log" img="sql_log.png" imgdis="sql_log.png"/> 
          <item id="toolbar_btnevent_log" type="button" text="SQL Event Log" img="event_log.png" imgdis="event_log.png"/> 
          <item id="toolbar_sep05" type="separator"/>
          <item id="toolbar_btnpolicy_history" type="button" text="Policy History" img="policy_history.png" imgdis="policy_history.png"/> 
          <item id="toolbar_btnwork_history" type="button" text="Work History" img="work_history.png" imgdis="work_history.png"/>
      </toolbar>
      <?
	}
}
/* End of file toolbar.php */
/* Location: ./application/controllers/menu/toolbar.php */