<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Top_menu
*
* 메뉴 XML을 리턴하는 컨트롤러
*
* @uses     CI_Controller
* @category menu
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link     
*/
class Top_menu extends CI_Controller {

    /**
     * index
     * 
     * Top_menu 컨트롤러 index
     * 
     * @access public
     *
     * @return mixed Value.
     */
	public function index()
	{
        $this->output->set_content_type('application/xml');
        ?>
        <menu>
          <item id="monitoring" text="<?=_("Monitoring")?>" img="sql_mon.png" imgdis="sql_mon.png">
            <item id="sql_mon" text="<?=_("SQL Monitoring")?>" img="sql_mon.png" imgdis="sql_mon.png"/>
            <item id="event_mon" text="<?=_("Event Monitoring")?>" img="event_mon.png" imgdis="event_mon.png"/>
          </item>
          <item id="sep_top_2" type="separator"/>
          <item id="log" text="<?=_("Log")?>" img="sql_hier_log.png" imgdis="sql_hier_log.png">
            <item id="sql_hier_log_t" text="<?=_("SQL Log Wizard")?>" img="sql_hier_log.png" imgdis="sql_hier_log.png"/>
            <item id="sql_log" text="<?=_("SQL Log")?>" img="sql_log.png" imgdis="sql_log.png"/>
            <item id="event_log" text="<?=_("Event Log")?>" img="event_log.png" imgdis="event_log.png"/>
          </item>
          <item id="sep_top_3" type="separator"/>
          <item id="History" text="<?=_("History")?>" img="policy_history.png" imgdis="policy_history.png">
            <item id="policy_history" text="<?=_("Policy History")?>" img="policy_history.png" imgdis="policy_history.png"/>
            <item id="work_history" text="<?=_("Work History")?>" img="work_history.png" imgdis="work_history.png"/>
          </item>
          <item id="sep_top_4" type="separator"/>
          <item id="Manage" text="<?=_("Manage")?>" img="whitesql.png" imgdis="whitesql.png">
            <item id="whitesql_pol" text="<?=_("WhiteSQL")?>" img="whitesql.png" imgdis="whitesql.png"/>
            <item id="sql_pol" text="<?=_("SQL Policy")?>" img="sql_pol.png" imgdis="sql_pol.png"/>
            <item id="sql_convert" text="<?=_("SQL Convert")?>" img="sql_convert.png" imgdis="sql_convert.png"/>
          </item>
          <item id="sep_top_5" type="separator"/>
          <item id="help" text="<?=_("Help")?>" img="help.png" imgdis="help.png"/>
        </menu>
        <?
	}
}
/* End of file main.php */
/* Location: ./application/controllers/main/main.php */