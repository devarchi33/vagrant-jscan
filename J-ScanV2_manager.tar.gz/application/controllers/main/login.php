<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Login
*
* 로그인 컨트롤러
*
* @uses     CI_Controller
* @category main
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class Login extends CI_Controller {

    public function __construct(){

        parent::__construct();
    }

    /**
     * index
     *
     * 메인 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function index()
	{
		//login view를 로드 합니다.
		$this->load->view('main/login.php');
	}

    public function action(){

        //파라미터를 받는다.
        $sLoginId        = $this->input->post('login-id');
        $sLoginPassword  = $this->input->post('login-pw');
       
        $aData = getUserInfo($sLoginId);

        if($aData){

            $this->load->library('PasswordHash', array('iteration_count_log2' => 8, 'portable_hashes' => true), 'HashPassword');

            $check = $this->HashPassword->CheckPassword($sLoginPassword, $aData['user_pass']);

            if($check){

                //쿠키 헬퍼 로드
                $this->load->helper('cookie');

                $cookie = generateAuthCookie($sLoginId, $aData['user_pass']);

                set_cookie( 
                    COOKIEHASH, 
                    $cookie, 
                    0, 
                    WHITESQL_HOST, 
                    '/' ,
                    'whitesql_'
                );
                
                $bSuccess = true;

                updateLastLogin($aData['user_id']);

                //결과 데이터 설정
                $sResult = "success";
                $sMessage = "로그인 성공";
            }
            else {

                $bSuccess = false;

                //결과 데이터 설정
                $sResult = "fail";
                $sMessage = "올바르지 않은 사용자 정보입니다";
            }
        }
        else {

            $bSuccess = false;

            //결과 데이터 설정
            $sResult = "fail";
            $sMessage = "올바르지 않은 사용자 정보입니다";
        }

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'success' => $bSuccess,
            'result'  => $sResult,
            'info' => $aData,
            'message' => $sMessage
        )));
    }

    public function getUserInfo(){

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(getUserInfo()));
    }

    public function destroy(){

        $this->_destroy();

        $bSuccess = true;

        //결과 데이터 설정
        $sResult = "success";
        $sMessage = "삭제 성공";

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'success' => $bSuccess,
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }

    private function _destroy(){

        //쿠키 헬퍼 로드
        $this->load->helper('cookie');

        set_cookie( 
            COOKIEHASH, 
            '', 
            '', 
            WHITESQL_HOST,
            '/' ,
            'whitesql_'
        );
    }
    
    public function check(){

        $aResult = checkValidCookie();

        if($aResult['result'] == 'fail'){

            $this->_destroy();
        }

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode($aResult));
    }
}
/* End of file login.php */
/* Location: ./application/controllers/main/login.php */