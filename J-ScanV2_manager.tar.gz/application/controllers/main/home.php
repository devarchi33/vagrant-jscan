<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Main
 *
 * 처음 접속시 메인 컨트롤러
 *
 * @uses     CI_Controller
 * @category main
 * @package  WhiteSQL
 * @author   정주원 <jjwcom@nate.com>
 * @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
 * @link
 */
class Home extends CI_Controller
{

    public function __construct()
    {

        parent::__construct();

        $this->redis = new Redis();
        $this->redis->connect('127.0.0.1', 6379);
    }

    /**
     * index
     *
     * 메인 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function index()
    {

        $this->load->config("system", true);
        $sSKin = $this->config->item('skin', 'system');

        $bCheck = checkValidCookie();

        if ($bCheck['result'] == "success") {

            //main view를 로드 합니다.
            $this->load->view('main/main.php', array(
                'skin' => $sSKin
            ));
        } else {

            //login view를 로드 합니다.
            $this->load->view('main/login.php', array(
                'skin' => $sSKin
            ));
        }
    }

    public function loadUniqSQLsloadUniqSQLs()
    {

        $this->load->model('tbl_uniqsql');
        foreach ($this->tbl_uniqsql->get() as $nIdx => $aRow) {

            $this->uniqsql[$aRow['uniqsql_id']] = $aRow['uniq_sqltext'];
        }
    }

    public function getMainPanelData()
    {

        $sServer = $this->input->post('server', 'root');
        $sType   = $this->input->post('type', 'now');

        $aResult = array(
            'event_count'             => $this->getNumOfEvent($sType, $sServer),
            'sql_policy'              => $this->getNumOfQueryExecByPolicy($sType, $sServer),
            'exec_result_count'       => $this->getAvgNumOfQueryExecResults($sType, $sServer),
            'exec_count'              => $this->getNumOfQueryExec($sType, $sServer),
            'most_access_ip'          => $this->getMostAccessIP($sType, $sServer),
            'much_lookup_ip'          => $this->getMuchLookupIP($sType, $sServer),
            'personal_info_access_ip' => $this->getPersonalInfoAccessIP($sType, $sServer),
            'total_grid'              => $this->getStatusOfQueryExec($sType, $sServer),
        );

        $this->output->set_content_type('application/json')->set_output(json_encode($aResult));
    }

    public function getNumOfEvent($sType, $sServer)
    {

        if ($sType == 'now') {

            $sServer = str_replace("-", ":", $sServer);
            $aData   = array_fill_keys(array('notice', 'attention', 'alert', 'danger', 'serious'), 0);
            $aData   = array_merge($aData, $this->redis->hGetAll('event_count:'.$sServer));


            $tmp = array(
                array('event' => '알림', 'value' => (int)$aData['notice']),
                array('event' => '주의', 'value' => (int)$aData['attention']),
                array('event' => '경고', 'value' => (int)$aData['alert']),
                array('event' => '위험', 'value' => (int)$aData['danger']),
                array('event' => '심각', 'value' => (int)$aData['serious'])
            );

            return $tmp;
        }

        //테이블 모델 로드
        $this->load->model('tbl_summary');
        $aData = $this->tbl_summary->getNumOfEvent($sType, $sServer);

        return $aData;
    }

    public function getNumOfQueryExecByPolicy($sType, $sServer)
    {

        if ($sType == 'now') {

            $sServer = str_replace("-", ":", $sServer);
            $aData   = array_fill(0, 8, 0);

            $aPolicies = $this->redis->hGetAll('sql_policy:'.$sServer);

            foreach($aPolicies as $nIdx => $nPoilcyCnt){

                $aData[$nIdx] = $nPoilcyCnt;
            }

            if (
                $aData[0] == 0 && $aData[1] == 0 && $aData[2] == 0
                && $aData[3] == 0 && $aData[4] == 0 && $aData[5] == 0
                && $aData[6] == 0 && $aData[7] == 0
            ) {

                $aSize = array_fill(0, 8, 1);
            } else {

                $aSize = $aData;
            }


            $tmp = [];
            array_push($tmp, array('event' => 'None WhiteSQL', 'value' => (int)$aData[0], 'size' => (int)$aSize[0]));
            array_push($tmp, array('event' => 'SQL', 'value' => (int)$aData[1], 'size' => (int)$aSize[1]));
            array_push($tmp, array('event' => 'SQL변경', 'value' => (int)$aData[2], 'size' => (int)$aSize[2]));
            array_push($tmp, array('event' => 'IP', 'value' => (int)$aData[3], 'size' => (int)$aSize[3]));
            array_push($tmp, array('event' => 'LOGIN ID', 'value' => (int)$aData[4], 'size' => (int)$aSize[4]));
            array_push($tmp, array('event' => '주요TABLE', 'value' => (int)$aData[5], 'size' => (int)$aSize[5]));
            array_push($tmp, array('event' => 'SQL유형', 'value' => (int)$aData[6], 'size' => (int)$aSize[6]));
            array_push($tmp, array('event' => '개인정보TABLE', 'value' => (int)$aData[7], 'size' => (int)$aSize[7]));

            return $tmp;
        }

        //테이블 모델 로드
        $this->load->model('tbl_summary');
        $aData = $this->tbl_summary->getNumOfQueryExecByPolicy($sType, $sServer);

        return $aData;
    }

    public function getAvgNumOfQueryExecResults($sType, $sServer)
    {

        if ($sType == 'now') {

            $sServer = str_replace("-", ":", $sServer);
            $aData   = $this->redis->hGetAll('exec_result_count:'.$sServer);

            arsort($aData);
            $aData = array_slice($aData, 0, 10);

            $tmp = array();
            foreach ($aData as $sIdx => $nVal) {

                list($agent_id, $uniqsql_id, $ipaddr) = explode(":", $sIdx);

                $agent_name   = $this->redis->hGet('server:'.$agent_id, 'agent_name');
                $sql_type     = $this->redis->hGet('uniqsql:'.$uniqsql_id, 'sql_type');
                $ref_tables   = $this->redis->hGet('uniqsql:'.$uniqsql_id, 'ref_tables');
                $result_count = $nVal;

                array_push($tmp, array(
                    'agent_id'     => $agent_id,
                    'ip'           => $ipaddr,
                    'uniqsql_id'   => $uniqsql_id,
                    'agent_name'   => $agent_name,
                    'sql_type'     => $sql_type,
                    'ref_tables'   => $ref_tables,
                    'result_count' => $result_count
                ));
            }

            return $tmp;
        }

        //데이터 베이스 연결
        $this->load->model('tbl_summary');
        $aData = $this->tbl_summary->getAvgNumOfQueryExecResults($sType, $sServer);

        return $aData;
    }

    public function getNumOfQueryExec($sType, $sServer)
    {

        if ($sType == 'now') {

            $sServer = str_replace("-", ":", $sServer);
            $aData   = $this->redis->hGetAll('exec_count:'.$sServer);

            arsort($aData);
            $aData = array_slice($aData, 0, 10);

            $tmp = array();
            foreach ($aData as $sIdx => $nVal) {

                list($agent_id, $uniqsql_id, $ipaddr) = explode(":", $sIdx);

                $agent_name = $this->redis->hGet('server:'.$agent_id, 'agent_name');
                $sql_type   = $this->redis->hGet('uniqsql:'.$uniqsql_id, 'sql_type');
                $ref_tables = $this->redis->hGet('uniqsql:'.$uniqsql_id, 'ref_tables');
                $exec_count = $nVal;

                array_push($tmp, array(
                    'agent_id'   => $agent_id,
                    'ip'         => $ipaddr,
                    'uniqsql_id' => $uniqsql_id,
                    'agent_name' => $agent_name,
                    'sql_type'   => $sql_type,
                    'ref_tables' => $ref_tables,
                    'exec_count' => $exec_count
                ));
            }

            return $tmp;
        }

        //데이터 베이스 연결
        $this->load->model('tbl_summary');
        $aData = $this->tbl_summary->getNumOfQueryExec($sType, $sServer);

        return $aData;
    }

    public function getStatusOfQueryExec($sType, $sServer)
    {

        if ($sType == 'now') {

            $level = array(0 => '-', 1 => '알림', 2 => '주의', 3 => '경고', 4 => '위험', 5 => '심각');

            $sServer = str_replace("-", ":", $sServer);
            $aData   = $this->redis->sort($sServer.":agent");
            $tmp     = array();
            foreach ($aData as $sIdx => $nAgentId) {

                $aAgent = $this->redis->hGetAll('server:'.$nAgentId);

                array_push($tmp, array(
                    'agent_name'        => $aAgent['agent_name'],
                    'agent_mode'        => $aAgent['agent_mode'],
                    'status'            => $aAgent['status'],
                    'license_status'    => $aAgent['license_status'],
                    'event_level'       => $level[$this->redis->get('warning_level:server:'.$nAgentId)],
                    'cnt_table'         => (int)$this->redis->hGet('total_grid:'.$sServer, $nAgentId.':cnt_table'),
                    'cnt_conv'          => (int)$this->redis->hGet('total_grid:'.$sServer, $nAgentId.':cnt_conv'),
                    'cnt_fail'          => (int)$this->redis->hGet('total_grid:'.$sServer, $nAgentId.':cnt_fail'),
                    'cnt_exec'          => (int)$this->redis->hGet('total_grid:'.$sServer, $nAgentId.':cnt_exec'),
                    'cnt_personal_info' => (int)$this->redis->hGet('total_grid:'.$sServer, $nAgentId.':cnt_personal_info')
                ));
            }

            return $tmp;
        }

        //데이터 베이스 연결
        $this->load->model('tbl_summary');
        $aData = $this->tbl_summary->getStatusOfQueryExec($sType, $sServer);

        return $aData;
    }

    public function getMostAccessIP($sType, $sServer)
    {

        if ($sType == 'now') {

            $sServer = str_replace("-", ":", $sServer);
            $aData   = $this->redis->hGetAll('most_access_ip:'.$sServer);

            arsort($aData);
            array_slice($aData, 0, 10);

            $tmp = array();
            foreach ($aData as $sIdx => $nVal) {

                $ipaddr = $sIdx;

                array_push($tmp, array(
                    'ip'    => $ipaddr,
                    'value' => $nVal
                ));
            }

            return $tmp;
        }

        //데이터 베이스 연결
        $this->load->model('tbl_summary');
        $aData = $this->tbl_summary->getMostAccessIP($sType, $sServer);

        return $aData;
    }

    public function getMuchLookupIP($sType, $sServer)
    {

        if ($sType == 'now') {

            $sServer = str_replace("-", ":", $sServer);
            $aData   = $this->redis->hGetAll('much_lookup_ip:'.$sServer);

            arsort($aData);
            array_slice($aData, 0, 10);

            $tmp = array();
            foreach ($aData as $sIdx => $nVal) {

                $ipaddr = $sIdx;

                array_push($tmp, array(
                    'ip'    => $ipaddr,
                    'value' => $nVal
                ));
            }

            return $tmp;
        }

        $this->load->model('tbl_summary');
        $aData = $this->tbl_summary->getMuchLookupIP($sType, $sServer);

        return $aData;
    }

    public function getPersonalInfoAccessIP($sType, $sServer)
    {

        if ($sType == 'now') {

            $sServer = str_replace("-", ":", $sServer);
            $aData   = $this->redis->hGetAll('personal_info_access_ip:'.$sServer);

            arsort($aData);
            array_slice($aData, 0, 10);

            $tmp = array();
            foreach ($aData as $sIdx => $nVal) {

                $ipaddr = $sIdx;

                array_push($tmp, array(
                    'ip'    => $ipaddr,
                    'value' => $nVal
                ));
            }

            return $tmp;
        }

        //데이터 베이스 연결
        $this->load->model('tbl_summary');
        $aData = $this->tbl_summary->getPersonalInfoAccessIP($sType, $sServer);

        return $aData;
    }

    public function checkLicense(){

        $this->load->model('tbl_agent_info');

        $sResult = 'success';

        $aData = $this->tbl_agent_info->get();

        $aAgents = array();
        foreach($aData as $nIdx => $aRow){

            if($aRow['license_expiredate']){

                $nExpireDate = date("Ymd", strtotime($aRow['license_expiredate']));

                if(date("Ymd", strtotime("+7 days")) >= $nExpireDate){

                    $sResult = 'fail';
                    array_push($aAgents, $aRow);
                }
            }
        }

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result' => $sResult,
            'agents' => $aAgents
        )));
    }
}
/* End of file home.php */
/* Location: ./application/controllers/main/home.php */
