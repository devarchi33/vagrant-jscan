<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * DBMonitoring
 *
 * 처음 접속시 메인 컨트롤러
 *
 * @uses     CI_Controller
 * @category main
 * @package  WhiteSQL
 * @author   정주원 <jjwcom@nate.com>
 * @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
 * @link
 */
class DBMonitoring extends CI_Controller
{

    public function __construct()
    {

        parent::__construct();

        $this->redis = new Redis();
        $this->redis->connect('127.0.0.1', 6379);
    }

    private function getAgent(){

        $aAgents = array(
            15,
            16,
            17,
            18,
            19,
            20
        );

        $nAgent = $aAgents[array_rand($aAgents, 1)];

        return $nAgent;
    }

    private function  makeLog(&$aRow)
    {
        $nAgent = $this->getAgent();

        return array(
            $nAgent, //agent_id
            "1", //agent_mode
            str_replace(".", "", microtime(true)), //request_time
            $aRow["PRESTMT"], //prestmt
            $aRow["SQL_FULLTEXT"]->load(), // sql_str
            "0", //block_yn
            $aRow["PARAMS"], //sql_param
            "jdbc:oracle:thin:@192.168.0.13:1521:orcl", //dbconn_url
            $aRow["USERNAME"], //dbconn_account
            "", //class_trace
            "0", //policy_id
            "N/A", //login_id
            "192.168.0.20", //ipaddr
            strtotime($aRow["EXEC_STARTTIME"]), //exec_starttime
            $aRow["ELAPSED_TIME"], //exec_elapsedtime
            "1", //execute_yn
            "", //fail_code
            "1", //result_count
            "none", //privacy_type
            "null", //privacy_value
            "N/A" //result_data
        );
    }

    public function oracle(){

        switch ($pid = pcntl_fork()) {
            case -1:

                // @fail
                die('Fork failed');
                break;

            case 0:

                $conn = oci_connect('sys', 'oracle', '211.170.163.68:1515/orcl', 'AL32UTF8', OCI_SYSDBA);

                if (!$conn) {
                    $e = oci_error();
                    trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
                }

                $sSQL = '
            SELECT
                    params.SQL_ID,
                    params.CHILD_NUMBER,
                    params.PARAMS,
                    NVL2(params.PARAMS, \'S\', \'P\') as PRESTMT,
                    vsql.SQL_FULLTEXT,
                    vsql.ELAPSED_TIME / 100000 as ELAPSED_TIME,
                    vsess.USERNAME,
                    TO_CHAR(vsess.SQL_EXEC_START, \'YYYY-MM-DD HH24:MI:SS\') as EXEC_STARTTIME,
                    vsess.PORT,
					UTL_INADDR.GET_HOST_ADDRESS
            FROM (
                SELECT
                    params.SQL_ID,
                    params.CHILD_NUMBER,
                    WM_CONCAT(params.VALUE_STRING) as PARAMS
                FROM (
                    SELECT
                            vsql.SQL_ID,
                            vsql.CHILD_NUMBER,
                            params.VALUE_STRING
                    FROM v$session vsess
                    INNER JOIN
                        v$sql vsql ON
                            vsess.sql_id = vsql.sql_id
                    LEFT OUTER JOIN
                        v$sql_bind_capture params ON
                            params.SQL_ID = vsql.SQL_ID
                            AND params.CHILD_NUMBER = vsql.CHILD_NUMBER
                    ORDER BY vsql.SQL_ID, vsql.CHILD_NUMBER, params.POSITION
                ) params
                GROUP BY params.SQL_ID, params.CHILD_NUMBER
            ) params
            INNER JOIN v$sql vsql ON
                vsql.SQL_ID = params.SQL_ID
                AND vsql.CHILD_NUMBER = params.CHILD_NUMBER
            LEFT OUTER JOIN v$session vsess ON
                vsess.sql_address = vsql.address
        ';

                while (true) {

                    // Prepare the statement
                    $stid = oci_parse($conn, $sSQL);
                    if (!$stid) {

                        $e = oci_error($conn);
                        trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
                    }

                    // Perform the logic of the query
                    $r = oci_execute($stid);
                    if (!$r) {

                        $e = oci_error($stid);
                        trigger_error(htmlentities($e['message'], ENT_QUOTES), E_USER_ERROR);
                    }

                    // Fetch the results of the query
                    while ($row = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS)) {

                        $aLog = makeLog($row);
                        $sLog = implode("\f", $aLog);

                        $aAgent = $redis->hGetAll('server:'.$aLog[0]);

                        $sData = '';
                        $sData .= $sLog;

                        $redis->rPush('audit:'.$aAgent['ipaddr'].':'.$aAgent['port'], $sLog);
                    }

//            break;
//            sleep(1);
                    usleep(1000);

                }

                oci_free_statement($stid);
                oci_close($conn);

                break;
        }
    }

}

?>
