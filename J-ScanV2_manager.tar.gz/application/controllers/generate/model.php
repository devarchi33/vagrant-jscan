<?php
class Model extends CI_Controller {

	var $data;
	
	function __construct()
	{
		parent::__construct();

		$this->load->model('generate');
	}
	
	function index()
	{
		$this->code_generate();
	}
	
	function code_generate($bViewMode = false)
	{
		$tbl_list = $this->generate->get_table_list();
		foreach($tbl_list as $idx => $tbl){
			
			$tbl_info = $this->generate->get_table_info($tbl);
			$this->data['field_list'] = $this->generate->get_field_list($tbl);
			
			if($tbl_info) {
				
				$this->data = array(
					'field_list' => $this->data['field_list'],
					'tbl' => $tbl, 
					'Tbl' => ucfirst($tbl),
					'tbl_info' => $tbl_info,
					'primary_key' => $this->_get_primary_key($tbl_info),
					'columns' => $this->_get_columns($tbl_info),
				);
				
				$this->data['model_code'] = "<?php\n".$this->_model_code_gen()."?>";
				
				if($bViewMode == true){

					$this->output->append_output($this->data['model_code']);
				}
				else {

					if(!file_exists(APPPATH."models/model_".$tbl.".php")){

						file_put_contents(APPPATH."models/model_".$tbl.".php", $this->data['model_code']);
					}
				}
			}
		}
	}
	
	function _model_code_gen()
	{
		return $this->load->view('generate/model', $this->data, TRUE);
	}

	function _get_columns($tbl_info)
	{
		$keys = array();
		
		foreach ($tbl_info as $col) {
						
			$keys[] = $col->name;
		}
		
		return $keys;
	}
	function _get_primary_key($tbl_info)
	{
		$keys = array();
		
		foreach ($tbl_info as $col) {
			
			if($col->primary_key == 1){
				
				$keys[] = $col->name;
			}
		}
		
		return $keys;
	}
	
}