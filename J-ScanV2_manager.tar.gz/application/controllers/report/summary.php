<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Summary 
*
* Summary report 관련 컨트롤러
*
* @uses     CI_Controller
* @category Summary
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class Summary extends CI_Controller {

    /**
     * index
     *
     * Summary 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function index(){


	}

    /**
     * getDateExecutionData
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getDateExecutionData()
    {
        $sSDate = $this->input->get('fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');

        $aHosts = getServerList($sServer);
        $aDates = getDateList($sSDate, $sEDate);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_anal_log');
       
        foreach($this->tbl_anal_log->getDateExecutionCount($aHosts, $sSDate, $sEDate) as $nIdx => $aRow){

            $aData[$aRow['day']] = $aRow['cnt'];
        }

        //에이전트 정보를 가져온다.
        $aResult = array();

        foreach($aDates as $nIdx => $nDay){
            
            array_push($aResult, array(
                'date' => $nDay,
                'value' => @(int)$aData[$nDay]
            ));
        }
        
        $this->output->set_content_type('application/json')->set_output(json_encode($aResult));
    }    

    /**
     * getWeeklyExecutionData
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getWeeklyExecutionData()
    {
        $sSDate = $this->input->get('fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');
        
        $aHosts = getServerList($sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_anal_log');
       
        foreach($this->tbl_anal_log->getWeeklyExecutionCount($aHosts, $sSDate, $sEDate) as $nIdx => $aRow){

            $aData[$aRow['wday']] = $aRow['cnt'];
        }

        //에이전트 정보를 가져온다.
        $aResult = array();

        foreach(array(1 => 'Sun', 2 => 'Mon', 3 => 'Tue', 4 => 'Wed', 5 => 'Thu', 6 => 'Fri', 7 => 'Sat') as $nWeek => $sWeek){

            array_push($aResult, array(
                'date' => $sWeek,
                'value' => @(int)$aData[$nWeek]
            ));
        }
        
        $this->output->set_content_type('application/json')->set_output(json_encode($aResult));
    }    


    /**
     * getDailyExecutionData
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getDailyExecutionData()
    {
        $sSDate = $this->input->get('fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');

        $aHosts = getServerList($sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_anal_log');
       
        foreach($this->tbl_anal_log->getDailyExecutionCount($aHosts, $sSDate, $sEDate) as $nIdx => $aRow){

            $aData[$aRow['day']] = $aRow['cnt'];
        }

        //에이전트 정보를 가져온다.
        $aResult = array();

        foreach(range(1, 31) as $nIdx => $nDay){
            
            array_push($aResult, array(
                'date' => $nDay,
                'value' => @(int)$aData[$nDay]
            ));
        }
        
        $this->output->set_content_type('application/json')->set_output(json_encode($aResult));
    }


    /**
     * getHourlyExecutionData
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getHourlyExecutionData()
    {
        $sSDate = $this->input->get('fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');
        
        $aHosts = getServerList($sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_anal_log');
        
        foreach($this->tbl_anal_log->getHourlyExecutionCount($aHosts, $sSDate, $sEDate) as $nIdx => $aRow){

            $aData[$aRow['hour']] = $aRow['cnt'];
        }

        //에이전트 정보를 가져온다.
        $aResult = array();
        foreach(range(0, 23) as $nIdx => $nHour){

            array_push($aResult, array(
                'date' => $nHour,
                'value' => @(int)$aData[$nHour]
            ));
        }
        
        $this->output->set_content_type('application/json')->set_output(json_encode($aResult));
    }    


    /**
     * getSummaryInfo
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getQueryExecuteTop20()
    {
        $sSDate = $this->input->get('report_Top20-fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('report_Top20-tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');

        $aHosts = getServerList($sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_anal_log');

        //에이전트 정보를 가져온다.
        $aData = $this->tbl_anal_log->getQueryExecuteTop20($aHosts, $sSDate, $sEDate);
        
        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }    

    /**
     * getResultCountTop20
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getResultCountTop20()
    {
        $sSDate = $this->input->get('report_Top20-fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('report_Top20-tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');

        $aHosts = getServerList($sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_anal_log');

        //에이전트 정보를 가져온다.
        $aData = $this->tbl_anal_log->getResultCountTop20($aHosts, $sSDate, $sEDate);

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }


    /**
     * getIPGridData
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getIPGridData()
    {
        $sSDate = $this->input->get('fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');

        $aHosts = getServerList($sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_anal_log');

        //에이전트 정보를 가져온다.
        $aData = $this->tbl_anal_log->getIPExecutionCount($aHosts, $sSDate, $sEDate);
        
        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    /**
     * getLoginIDGridData
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getLoginIDGridData()
    {
        $sSDate = $this->input->get('fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');

        $aHosts = getServerList($sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_anal_log');

        //에이전트 정보를 가져온다.
        $aData = $this->tbl_anal_log->getLoginIDPExecutionCount($aHosts, $sSDate, $sEDate);
        
        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    /**
     * getAccessGridData
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getAccessGridData($sMode = 'PersonalInfo')
    {
        $sSDate = $this->input->get('fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');

        $aHosts = getServerList($sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_anal_log');

        //에이전트 정보를 가져온다.
        $aData = $this->tbl_anal_log->getAccessCount($sMode, $aHosts, $sSDate, $sEDate);
        
        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }


    /**
     * getEventListGridData
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getEventListGridData()
    {
        $sSDate = $this->input->get('fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');

        $sSort = $this->input->get('sort');

        $aHosts = getServerList($sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_eventlog');

        //에이전트 정보를 가져온다.
        

        if($sSort){ 

            $oSort = array_pop(json_decode($sSort));
            $aData = $this->tbl_eventlog->getEventList($aHosts, $sSDate, $sEDate, $oSort->property, $oSort->direction);
        }
        else {

            $aData = $this->tbl_eventlog->getEventList($aHosts, $sSDate, $sEDate);
        }

        foreach($aData as $nIdx => $aRow){

            $aData[$nIdx]['event_level'] = getEventLevel($aRow['event_level']);
            $aData[$nIdx]['policy_type'] = getPolicyType($aRow['policy_type']);
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    } 

    /**
     * getPolicyChartData
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getPolicyChartData()
    {
        $sSDate = $this->input->get('fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');

        $this->config->load('system', true);

        $aPolicies = $this->config->item('policy_type', 'system');
        $aEventLevelKey = $this->config->item('event_level_key', 'system');

        $aHosts = getServerList($sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_eventlog');

        $aEventLevel = array_flip($aEventLevelKey);

        //에이전트 정보를 가져온다.
        $aEventData = $this->tbl_eventlog->getPolicyEventData($aHosts, $sSDate, $sEDate);

        $aData = array();
        foreach($aPolicies as $nPolicy => $sPolicy){

            foreach($aEventData as $nIdx => $aRow){

                if($aRow['policy'] == $nPolicy){

                    $aRow['policy'] = $sPolicy;
                    array_push($aData, $aRow);
                    unset($aEventData[$nIdx]);
                    continue 2;
                }
            }

            array_push($aData, array(
                'policy'    => $sPolicy,
                'notice'    => 0,
                'attention' => 0,
                'alert'     => 0,
                'danger'    => 0,
                'serious'   => 0
            ));
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    /**
     * getEventChartData
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getEventChartData()
    {
        $sSDate = $this->input->get('fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');

        $this->config->load('system', true);

        $aEventLevel = $this->config->item('event_level', 'system');

        $aHosts = getServerList($sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_eventlog');

        //에이전트 정보를 가져온다.
        $aPolicyData = $this->tbl_eventlog->getEventData($aHosts, $sSDate, $sEDate);

        $aData = array();
        foreach($aEventLevel as $nEvent => $sEvent){

            foreach($aPolicyData as $nIdx => $aRow){

                if($aRow['event_level'] == $nEvent){

                    array_push($aData, array(
                        'event_level'         => $sEvent,
                        'none'                => (int)$aRow['none'],
                        'sql'                 => (int)$aRow['sql'],
                        'sql_convert'         => (int)$aRow['sql_convert'],
                        'ip'                  => (int)$aRow['ip'],
                        'login_id'            => (int)$aRow['login_id'],
                        'table'               => (int)$aRow['table'],
                        'sql_type'            => (int)$aRow['sql_type'],
                        'personal_info_table' => (int)$aRow['personal_info_table']
                    ));
                    unset($aPolicyData[$nIdx]);
                    continue 2;
                }
            }

            array_push($aData, array(
                'event_level'         => $sEvent,
                'none'                => 0,
                'sql'                 => 0,
                'sql_convert'         => 0,
                'ip'                  => 0,
                'login_id'            => 0,
                'table'               => 0,
                'sql_type'            => 0,
                'personal_info_table' => 0
            ));
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    /**
     * getIPQuantityGridData
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getIPQuantityGridData()
    {
        $sSDate = $this->input->get('fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');

        $this->config->load('system', true);

        $aEventLevel = $this->config->item('event_level', 'system');

        $aHosts = getServerList($sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_anal_log');

        //에이전트 정보를 가져온다.
        $aData = $this->tbl_anal_log->getIPQuantity($aHosts, $sSDate, $sEDate);

        

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    /**
     * getLoginIDQuantityGridData
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getLoginIDQuantityGridData()
    {
        $sSDate = $this->input->get('fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');

        $this->config->load('system', true);

        $aEventLevel = $this->config->item('event_level', 'system');

        $aHosts = getServerList($sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_anal_log');

        //에이전트 정보를 가져온다.
        $aData = $this->tbl_anal_log->getLoginIDQuantity($aHosts, $sSDate, $sEDate);

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    /**
     * getIPCountGridData
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getIPCountGridData()
    {
        $sSDate = $this->input->get('fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');

        $this->config->load('system', true);

        $aEventLevel = $this->config->item('event_level', 'system');

        $aHosts = getServerList($sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_anal_log');

        //에이전트 정보를 가져온다.
        $aData = $this->tbl_anal_log->getIPCount($aHosts, $sSDate, $sEDate);

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    /**
     * getLoginIDCountGridData
     *
     * Summary 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getLoginIDCountGridData()
    {
        $sSDate = $this->input->get('fdate', date("Y-m-d", strtotime("-1 month")));
        $sEDate = $this->input->get('tdate', date("Y-m-d"));
        $sServer = $this->input->get('server');

        $this->config->load('system', true);

        $aEventLevel = $this->config->item('event_level', 'system');

        $aHosts = getServerList($sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_anal_log');

        //에이전트 정보를 가져온다.
        $aData = $this->tbl_anal_log->getLoginIDCount($aHosts, $sSDate, $sEDate);

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

}
/* End of file summary.php */
/* Location: ./application/controllers/Summary/summary.php */