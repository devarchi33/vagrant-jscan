<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Install
*
* 설치
*
* @uses     CI_Controller
* @category monitoring
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class Install extends CI_Controller {

    /**
     * index
     *
     * 메인 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function index()
    {

        $this->load->config("system", true);
        $sSKin = $this->config->item('skin', 'system');

        //main view를 로드 합니다.
        $this->load->view('install/install.php', array(
            'skin' => $sSKin
        ));

        $nError = 0;
        if(strlen(file_get_contents(APPPATH."config/database.php")) > 0){

            $nError++;
        }

        if(strlen(file_get_contents(APPPATH."config/daemon.php")) > 0){

            $nError++;
        }

        if(strlen(file_get_contents(APPPATH."config/manager.cfg")) > 0){

            $nError++;
        }

        if($nError > 0){
            
            header("Content-Type: text/html; charset=UTF-8", true);

            $str = "인스톨을 계속 진행하려면 아래의 파일들을 열고 내용을 비워주세요.<br><br>";
            $str.= "주의 ) 파일을 삭제하는 것이 아니라 내용을 비움<br><br>";
            $str.= APPPATH."config/database.php<br>";
            $str.= APPPATH."config/daemon.php<br>";
            $str.= APPPATH."config/manager.cfg<br>";

            show_error($str);
        }
    }
    
    /**
     * getEnv
     *
     * 서버 환경 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getEnv()
    {

    }

    /**
     * getPHPINI
     *
     * php_ini 설정 내용을 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getPHPINI()
    {
        
        $aINI = array();

        $aINI['date.timezone']  = ini_get('date.timezone');
        $aINI['short_open_tag'] = ini_get('short_open_tag');
        
        $this->output->set_content_type('application/json')->set_output(json_encode($aINI));
    }    

    /**
     * getModule
     *
     * 설치된 모듈 목록을 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function getModule()
	{
        $aExtensions = get_loaded_extensions();

        $aModules = array();
        $aModules['json']    = in_array('json', $aExtensions);
        $aModules['mysqli']  = in_array('mysqli', $aExtensions);
        $aModules['sockets'] = in_array('sockets', $aExtensions);
        $aModules['pthreads'] = in_array('pthreads', $aExtensions);    
        $aModules['zip']     = in_array('zip', $aExtensions);

        $this->output->set_content_type('application/json')->set_output(json_encode($aModules));
	}

    /**
     * getDirectoryPermission
     *
     * 디렉토리 퍼미션 점검
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getDirectoryPermission()
    {
        $aDir = array();
        foreach(array(APPPATH."data", APPPATH."config/database.php", APPPATH."config/daemon.php") as $nIdx => $sPath){
            
            $sCheckResult = (boolean)is_writable($sPath);

            //if($sCheckResult == false) @chmod($sPath, 0777);

            $aDir[$sPath] = $sCheckResult;
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aDir));
    }   

    /**
     * checkDatabaseConnection
     *
     * 데이터 베이스 커텍션 확인
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function checkDatabaseConnection()
    {
        $sDBHost = $this->input->post("install-db-host");
        $sDBUser = $this->input->post("install-db-user");
        $sDBPass = $this->input->post("install-db-pass");
        $sDBName = $this->input->post("install-db-name");

        $nError = 0;
        $sMessage = "";

        if(!$sDBHost || !$sDBUser || !$sDBPass){

            $nError++;
            $sMessage = '올바르지 않은 연결정보입니다.';
        }       

        if($nError == 0 && (!$oConn = @mysqli_connect($sDBHost, $sDBUser, $sDBPass))){

            $nError++;
            $sMessage = '올바르지 않은 연결정보입니다.';
        }
        
        if($nError == 0){

            if(!mysqli_select_db($oConn, $sDBName)){

                $nError++;
                $sMessage = '올바르지 않은 DB명입니다.';
            }
        }

        if($nError == 0){

            $sMessage = "연결되었습니다.";
        }

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'  => $nError == 0 ? "success" : "fail",
            'message' => $sMessage
        )));
    }    

    /**
     * save
     *
     * 저장하기
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function save()
    {
        $sDBHost                 = $this->input->post("install-db-host");
        $sDBUser                 = $this->input->post("install-db-user");
        $sDBPass                 = $this->input->post("install-db-pass");
        $sDBName                 = $this->input->post("install-db-name");
        $sAdminId                = $this->input->post("install-admin-id");
        $sAdminName              = $this->input->post("install-admin-name");
        $sAdminPass              = $this->input->post("install-admin-pass");
        $sAdminPassConfirm       = $this->input->post("install-admin-pass-confirm");
        $sAdminEmail             = $this->input->post("install-admin-email");
        $nLogPort                = $this->input->post("system-manager-log-port");
        $nListenPort             = $this->input->post("system-manager-listen-port");
        $nStateCheckPeriod       = $this->input->post("system-state-check-period");
        $nAgentHealthCheckPeriod = $this->input->post("system-agent-health-check-period");
        $nLogFileSize            = $this->input->post("system-log-file-size");
        $nMaxAgentNumber         = $this->input->post("system-max-agent-num");

        $nError = 0;
        $sMessage = "";

        if($sAdminPassConfirm != $sAdminPass){

            $nError++;
            $sMessage = '관리자 패스워드 정보가 상이합니다. 다시 확인해주세요';
        }

        //데이터 베이스 정보가 제대로 넘어 오지 않았다면 에러
        if($nError == 0){

            if(!$sDBHost || !$sDBUser || !$sDBPass){

                $nError++;
                $sMessage = '올바르지 않은 연결정보입니다.';
            }       
        }

        $oConn = null;

        //제대로 연결이 안된다면 에러
        if($nError == 0){

            if(!$oConn = @mysqli_connect($sDBHost, $sDBUser, $sDBPass)){

                $nError++;
                $sMessage = '올바르지 않은 연결정보입니다.';
            }
        }
            
        //디비선택이 되지 않는다면 에러
        if($nError == 0){

            if(!mysqli_select_db($oConn, $sDBName)){

                $nError++;
                $sMessage = '올바르지 않은 DB명입니다.';
            }
        }

        //데이터베이스 설정 파일을 셋팅한다.
        if($nError == 0){

            if(is_writable(APPPATH."config/database.php") == true){


                $sDatabase = file_get_contents(APPPATH."install/database.php");
                $sDatabase = str_replace(array('{host}', '{user}', '{pass}', '{name}'), array($sDBHost, $sDBUser, $sDBPass, $sDBName), $sDatabase);
                file_put_contents(APPPATH."config/database.php", $sDatabase);
            }
            else {

                $nError++;
                $sMessage = APPPATH."config/database.php - 퍼미션 변경 요망";
            }
        }

        //데몬 설정 파일을 셋팅한다.
        if($nError == 0){

            if(is_writable(APPPATH."config/daemon.php") == true){

                $sDaemon = file_get_contents(APPPATH."install/daemon.php");
                $sDaemon = str_replace(
                            array(
                                '{system_manager_ip}', '{system_manager_log_port}', '{system_manager_listen_port}', '{system_state_check_period}', 
                                '{system_agent_health_check_period}', '{system_log_file_size}', '{system_max_agent_num}'
                            ), 
                            array(
                                $_SERVER['SERVER_ADDR'], $nLogPort, $nListenPort, $nStateCheckPeriod, 
                                $nAgentHealthCheckPeriod, $nLogFileSize, $nMaxAgentNumber
                            ), 
                            $sDaemon);
                file_put_contents(APPPATH."config/daemon.php", $sDaemon);
            }
            else {

                $nError++;
                $sMessage = APPPATH."config/daemon.php - 퍼미션 변경 요망";
            }
        }

        //C 매니저 데몬 설정 파일을 셋팅한다.
        if($nError == 0){

            if(is_writable(APPPATH."config/manager.cfg") == true){

                $sCfg = file_get_contents(APPPATH."install/manager.cfg");
                $sCfg = str_replace(
                            array(
                                '{system_manager_log_port}', '{system_manager_listen_port}', '{system_state_check_period}', 
                                '{system_agent_health_check_period}', '{system_log_file_size}', '{system_max_agent_num}',
                                '{host}', '{user}', '{pass}', '{name}'
                            ), 
                            array(
                                $nLogPort, $nListenPort, $nStateCheckPeriod, 
                                $nAgentHealthCheckPeriod, $nLogFileSize, $nMaxAgentNumber,
                                $sDBHost, $sDBUser, $sDBPass, $sDBName
                            ), 
                            $sCfg);
                file_put_contents(APPPATH."config/manager.cfg", $sCfg);
            }
            else {

                $nError++;
                $sMessage = APPPATH."config/manager.cfg - 퍼미션 변경 요망";
            }
        }

        //scheme을 등록한다.
        if($nError == 0){

            foreach(explode(";", file_get_contents(APPPATH."install/scheme.sql")) as $nIdx => $sSql){

                if(!trim($sSql)) continue;

                $oResult = @mysqli_query($oConn, $sSql);

                if(mysqli_errno($oConn) > 0){

                    $nError++;
                    $sMessage = mysqli_error($oConn).", SQL :".$sSql;
                }

                if($nError > 0){

                    break;
                }
            }
        }

        //관리자 정보 등록
        if($nError == 0){

            $this->load->library('PasswordHash', array('iteration_count_log2' => 8, 'portable_hashes' => true), 'HashPassword');
            $sPassword = $this->HashPassword->HashPassword($sAdminPass);

            $sSql = "
                INSERT INTO `tbl_userinfo` (
                    `user_name`,
                    `user_loginid`,
                    `user_pass`,
                    `user_level`,
                    `use_yn`,
                    `user_email`
                ) 
                VALUES
                (
                    '".$sAdminName."',
                    '".$sAdminId."',
                    '".$sPassword."',
                    '10',
                    '1',
                    '".$sAdminEmail."'
                );
            ";
            mysqli_query($oConn, $sSql);

            if(mysqli_errno($oConn) > 0){

                $nError++;
                $sMessage = mysqli_error($oConn);
            }
        }

        //기본 시스템 스탯 입력
        if($nError == 0){

            $sSql = "
                INSERT INTO `mt_state` (
                    `cpu`, `mem`, `disk`
                ) 
                VALUES
                (
                    0, 0, 0
                );
            ";
            mysqli_query($oConn, $sSql);

            if(mysqli_errno($oConn) > 0){

                $nError++;
                $sMessage = mysqli_error($oConn);
            }
        }

        if($oConn) @mysqli_close($oConn);

        if($nError == 0){

            $sMessage = "설치 완료 되었습니다.";
        }

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'success'  => $nError == 0 ? true : false,
            'message' => $sMessage
        )));
    }
}
/* End of file install.php */
/* Location: ./application/controllers/install/install.php */