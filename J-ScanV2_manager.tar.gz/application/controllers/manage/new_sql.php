<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* New_sql
*
* New_sql 클래스
*
* @uses     CI_Controller
* @category log
* @package  NewSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class New_sql extends CI_Controller {

    /**
     * index
     *
     * 메인 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function index()
	{

        return $this->getGridData();
	}

    /**
     * getListData
     * 
     * SQL 그리드 데이터를 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getListData($nApprovalYn = null){
        
        //파라미터를 받는다.
        $sServer = $this->input->get('server');
        $nStartNo = $this->input->get("start");
        $nEndNo = $this->input->get("limit");
        $sSort = $this->input->get("sort");
        $sSearchMode = $this->input->get('manage_NewSQL-search-mode');
        $sSearchKeyword = $this->input->get('manage_NewSQL-search-keyword');

        //SQLConvert 메뉴에서도 해당 컨트롤러 메소드를 사용하기 때문에 검색 파라미터가
        //존재하는지 체크한다.

        if(!$sSearchMode){
            
            $sSearchMode = $this->input->get('manage_SQLConvert-Add-search-mode');
        }

        if(!$sSearchKeyword){
            
            $sSearchKeyword = $this->input->get('manage_SQLConvert-Add-search-keyword');
        }

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $aServers = getServerList($sServer);

        //테이블 모델 로드
        $this->load->model('tbl_newsql');

        /**
         * 
         * 리스트의 토탈 갯수를 구한다.
         */

        //전체 로그 갯수
        $nTotalCount = 0;

        //서버정보가 있을경우 조건절에 서버 추가.
        if($aServers) $this->tbl_newsql->setAgentId($aServers);

        //검색어가 있을 경우 like 검색 추가.
        if($sSearchMode && $sSearchKeyword){

            if($sSearchMode == 'sqltext') $this->tbl_newsql->setUniqSQLQuery($sSearchKeyword);  
            else  $this->tbl_newsql->setClassString($sSearchKeyword);  
        } 

        //승인된 것만 보여주는 조건 추가 
        if($nApprovalYn !== null){

            $this->tbl_newsql->setApprovalYn($nApprovalYn);  
        }
       
        $this->tbl_newsql->select('
            COUNT(1) as cnt
        ', true);

        //토탈 갯수를 구한다.
        $aTotal = array_pop($this->tbl_newsql->joinUniqSQL()->joinClassTrace()->get());

        /**
         * 
         * 리스트의 데이터를 구한다.
         */

        //소팅에 대한 명령이 들어오면 상황에 맞게 order by 해준다.
        if($sSort){ 

            $oSort = array_pop(json_decode($sSort));
            $this->tbl_newsql->db->order_by($oSort->property, $oSort->direction);
        }
        
        //서버정보가 있을경우 조건절에 서버 추가.
        if($aServers) $this->tbl_newsql->setAgentId($aServers);

        //검색어가 있을 경우 like 검색 추가.
        if($sSearchMode && $sSearchKeyword){

            if($sSearchMode == 'sqltext') $this->tbl_newsql->setUniqSQLQuery($sSearchKeyword);  
            else  $this->tbl_newsql->setClassString($sSearchKeyword);  
        }

        //승인된 것만 보여주는 조건 추가 
        if($nApprovalYn !== null){

            $this->tbl_newsql->setApprovalYn($nApprovalYn);  
        }

        //최근데이터를 가장 앞으로 보여준다.
        $this->tbl_newsql->db->order_by('newsql_id', 'DESC');

        $this->tbl_newsql->select(array(
            'newsql_id',
            'newsql.sql_type',
            'uniq.uniq_sqltext',
            'class_string',
            'reg_date'
        ));

        //조건에 따른 데이터를 통계테이블에서 가져온다
        $aData = $this->tbl_newsql->joinUniqSQL()->joinClassTrace()->get();

        $aList = array();
        foreach($aData as $nIdx => $aRow){

            $aList[] = $aRow;
        }

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'list' => $aList,
            'total' => $aTotal['cnt']
        )));
    }

    /**
     * getQueryData
     * 
     * Syntax Highlight를 적용한 쿼리를 보여준다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getQueryData($nNewSqlId){

        //테이블 모델 로드
        $this->load->model('tbl_newsql');

        //SQL Formatter 라이브러리 로드
        $this->load->library('SqlFormatter');

        //SELECT할 필드를 셋팅한다.
        $this->tbl_newsql->select(array(
            'newsql.orig_sqltext',
            'uniq_sqltext'
        ));

        //조건에 따른 데이터를 통계테이블에서 가져온다
        $aData = array_pop($this->tbl_newsql->joinUniqSql()->get($nNewSqlId));

        //SQL Format Syntax Highlight 적용
        $aData['orig_sqltext'] = SqlFormatter::format($aData['orig_sqltext']);
        $aData['uniq_sqltext'] = SqlFormatter::format($aData['uniq_sqltext']);
        
        //JSON 양식 출력
        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    public function getServerList(){

        //필요한 모델을 로드한다.
        $this->load->model(array(
            'tbl_agent_info'
        ));

        //에이전트 그룹정보와 조인한 tbl_agent_info를 가져온다.
        $aData = $this->tbl_agent_info->joinAgentGroupInfo()->select(array('group_name'), false)->get();

        //트리의 최상위 노드
        $aTree = array();

        foreach($aData as $nIdx => $aRow){

            //호스트 그룹 노드 설정
            $aTree[] = array(
                'id'   => 'server-'.$aRow['agent_id'],
                'text' => $aRow['agent_name'],
                'leaf' => true
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aTree));
    }

    /**
     * export
     * 
     * 쿼리를 export 한다.
     * 
     * @access public
     *
     * @return excel file
     */
    public function export(){

        //파라미터를 받는다.
        $sServer = $this->input->get('serverId', 'root');
        $sSort = $this->input->get("sort");
        $sSearchMode = $this->input->get('manage_NewSQL-search-mode');
        $sSearchKeyword = $this->input->get('manage_NewSQL-search-keyword');

        ini_set('memory_limit', '-1');
        set_time_limit(0);

        //테이블 모델 로드
        $this->load->model('tbl_newsql');

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $aServers = getServerList($sServer);

        /**
         * 
         * 리스트의 데이터를 구한다.
         */

        //소팅에 대한 명령이 들어오면 상황에 맞게 order by 해준다.
        if($sSort){ 

            $oSort = array_pop(json_decode($sSort));
            $this->tbl_newsql->db->order_by($oSort->property, $oSort->direction);
        }
        
        //서버정보가 있을경우 조건절에 서버 추가.
        if($aServers) $this->tbl_newsql->setAgentId($aServers);

        //검색어가 있을 경우 like 검색 추가.
        if($sSearchMode && $sSearchKeyword){

            if($sSearchMode == 'sqltext') $this->tbl_newsql->setUniqSQLQuery($sSearchKeyword);  
            else  $this->tbl_newsql->setClassString($sSearchKeyword);  
        }

        //최근데이터를 가장 앞으로 보여준다.
        $this->tbl_newsql->db->order_by('newsql_id', 'DESC');

        $this->tbl_newsql->select(array(
            'newsql.newsql_id',
            'newsql.agent_id',
            'newsql.uniqsql_id',
            'newsql.class_id',
            'agent_name',
            'class_string',
            'newsql.orig_sqltext',
        ));

        //조건에 따른 데이터를 통계테이블에서 가져온다
        $aData = $this->tbl_newsql->joinUniqSQL()->joinAgentInfo()->joinClassTrace()->get();

        $this->load->library("PHPExcel", null, "PHPExcel");

        $this->PHPExcel->setActiveSheetIndex(0);
        $sheet = $this->PHPExcel->getActiveSheet();

        if(count($aData) > 0){
            
            $aKeys = array_keys($aData[0]);

            $col = 'A';
            foreach($aKeys as $nIdx => $sVal){

                $sheet->SetCellValue($col.'1', iconv("utf-8", "euc-kr", $sVal));
                $sheet->getStyle($col.'1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('E7E7E7');
                $col++;
            }

            $row = 2;
            foreach($aData as $aRow){

                $col = 'A';
                foreach($aRow as $nIdx => $sVal){

                    $col_idx = $col.$row;

                    $preg_val = preg_replace("/(xx1[a-zA-Z0-9_.\'\",()]+)/", "[p]$1[p]", $sVal, -1);

                    $tmp = explode('[p]', $preg_val);

                    if(count($tmp) > 1){

                        $objRichText = new PHPExcel_RichText();

                        foreach($tmp as $tidx => $tval){

                            if(preg_match("/(xx1[a-zA-Z0-9_.\'\",()]+)/", $tval) == true){

                                $objPayable = $objRichText->createTextRun($tval);
                                $objPayable->getFont()->setBold(true);
                                $objPayable->getFont()->setItalic(true);
                                $objPayable->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_RED ) );
                            }
                            else {

                                $objRichText->createText($tval);
                            }
                        }
         
                        $sheet->SetCellValue($col_idx, $objRichText);
                    }
                    else {

                        $sheet->SetCellValue($col_idx, $sVal);
                    }

                    // $sheet->getStyle($col_idx)->getAlignment()->setWrapText(true)->setVertical(PHPExcel_Style_Alignment::VERTICAL_TOP);
                    // $calculatedWidth = $sheet->getColumnDimension($col_idx)->setAutoSize(true);

                    $col++;
                }

                $row++;
            }

            $styleArray = array(
                   'borders' => array(
                         'allborders' => array(
                                'style' => PHPExcel_Style_Border::BORDER_THIN,
                                'color' => array('argb' => '00000000'),
                         )
                   )
            );

            $this->PHPExcel->getActiveSheet()->getStyle('A1:'.chr(ord($col) - 1).--$row)->applyFromArray($styleArray);

        }

        $this->PHPExcel->getActiveSheet()->setTitle('New SQL');

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="newsql_list.xlsx"');
        header('Cache-Control: max-age=0');

        $objWriter = PHPExcel_IOFactory::createWriter($this->PHPExcel, 'Excel2007');
        $objWriter->save('php://output');
    }

    public function del(){

        //파라미터를 받는다.
        $sDelList = $this->input->post('ids');

        //테이블 모델 로드
        $this->load->model(array(
            'tbl_newsql'
        ));

        $aDelList = explode(",", $sDelList);
        
        foreach($aDelList as $nIdx => $nId){

            //삭제 전 데이터를 가져온다.
            $aData = array_pop($this->tbl_newsql->get($nId));

            //정책 삭제
            $this->tbl_newsql->del($nId);
        }

        //결과 데이터 설정
        $sResult = "success";
        $sMessage = "삭제 완료";

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }
}
/* End of file new_sql.php */
/* Location: ./application/controllers/manage/new_sql.php */