<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* White_sql
*
* White_sql 클래스
*
* @uses     CI_Controller
* @category log
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class White_sql extends CI_Controller {

    /**
     * index
     *
     * 메인 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function index()
	{

        return $this->getGridData();
	}

    /**
     * getListData
     * 
     * SQL 그리드 데이터를 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getListData($nApprovalYn = null){
        
        //파라미터를 받는다.
        $sServer = $this->input->get('server');
        $nStartNo = $this->input->get("start");
        $nEndNo = $this->input->get("limit");
        $sSort = $this->input->get("sort");
        $sSearchMode = $this->input->get('manage_WhiteSQL-search-mode');
        $sSearchKeyword = $this->input->get('manage_WhiteSQL-search-keyword');

        //SQLConvert 메뉴에서도 해당 컨트롤러 메소드를 사용하기 때문에 검색 파라미터가
        //존재하는지 체크한다.

        if(!$sSearchMode){
            
            $sSearchMode = $this->input->get('manage_SQLConvert-Add-search-mode');
        }

        if(!$sSearchKeyword){
            
            $sSearchKeyword = $this->input->get('manage_SQLConvert-Add-search-keyword');
        }

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $aServers = getServerList($sServer);

        //테이블 모델 로드
        $this->load->model('tbl_whitesql_list');

        /**
         * 
         * 리스트의 토탈 갯수를 구한다.
         */

        //전체 로그 갯수
        $nTotalCount = 0;

        //서버정보가 있을경우 조건절에 서버 추가.
        if($aServers) $this->tbl_whitesql_list->setAgentId($aServers);

        //검색어가 있을 경우 like 검색 추가.
        if($sSearchMode && $sSearchKeyword){

            if($sSearchMode == 'sqltext') $this->tbl_whitesql_list->setUniqSQLQuery($sSearchKeyword);  
            else  $this->tbl_whitesql_list->setClassString($sSearchKeyword);  
        } 

        //승인된 것만 보여주는 조건 추가 
        if($nApprovalYn !== null){

            $this->tbl_whitesql_list->setApprovalYn($nApprovalYn);  
        }
       
        $this->tbl_whitesql_list->select('
            COUNT(1) as cnt
        ', true);

        //토탈 갯수를 구한다.
        $aTotal = array_pop($this->tbl_whitesql_list->joinUniqSQL()->joinClassTrace()->get());

        /**
         * 
         * 리스트의 데이터를 구한다.
         */

        //소팅에 대한 명령이 들어오면 상황에 맞게 order by 해준다.
        if($sSort){ 

            $oSort = array_pop(json_decode($sSort));
            $this->tbl_whitesql_list->db->order_by($oSort->property, $oSort->direction);
        }
        
        //서버정보가 있을경우 조건절에 서버 추가.
        if($aServers) $this->tbl_whitesql_list->setAgentId($aServers);

        //검색어가 있을 경우 like 검색 추가.
        if($sSearchMode && $sSearchKeyword){

            if($sSearchMode == 'sqltext') $this->tbl_whitesql_list->setUniqSQLQuery($sSearchKeyword);  
            else  $this->tbl_whitesql_list->setClassString($sSearchKeyword);  
        }

        //승인된 것만 보여주는 조건 추가 
        if($nApprovalYn !== null){

            $this->tbl_whitesql_list->setApprovalYn($nApprovalYn);  
        }

        //최근데이터를 가장 앞으로 보여준다.
        $this->tbl_whitesql_list->db->order_by('whitesql_id', 'DESC');

        $this->tbl_whitesql_list->select(array(
            'whitesql_id',
            'uniq_sqltext',
            'class_string',
            'approval_yn',
            'approval_user_id',
            'user_name as approval_user_name',
            'IF(IFNULL(approval_time, 0) = 0, "", DATE_FORMAT(FROM_UNIXTIME(approval_time), "%Y-%m-%d %H:%i:%s")) AS approval_time',
            'sync_flag',
            'state',
            'on_off'
        ));

        //조건에 따른 데이터를 통계테이블에서 가져온다
        $aData = $this->tbl_whitesql_list->joinUniqSQL()->joinApprovalUserInfo()->joinClassTrace()->get();

        $aList = array();
        foreach($aData as $nIdx => $aRow){

            $aList[] = $aRow;
        }

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'list' => $aList,
            'total' => $aTotal['cnt']
        )));
    }

    /**
     * getQueryData
     * 
     * Syntax Highlight를 적용한 쿼리를 보여준다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getQueryData($nWhiteSqlId){

        //테이블 모델 로드
        $this->load->model('tbl_whitesql_list');

        //SQL Formatter 라이브러리 로드
        $this->load->library('SqlFormatter');

        //SELECT할 필드를 셋팅한다.
        $this->tbl_whitesql_list->select(array(
            'orig_sqltext',
            'uniq_sqltext'
        ));

        //조건에 따른 데이터를 통계테이블에서 가져온다
        $aData = array_pop($this->tbl_whitesql_list->joinUniqSql()->get($nWhiteSqlId));

        //SQL Format Syntax Highlight 적용
        $aData['orig_sqltext'] = SqlFormatter::format($aData['orig_sqltext']);
        $aData['uniq_sqltext'] = SqlFormatter::format($aData['uniq_sqltext']);
        
        //JSON 양식 출력
        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    /**
     * export
     * 
     * 쿼리를 export 한다.
     * 
     * @access public
     *
     * @return excel file
     */
    public function export(){

        //파라미터를 받는다.
        $sServer = $this->input->get('serverId', 'root');
        $sSort = $this->input->get("sort");
        $sSearchMode = $this->input->get('manage_WhiteSQL-search-mode');
        $sSearchKeyword = $this->input->get('manage_WhiteSQL-search-keyword');

        ini_set('memory_limit', '-1');
        set_time_limit(0);

        //테이블 모델 로드
        $this->load->model('tbl_whitesql_list');

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $aServers = getServerList($sServer);

        /**
         * 
         * 리스트의 데이터를 구한다.
         */

        //소팅에 대한 명령이 들어오면 상황에 맞게 order by 해준다.
        if($sSort){ 

            $oSort = array_pop(json_decode($sSort));
            $this->tbl_whitesql_list->db->order_by($oSort->property, $oSort->direction);
        }
        
        //서버정보가 있을경우 조건절에 서버 추가.
        if($aServers) $this->tbl_whitesql_list->setAgentId($aServers);

        //검색어가 있을 경우 like 검색 추가.
        if($sSearchMode && $sSearchKeyword){

            if($sSearchMode == 'sqltext') $this->tbl_whitesql_list->setUniqSQLQuery($sSearchKeyword);  
            else  $this->tbl_whitesql_list->setClassString($sSearchKeyword);  
        }

        //최근데이터를 가장 앞으로 보여준다.
        $this->tbl_whitesql_list->db->order_by('whitesql_id', 'DESC');

        $this->tbl_whitesql_list->select(array(
            'whitesql.whitesql_id',
            'whitesql.agent_id',
            'whitesql.uniqsql_id',
            'whitesql.class_id',
            'agent_name',
            'class_string',
            'orig_sqltext',
        ));

        //조건에 따른 데이터를 통계테이블에서 가져온다
        $aData = $this->tbl_whitesql_list->joinUniqSQL()->joinAgentInfo()->joinClassTrace()->get();

        $this->load->library("PHPExcel", null, "PHPExcel");

        $this->PHPExcel->setActiveSheetIndex(0);
        $sheet = $this->PHPExcel->getActiveSheet();

        if(count($aData) > 0){
            
            $aKeys = array_keys($aData[0]);

            $col = 'A';
            foreach($aKeys as $nIdx => $sVal){

                $sheet->SetCellValue($col.'1', iconv("utf-8", "euc-kr", $sVal));
                $sheet->getStyle($col.'1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('E7E7E7');
                $col++;
            }

            $row = 2;
            foreach($aData as $aRow){

                $col = 'A';
                foreach($aRow as $nIdx => $sVal){

                    $col_idx = $col.$row;

                    $preg_val = preg_replace("/(xx1[a-zA-Z0-9_.\'\",()]+)/", "[p]$1[p]", $sVal, -1);

                    $tmp = explode('[p]', $preg_val);

                    if(count($tmp) > 1){

                        $objRichText = new PHPExcel_RichText();

                        foreach($tmp as $tidx => $tval){

                            if(preg_match("/(xx1[a-zA-Z0-9_.\'\",()]+)/", $tval) == true){

                                $objPayable = $objRichText->createTextRun($tval);
                                $objPayable->getFont()->setBold(true);
                                $objPayable->getFont()->setItalic(true);
                                $objPayable->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_RED ) );
                            }
                            else {

                                $objRichText->createText($tval);
                            }
                        }
         
                        $sheet->SetCellValue($col_idx, $objRichText);
                    }
                    else {

                        $sheet->SetCellValue($col_idx, $sVal);
                    }

                    // $sheet->getStyle($col_idx)->getAlignment()->setWrapText(true)->setVertical(PHPExcel_Style_Alignment::VERTICAL_TOP);
                    // $calculatedWidth = $sheet->getColumnDimension($col_idx)->setAutoSize(true);

                    $col++;
                }

                $row++;
            }

            $styleArray = array(
                   'borders' => array(
                         'allborders' => array(
                                'style' => PHPExcel_Style_Border::BORDER_THIN,
                                'color' => array('argb' => '00000000'),
                         )
                   )
            );

            $this->PHPExcel->getActiveSheet()->getStyle('A1:'.chr(ord($col) - 1).--$row)->applyFromArray($styleArray);

        }

        $this->PHPExcel->getActiveSheet()->setTitle('White SQL');

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="whitesql_list.xlsx"');
        header('Cache-Control: max-age=0');

        $objWriter = PHPExcel_IOFactory::createWriter($this->PHPExcel, 'Excel2007');
        $objWriter->save('php://output');
    }

    public function import(){

        //파라미터를 받는다.
        $sServer = $this->input->post('manage_WhiteSQL-Import-agent-id');

        if(!$sServer){

            $aResult = array('success' => false, 'error' => '선택된 서버가 없습니다.');
            $this->output->set_content_type('application/json')->set_output(json_encode($aResult));

            return;
        }

        $sServer = str_replace('server-', '', $sServer);
        
        ini_set('memory_limit', '-1');
        set_time_limit(0);

        //테이블 모델 로드
        $this->load->model('tbl_whitesql_list');

        $this->load->library("PHPExcel", null, "PHPExcel");

        $config['upload_path'] = APPPATH."data";
        $config['allowed_types'] = 'xlsx';

        $this->load->library('upload', $config);    
        
        $aResult = null;
        if (!$this->upload->do_upload("import-excel"))
        {
            $aResult = array('success' => false, 'error' => $this->upload->display_errors());
            $this->output->set_content_type('application/json')->set_output(json_encode($aResult));

            return;
        }

        $aUpload = $this->upload->data();

        /**  Create a new Reader of the type defined in $inputFileType  **/
        $objReader = PHPExcel_IOFactory::createReader("Excel2007");

        /**  Load $inputFileName to a PHPExcel Object  **/
        $objPHPExcel = $objReader->load($aUpload['full_path']);
        
        $objPHPExcel->setActiveSheetIndex(0);
        $objWorksheet  = $objPHPExcel->setActiveSheetIndex(0);
        $highestRow    = $objWorksheet->getHighestRow();
        $highestColumn = $objWorksheet->getHighestColumn();

        $aHeading = $objWorksheet->rangeToArray('A1:'.$highestColumn.'1', null, true, true, true);
        $aHeading = $aHeading[1];

        //컬럼의 순서와 컬럼의 구성이 하나라도 맞지 않는다면 에러를 표시한다.
        $bMatchColumn = true;
        if($aHeading['A'] != 'whitesql_id') $bMatchColumn = false;
        if($aHeading['B'] != 'agent_id') $bMatchColumn = false;
        if($aHeading['C'] != 'uniqsql_id') $bMatchColumn = false;
        if($aHeading['D'] != 'class_id') $bMatchColumn = false;
        if($aHeading['E'] != 'agent_name') $bMatchColumn = false;
        if($aHeading['F'] != 'class_string') $bMatchColumn = false;
        if($aHeading['G'] != 'orig_sqltext') $bMatchColumn = false;

        if($bMatchColumn == false){

            $aResult = array('success' => false, 'error' => '컬럼의 구성이나 순서가 정해진 양식과 맞지 않습니다.');
            $this->output->set_content_type('application/json')->set_output(json_encode($aResult));
            return ;
        }        

        $r = -1;
        $aData = array();
        for ($nRow = 2; $nRow <= $highestRow; ++$nRow) {

            $aDataRow = $objWorksheet->rangeToArray('A'.$nRow.':'.$highestColumn.$nRow,null, true, true, true);

            ++$r;
            foreach($aHeading as $sColKey => $sColHeading) {

                $aData[$r][$sColHeading] = $aDataRow[$nRow][$sColKey];
            }
        }

        foreach($aData as $nIdx => $aRow){
            
            if($sServer != $aRow['agent_id']){

                $aRow['agent_id'] = $sServer;

                $this->tbl_whitesql_list->add(array(
                    'agent_id' => $aRow['agent_id'],
                    'uniqsql_id' => $aRow['uniqsql_id'],
                    'class_id' => $aRow['class_id'],
                    'reg_time' => time(),
                    'last_work_time' => time(),
                    'last_work_user_id' => ''
                ));
            }
            else if($sServer == $aRow['agent_id'] && !$aRow['whitesql_id']){
                
                $this->tbl_whitesql_list->add(array(
                    'agent_id' => $aRow['agent_id'],
                    'uniqsql_id' => $aRow['uniqsql_id'],
                    'class_id' => $aRow['class_id'],
                    'reg_time' => time(),
                    'last_work_time' => time(),
                    'last_work_user_id' => ''
                ));
            }
        }

        // unlink(UPLOAD_TEMP_DIR.$filename);

        if(!$aResult) $aResult = array('success' => true);

        //JSON 양식 출력
        $this->output->set_content_type('application/json')->set_output(json_encode($aResult));
    }

    public function getServerList(){

        //필요한 모델을 로드한다.
        $this->load->model(array(
            'tbl_agent_info'
        ));

        //에이전트 그룹정보와 조인한 tbl_agent_info를 가져온다.
        $aData = $this->tbl_agent_info->joinAgentGroupInfo()->select(array('group_name'), false)->get();

        //트리의 최상위 노드
        $aTree = array();

        foreach($aData as $nIdx => $aRow){

            //호스트 그룹 노드 설정
            $aTree[] = array(
                'id'   => 'server-'.$aRow['agent_id'],
                'text' => $aRow['agent_name'],
                'leaf' => true
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aTree));
    }

    public function del(){

        //파라미터를 받는다.
        $sDelList = $this->input->post('ids');

        //테이블 모델 로드
        $this->load->model(array(
            'tbl_whitesql_list',
            'tbl_convsql_list',
            'tbl_uniqsql_execution_count'
        ));

        $aDelList = explode(",", $sDelList);
        
        foreach($aDelList as $nIdx => $nId){

            //삭제 전 데이터를 가져온다.
            $aData = array_pop($this->tbl_whitesql_list->get($nId));

            //정책 삭제
            $this->tbl_whitesql_list->del($nId);

            //정책 삭제 합니다.
            $this->tbl_uniqsql_execution_count->del($aData['uniqsql_id'], $aData['agent_id']);

            //White SQL에 연결된 Convert SQL도 삭제
            foreach($this->tbl_convsql_list->setWhiteSQLId($nId)->get() as $nIdx => $aRow){

                $this->tbl_convsql_list->del($aRow['convsql_id']);
            }

            //정책 히스토리 저장
            writePolicyHistory(POLICY_WHITE_SQL, 'del', $aData['whitesql_id'], $aData['agent_id'], 'White SQL deleted', json_encode($aData));
        }

        //결과 데이터 설정
        $sResult = "success";
        $sMessage = "삭제 완료";

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }

    public function approval(){

        //파라미터를 받는다.
        $sSQLList    = $this->input->post('ids');
        $nApprovalYn = $this->input->post('approval_yn');

        //테이블 모델 로드
        $this->load->model('tbl_whitesql_list');

        $aSQLList = explode(",", $sSQLList);
        
        foreach($aSQLList as $nIdx => $nId){

            $aUser = getUserInfo();

            //삭제 전 데이터를 가져온다.
            $aData = array_pop($this->tbl_whitesql_list->get($nId));

            //승인여부 세팅
            $this->tbl_whitesql_list->mod($nId, array(
                'approval_yn'      => $nApprovalYn ? "1" : "0",
                'approval_time'    => time(),
                'approval_user_id' => $aUser['user_id']
            ));

            //정책 히스토리 저장
            writePolicyHistory(POLICY_WHITE_SQL, 'mod', $aData['whitesql_id'], $aData['agent_id'], 'White SQL '.($nApprovalYn ? "approved" : "unapproved"), json_encode($aData));
        }

        //결과 데이터 설정
        $sResult = "success";
        $sMessage = ($nApprovalYn ? "" : "미") . "승인 완료";

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }

    public function setUsable(){

        //파라미터를 받는다.
        $sSQLList = $this->input->post('ids');
        $nOnOff   = $this->input->post('on_off');

        //테이블 모델 로드
        $this->load->model(array(
            'tbl_whitesql_list',
            'tbl_convsql_list'
        ));

        $aSQLList = explode(",", $sSQLList);
        
        foreach($aSQLList as $nIdx => $nId){

            $aUser = getUserInfo();

            //삭제 전 데이터를 가져온다.
            $aData = array_pop($this->tbl_whitesql_list->get($nId));

            //사용여부 셋팅
            $this->tbl_whitesql_list->mod($nId, array(
                'on_off' => $nOnOff
            ));

            //White SQL에 연결된 Convert SQL도 변경
            foreach($this->tbl_convsql_list->setWhiteSQLId($nId)->get() as $nIdx => $aRow){

                $this->tbl_convsql_list->mod($aRow['convsql_id'], array(
                    'on_off' => $nOnOff
                ));
            }

            //정책 히스토리 저장
            writePolicyHistory(POLICY_WHITE_SQL, 'mod', $aData['whitesql_id'], $aData['agent_id'], 'White SQL is '.($nOnOff ? "enabled" : "disabled"), json_encode($aData));
        }

        //결과 데이터 설정
        $sResult = "success";
        $sMessage = ($nOnOff ? "사용" : "미사용")."처리 완료";

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }
}
/* End of file white_sql.php */
/* Location: ./application/controllers/manage/white_sql.php */