<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* User
*
* User 관련 컨트롤러
*
* @uses     CI_Controller
* @category history
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class User extends CI_Controller {

    /**
     * index
     *
     * 메인 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function index()
	{

        return $this->getGridData();
	}

    /**
     * getSQLGridData
     * 
     * SQL 그리드 데이터를 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getGridData($nUserId = null){

        $this->load->model('tbl_userinfo');

        $this->load->config("system", true);
        $aUserLevel = $this->config->item('user_level', 'system');

        $nTotalCount = 0;

        if($nUserId !== null){

            $aData = array_pop($this->tbl_userinfo->select(array(
                'user_id', 'user_name', 'user_loginid', 'user_email', 
                'user_level', 'user_lastdate', 'use_yn', 'description'
            ))->get($nUserId));

            $this->output->set_content_type('application/json')->set_output(json_encode($aData));
        }
        else {

            $nStartNo = $this->input->get("start");
            $nEndNo = $this->input->get("limit");
            $sSort = $this->input->get("sort");
            $sSearchType = $this->input->get('manage_User-search-mode');
            $sSearchKeyword = $this->input->get('manage_User-search-keyword');
            
            if($sSearchType && $sSearchKeyword) $this->tbl_userinfo->db->like($sSearchType, $sSearchKeyword);

            $nTotalCount = $this->tbl_userinfo->count();

            if($sSort){ 

                $oSort = array_pop(json_decode($sSort));
                $this->tbl_userinfo->db->order_by($oSort->property, $oSort->direction);
            }
            else {

                $this->tbl_userinfo->db->order_by('user_id', 'desc');   
            }
            
            if($sSearchType && $sSearchKeyword) $this->tbl_userinfo->db->like($sSearchType, $sSearchKeyword);

            $aData = $this->tbl_userinfo->select(array(
                'user_id', 'user_name', 'user_loginid', 'user_email', 
                'user_level', 'user_lastdate', 'use_yn', 'description', 'servers'
            ))->limit($nStartNo, $nEndNo)->get();

            $aList = array();
            foreach($aData as $nIdx => $aRow){

                $aRow['user_level_nm'] = $aRow['user_level'] ? $aUserLevel[$aRow['user_level']] : '입력안됨';
                $aList[] = $aRow;
            }

            $this->output->set_content_type('application/json')->set_output(json_encode(array(
                'list' => $aList,
                'total' => $nTotalCount
            )));
        }
    }

    /**
     * getUserLevelList
     *
     * user level list 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getUserLevelList()
    {

        $this->load->config("system", true);
        $aUserLevel = $this->config->item('user_level', 'system');

        foreach($aUserLevel as $nIdx => $sLevel){
            
            if($nIdx == 10) continue;

            $aList[] = array(
                'id'   => $nIdx,
                'text' => $sLevel
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aList));
    }

    /**
     * checkLoginID
     *
     * 전달 받은 유저 아이디가 존재 하는지 체크한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function checkLoginID(){

        //파라미터를 받는다.
        $sText = $this->input->post('text');

        //모델을 로드한다.
        $this->load->model('tbl_userinfo');

        //맞는값이 들어왔는지 검사.
        if($sText){

            //그룹 정보를 수정한다.
            $aUser = array_pop($this->tbl_userinfo->setLoginId($sText)->getAll());

            if($aUser){
                
                if($aUser['use_yn'] == 1){

                    $sResult = "fail";
                    $sMessage = "이미 존재하는 아이디입니다.";
                }
                else {

                    $sResult = "fail";
                    $sMessage = "사용할 수 없는 아이디입니다.";
                }
            }
            else {

                $sResult = "success";
                $sMessage = "사용할 수 있는 아이디입니다.";
            }
        }
        else {

            $sResult = "fail";
            $sMessage = "유저명을 입력하세요";
        }

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'   => $sResult,
            'message'  => $sMessage
        )));
    }

    /**
     * addUser
     *
     * User를 추가 한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function add(){

        //파라미터를 받는다.      
        $sManageServer    = $this->input->post('manage_server');
        $sUserLoginId     = $this->input->post('user_loginid');
        $sUserPass        = $this->input->post('user_pass');
        $sUserPassConfirm = $this->input->post('user_pass_confirm');
        $sUserName        = $this->input->post('user_name');
        $nUserLevel       = $this->input->post('user_level');
        $sUserEmail       = $this->input->post('user_email');
        $sDescription     = $this->input->post('description');
        // $nUseYn           = $this->input->post('use_yn');

        //모델을 로드한다.
        $this->load->model('tbl_userinfo');
        
        $sResult = null;

        //패스워드가 넘어왔고 두개가 같다면 해쉬한다.
        if(!empty($sUserPass) && !empty($sUserPassConfirm)){

             if($sUserPass == $sUserPassConfirm){

                $this->load->library('PasswordHash', array('iteration_count_log2' => 8, 'portable_hashes' => true), 'HashPassword');
                $sPassword = $this->HashPassword->HashPassword($sUserPass);
            }
            else {

                //결과 데이터 설정
                $sResult = "fail";
                $sMessage = "변경하려는 패스워드 정보가 일치 하지 않습니다.";
            }
        }
        else {

            //결과 데이터 설정
            $sResult = "fail";
            $sMessage = "패스워드 정보가 설정되지 않았습니다.";
        }

        if($sResult != "fail"){

            //유저 정보를 추가 한다.
            $nUserId = $this->tbl_userinfo->add(array(
                'servers'      => $sManageServer ? '['.$sManageServer.']' : '',
                'user_loginid' => $sUserLoginId,
                'user_pass'    => $sPassword,
                'user_name'    => $sUserName,
                'user_level'   => $nUserLevel,
                'user_email'   => $sUserEmail,
                'description'  => $sDescription,
                'use_yn'       => 1
            ));

            //히스토리 추가
            writeWorkHistory('add', 0, 'User added');

            //결과 데이터 설정
            $sResult = "success";
            $sMessage = "입력 완료";
        }

        //결과 메시지를 JSON 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'success' => true,
            'mode'    => 'add',
            'result'  => $sResult,
            'message' => $sMessage,
            'id'      => $nUserId
        )));
    }

    /**
     * mod
     *
     * User를 수정 한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function mod(){

        //파라미터를 받는다.      
        $nUserId          = $this->input->post('user_id');
        $sManageServer    = $this->input->post('manage_server');
        $sUserPass        = $this->input->post('user_pass');
        $sUserPassConfirm = $this->input->post('user_pass_confirm');
        $sUserName        = $this->input->post('user_name');
        $nUserLevel       = $this->input->post('user_level');
        $sUserEmail       = $this->input->post('user_email');
        $sDescription     = $this->input->post('description');
        // $nUseYn           = $this->input->post('use_yn');

        //모델을 로드한다.
        $this->load->model('tbl_userinfo');
        
        //수정할 값을 셋팅한다.
        $aUpdateValue = array(
            'servers'     => $sManageServer ? '['.$sManageServer.']' : '',
            'user_name'   => $sUserName,
            'user_level'  => $nUserLevel,
            'user_email'  => $sUserEmail,
            'description' => $sDescription,
            //'use_yn'      => $nUseYn
        );

        $sResult = null;

        //패스워드가 넘어왔고 두개가 같다면 해쉬한다.
        if(!empty($sUserPass) || !empty($sUserPassConfirm)){

             if($sUserPass == $sUserPassConfirm){

                $this->load->library('PasswordHash', array('iteration_count_log2' => 8, 'portable_hashes' => true), 'HashPassword');
                $sPassword = $this->HashPassword->HashPassword($sUserPass);

                $aUpdateValue = array_merge($aUpdateValue, array('user_pass' => $sPassword));
            }
            else {

                //결과 데이터 설정
                $sResult = "fail";
                $sMessage = "변경하려는 패스워드 정보가 일치 하지 않습니다.";
            }
        }

        if($sResult != "fail"){

            //수정 전 데이터를 가져온다.
            $aOld = array_pop($this->tbl_userinfo->get($nUserId));

            //유저 정보를 수정 한다.
            $this->tbl_userinfo->mod($nUserId, $aUpdateValue);

            //수정 후 데이터를 가져온다.
            $aNew = array_pop($this->tbl_userinfo->get($nUserId));

            //히스토리 추가
            writeWorkHistory('mod', 0, 'User modified', json_encode($aOld), json_encode($aNew));

            //결과 데이터 설정
            $sResult = "success";
            $sMessage = "수정 완료";
        }

        //결과 메시지를 JSON 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'success' => true,
            'mode'    => 'mod',
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }

    /**
     * delUser    
     *
     * User를 삭제 한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function del(){

        //파라미터를 받는다.
        $sUser = $this->input->post('ids');

        //유저 primary key를 얻는다.
        $aUserIds = explode(",", $sUser);

        $aUser = getUserInfo();

        //결과에 따른 메시지 출력
        if(count($aUserIds) > 0){

            if(in_array($aUser['user_id'], $aUserIds)){

                $sResult = "fail";
                $sMessage = "자기 자신을 삭제 할 수 없습니다.";
            }
            else {

                //모델을 로드한다.
                $this->load->model('tbl_userinfo');

                //서버 정보를 삭제한다.
                $this->tbl_userinfo->del($aUserIds);

                //히스토리 추가
                writeWorkHistory('del', 0, 'User deleted');

                //결과 데이터 설정
                $sResult = "success";
                $sMessage = "삭제 처리 완료";
            }
        }
        else {

            //결과 데이터 설정
            $sResult = "fail";
            $sMessage = "선택된 유저가 없습니다.";
        }

        //결과 메시지를 JSON 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'   => $sResult,
            'message'  => $sMessage
        )));
    }
}
/* End of file main.php */
/* Location: ./application/controllers/main/main.php */