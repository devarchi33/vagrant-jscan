<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Server
 *
 * Server management 관련 컨트롤러
 *
 * @uses     CI_Controller
 * @category server
 * @package  WhiteSQL
 * @author   정주원 <jjwcom@nate.com>
 * @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
 * @link
 */
class Server extends CI_Controller
{

    /**
     * index
     *
     * Server_tree 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function index()
    {
        $sNode = $this->input->get('node');

        //security mode config 파일을 불러온다.
        $this->load->config('system', true);

        //security mode 함축 단어 배열을 가져온다.
        $aSecurityModeChar = $this->config->item('mode_char', 'system');

        //server mode 단어 배열을 가져온다.
        $aServerMode  = $this->config->item('server_mode', 'system');
        $aLicense     = $this->config->item('license', 'system');
        $aPrivacyFlag = $this->config->item('privacy_flag', 'system');
        $aSyncFlag    = $this->config->item('sync_flag', 'system');

        $aTree = array();

        if ($sNode == 'root') {

            $aData = getAllowGroup();

            foreach ($aData as $nIdx => $aRow) {

                //호스트 그룹 노드 설정
                $aTree[] = array(
                    'icon'     => '/images/host_group_en.png',
                    'id'       => 'group-'.$aRow['group_id'],
                    'expanded' => true,
                    'text'     => $aRow['group_name']
                );
            }
        } else if (strpos($sNode, 'group') > -1) {

            $nGroupId = str_replace("group-", "", $sNode);
            $aData    = getAllowServer($nGroupId);

            foreach ($aData as $nIdx => $aRow) {

                if ($aRow['status'] == 1) {

                    $sIcon = 'host_en';

                    $sAgentMode = $aServerMode[$aRow['agent_mode']];
                    $sIcon      = 'mode_'.$sAgentMode;
                } else {

                    $sIcon = 'host_dis';
                }

                $sText = $aRow['agent_name'];

                if($aRow['license_expiredate']){

                    $nExpireDate = date("Ymd", strtotime($aRow['license_expiredate']));

                    if(date("Ymd", strtotime("+7 days")) >= $nExpireDate){

                        $sText .= " (".$aRow['license_expiredate'].")";
                    }
                }
                //호스트 그룹 노드 설정
                $aTree[] = array(
                    'id'                 => 'server-'.$aRow['agent_id'],
                    'icon'               => '/images/'.$sIcon.'.png',
                    'text'               => $sText,
                    'leaf'               => true,
                    'name'               => $aRow['agent_name'],
                    'ip'                 => $aRow['ipaddr'],
                    'group_id'           => $aRow['group_id'],
                    'port'               => $aRow['port'],
                    'sync_flag'          => @$aSyncFlag[$aRow['sync_flag']],
                    'agent_mode'         => @$aServerMode[$aRow['agent_mode']],
                    'privacy_flag'       => $aRow['privacy_flag'],
                    'rs_logging_yn'      => $aRow['rs_logging_yn'],
                    'license_check_nm'   => @$aLicense[$aRow['license_check']],
                    'license_check'      => $aRow['license_check'],
                    'license_status'     => $aRow['license_status'],
                    'license_expiredate' => $aRow['license_expiredate'],
                    'license_key'        => $aRow['license_key'],
                    'server_type'        => $aRow['server_type'],
                    'sid'                => $aRow['sid'],
                    'db_user_id'         => $aRow['db_user_id'],
                    'db_passwd'          => $aRow['db_passwd'],
                    'db_kind'            => $aRow['db_kind']
                );
            }
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aTree));
    }

    /**
     * databases
     *
     * tbl_dbconn 테이블의 데이터베이스 목록을 불러온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function databases()
    {
        $sNode = $this->input->get('node');

        //security mode config 파일을 불러온다.
        $this->load->config('system', true);

        $aTree = array();

        if ($sNode == 'root') {

            $this->load->model('tbl_dbconn');

            $aData = $this->tbl_dbconn->get();

            foreach ($aData as $nIdx => $aRow) {

                //호스트 그룹 노드 설정
                array_push($aTree, array(
                    'icon'      => '/images/host_group_en.png',
                    'id'        => 'database-'.$aRow['dbconn_id'],
                    'leaf'      => true,
                    'text'      => $aRow['dbname'],
                    'dbconn_id' => $aRow['dbconn_id'],
                    'ipaddr'    => $aRow['ipaddr'],
                    'port'      => $aRow['port'],
                    'sid'       => $aRow['sid'],
                    'dbname'    => $aRow['dbname']
                ));
            }
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aTree));
    }

    public function getList()
    {

        $this->load->model('tbl_agent_info');

        $aData = $this->tbl_agent_info->get();

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    /**
     * getServerList
     *
     * server list 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getServerList()
    {
        //security mode config 파일을 불러온다.
        $this->load->config('system', true);

        //security mode 함축 단어 배열을 가져온다.
        $aServerMode  = $this->config->item('server_mode', 'system');
        $aLicense     = $this->config->item('license', 'system');
        $aPrivacyFlag = $this->config->item('privacy_flag', 'system');
        $aSyncFlag    = $this->config->item('sync_flag', 'system');

        //필요한 모델을 로드한다.
        $this->load->model(array(
            'tbl_agent_info',
            'tbl_agentgroup_info'
        ));

        //에이전트 그룹정보와 조인한 tbl_agent_info를 가져온다.
        $this->tbl_agent_info->db->where('del_yn', '0');
        $aData = $this->tbl_agent_info->joinAgentGroupInfo()->select(array('group_name'), false)->get();

        //트리의 최상위 노드
        $aTree     = array();
        $aChildren = array();
        foreach ($aData as $nIdx => $aRow) {

            //호스트 그룹 노드 설정
            $aChildren[$aRow['group_id']][] = array(
                'id'                 => 'server-'.$aRow['agent_id'],
                'icon'               => '/images/host_'.($aRow['status'] == 1 ? 'en' : 'dis').'.png',
                'name'               => $aRow['agent_name'],
                'ip'                 => $aRow['ipaddr'],
                'group_id'           => $aRow['group_id'],
                'port'               => $aRow['port'],
                'sync_flag'          => @$aSyncFlag[$aRow['sync_flag']],
                'agent_mode'         => @$aServerMode[$aRow['agent_mode']],
                'privacy_flag'       => $aRow['privacy_flag'],
                'rs_logging_yn'      => $aRow['rs_logging_yn'],
                'license_check_nm'   => @$aLicense[$aRow['license_check']],
                'license_check'      => $aRow['license_check'],
                'license_key'        => $aRow['license_key'],
                'license_expiredate' => $aRow['license_expiredate'],
                'leaf'               => true
            );
        }

        //에이전트 그룹정보를 가져온다.
        $aData = $this->tbl_agentgroup_info->get();

        foreach ($aData as $nIdx => $aRow) {

            //호스트 그룹 노드 설정
            $aTree[] = array(
                'id'       => 'group-'.$aRow['group_id'],
                'icon'     => '/images/host_group_en.png',
                'name'     => $aRow['group_name'],
                'expanded' => true,
                'children' => @$aChildren[$aRow['group_id']],
                'leaf'     => @$aChildren[$aRow['group_id']] ? false : true
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aTree));
    }

    /**
     * getServerInfo
     *
     * server 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getServerInfo()
    {
        //파라미터를 받는다.
        $sServer = $this->input->post('server');

        //에이전트 primary key를 얻는다.
        $nAgentId = str_replace("server-", "", $sServer);

        //필요한 모델을 로드한다.
        $this->load->model('tbl_agent_info');

        //에이전트 정보를 가져온다.
        $aData = array_pop($this->tbl_agent_info->get($nAgentId));

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    /**
     * getGroupList
     *
     * group list 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getGroupList()
    {
        //필요한 모델을 로드한다.
        $this->load->model(array(
            'tbl_agentgroup_info'
        ));

        //에이전트 그룹정보를 가져온다.
        $aData = $this->tbl_agentgroup_info->get();

        $aTree = array();

        foreach ($aData as $nIdx => $aRow) {

            //호스트 그룹 노드 설정
            $aTree[] = array(
                'id'   => $aRow['group_id'],
                'text' => $aRow['group_name']
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aTree));
    }

    /**
     * getLicenseList
     *
     * 라이센스 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getLicenseList()
    {
        //config 파일을 불러온다.
        $this->load->config('system', true);

        //security mode 함축 단어 배열을 가져온다.
        $aLicense = $this->config->item('license', 'system');

        $aTree = array();

        foreach ($aLicense as $nIdx => $sVal) {

            //호스트 그룹 노드 설정
            $aTree[] = array(
                'id'   => $nIdx,
                'text' => $sVal
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aTree));
    }


    /**
     * addGroup
     *
     * server group을 추가한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function addGroup()
    {

        //파라미터를 받는다.
        $sText = $this->input->post('text');

        //모델을 로드한다.
        $this->load->model('tbl_agentgroup_info');

        //맞는값이 들어왔는지 검사.
        if ($sText) {

            //그룹 정보를 수정한다.
            $nGroupId = $this->tbl_agentgroup_info->add(array(
                'group_name' => $sText
            ));

            writeWorkHistory('add', 0, 'Server Group added');

            $sResult  = "success";
            $sMessage = "저장 완료";
        } else {

            $nGroupId = 0;
            $sResult  = "fail";
            $sMessage = "그룹명을 입력하세요";
        }

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'   => $sResult,
            'message'  => $sMessage,
            'group_id' => 'group-'.$nGroupId
        )));
    }

    /**
     * checkServerName
     *
     * 전달 받은 서버 네임이 존재 하는지 체크한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function checkServerName()
    {

        //파라미터를 받는다.
        $sText = $this->input->post('text');

        //모델을 로드한다.
        $this->load->model('tbl_agent_info');

        //맞는값이 들어왔는지 검사.
        if ($sText) {

            //그룹 정보를 수정한다.
            $aAgent = array_pop($this->tbl_agent_info->setAgentName($sText)->get());

            if ($aAgent) {

                $sResult  = "fail";
                $sMessage = "이미 존재하는 서버명입니다.";
            } else {

                $sResult  = "success";
                $sMessage = "사용할 수 있는 서버명입니다.";
            }
        } else {

            $sResult  = "fail";
            $sMessage = "서버명을 입력하세요";
        }

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }

    /**
     * checkDatabaseName
     *
     * 전달 받은 디비 네임이 존재 하는지 체크한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function checkDatabaseName()
    {

        //파라미터를 받는다.
        $sText = $this->input->post('text');

        //모델을 로드한다.
        $this->load->model('tbl_dbconn');

        //맞는값이 들어왔는지 검사.
        if ($sText) {

            //그룹 정보를 수정한다.
            $aAgent = array_pop($this->tbl_dbconn->setDBName($sText)->get());

            if ($aAgent) {

                $sResult  = "fail";
                $sMessage = "이미 존재하는 디비명입니다.";
            } else {

                $sResult  = "success";
                $sMessage = "사용할 수 있는 디비명입니다.";
            }
        } else {

            $sResult  = "fail";
            $sMessage = "디비명을 입력하세요";
        }

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }


    /**
     * modGroup
     *
     * server 정보를 변경한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function modGroup()
    {

        //파라미터를 받는다.
        $sServer = $this->input->post('server');
        $sText   = $this->input->post('text');

        //그룹 primary key를 얻는다.
        $nGroupId = str_replace("group-", "", $sServer);

        //모델을 로드한다.
        $this->load->model('tbl_agentgroup_info');

        //맞는값이 들어왔는지 검사.
        if ($sText) {

            //수정 전 데이터를 가져온다.
            $aOld = array_pop($this->tbl_agentgroup_info->get($nGroupId));

            //그룹 정보를 수정한다.
            $this->tbl_agentgroup_info->mod($nGroupId, array(
                'group_name' => $sText
            ));

            //수정 후 데이터를 가져온다.
            $aNew = array_pop($this->tbl_agentgroup_info->get($nGroupId));

            writeWorkHistory('mod', 0, 'Server Group modified', json_encode($aOld), json_encode($aNew));

            $sResult  = "success";
            $sMessage = "저장 완료";
        } else {

            $sResult  = "fail";
            $sMessage = "그룹명을 입력하세요";
        }

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }

    /**
     * delGroup
     *
     * server group을 삭제 한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function delGroup()
    {

        //파라미터를 받는다.
        $sServer = $this->input->post('server');

        //그룹 primary key를 얻는다.
        $nGroupId = str_replace("group-", "", $sServer);

        //모델을 로드한다.
        $this->load->model(array(
            'tbl_agentgroup_info',
            'tbl_agent_info'
        ));

        $aAgent = $this->tbl_agent_info->setGroupId($nGroupId)->get();

        if (count($aAgent) > 0) {

            $sResult  = "fail";
            $sMessage = "하위에 서버가 있을 경우는 삭제 할 수 없습니다.";
        } else {
            //삭제 전 데이터를 가져온다.
            $aOld = array_pop($this->tbl_agentgroup_info->get($nGroupId));

            //그룹 정보를 삭제 한다.
            $nGroupId = $this->tbl_agentgroup_info->del($nGroupId);

            writeWorkHistory('del', 0, 'Server Group deleted', json_encode($aOld));

            $sResult  = "success";
            $sMessage = "삭제 완료";
        }

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }

    /**
     * addServer
     *
     * server를 추가 한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function addServer()
    {

        //파라미터를 받는다.
        $nGroupId    = $this->input->post('add-server-group-id');
        $sHostName   = $this->input->post('add-server-name');
        $nIp1        = $this->input->post('add-server-ip-1');
        $nIp2        = $this->input->post('add-server-ip-2');
        $nIp3        = $this->input->post('add-server-ip-3');
        $nIp4        = $this->input->post('add-server-ip-4');
        $nPort       = $this->input->post('add-server-port');
        $nLicense    = $this->input->post('add-server-license-check');
        $sExpireDate = $this->input->post('add-server-license-expiredate');
        $sLicenseKey = $this->input->post('add-server-license-key');

        $nServerType = $this->input->post('add-server-type');

        if ($nServerType == SERVER_TYPE_DBMON) {

            $nDBKind      = $this->input->post('add-server-db-kind');
            $sDBSID       = $this->input->post('add-server-db-sid', '');
            $sDBUser      = $this->input->post('add-server-db-user');
            $sDBPass      = $this->input->post('add-server-db-pass');
            $nPrivacyFlag = '0';
            $nLoggingYn   = '0';
        } else if ($nServerType == SERVER_TYPE_AGENT) {

            $nDBKind      = '0';
            $sDBSID       = '';
            $sDBUser      = '';
            $sDBPass      = '';
            $nPrivacyFlag = $this->input->post('add-server-privacy-flag', '0');
            $nLoggingYn   = $this->input->post('add-server-logging-yn', '0');
        }

        $nIpAddress = $nIp1.".".$nIp2.".".$nIp3.".".$nIp4;

        //모델을 로드한다.
        $this->load->model(array(
            'tbl_agent_info',
            'tbl_dbconn',
            'tbl_agent_dbconn'
        ));

        $bSave     = true;
        $bSuccess  = true;
        $nDBConnId = null;
        if ($nServerType == SERVER_TYPE_DBMON) {

            //system환경 설정을 가져온다.
            $this->load->config('system', true);

            //DB종류 배열을 가져온다.
            $aDBKind = $this->config->item('db_kind', 'system');
            $sDBName = $aDBKind[$nDBKind]['name'];

            $sDBConnUrl = "jdbc:".$sDBName.":thin:@".$nIpAddress.":".$nPort.":".$sDBSID;
            $sHashKey   = md5($nIpAddress.":".$nPort.":".$sDBSID);

            $nDBConnId = $this->tbl_dbconn->add(array(
                'dbconn_id'      => $sHashKey,
                'dbconn_url'     => $sDBConnUrl,
                'dbconn_account' => $sDBUser,
                'ipaddr'         => $nIpAddress,
                'port'           => $nPort,
                'sid'            => $sDBSID,
                'dbname'         => $sDBName."@".$nIpAddress
            ));

            if (!$nDBConnId) {

                $bSave = false;
            }
        }

        //서버 정보를 추가 한다.
        $nAgentId = $this->tbl_agent_info->add(array(
            'group_id'           => $nGroupId,
            'agent_name'         => $sHostName,
            'ipaddr'             => $nIpAddress,
            'port'               => $nPort,
            'status'             => '1',
            'agent_mode'         => '0',
            'privacy_flag'       => $nPrivacyFlag,
            'rs_logging_yn'      => $nLoggingYn,
            'license_check'      => $nLicense,
            'license_expiredate' => $sExpireDate,
            'license_key'        => $sLicenseKey,
            'server_type'        => $nServerType,
            'db_kind'            => $nDBKind,
            'sid'                => $sDBSID,
            'db_user_id'         => $sDBUser,
            'db_passwd'          => $sDBPass
        ));

        writeWorkHistory('add', $nAgentId, 'Server added');

        //결과 데이터 설정
        $sResult  = "success";
        $sMessage = "추가 완료되었습니다.";

        if ($nDBConnId && $nAgentId) {

            $this->tbl_agent_dbconn->add(array(
                'agent_id'  => $nAgentId,
                'dbconn_id' => $nDBConnId
            ));
        }

        //결과 메시지를 JSON 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'success' => $bSuccess,
            'mode'    => 'add',
            'result'  => $sResult,
            'message' => $sMessage,
            'id'      => $nAgentId
        )));
    }

    /**
     * modServer
     *
     * server를 추가 한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function modServer()
    {

        //파라미터를 받는다.
        $sServer     = $this->input->post('add-server-id');
        $nGroupId    = $this->input->post('add-server-group-id');
        $sHostName   = $this->input->post('add-server-name');
        $nIp1        = $this->input->post('add-server-ip-1');
        $nIp2        = $this->input->post('add-server-ip-2');
        $nIp3        = $this->input->post('add-server-ip-3');
        $nIp4        = $this->input->post('add-server-ip-4');
        $nPort       = $this->input->post('add-server-port');
        $nLicense    = $this->input->post('add-server-license-check');
        $sExpireDate = $this->input->post('add-server-license-expiredate');
        $sLicenseKey = $this->input->post('add-server-license-key');

        $nServerType = $this->input->post('add-server-type');

        if ($nServerType == SERVER_TYPE_DBMON) {

            $nDBKind      = $this->input->post('add-server-db-kind');
            $sDBSID       = $this->input->post('add-server-db-sid');
            $sDBUser      = $this->input->post('add-server-db-user');
            $sDBPass      = $this->input->post('add-server-db-pass');
            $nPrivacyFlag = '0';
            $nLoggingYn   = '0';
        } else if ($nServerType == SERVER_TYPE_AGENT) {

            $nDBKind      = '0';
            $sDBSID       = '';
            $sDBUser      = '';
            $sDBPass      = '';
            $nPrivacyFlag = $this->input->post('add-server-privacy-flag', '0');
            $nLoggingYn   = $this->input->post('add-server-logging-yn', '0');
        }

        //에이전트 primary key를 얻는다.
        $nAgentId = str_replace("server-", "", $sServer);

        //아이피 주소를 합친다.
        $nIpAddress = $nIp1.".".$nIp2.".".$nIp3.".".$nIp4;

        //모델을 로드한다.
        $this->load->model('tbl_agent_info');

        //수정 전 데이터를 가져온다.
        $aOld = array_pop($this->tbl_agent_info->get($nAgentId));

        //서버 정보를 수정 한다.
        $this->tbl_agent_info->mod($nAgentId, array(
            'group_id'           => $nGroupId,
            'agent_name'         => $sHostName,
            'ipaddr'             => $nIpAddress,
            'port'               => $nPort,
            'privacy_flag'       => $nPrivacyFlag,
            'rs_logging_yn'      => $nLoggingYn,
            'license_check'      => $nLicense,
            'license_expiredate' => $sExpireDate,
            'license_key'        => $sLicenseKey,
            'server_type'        => $nServerType,
            'db_kind'            => $nDBKind,
            'sid'                => $sDBSID,
            'db_user_id'         => $sDBUser,
            'db_passwd'          => $sDBPass
        ));

        //수정 후 데이터를 가져온다.
        $aNew = array_pop($this->tbl_agent_info->get($nAgentId));

        //히스토리 추가
        writeWorkHistory('mod', $nAgentId, 'Server modified', json_encode($aOld), json_encode($aNew));

        //결과 데이터 설정
        $sResult  = "success";
        $sMessage = "수정 완료";

        //결과 메시지를 JSON 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'success' => true,
            'mode'    => 'mod',
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }

    /**
     * modDatabase
     *
     * database를 수 한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function modDatabase()
    {

        //파라미터를 받는다.
        $nDatabase     = $this->input->post('add-database-id');
        $sDatabaseName = $this->input->post('add-database-name');

        //모델을 로드한다.
        $this->load->model('tbl_dbconn');

        //수정 전 데이터를 가져온다.
        $aOld = array_pop($this->tbl_dbconn->get($nDatabase));

        //서버 정보를 수정 한다.
        $this->tbl_dbconn->mod($nDatabase, array(
            'dbname' => $sDatabaseName
        ));

        //수정 후 데이터를 가져온다.
        $aNew = array_pop($this->tbl_dbconn->get($nDatabase));

        //히스토리 추가
        writeWorkHistory('mod', $nDatabase, 'Database modified', json_encode($aOld), json_encode($aNew));

        //결과 데이터 설정
        $sResult  = "success";
        $sMessage = "수정 완료";

        //결과 메시지를 JSON 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'success' => true,
            'mode'    => 'mod',
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }

    /**
     * delServer
     *
     * server를 삭제 한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function delServer()
    {

        //파라미터를 받는다.
        $sServer = $this->input->post('server');

        //서버 primary key를 얻는다.
        $nAgentId = str_replace("server-", "", $sServer);

        //모델을 로드한다.
        $this->load->model('tbl_agent_info');

        //삭제 전 데이터를 가져온다.
        $aOld = array_pop($this->tbl_agent_info->get($nAgentId));

        //서버 정보를 삭제한다.
        $this->tbl_agent_info->del($nAgentId);

        //히스토리 추가
        writeWorkHistory('del', $nAgentId, 'Server deleted', json_encode($aOld));

        //결과 데이터 설정
        $sResult  = "success";
        $sMessage = "삭제 완료";

        //결과 메시지를 JSON 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }

    /**
     * changeServerMode
     *
     * server의 security_mode를 설정한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function changeServerMode()
    {

        //파라미터를 받는다.
        $sServer = $this->input->post('server');
        $sMode   = $this->input->post('mode', 0);

        $nMode = constant('AGENT_MODE_'.strtoupper($sMode));

        //서버 primary key를 얻는다.
        $nAgentId = str_replace("server-", "", $sServer);

        //모델을 로드한다.
        $this->load->model('tbl_agent_info');

        //socket helper를 로드한다.
        $this->load->helper('cmd_socket');

        $aAgent = array_pop($this->tbl_agent_info->get($nAgentId));

        //에이전트에 동기화 요청
        $aResult = syncPolicy($aAgent);

        //결과에 따른 메시지 출력
        if ($aResult['result'] == true) {

            //서버의 모니터링 모드를 수정 한다.
            $this->tbl_agent_info->mod($nAgentId, array(
                'agent_mode' => (string)$nMode
            ));

            //소켓에 보낼 파라미터
            $sParams = $nAgentId.":".$nMode.":0";

            $aNew = array_pop($this->tbl_agent_info->get($nAgentId));

            //히스토리 추가
            writeWorkHistory('mod', $nAgentId, 'Server agent mode modified', json_encode($aAgent), json_encode($aNew));

            //결과 데이터 설정
            $sResult  = "success";
            $sMessage = "운영 모드 변경 완료 - ".ucfirst($sMode);

        } else {

            //결과 데이터 설정
            $sResult  = "fail";
            $sMessage = $aResult['message'];
        }

        //결과 메시지를 JSON 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }

    /**
     * syncPolicy
     *
     * 서버의 정책을 동기화 한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function syncPolicy()
    {

        //파라미터를 받는다.
        $sServer = $this->input->post('server');
        $sCmd    = $this->input->post('cmd', 'Policies');

        //서버 primary key를 얻는다.
        $nAgentId = str_replace("server-", "", $sServer);

        //히스토리 추가
        writeWorkHistory('mod', $nAgentId, 'Server policy sync');

        //socket helper를 로드한다.
        $this->load->helper('cmd_socket');

        //소켓에 보낼 파라미터
        $sParams = $nAgentId;

        //에이전트 모델 로드
        $this->load->model('tbl_agent_info');

        $aAgent = array_pop($this->tbl_agent_info->get($nAgentId));

        //에이전트에 동기화 요청
        $aResult = syncPolicy($aAgent);

        // //모델을 로드한다.
        $this->load->model('tbl_policy_list');

        $bChanged = false;

        //서버의 모니터링 모드를 수정 한다.
        $aAgents = $this->tbl_policy_list->setAgentId($nAgentId)->get();
        foreach ($aAgents as $nIdx => $aRow) {

            if ($aRow['state'] == 'A' || $aRow['state'] == 'M') {

                $bChanged = true;
                $this->tbl_policy_list->mod($aRow['policy_id'], array(
                    'sync_flag'      => '1',
                    'sync_succ_flag' => '1',
                    'state'          => 'N'
                ));
            } else if ($aRow['state'] == 'D') {

                $bChanged = true;
                $this->tbl_policy_list->mod($aRow['policy_id'], array(
                    'sync_flag'      => '1',
                    'sync_succ_flag' => '1',
                    'del_yn'         => '1'
                ));
            }
        }

        //system환경 설정을 가져온다.
        $this->load->config('queue', true);

        //DB종류 배열을 가져온다.
        $keyMQSync = $this->config->item('mq_sync', 'queue');

        $mqSync = msg_get_queue($keyMQSync, 0600);

        msg_send($mqSync, 1, $sCmd, true, true, $msg_err);

        //결과에 따른 메시지 출력
        if ($aResult['result'] == true) {

            //결과 데이터 설정
            $sResult  = "success";
            $sMessage = $aResult['message'];
        } else {

            //결과 데이터 설정
            $sResult  = "fail";
            $sMessage = $aResult['message'];
        }

        //결과 메시지를 JSON 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }

    /**
     * getDBKind
     *
     * 디비 종류 리스트를 출력한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getDBKind()
    {

        $aList = array();

        //system환경 설정을 가져온다.
        $this->load->config('system', true);

        //DB종류 배열을 가져온다.
        $aDBKind = $this->config->item('db_kind', 'system');
        foreach ($aDBKind as $sKey => $aDB) {

            array_push($aList, array(
                'id'   => $sKey,
                'text' => $aDB['name'],
                'port' => $aDB['port']
            ));
        }
        $this->output->set_content_type('application/json')->set_output(json_encode($aList));
    }
}
/* End of file server.php */
/* Location: ./application/controllers/manage/server.php */