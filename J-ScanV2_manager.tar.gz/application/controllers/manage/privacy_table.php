<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Privacy_table
*
* Privacy_table 클래스
*
* @uses     CI_Controller
* @category log
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class Privacy_table extends CI_Controller {

    /**
     * index
     *
     * 메인 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function index()
	{

        return $this->getGridData();
	}

    /**
     * getListData
     * 
     * 정책 그리드 데이터를 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getListData(){
        
        //파라미터를 받는다.
        $sServer = $this->input->get('server');
        $nStartNo = $this->input->get("start");
        $nEndNo = $this->input->get("limit");
        $sSort = $this->input->get("sort");
        $sSearchMode = $this->input->get('manage_SQLPolicy-search-mode');
        $sSearchKeyword = $this->input->get('manage_SQLPolicy-search-keyword');

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $aServers = getServerList($sServer);

        //테이블 모델 로드
        $this->load->model('tbl_privacytbl_list');

        /**
         * 
         * 리스트의 토탈 갯수를 구한다.
         */

        //전체 로그 갯수
        $nTotalCount = 0;

        //서버정보가 있을경우 조건절에 서버 추가.
        if($aServers) $this->tbl_privacytbl_list->setAgentId($aServers);

        //검색어가 있을 경우 like 검색 추가.
        if($sSearchMode && $sSearchKeyword){

            $this->tbl_privacytbl_list->setTableName($sSearchKeyword);  
        }
        
        $this->tbl_privacytbl_list->select('
            COUNT(1) as cnt
        ', true);

        //토탈 갯수를 구한다.
        $aTotal = array_pop($this->tbl_privacytbl_list->get());

        /**
         * 
         * 리스트의 데이터를 구한다.
         */

        //소팅에 대한 명령이 들어오면 상황에 맞게 order by 해준다.
        if($sSort){ 

            $oSort = array_pop(json_decode($sSort));
            $this->tbl_privacytbl_list->db->order_by($oSort->property, $oSort->direction);
        }
        
        //서버정보가 있을경우 조건절에 서버 추가.
        if($aServers) $this->tbl_privacytbl_list->setAgentId($aServers);

        //검색어가 있을 경우 like 검색 추가.
        if($sSearchMode && $sSearchKeyword){

            $this->tbl_privacytbl_list->setTableName($sSearchKeyword);  
        }

        //최근데이터를 가장 앞으로 보여준다.
        $this->tbl_privacytbl_list->db->order_by('privacytbl_id', 'DESC');

        //SELECT할 필드를 셋팅한다.
        $this->tbl_privacytbl_list->select(array(
            'privacytbl_id',
            'privacytbl_name',
            'privacytbl',
            'IF(IFNULL(reg_time, 0) = 0, "", DATE_FORMAT(FROM_UNIXTIME(reg_time), "%Y-%m-%d %H:%i:%s")) AS reg_time',
            'reg_user_id',
            'user_name',
            'state',
            'sync_flag',
            'sync_succ_flag',
            'sync_time',
            'sync_user_id',
            'privacy.last_work_time',
            'privacy.last_work_user_id'
        ));

        //조건에 따른 데이터를 통계테이블에서 가져온다
        $aData = $this->tbl_privacytbl_list->joinUserInfo()->get();

        $aList = array();
        foreach($aData as $nIdx => $aRow){
            $aRow['active'] = false;
            $aList[] = $aRow;
        }

        //JSON 양식 출력
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'list' => $aList,
            'total' => $aTotal['cnt']
        )));
    }

    /**
     * getUniqSQLTableList
     * 
     * UniqSQL을 통해 얻어진 테이블 정보를 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getUniqSQLTableList(){
        
        //파라미터를 받는다.
        $sServer = $this->input->get('server');
        $nStartNo = $this->input->get("start");
        $nEndNo = $this->input->get("limit");
        $sSort = $this->input->get("sort");
        $sSearchKeyword = $this->input->get('manage_PrivacyTable-Add-search-keyword');

        //테이블 모델 로드
        $this->load->model('tbl_uniqsql_tables');

        /**
         * 
         * 리스트의 토탈 갯수를 구한다.
         */

        //전체 로그 갯수
        $nTotalCount = 0;

        //검색어가 있을 경우 like 검색 추가.
        if($sSearchKeyword){

            $this->tbl_uniqsql_tables->setTableName($sSearchKeyword);  
        }
        
        $this->tbl_uniqsql_tables->select('
            COUNT(1) as cnt
        ', true);

        //토탈 갯수를 구한다.
        $aTotal = array_pop($this->tbl_uniqsql_tables->get());

        /**
         * 
         * 리스트의 데이터를 구한다.
         */

        //소팅에 대한 명령이 들어오면 상황에 맞게 order by 해준다.
        if($sSort){ 

            $oSort = array_pop(json_decode($sSort));
            $this->tbl_uniqsql_tables->db->order_by($oSort->property, $oSort->direction);
        }

        //검색어가 있을 경우 like 검색 추가.
        if($sSearchKeyword){

            $this->tbl_uniqsql_tables->setTableName($sSearchKeyword);  
        }

        //최근데이터를 가장 앞으로 보여준다.
        $this->tbl_uniqsql_tables->db->order_by('uniqsqltbl_id', 'DESC');

        $this->tbl_uniqsql_tables->select(array(
            'uniqsqltbl_id',
            'tbl_name'
        ), true);

        //조건에 따른 데이터를 통계테이블에서 가져온다
        $aList = $this->tbl_uniqsql_tables->get();

        //JSON 양식 출력
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'list' => $aList,
            'total' => $aTotal['cnt']
        )));
    }

    /**
     * getUniqSQLTableListByQuery
     * 
     * UniqSQL을 통해 얻어진 테이블 정보를 주어진 쿼리를 통해 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getUniqSQLTableListByQuery(){
        
        //파라미터를 받는다.
        $sQuery = $this->input->get('query');

        //테이블 모델 로드
        $this->load->model('tbl_uniqsql_tables');

        $this->tbl_uniqsql_tables->select(array(
            'uniqsqltbl_id',
            'tbl_name'
        ), true);

        //검색어가 있을 경우 like 검색 추가.
        if($sQuery){

            $this->tbl_uniqsql_tables->setTableName($sQuery);  
        }

        //최근데이터를 가장 앞으로 보여준다.
        $this->tbl_uniqsql_tables->withoutPrivacyTable($sQuery);
        $this->tbl_uniqsql_tables->db->order_by('tbl_name', 'ASC');
        $this->tbl_uniqsql_tables->db->group_by('tbl_name');
    

        //조건에 따른 데이터를 통계테이블에서 가져온다
        $aList = array();
        foreach($this->tbl_uniqsql_tables->get() as $nIdx => $aRow){

            array_push($aList, array(
                'id' => $aRow['uniqsqltbl_id'],
                'text' => $aRow['tbl_name']
            ));
        }

        //JSON 양식 출력
        $this->output->set_content_type('application/json')->set_output(json_encode($aList));
    }

/**
     * getPrivacyTableListByQuery
     * 
     * Privacy테이블 정보를 주어진 쿼리를 통해 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getPrivacyTableListByQuery(){
        
        //파라미터를 받는다.
        $sQuery = $this->input->get('query');

        //테이블 모델 로드
        $this->load->model('tbl_privacytbl_list');

        //검색어가 있을 경우 like 검색 추가.
        if($sQuery){

            $this->tbl_privacytbl_list->setTableName($sQuery);  
        }

        //최근데이터를 가장 앞으로 보여준다.
        $this->tbl_privacytbl_list->select(array(
            'privacytbl_id',
            'privacytbl'
        ), true);

        $this->tbl_privacytbl_list->db->order_by('privacytbl', 'ASC');
        $this->tbl_privacytbl_list->db->group_by('privacytbl');


        //조건에 따른 데이터를 통계테이블에서 가져온다
        $aList = array();
        foreach($this->tbl_privacytbl_list->get() as $nIdx => $aRow){

            array_push($aList, array(
                'id'   => $aRow['privacytbl_id'],
                'text' => $aRow['privacytbl']
            ));
        }

        //JSON 양식 출력
        $this->output->set_content_type('application/json')->set_output(json_encode($aList));
    }

    /**
     * get
     * 
     * 정책 내용을 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function get($nPolicyId){
        
        //테이블 모델 로드
        $this->load->model('tbl_privacytbl_list');

        //SELECT할 필드를 셋팅한다.
        $this->tbl_privacytbl_list->select(array(
            'policy_id',
            'policy_name',
            'policy_type',
            'policy_properties',
            'agent_id',
            'alarm_level',
            'block',
            'IF(IFNULL(reg_time, 0) = 0, "", DATE_FORMAT(FROM_UNIXTIME(reg_time), "%Y-%m-%d %H:%i:%s")) AS reg_time',
            'reg_user_id',
            'user_name',
            'state',
            'on_off',
            'sync_flag',
            'sync_succ_flag',
            'sync_time',
            'sync_user_id',
            'pol.last_work_time',
            'pol.last_work_user_id'
        ));

        //조건에 따른 데이터를 통계테이블에서 가져온다
        $aData = array_pop($this->tbl_privacytbl_list->joinUserInfo()->get($nPolicyId));

        //JSON 양식 출력
        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    public function save(){

        //파라미터를 받는다.
        $sServer           = $this->input->post('agent_id');
        $nPrivacyTableId   = $this->input->post('add-privacy-table-id');
        $sPrivacyTableName = $this->input->post('add-privacy-table-name');
        $sPrivacyTable     = $this->input->post('add-privacy-table');

        $nServer = str_replace("server-", "", $sServer);
        
        //테이블 모델 로드
        $this->load->model(array(
            'tbl_privacytbl_list'
        ));

        if($nPrivacyTableId){

            $sBefore = json_encode(array_pop($this->tbl_privacytbl_list->get($nPrivacyTableId)));

            $this->tbl_privacytbl_list->mod($nPrivacyTableId, array(
                'privacytbl_name' => $sPrivacyTableName,
                'privacytbl'      => $sPrivacyTable,
                'agent_id'          => $nServer,
                'state'             => 'A'
            ));
            $sMessage = "수정 완료";

            $sAfter = json_encode(array_pop($this->tbl_privacytbl_list->get($nPrivacyTableId)));

            //정책 히스토리 저장

            writeWorkHistory('mod', $nServer, 'Privacy table was modified', $sBefore, $sAfter, '개인정보 테이블');
        }
        else {

            $nPrivacyTableId = $this->tbl_privacytbl_list->add(array(
                'privacytbl_name' => $sPrivacyTableName,
                'privacytbl'      => $sPrivacyTable,
                'agent_id'        => $nServer,
                'state'           => 'A'
            ));
            $sMessage = "추가 완료";

            writeWorkHistory('add', $nServer, 'Privacy table was added', null, null, '개인정보 테이블');
        }

        //결과 데이터 설정
        $sResult = "success";
        

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }

    public function del(){

        //파라미터를 받는다.
        $sServer = $this->input->post('agent_id');
        $sDelList = $this->input->post('ids');

        $nServer = str_replace("server-", "", $sServer);

        //테이블 모델 로드
        $this->load->model('tbl_privacytbl_list');

        $aDelList = explode(",", $sDelList);
        
        foreach($aDelList as $nIdx => $nId){

            //삭제 전 데이터를 가져온다.
            $aData = array_pop($this->tbl_privacytbl_list->get($nId));

            //정책 삭제
            $this->tbl_privacytbl_list->del($nId);

            //정책 히스토리 저장
            writeWorkHistory('del', $nServer, 'Privacy table was deleted', json_encode($aData), null, '개인정보 테이블');
        }

        //결과 데이터 설정
        $sResult = "success";
        $sMessage = "삭제 완료";

        //결과 메시지를 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'  => $sResult,
            'message' => $sMessage
        )));
    }

    /**
     * syncPrivacyTable
     *
     * 서버의 개인정보 테이블 목록을 동기화 한다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function syncPrivacyTable(){

        //파라미터를 받는다.
        $sServer = $this->input->post('server');

        //서버 primary key를 얻는다.
        $nAgentId = str_replace("server-", "", $sServer);

        //히스토리 추가
        writeWorkHistory('mod', $nAgentId, 'Server privacy table sync');

        //socket helper를 로드한다.
        $this->load->helper('cmd_socket');

        //소켓에 보낼 파라미터
        $sParams = $nAgentId;

        //에이전트 모델 로드
        $this->load->model('tbl_agent_info');

        $aAgent = array_pop($this->tbl_agent_info->get($nAgentId));

        //에이전트에 동기화 요청
        $aResult = syncPolicy($aAgent);

        //결과에 따른 메시지 출력
        if($aResult['result'] == true){
            
            //결과 데이터 설정
            $sResult = "success";
            $sMessage = $aResult['message'];

            // //모델을 로드한다.
            $this->load->model('tbl_privacytbl_list');

            //서버의 모니터링 모드를 수정 한다.
            $aAgents = $this->tbl_privacytbl_list->setAgentId($nAgentId)->get();
            foreach($aAgents as $nIdx => $aRow){

                if($aRow['state'] == 'A' || $aRow['state'] == 'M'){

                    $this->tbl_privacytbl_list->mod($aRow['privacytbl_id'], array(
                        'sync_flag'      => '1',
                        'sync_succ_flag' => '1',
                        'state'          => 'N'
                    ));
                }
                else if($aRow['state'] == 'D'){

                    $this->tbl_privacytbl_list->mod($aRow['privacytbl_id'], array(
                        'sync_flag'      => '1',
                        'sync_succ_flag' => '1',
                        'del_yn'         => '1'
                    ));
                }
            }

        }
        else {

            //결과 데이터 설정
            $sResult = "fail";
            $sMessage = $aResult['message'];
        }

        //결과 메시지를 JSON 출력한다.
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'   => $sResult,
            'message'  => $sMessage
        )));
    }
}
/* End of file privacy_table.php */
/* Location: ./application/controllers/manage/privacy_table.php */