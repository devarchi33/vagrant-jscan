<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Sql
*
* Sql 로그
*
* @uses     CI_Controller
* @category log
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class Sql extends CI_Controller {

    /**
     * index
     *
     * 메인 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function index()
	{

        return $this->getGridData();
	}

    public function getDetailData($nLogId){
        
        $this->load->model('tbl_anal_log');

        //SQL Formatter 라이브러리 로드
        $this->load->library('SqlFormatter');
        
        $aData = array_pop($this->tbl_anal_log->select(array(
            'sqllog_id',
            'sql_type',
            'uniqsql_id',
            'dbconn_id',
            'class_name',
            'class_id',
            'whitesql_id',
            'convsql_id',
            'blocksql_id',
            'sqllog_check',
            'log_reg_date',
            'result_data_saved',
            'privacytbl_yn',
            'anal.agent_mode',
            'request_time',
            'prestmt',
            'sql_str',
            'sql_param',
            'dbconn_url',
            'dbconn_account',
            'class_trace',
            'block_yn',
            'login_id',
            'anal.ipaddr',
            'exec_starttime',
            'exec_elapsedtime',
            'execute_yn',
            'fail_code',
            'result_count',
            'privacy_type',
            'privacy_value',
            'result_data',
            'agent.agent_id',
            'agent.agent_name',
            'policy.policy_id',
            'policy.policy_type',
            'policy.policy_name'
        ), true)->joinAgentInfo()->joinPolicyList()->get($nLogId));

//        $this->output->enable_profiler(TRUE);

        //SQL Format Syntax Highlight 적용
        $aData['sql_str'] = SqlFormatter::format($aData['sql_str']);

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    /**
     * getSQLGridData
     * 
     * SQL 그리드 데이터를 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getGridData($nLogId = null){

        $this->load->model('tbl_anal_log');

        $this->load->config("system", true);
        $aServerMode = $this->config->item('server_mode', 'system');

        $nTotalCount = 0;

        $nStartNo = $this->input->get("start");
        $nEndNo = $this->input->get("limit");
        $sSort = $this->input->get("sort");
        $sServer = $this->input->get('server');
        $sSearchType = $this->input->get('log_SQL-search-type', '');
        $sSearchWhiteSQL = $this->input->get('log_SQL-search-white-sql', '');
        $sSearchConvSQL = $this->input->get('log_SQL-search-conv-sql', '');

        $sFDate = $this->input->get('log_SQL-fdate', date('Y-m-d'));
        $sFTime = $this->input->get('log_SQL-ftime', '00:00:00');
        $sTDate = $this->input->get('log_SQL-tdate', date('Y-m-d'));
        $sTTime = $this->input->get('log_SQL-ttime', '23:59:59');

        $nSearchTime = $this->input->get('log_SQL-search-time');

        $sIp = $this->input->get("log_SQL-ip");
        $sQuery = $this->input->get('log_SQL-query');

        $aHosts = getServerList($sServer);

        if($aHosts) $this->tbl_anal_log->setAgentId($aHosts);
        if($sFDate && $sTDate) $this->tbl_anal_log->setRequestTime($sFDate." ".$sFTime, $sTDate." ".$sTTime);
        if($sIp) $this->tbl_anal_log->setIp($sIp);

        if($nSearchTime){

            $this->tbl_anal_log->db->where('hour(request_time) = '.$nSearchTime);
        }

        if($sSearchWhiteSQL == 'whitesql_y'){

            $this->tbl_anal_log->db->where('whitesql_id > 0');
        }
        else if($sSearchWhiteSQL == 'whitesql_n'){

            $this->tbl_anal_log->db->where('whitesql_id = 0');
        }

        if($sSearchConvSQL == 'convsql_y'){

            $this->tbl_anal_log->db->where('convsql_id > 0');
        }
        else if($sSearchConvSQL == 'convsql_n'){

            $this->tbl_anal_log->db->where('convsql_id = 0');
        }

        if($sQuery){

            if($sSearchType == 'class_name') {

                $this->tbl_anal_log->db->like('class_name', $sQuery);
            }
            else if($sSearchType == 'sql_str'){

                $this->tbl_anal_log->db->like('sql_str', $sQuery);
            }
            else if($sSearchType == 'sql_type'){

                $this->tbl_anal_log->db->like('sql_type', $sQuery);
            }
        }

        $nTotalCount = $this->tbl_anal_log->joinAgentInfo()->liveAgent()->count();

        if($sSort){

            $oSort = array_pop(json_decode($sSort));
            $this->tbl_anal_log->db->order_by($oSort->property, $oSort->direction);
        }
        else {

            $this->tbl_anal_log->db->order_by('anal.log_reg_date', 'desc');
        }

        if($aHosts) $this->tbl_anal_log->setAgentId($aHosts);
        if($sFDate && $sTDate) $this->tbl_anal_log->setRequestTime($sFDate." ".$sFTime, $sTDate." ".$sTTime);

        if($nSearchTime){

            $this->tbl_anal_log->db->where('hour(request_time) = '.$nSearchTime);
        }

        if($sIp) $this->tbl_anal_log->setIp($sIp);

        if($sSearchWhiteSQL == 'whitesql_y'){

            $this->tbl_anal_log->db->where('whitesql_id > 0');
        }
        else if($sSearchWhiteSQL == 'whitesql_n'){

            $this->tbl_anal_log->db->where('whitesql_id = 0');
        }

        if($sSearchConvSQL == 'convsql_y'){

            $this->tbl_anal_log->db->where('convsql_id > 0');
        }
        else if($sSearchConvSQL == 'convsql_n'){

            $this->tbl_anal_log->db->where('convsql_id = 0');
        }

        if($sQuery){

            if($sSearchType == 'class_name') {

                $this->tbl_anal_log->db->like('class_name', $sQuery);
            }
            else if($sSearchType == 'sql_str'){

                $this->tbl_anal_log->db->like('sql_str', $sQuery);
            }
            else if($sSearchType == 'sql_type'){

                $this->tbl_anal_log->db->like('sql_type', $sQuery);
            }
        }

        $aData = $this->tbl_anal_log->select(array(
            'sqllog_id',
            'request_time as request_time', //실행시간
            'agent_name', //서버
            'anal.agent_mode',
            'login_id',
            'sql_type', //유형
            'sql_str as query', //쿼리
            'class_name', //클래스
            'anal.ipaddr as ip', //소스IP
            'IF(execute_yn = 1, "성공" , "실패") as execute_yn', //실행결과
            'IF(whitesql_id > 0, 1, 0) as whitesql_yn', //실행결과
            'IF(convsql_id > 0, 1, 0) as convsql_yn', //실행결과
            'exec_elapsedtime', //수행시간,
            'privacy_type',
            'result_count', //결과건수
            'result_data_saved'
        ))->joinAgentInfo()->liveAgent()->limit($nStartNo, $nEndNo)->get($nLogId);

//        $this->output->enable_profiler(TRUE);

        $aList = array();
        foreach($aData as $nIdx => $aRow){

            $aRow['agent_name'] = $aRow['agent_name'] ? $aRow['agent_name'] : '입력안됨';
            $aRow['agent_mode'] = $aRow['agent_mode'] ? @$aServerMode[$aRow['agent_mode']] : '입력안됨';

            $aList[] = $aRow;
        }

//        $this->output->enable_profiler(TRUE);
//
//        return;
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'list' => $aList,
            'total' => $nTotalCount
        )));
    }

    public function getResultData($nSQLLogId){

        //필요한 모델을 로드한다.
        $this->load->model(array(
            'tbl_sqllog_result_data'
        ));

        $aData = array_pop($this->tbl_sqllog_result_data->get($nSQLLogId));

        $sData = substr($aData['result_data'], 7);

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'data' => $sData
        )));
    }

    public function getServerList(){

        //필요한 모델을 로드한다.
        $this->load->model(array(
            'tbl_agent_info'
        ));

        //에이전트 그룹정보와 조인한 tbl_agent_info를 가져온다.
        $aData = $this->tbl_agent_info->joinAgentGroupInfo()->select(array('group_name'), false)->get();

        //트리의 최상위 노드
        $aTree = array();

        foreach($aData as $nIdx => $aRow){

            //호스트 그룹 노드 설정
            $aTree[] = array(
                'id'   => 'server-'.$aRow['agent_id'],
                'text' => $aRow['agent_name'],
                'leaf' => true
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aTree));
    }

    public function getPolicyTypeList(){

        $this->load->config("policy", true);
        $aType = $this->config->item('type', 'policy');

        $aData = array();

        $aData[] = array(
            'id' => '',
            'text' => '선택'
        );
        foreach($aType as $nIdx => $sVal){

            $aData[] = array(
                'id' => $nIdx,
                'text' => $sVal
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }


    public function getUserList(){

        //필요한 모델을 로드한다.
        $this->load->model(array(
            'tbl_userinfo'
        ));

        //에이전트 그룹정보와 조인한 tbl_agent_info를 가져온다.
        $aData = $this->tbl_userinfo->get();
        $aList = array();
        foreach($aData as $nIdx => $aRow){

            $aList[] = array(
                'id' => $aRow['user_id'],
                'text' => $aRow['user_name']
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aList));
    }

    /**
     * 엑셀 다운로드
     * 
     * 로그 엑셀 다운로드
     * 
     * @access public
     *
     * @return excel file
     */
    public function export(){

        ini_set('memory_limit', '-1');
        set_time_limit(0);

        $this->load->model('tbl_sqllog');

        $this->load->config("system", true);
        $aServerMode = $this->config->item('server_mode', 'system');

        $sServer = $this->input->get('server');
        $sFDate = $this->input->get('log_SQL-fdate', date('Y-m-d'));
        $sTDate = $this->input->get('log_SQL-tdate', date('Y-m-d'));
        $sFTime = $this->input->get('log_SQL-ftime', '00:00:00');
        $sTTime = $this->input->get('log_SQL-ttime', '23:59:59');
        $sIp = $this->input->get("log_SQL-ip");
        $sQuery = $this->input->get('log_SQL-query');

        $aHosts = getServerList($sServer);

        if($aHosts) $this->tbl_sqllog->setAgentId($aHosts);
        if($sFDate && $sTDate) $this->tbl_sqllog->setRequestTime($sFDate." ".$sFTime, $sTDate." ".$sTTime);
        if($sIp) $this->tbl_sqllog->setIp($sIp);
        if($sQuery) $this->tbl_sqllog->setSqlText($sQuery);

        $aData = $this->tbl_sqllog->select(array(
            'sqllog_id',
            'request_time as request_time', //실행시간
            'agent_name', //서버
            'sql_log.agent_mode',
            'sql_log.login_id',
            'sql_type', //유형
            'req_sqltext as query', //쿼리
            'class_name', //클래스
            'sql_log.ipaddr as ip', //소스IP
            'IF(execute_yn = 1, "성공" , "실패") as execute_yn', //실행결과
            'exec_elapsedtime', //수행시간
            'result_count' //결과건수
        ))->joinAgentInfo()->get();

        $aList = array();
        foreach($aData as $nIdx => $aRow){

            $aRow['agent_name'] = $aRow['agent_name'] ? $aRow['agent_name'] : '입력안됨';
            $aRow['agent_mode'] = $aRow['agent_mode'] ? $aServerMode[$aRow['agent_mode']] : '입력안됨';

            $aList[] = $aRow;
        }


        $this->load->library("PHPExcel", null, "PHPExcel");

        $this->PHPExcel->setActiveSheetIndex(0);
        $sheet = $this->PHPExcel->getActiveSheet();
        
        if(count($aList) > 0){

            $aKeys = array_keys($aList[0]);

            $col = 'A';
            foreach($aKeys as $nIdx => $sVal){

                $sheet->SetCellValue($col.'1', iconv("utf-8", "euc-kr", $sVal));
                $sheet->getStyle($col.'1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('E7E7E7');
                $col++;
            }

        // $this->PHPExcel->getActiveSheet()->getColumnDimension('A')->setVisible(false);
        // $this->PHPExcel->getActiveSheet()->getColumnDimension('B')->setVisible(false);
        // $this->PHPExcel->getActiveSheet()->getColumnDimension('C')->setVisible(false);
        // $this->PHPExcel->getActiveSheet()->getColumnDimension('D')->setVisible(false);

            $nRow = 2;
            foreach($aList as $aRow){

                $col = 'A';
                foreach($aRow as $nIdx => $sVal){

                    $col_idx = $col.$nRow;

                    $preg_val = preg_replace("/(xx1[a-zA-Z0-9_.\'\",()]+)/", "[p]$1[p]", $sVal, -1);

                    $tmp = explode('[p]', $preg_val);

                    if(count($tmp) > 1){

                        $objRichText = new PHPExcel_RichText();

                        foreach($tmp as $tidx => $tval){

                            if(preg_match("/(xx1[a-zA-Z0-9_.\'\",()]+)/", $tval) == true){

                                $objPayable = $objRichText->createTextRun($tval);
                                $objPayable->getFont()->setBold(true);
                                $objPayable->getFont()->setItalic(true);
                                $objPayable->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_RED ) );
                            }
                            else {

                                $objRichText->createText($tval);
                            }
                        }
         
                        $sheet->SetCellValue($col_idx, $objRichText);
                    }
                    else {

                        $sheet->SetCellValue($col_idx, $sVal);
                    }

                    // $sheet->getStyle($col_idx)->getAlignment()->setWrapText(true)->setVertical(PHPExcel_Style_Alignment::VERTICAL_TOP);
                    // $calculatedWidth = $sheet->getColumnDimension($col_idx)->setAutoSize(true);

                    $col++;
                }

                $nRow++;
            }

            $styleArray = array(
                   'borders' => array(
                         'allborders' => array(
                                'style' => PHPExcel_Style_Border::BORDER_THIN,
                                'color' => array('argb' => '00000000'),
                         )
                   )
            );

            $this->PHPExcel->getActiveSheet()->getStyle('A1:'.chr(ord($col) - 1).--$nRow)->applyFromArray($styleArray);
        }

        $this->PHPExcel->getActiveSheet()->setTitle('SQL Log');

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="sql_log.xlsx"');
        header('Cache-Control: max-age=0');

        $objWriter = PHPExcel_IOFactory::createWriter($this->PHPExcel, 'Excel2007');
        $objWriter->save('php://output');
    }
}
/* End of file sql.php */
/* Location: ./application/controllers/log/sql.php */