<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Converted_sql
*
* Converted_sql 로그
*
* @uses     CI_Controller
* @category log
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class Converted_sql extends CI_Controller {

    /**
     * index
     *
     * 메인 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function index()
	{

        return $this->getGridData();
	}

    /**
     * getListData
     * 
     * SQL 그리드 데이터를 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getListData(){
        
        //파라미터를 받는다.
        $sServer = $this->input->get('server');
        $nStartNo = $this->input->get("start");
        $nEndNo = $this->input->get("limit");
        $sSort = $this->input->get("sort");
        $sFDate = $this->input->get('log_ConvertedSQL-fdate', date('Y-m-d'));
        $sTDate = $this->input->get('log_ConvertedSQL-tdate', date('Y-m-d'));
        $sQuery = $this->input->get('log_ConvertedSQL-query'); 

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $aServers = getServerList($sServer);

        //테이블 모델 로드
        $this->load->model('tbl_sqllog_convert_summary');
        //$this->output->enable_profiler(TRUE);
        /**
         * 
         * 리스트의 토탈 갯수를 구한다.
         */

        //전체 로그 갯수
        $nTotalCount = 0;

        //서버정보가 있을경우 조건절에 서버 추가.
        if($aServers) $this->tbl_sqllog_convert_summary->setAgentId($aServers);

        //기간이 있을 경우 기간 추가.
        if($sFDate && $sTDate) $this->tbl_sqllog_convert_summary->setDate($sFDate, $sTDate);

        //쿼리가 있을 경우 like 검색 추가.
        if($sQuery) $this->tbl_sqllog_convert_summary->setSqlText($sQuery);

        $this->tbl_sqllog_convert_summary->select('
            COUNT(1) as cnt
        ', true);

        //토탈 갯수를 구한다.
        $aTotal = array_pop($this->tbl_sqllog_convert_summary->joinUniqSql()->joinAgentInfo()->get());

        /**
         * 
         * 리스트의 데이터를 구한다.
         */

        //소팅에 대한 명령이 들어오면 상황에 맞게 order by 해준다.
        if($sSort){ 

            $oSort = array_pop(json_decode($sSort));
            $this->tbl_sqllog_convert_summary->db->order_by($oSort->property, $oSort->direction);
        }

        //서버정보가 있을경우 조건절에 서버 추가.
        if($aServers) $this->tbl_sqllog_convert_summary->setAgentId($aServers);

        //기간이 있을 경우 기간 추가.
        if($sFDate && $sTDate) $this->tbl_sqllog_convert_summary->setDate($sFDate, $sTDate);

        //쿼리가 있을 경우 like 검색 추가.
        if($sQuery) $this->tbl_sqllog_convert_summary->setSqlText($sQuery);

        //최근데이터를 가장 앞으로 보여준다.
        $this->tbl_sqllog_convert_summary->db->order_by('sum_log.date_f', 'DESC');
        
        //조건에 따른 데이터를 통계테이블에서 가져온다
        $aData = $this->tbl_sqllog_convert_summary->select(array(
            'date_f as ymd',
            'agent.agent_name', //서버
            'uniq.orig_sqltext as query', //쿼리
            'cls.class_string', //클래스
            'sum_log.agent_id',
            'sum_log.uniqsql_id',
            'sum_log.class_id',
            'sum_log.sum_count',
            'sum_log.avg_elapsedtime', //수행시간
            'sum_log.avg_result_count' //결과건수
        ))->joinAgentInfo()->joinClassTrace()->joinUniqSql()->limit($nStartNo, $nEndNo)->get();

        $aList = array();
        foreach($aData as $nIdx => $aRow){

            $aRow['agent_name'] = $aRow['agent_name'] ? $aRow['agent_name'] : '입력안됨';
            $aList[] = $aRow;
        }

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'list' => $aList,
            'total' => $aTotal['cnt']
        )));
    }

    /**
     * getDetailListData
     * 
     * 상세보기 SQL 그리드 데이터를 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getDetailListData($sYmd, $nAgentId, $nUniqSqlId, $nClassId){

        //파라미터를 받는다.
        $nStartNo = $this->input->get("start");
        $nEndNo = $this->input->get("limit");
        $sSort = $this->input->get("sort");

        //모델을 로드한다.
        $this->load->model('tbl_sqllog');

        //SQL Formatter 라이브러리 로드
        $this->load->library('SqlFormatter', 'SqlFormatter');

        //전체 레코드수 초기화
        $nTotalCount = 0;

        //검색 조건절 추가(전체레코드)
        $this->tbl_sqllog->setRequestTime($sYmd, $sYmd);
        $this->tbl_sqllog->setAgentId($nAgentId);
        $this->tbl_sqllog->setUniqSqlId($nUniqSqlId);
        $this->tbl_sqllog->setClassId($nClassId);

        //전체 레코드수 구하기
        $nTotalCount = $this->tbl_sqllog->count();

        //검색 조건절 추가(리스트)
        $this->tbl_sqllog->setRequestTime($sYmd, $sYmd);
        $this->tbl_sqllog->setAgentId($nAgentId);
        $this->tbl_sqllog->setUniqSqlId($nUniqSqlId);
        $this->tbl_sqllog->setClassId($nClassId);
        
        //소트 명령이 오면 테이블 소트한다.
        if($sSort){ 

            $oSort = array_pop(json_decode($sSort));
            $this->tbl_sqllog->db->order_by($oSort->property, $oSort->direction);
        }
        
        $aData = $this->tbl_sqllog->select(array(
            'sql_log.sqllog_id',
            'DATE_FORMAT(sql_log.request_time, "%Y-%m-%d %H:%i:%s") as request_time', //수행시간
            'sql_log.sql_type', //유형
            'sql_log.req_sqltext as org_sql', //원본쿼리
            'policy.policy_properties as policy_properties', //변환쿼리
            'sql_log.ipaddr as ip', //소스IP
            'if(sql_log.convsql_id > 0, "Yes", "No") as change_yn',
            'sql_log.result_count',
            'sql_log.sqlparam',
            'sql_log.exec_elapsedtime' //실행시간
        ))->joinPolicyList()->limit($nStartNo, $nEndNo)->get();

        $aList = array();
        $nNum = $nTotalCount - $nStartNo;
        foreach($aData as $nIdx => $aRow){

            $aRow['num'] = $nNum--;
            $aRow['org_sql'] = @SqlFormatter::format($aRow['org_sql']);

            if($aRow['policy_properties']){

                $aProperties = @json_decode($aRow['policy_properties'], true);
                $aRow['pol_sql'] = @SqlFormatter::format($aProperties['convert']);
            }

            $aList[] = $aRow;
        }

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'list' => $aList,
            'total' => $nTotalCount
        )));
    }

    /**
     * getDetailData
     * 
     * 상세 조회 페이지에서의 그리드 데이트를 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getDetailViewData($sYmd, $nAgentId, $nUniqSqlId, $nClassId){

        //모델을 로드한다.
        $this->load->model(array(
            'tbl_uniqsql',
            'tbl_agent_info'
        ));

        //SQL Formatter 라이브러리 로드
        $this->load->library('SqlFormatter', 'SqlFormatter');

        $aUniqSQL = array_pop($this->tbl_uniqsql->get($nUniqSqlId));

        $aAgent = array_pop($this->tbl_agent_info->get($nAgentId));


        $aData['agent_name'] = $aAgent['agent_name'] ? $aAgent['agent_name'] : '입력안됨';
        $aData['uniqsql'] = SqlFormatter::format($aUniqSQL['uniq_sqltext']);

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    /**
     * getChartData
     * 
     * 상세 조회 페이지에서의 그리드 데이트를 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getDetailChartData($sYmd, $nAgentId, $nUniqSqlId, $nClassId){

        $this->load->model('tbl_sqllog');

        //검색 조건절 추가(리스트)
        $this->tbl_sqllog->setRequestTime($sYmd, $sYmd);
        $this->tbl_sqllog->setAgentId($nAgentId);
        $this->tbl_sqllog->setUniqSqlId($nUniqSqlId);
        $this->tbl_sqllog->setClassId($nClassId);
        
        $this->tbl_sqllog->db->group_by('time');
        $aData = $this->tbl_sqllog->select(array(
            'DATE_FORMAT(request_time, "%H") as time',
            'COUNT(1) as cnt' //실행시간
        ))->get();

        $aTimeData = array();
        foreach($aData as $nIdx => $aRow){

            $aTimeData[$aRow['time']] = $aRow['cnt'];
        }

        $aList = array();
        for($nTime = 0 ; $nTime < 24 ; $nTime++){

            $aList[] = array(
                'time' => str_pad($nTime, 2 , 0, STR_PAD_LEFT)."시",
                'value' => @(int)$aTimeData[str_pad($nTime, 2 , 0, STR_PAD_LEFT)]
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aList));
    }
}
/* End of file converted_sql.php */
/* Location: ./application/controllers/log/converted_sql.php */