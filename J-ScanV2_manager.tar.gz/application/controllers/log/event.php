<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Event
*
* Event 로그
*
* @uses     CI_Controller
* @category history
* @package  WhiteEvent
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class Event extends CI_Controller {

    /**
     * index
     *
     * 메인 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function index()
	{

        return $this->getGridData();
	}

    /**
     * getGridData
     * 
     * Event 그리드 데이터를 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getGridData($nLogId = null){

        $this->load->model(array(
            'tbl_eventlog',
            'tbl_newsql',
            'tbl_whitesql_list',
            'tbl_sqllog',
            'tbl_uniqsql'
        ));

        $this->load->config("system", true);

        $aLevel = $this->config->item('event_level', 'system');
        $aType  = $this->config->item('event_type', 'system');
        $aKind  = $this->config->item('event_kind', 'system');

        $nTotalCount = 0;

        if($nLogId !== null){

            $aEvent = array_pop($this->tbl_eventlog->select(array(
                'agent_name', 
                'evt_log.eventlog_id',
                'evt_log.event_type',
                'FROM_UNIXTIME(evt_log.event_time) as event_time',
                'evt_log.event_level',
                'evt_log.event_kind',
                'evt_log.event_msg',
                'evt_log.event_tblname',
                'evt_log.event_tblid',
                'evt_log.agent_id',
                'agent.ipaddr',
                'pol.policy_type',
                'pol.policy_name'
            ), false)->joinAgentInfo()->joinSQLLog()->joinPolicyList()->get($nLogId));

            switch($aEvent['event_tblname']){

                case "tbl_newsql":

                    $aMore = array_pop($this->tbl_newsql->get($aEvent['event_tblid']));
                    $aEvent['sqltext'] = $aMore['orig_sqltext'];
                    $aEvent = @array_merge($aEvent, $aMore);
                    $aEvent['execute_yn'] = 1;
                    break;

                case "tbl_sqllog":

                    $aMore = array_pop($this->tbl_sqllog->get($aEvent['event_tblid']));
                    $aEvent['sqltext'] = $aMore['req_sqltext'];
                    $aEvent = @array_merge($aEvent, $aMore);
                    break;

                case "tbl_whitesql_list":

                    $aMore = array_pop($this->tbl_whitesql_list->get($aEvent['event_tblid']));
                    $aUniq = array_pop($this->tbl_uniqsql->get($aMore['uniqsql_id']));
                    $aEvent['sqltext'] = $aUniq['uniq_sqltext'];
                    $aEvent = @array_merge($aEvent, $aMore);
                    $aEvent['execute_yn'] = 1;
                    break;
            }


            //SQL Formatter 라이브러리 로드
            $this->load->library('SqlFormatter');
                        
            //SQL Format Syntax Highlight 적용
            $aEvent['sqltext'] = @SqlFormatter::format($aEvent['sqltext']);
            $aEvent['policy_type'] = @getPolicyType($aEvent['policy_type']);

            $aData[] = $aEvent;
        }
        else {
            
            $nStartNo    = $this->input->get("start");
            $nEndNo      = $this->input->get("limit");
            $sSort       = $this->input->get("sort");
            $sServer     = $this->input->get('server');
            $sFDate      = $this->input->get('log_Event-fdate', date('Y-m-d'));
            $sTDate      = $this->input->get('log_Event-tdate', date('Y-m-d'));
            $sEventLevel = $this->input->get("log_Event-EventLevel");
            $nEventKind  = $this->input->get("log_Event-EventKind");
            $sMessage    = $this->input->get('log_Event-message');

            $aHosts = getServerList($sServer);

            if($aHosts) $this->tbl_eventlog->setAgentId($aHosts);
            if($sFDate && $sTDate) $this->tbl_eventlog->setEventTime($sFDate, $sTDate);
            if($sEventLevel) $this->tbl_eventlog->setEventLevel($sEventLevel);
            if($nEventKind) $this->tbl_eventlog->setEventKind($nEventKind);
            if($sMessage) $this->tbl_eventlog->setEventMessage($sMessage);

            $nTotalCount = $this->tbl_eventlog->joinAgentInfo()->count();

            if($sSort){ 

                $oSort = array_pop(json_decode($sSort));
                $this->tbl_eventlog->db->order_by($oSort->property, $oSort->direction);
            }
            else {

                $this->tbl_eventlog->db->order_by('eventlog_id', 'desc');
            }

            if($aHosts) $this->tbl_eventlog->setAgentId($aHosts);
            if($sFDate && $sTDate) $this->tbl_eventlog->setEventTime($sFDate, $sTDate);
            if($sEventLevel) $this->tbl_eventlog->setEventLevel($sEventLevel);
            if($nEventKind) $this->tbl_eventlog->setEventKind($nEventKind);
            if($sMessage) $this->tbl_eventlog->setEventMessage($sMessage);

            $aData = $this->tbl_eventlog->select(array(
                'eventlog_id',
                'FROM_UNIXTIME(event_time) as event_time', //발생시간
                'agent_name', //서버        
                'event_kind',        
                'event_type', //유형
                'event_level', //레벨
                'event_msg', //메시지,
                'policy_type' //정책 유형
            ))->joinAgentInfo()->limit($nStartNo, $nEndNo)->get($nLogId);
        }

        $aList = array();
        foreach($aData as $nIdx => $aRow){

            $aRow['agent_name'] = @$aRow['agent_name'] ? $aRow['agent_name'] : ' - ';
            $aRow['event_type'] = @$aRow['event_type'] ? $aType[$aRow['event_type']] : ' - ';
            $aRow['event_level'] = @$aRow['event_level'] ? $aLevel[$aRow['event_level']] : ' - ';
            $aRow['event_kind'] = @$aKind[$aRow['event_kind']];
            $aRow['policy_type'] = @getPolicyType($aRow['policy_type']);

            $aList[] = $aRow;
        }

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'list' => $aList,
            'total' => $nTotalCount
        )));
    }

    public function getServerList(){

        //필요한 모델을 로드한다.
        $this->load->model(array(
            'tbl_agent_info'
        ));

        //에이전트 그룹정보와 조인한 tbl_agent_info를 가져온다.
        $aData = $this->tbl_agent_info->joinAgentGroupInfo()->select(array('group_name'), false)->get();

        //트리의 최상위 노드
        $aTree = array();

        foreach($aData as $nIdx => $aRow){

            //호스트 그룹 노드 설정
            $aTree[] = array(
                'id'   => 'server-'.$aRow['agent_id'],
                'text' => $aRow['agent_name'],
                'leaf' => true
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aTree));
    }

    public function getEventKindList(){

        $this->load->config("system", true);
        $aType = $this->config->item('event_kind', 'system');

        $aData = array();

        $aData[] = array(
            'id' => '',
            'text' => '전체'
        );
        foreach($aType as $nIdx => $sVal){

            $aData[] = array(
                'id' => $nIdx,
                'text' => $sVal
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    public function getEventLevelList(){

        $this->load->config("system", true);
        $aType = $this->config->item('event_level', 'system');

        $aData = array();

        $aData[] = array(
            'id' => '',
            'text' => '전체'
        );
        foreach($aType as $nIdx => $sVal){

            $aData[] = array(
                'id' => $nIdx,
                'text' => $sVal
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }
}
/* End of file event.php */
/* Location: ./application/controllers/log/event.php */