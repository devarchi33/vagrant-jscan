<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Event_tree
*
* Event Tree json을 리턴하는 컨트롤러
*
* @uses     CI_Controller
* @category server
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class Event_tree extends CI_Controller {

    /**
     * index
     *
     * Event_tree 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function index()
	{
        $sNode = $this->input->get('node');

        if($sNode != 'root') return;

        //security mode config 파일을 불러온다.
        $this->load->config('system', true);

        //security mode 함축 단어 배열을 가져온다.
        $aEventLevel = $this->config->item('event_level', 'system');
        $aEventLevelKey = $this->config->item('event_level_key', 'system');

        $this->load->model('mt_event');

        $aData = array_pop($this->mt_event->get());

        //트리의 최상위 노드
        $aLevelData = array();
        foreach($aEventLevel as $nLevel => $sLevelNm){
            
            $sKey = @$aEventLevelKey[$nLevel];
            $nNum = @(int)$aData[$sKey];

            //호스트 그룹 노드 설정
            $aLevelData[$nLevel] = array(
                'text' => $sLevelNm."(".$nNum.")",
                'leaf' => true
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aLevelData));
	}
}
/* End of file event_tree.php */
/* Location: ./application/controllers/server/event_tree.php */