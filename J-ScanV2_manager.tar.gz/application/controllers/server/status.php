<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Status
*
* 서버 각정 상태를 리턴해주는 컨트롤러
*
* @uses     CI_Controller
* @category server
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class Status extends CI_Controller {

    /**
     * index
     *
     * Server_tree 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function index()
    {
        $aUsage = $this->usage();
        $aEvent = $this->event();
        $aServers = $this->getServerList();
        $aDatabases = $this->getDatabaseList();

        $this->load->model('tbl_userinfo');

        $aUser = getUserInfo();

        $this->tbl_userinfo->updateLastLogin($aUser['user_id']);

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'usage' => $aUsage,
            //'event' => $aEvent,
            'servers' => $aServers,
            'databases' => $aDatabases
        )));
    }

    /**
     * usage
     *
     * CPU, 메모리, 디스크 사용률을 구해서 json으로 출력한다.
     * 
     * @access public
     *
     * @return mixed Value.
     */
    public function usage(){

        $aData = array();

        $a = $this->getCPUInfo(); 
        sleep(1); 
        $b = $this->getCPUInfo(); 

        $total = array_sum($b)-array_sum($a); 

        $loadavg = ceil(100* (($b[0]+$b[1]+$b[2]) - ($a[0]+$a[1]+$a[2])) / $total); // user+nice+system 

        $aData['cpu'] = $loadavg;
        $aData['mem'] = $this->getMemInfo();
        $aData['disk'] = $this->getDiskInfo();

        return $aData;
    }

    function getCPUInfo() {

        $fp=fopen("/proc/stat", "r");
        
        if($fp === false) return false; 

        $a = explode(' ',fgets($fp)); 
        array_shift($a); //get rid of 'cpu' 

        while(!$a[0]) array_shift($a); //get rid of ' ' 

        fclose($fp); 

        return $a;
    }

    function getMemInfo() {
        
        $data = file('/proc/meminfo');
        $mems = array();
        
        $aItems = array('MemTotal', 'MemFree', 'Buffers', 'Cached');

        foreach( $data as $line ) {

            if(preg_match('/^('.implode('|', $aItems).')/', $line))
            {
                $aItem = explode(":", $line);
                $mems[$aItem[0]] = (int)$aItem[1];
            }
        }

        $nTotal = $mems['MemTotal'];
        unset($mems['MemTotal']);

        $mem =  ceil((100 - ((array_sum($mems) / $nTotal) * 100)));

        return $mem;
    }

    function getDiskInfo(){

        $sDir = '/home/';
        $disk = ceil(100 - ((disk_free_space($sDir) / disk_total_space($sDir)) * 100));
        
        return $disk;
    }

    function getServerList(){

        $this->load->model(array(
            'tbl_agent_info'
        ));

        return $this->tbl_agent_info->select(array('status', 'agent_id'))->get();
    }

    function getDatabaseList(){

        $this->load->model(array(
            'tbl_dbconn'
        ));

        return $this->tbl_dbconn->select(array('dbname', 'dbconn_id'))->get();
    }
    /**
     * event
     *
     * 이벤트 상태 
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function event()
    {
        //security mode config 파일을 불러온다.
        $this->load->config('system', true);

        //security mode 함축 단어 배열을 가져온다.
        $aEventLevel    = $this->config->item('event_level', 'system');
        $aEventLevelKey = $this->config->item('event_level_key', 'system');
        
        $this->load->model('tbl_summary_alarm_level');

        $aData = array_pop($this->tbl_summary_alarm_level->get());

        //트리의 최상위 노드
        $aLevelData = array();
        foreach (range(EVENT_TYPE_NOTICE, EVENT_TYPE_SERIOUS) as $nAlarmLevel) {

            $aLevelData[$nAlarmLevel] = array(
                'num' => (int)$aData['level'.$nAlarmLevel],
                'text' => $aEventLevel[$nAlarmLevel]
            );
        }

        return $aLevelData;
    }
}
/* End of file status.php */
/* Location: ./application/controllers/server/status.php */