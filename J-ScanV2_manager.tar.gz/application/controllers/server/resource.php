<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Resource
*
* Server Tree XML을 리턴하는 컨트롤러
*
* @uses     CI_Controller
* @category server
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class Resource extends CI_Controller {

    /**
     * index
     *
     * Server_tree 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function index()
	{
        $this->usage();
	}

    /**
     * usage
     *
     * CPU, 메모리, 디스크 사용률을 구해서 json으로 출력한다.
     * 
     * @access public
     *
     * @return mixed Value.
     */
    public function usage(){

        $aData = array();

        $this->load->model('mt_state');
        $aList = array_pop($this->mt_state->get());
        
        $aData = array();
        foreach(array('cpu', 'mem', 'disk') as $nIdx => $sKey){
            
            $aData[$sKey] = @(int)$aList[$sKey];
            //$aData[$sKey] = rand(10, 70);
        }

        $this->output->set_content_type('text/html')->set_output(json_encode($aData));
    }
}
/* End of file server_tree.php */
/* Location: ./application/controllers/server/server_tree.php */