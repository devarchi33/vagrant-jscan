<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Policy
*
* Policy 히스토리
*
* @uses     CI_Controller
* @category history
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class Policy extends CI_Controller {

    /**
     * index
     *
     * 메인 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function index()
	{

        return $this->getGridData();
	}

    /**
     * getSQLGridData
     * 
     * SQL 그리드 데이터를 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getGridData($nHisId = null){

        $this->load->model('tbl_policy_history');

        $nTotalCount = 0;

        if($nHisId !== null){

            $aData = $this->tbl_policy_history->select(array(
                'policy_history_id', 'agent_name', 'FROM_UNIXTIME(work_time) as work_time', 
                'pol_his.policy_type', 'user_name', 'work_message', 'work_before', 'work_after', 
                'work_type'
            ))->joinAgentInfo()->joinUserInfo()->get($nHisId);
        }
        else {

            $nStartNo = $this->input->get("start");
            $nEndNo = $this->input->get("limit");
            $sSort = $this->input->get("sort");
            $sServer = $this->input->get('server');
            $sServer = $this->input->get("history_Policy-Server", $sServer);
            $sFDate = $this->input->get('history_Policy-fdate', date('Y-m-d', strtotime('-1 month')));
            $sTDate = $this->input->get('history_Policy-tdate', date('Y-m-d'));
            $nPolicyType = $this->input->get('history_Policy-PolicyType');
            $sUser = $this->input->get('history_Policy-PolicyUser');
            $sMessage = $this->input->get('history_Policy-message');

            $aHosts = getServerList($sServer);
            
            if($aHosts) $this->tbl_policy_history->setAgentId($aHosts);
            if($sFDate && $sTDate) $this->tbl_policy_history->setWorkTime($sFDate, $sTDate);
            if(is_numeric($nPolicyType) === true) $this->tbl_policy_history->setPolicyType($nPolicyType);
            if($sUser) $this->tbl_policy_history->setUserId($sUser);
            if($sMessage) $this->tbl_policy_history->setMessage($sMessage);

            $nTotalCount = $this->tbl_policy_history->joinAgentInfo()->joinUserInfo()->count();

            if($sSort){ 

                $oSort = array_pop(json_decode($sSort));
                $this->tbl_policy_history->db->order_by($oSort->property, $oSort->direction);
            }
            else {

                $this->tbl_policy_history->db->order_by('policy_history_id', 'desc');   
            }
            
            if($aHosts) $this->tbl_policy_history->setAgentId($aHosts);
            if($sFDate && $sTDate) $this->tbl_policy_history->setWorkTime($sFDate, $sTDate);
            if(is_numeric($nPolicyType) === true) $this->tbl_policy_history->setPolicyType($nPolicyType);
            if($sUser) $this->tbl_policy_history->setUserId($sUser);
            if($sMessage) $this->tbl_policy_history->setMessage($sMessage);

            $aData = $this->tbl_policy_history->select(array(
                'policy_history_id', 'agent_name', 'FROM_UNIXTIME(work_time) as work_time', 
                'pol_his.policy_type', 'user_name', 'work_message'
            ))->joinAgentInfo()->joinUserInfo()->limit($nStartNo, $nEndNo)->get();
        }

        $aList = array();
        foreach($aData as $nIdx => $aRow){

            $aRow['agent_name'] = $aRow['agent_name'] ? $aRow['agent_name'] : '입력안됨';
            $aRow['policy_type'] = getPolicyType($aRow['policy_type']);
            $aList[] = $aRow;
        }

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'list' => $aList,
            'total' => $nTotalCount
        )));
    }

    public function getServerList(){

        //필요한 모델을 로드한다.
        $this->load->model(array(
            'tbl_agent_info'
        ));

        //에이전트 그룹정보와 조인한 tbl_agent_info를 가져온다.
        $aData = $this->tbl_agent_info->joinAgentGroupInfo()->select(array('group_name'), false)->get();

        //트리의 최상위 노드
        $aTree = array();

        foreach($aData as $nIdx => $aRow){

            //호스트 그룹 노드 설정
            $aTree[] = array(
                'id'   => 'server-'.$aRow['agent_id'],
                'text' => $aRow['agent_name'],
                'leaf' => true
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aTree));
    }

    public function getPolicyTypeList(){

        $this->load->config("system", true);
        $aType = $this->config->item('policy_type', 'system');

        $aData = array();

        $aData[] = array(
            'id' => '',
            'text' => '전체'
        );
        foreach($aType as $nIdx => $sVal){

            $aData[] = array(
                'id' => $nIdx,
                'text' => $sVal
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }


    public function getPolicyUserList(){

        //필요한 모델을 로드한다.
        $this->load->model(array(
            'tbl_userinfo'
        ));

        //에이전트 그룹정보와 조인한 tbl_agent_info를 가져온다.
        $aData = $this->tbl_userinfo->get();
        $aList = array();
        $aList[] = array(
            'id' => '',
            'text' => '전체'
        );
        foreach($aData as $nIdx => $aRow){

            $aList[] = array(
                'id' => $aRow['user_id'],
                'text' => $aRow['user_name']
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aList));
    }
}
/* End of file main.php */
/* Location: ./application/controllers/main/main.php */