<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Work
*
* Work 히스토리
*
* @uses     CI_Controller
* @category history
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class Work extends CI_Controller {

    /**
     * index
     *
     * 메인 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function index()
	{

        return $this->getGridData();
	}

    /**
     * getSQLGridData
     * 
     * SQL 그리드 데이터를 가져온다.
     * 
     * @access public
     *
     * @return mixed json object.
     */
    public function getGridData($nHisId = null){

        $this->load->model('tbl_work_history');

        $this->load->config("system", true);
        $aType = $this->config->item('work_type', 'system');

        $nTotalCount = 0;

        if($nHisId !== null){

            $aData = $this->tbl_work_history->select(array(
                'work_history_id', 'agent_name', 'FROM_UNIXTIME(work_time) as work_time', 
                'work_his.work_type', 'user_name', 'work_message', 'work_before', 'work_after'
            ))->joinAgentInfo()->joinUserInfo()->get($nHisId);
        }
        else {

            $nStartNo = $this->input->get("start");
            $nEndNo = $this->input->get("limit");
            $sSort = $this->input->get("sort");
            $sServer = $this->input->get('server');
            $sFDate = $this->input->get('history_Work-fdate', date('Y-m-d', strtotime('-1 month')));
            $sTDate = $this->input->get('history_Work-tdate', date('Y-m-d'));
            $sWorkType = $this->input->get('history_Work-WorkType');
            $sUser = $this->input->get('history_Work-WorkUser');
            $sMessage = $this->input->get('history_Work-message');

            $aHosts = getServerList($sServer);
            
            if($aHosts) $this->tbl_work_history->setAgentId($aHosts);
            if($sFDate && $sTDate) $this->tbl_work_history->setWorkTime($sFDate, $sTDate);
            if($sWorkType) $this->tbl_work_history->setWorkType($sWorkType);
            if($sUser) $this->tbl_work_history->setUserId($sUser);
            if($sMessage) $this->tbl_work_history->setMessage($sMessage);

            $nTotalCount = $this->tbl_work_history->joinAgentInfo()->joinUserInfo()->count();

            if($sSort){ 

                $oSort = array_pop(json_decode($sSort));
                $this->tbl_work_history->db->order_by($oSort->property, $oSort->direction);
            }
            else {

                $this->tbl_work_history->db->order_by('work_history_id', 'desc');
            }
            
            if($aHosts) $this->tbl_work_history->setAgentId($aHosts);
            if($sFDate && $sTDate) $this->tbl_work_history->setWorkTime($sFDate, $sTDate);
            if($sWorkType) $this->tbl_work_history->setWorkType($sWorkType);
            if($sUser) $this->tbl_work_history->setUserId($sUser);
            if($sMessage) $this->tbl_work_history->setMessage($sMessage);

            $aData = $this->tbl_work_history->select(array(
                'work_history_id', 'agent_name', 'FROM_UNIXTIME(work_time) as work_time', 
                'work_his.work_type', 'user_name', 'work_message'
            ))->joinAgentInfo()->joinUserInfo()->limit($nStartNo, $nEndNo)->get();
        }

        $aList = array();
        foreach($aData as $nIdx => $aRow){

            $aRow['agent_name'] = $aRow['agent_name'] ? $aRow['agent_name'] : '입력안됨';
            $aRow['work_type'] = $aRow['work_type'] ? $aType[$aRow['work_type']] : '입력안됨';
            $aList[] = $aRow;
        }

        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'list' => $aList,
            'total' => $nTotalCount
        )));
    }

    public function getServerList(){

        //필요한 모델을 로드한다.
        $this->load->model(array(
            'tbl_agent_info'
        ));

        //에이전트 그룹정보와 조인한 tbl_agent_info를 가져온다.
        $aData = $this->tbl_agent_info->joinAgentGroupInfo()->select(array('group_name'), false)->get();

        //트리의 최상위 노드
        $aTree = array();

        foreach($aData as $nIdx => $aRow){

            //호스트 그룹 노드 설정
            $aTree[] = array(
                'id'   => 'server-'.$aRow['agent_id'],
                'text' => $aRow['agent_name'],
                'leaf' => true
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aTree));
    }

    public function getWorkTypeList(){

        $this->load->config("system", true);
        $aType = $this->config->item('work_type', 'system');

        $aData = array();

        $aData[] = array(
            'id' => '',
            'text' => '전체'
        );
        foreach($aType as $nIdx => $sVal){

            if($sVal == 'Sync') continue;

            $aData[] = array(
                'id' => $nIdx,
                'text' => $sVal
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }


    public function getWorkUserList(){

        //필요한 모델을 로드한다.
        $this->load->model(array(
            'tbl_userinfo'
        ));

        //에이전트 그룹정보와 조인한 tbl_agent_info를 가져온다.
        $aData = $this->tbl_userinfo->get();
        $aList = array();
        $aList[] = array(
            'id' => '',
            'text' => '전체'
        );
        foreach($aData as $nIdx => $aRow){

            $aList[] = array(
                'id' => $aRow['user_id'],
                'text' => $aRow['user_name']
            );
        }

        $this->output->set_content_type('application/json')->set_output(json_encode($aList));
    }
}
/* End of file work.php */
/* Location: ./application/controllers/history/work.php */