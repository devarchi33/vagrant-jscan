<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Excel 
*
* excel 관련 컨트롤러
*
* @uses     CI_Controller
* @category excel
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class Excel extends CI_Controller {

    /**
     * index
     *
     * excel 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function index(){

        ini_set('memory_limit', '-1');
        set_time_limit(0);

        $sData = $this->input->post('data');
        $sColumns = $this->input->post('columns');

        $this->load->library("PHPExcel", null, "PHPExcel");

        $this->PHPExcel->setActiveSheetIndex(0);
        $sheet = $this->PHPExcel->getActiveSheet();
        
        $aColumns = json_decode($sColumns, true);
        $aData = json_decode($sData, true);
        

        $col = 'A';
        foreach($aColumns as $nIdx => $aRow){

            $sheet->SetCellValue($col.'1', $aRow['text']);
            $sheet->getStyle($col.'1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('E7E7E7');
            $col++;
        }

        $nRow = 2;
        foreach($aData as $aRow){

            $col = 'A';
            foreach($aRow as $nIdx => $sVal){

                $col_idx = $col.$nRow;

                $preg_val = preg_replace("/(xx1[a-zA-Z0-9_.\'\",()]+)/", "[p]$1[p]", $sVal, -1);

                $tmp = explode('[p]', $preg_val);

                if(count($tmp) > 1){

                    $objRichText = new PHPExcel_RichText();

                    foreach($tmp as $tidx => $tval){

                        if(preg_match("/(xx1[a-zA-Z0-9_.\'\",()]+)/", $tval) == true){

                            $objPayable = $objRichText->createTextRun($tval);
                            $objPayable->getFont()->setBold(true);
                            $objPayable->getFont()->setItalic(true);
                            $objPayable->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_RED ) );
                        }
                        else {

                            $objRichText->createText($tval);
                        }
                    }
     
                    $sheet->SetCellValue($col_idx, $objRichText);
                }
                else {

                    $sheet->SetCellValue($col_idx, $sVal);
                }

                // $sheet->getStyle($col_idx)->getAlignment()->setWrapText(true)->setVertical(PHPExcel_Style_Alignment::VERTICAL_TOP);
                // $calculatedWidth = $sheet->getColumnDimension($col_idx)->setAutoSize(true);

                $col++;
            }

            $nRow++;
        }

        $styleArray = array(
               'borders' => array(
                     'allborders' => array(
                            'style' => PHPExcel_Style_Border::BORDER_THIN,
                            'color' => array('argb' => '00000000'),
                     )
               )
        );

        $this->PHPExcel->getActiveSheet()->getStyle('A1:'.chr(ord($col) - 1).--$nRow)->applyFromArray($styleArray);

        $this->PHPExcel->getActiveSheet()->setTitle('SQL Convert');

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="'.time().'.xlsx"');
        header('Cache-Control: max-age=0');

        $objWriter = PHPExcel_IOFactory::createWriter($this->PHPExcel, 'Excel2007');
        $objWriter->save('php://output');
	}
}
/* End of file excel.php */
/* Location: ./application/controllers/util/excel.php */