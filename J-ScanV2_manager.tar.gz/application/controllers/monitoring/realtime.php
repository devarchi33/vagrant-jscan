<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Realtime
 *
 * 실시간 모니터링
 *
 * @uses     CI_Controller
 * @category monitoring
 * @package  WhiteSQL
 * @author   정주원 <jjwcom@nate.com>
 * @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
 * @link
 */
class Realtime extends CI_Controller
{

    /**
     * index
     *
     * 메인 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function index()
    {

        $this->getSQLLog();
    }

    public function getChartData($sCmd = 'avg_req_time_per_sec')
    {

        $this->load->config('realtime', true);

        $nStartSecond     = $this->config->item('start_second', 'realtime');
        $nLastRequestTime = $this->input->post('last_request_time', date("YmdHis"));
        $sServer          = $this->input->post('server', 'root');
        $nEDate           = date("YmdHis", strtotime('-'.$nStartSecond.' seconds', strtotime($nLastRequestTime)));
        $nSDate           = date("YmdHis", strtotime("-20 second", strtotime($nEDate)));

        $redis = new Redis();
        $redis->connect('127.0.0.1', 6379);

        $aAgents = $redis->sort('root:agent');

        if ($sCmd == 'avg_req_time_per_sec') {

            $aData = array();

            for ($nSDate; $nSDate <= $nEDate; $nSDate = date("YmdHis", strtotime("+1 second", strtotime($nSDate)))) {

                $sDate = date("m-d-Y H:i:s", strtotime($nSDate));
                $aRow  = array('date' => $sDate);
                foreach ($aAgents as $nIdx => $nAgentId) {

                    $nCnt  = (int)$redis->hget('exec_count_per_sec:server:'.$nAgentId, $nSDate);
                    $nTime = (float)$redis->hget('exec_time_per_sec:server:'.$nAgentId, $nSDate);

                    @$aRow[$nAgentId] = (float)($nTime / $nCnt);
                }

                array_push($aData, $aRow);
            }

        } else {

            $aData = array();
            for ($nSDate; $nSDate <= $nEDate; $nSDate = date("YmdHis", strtotime("+1 second", strtotime($nSDate)))) {

                $sDate = date("m-d-Y H:i:s", strtotime($nSDate));
                $aRow  = array('date' => $sDate);
                foreach ($aAgents as $nIdx => $nAgentId) {

                    $nCnt  = (int)$redis->hget('exec_count_per_sec:server:'.$nAgentId, $nSDate);
                    $aRow[$nAgentId] = $nCnt;
                }

                array_push($aData, $aRow);
            }
        }

        // $this->output->enable_profiler(TRUE);
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result'      => 'success',
            'data'        => $aData,
            'server_time' => explode('-', date('Y-m-d-H-i-s', strtotime('-'.$nStartSecond.' seconds')))
        )));
    }

    /**
     * getSQLLog
     *
     * SQL LOG 데이터를 가져온다.
     *
     * @access public
     *
     * @return mixed json object.
     */
    public function getSQLLog()
    {

        //파라미터를 받는다.

        $sServer = $this->input->post('server');

        $this->load->model('tbl_log');

        $redis = new Redis();
        $redis->connect('127.0.0.1', 6379);

        $aList = $redis->lRange('realtime_sql_log', 0, 19);
        $redis->multi();

        foreach ($aList as $nIdx => $aLogId) {

            $redis->hGetAll('realtime_sql_log:'.$aLogId);
        }

        $aResult = $redis->exec();

        foreach($aResult as $nIdx => $aRow){

            $aResult[$nIdx]['agent_name'] = $redis->hget('server:'.$aRow['agent_id'], 'agent_name');
        }

        //JSON 응답
        $this->output->set_content_type('application/json')->set_output(json_encode(array(
            'result' => 'success',
            'data'   => $aResult
        )));
    }

    public function getServers($sServer)
    {

        if ($sServer == 'root') {

            //필요한 모델을 로드한다.
            $this->load->model('tbl_agent_info');

            //에이전트 그룹정보를 가져온다.
            $aData       = array_pop($this->tbl_agent_info->select("GROUP_CONCAT(agent_id) as agents")->get());
            $sServerList = $aData['agents'];
        } else if (strpos($sServer, 'group') > -1) {

            //필요한 모델을 로드한다.
            $this->load->model('tbl_agent_info');

            //에이전트 그룹정보와 조인한 tbl_agent_info를 가져온다.
            $aData       = array_pop($this->tbl_agent_info->select("GROUP_CONCAT(agent_id) as agents")->setGroupId(str_replace("group-", "", $sServer))->get());
            $sServerList = $aData['agents'];
        } else {

            $sServerList = str_replace("server-", "", $sServer);
        }

        return $sServerList;
    }

    /**
     * getCurrentServerTime
     *
     * 서버의 현재시간을 json으로 반환한다.
     *
     * @access public
     *
     * @return mixed json object.
     */
    public function getCurrentServerTime()
    {

        $this->load->config('realtime', true);
        $nStartSecond = $this->config->item('start_second', 'realtime');

        $this->output->set_content_type('application/json')->set_output(
            json_encode(explode('-', date('Y-m-d-H-i-s', strtotime('-'.$nStartSecond.' seconds'))))
        );
    }

    /**
     * getServerList
     *
     * 서버 리스트를 json으로 반환한다.
     *
     * @access public
     *
     * @return mixed json object.
     */
    public function getServerList()
    {

        //필요한 모델을 로드한다.
        $this->load->model(array(
            'tbl_agent_info'
        ));

        //에이전트 그룹정보와 조인한 tbl_agent_info를 가져온다.
        $aData = $this->tbl_agent_info->select(array('agent_id', 'agent_name'))->isAgent()->live()->get();

        $aList = array();
        foreach ($aData as $nIdx => $aRow) {
            $aList[$aRow['agent_id']] = $aRow['agent_name'];
        }


        $this->output->set_content_type('application/json')->set_output(
            json_encode($aList)
        );
    }


}
/* End of file realtime.php */
/* Location: ./application/controllers/monitoring/realtime.php */