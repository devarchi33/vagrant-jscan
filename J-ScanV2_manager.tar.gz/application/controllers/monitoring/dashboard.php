<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Dashboard
 *
 * 대쉬보드
 *
 * @uses     CI_Controller
 * @category monitoring
 * @package  WhiteSQL
 * @author   정주원 <jjwcom@nate.com>
 * @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
 * @link
 */
class Dashboard extends CI_Controller
{

    public function __construct()
    {

        parent::__construct();

        $this->redis = new Redis();
        $this->redis->connect('127.0.0.1', 6379);
    }

    /**
     * index
     *
     * 메인 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function index()
    {

        $this->load->config("system", true);
        $sSKin = $this->config->item('skin', 'system');

        //main view를 로드 합니다.
        $this->load->view('monitoring/dashboard.php', array(
            'skin' => $sSKin
        ));
    }

    /**
     * getSQLLog
     *
     * SQL LOG 데이터를 가져온다.
     *
     * @access public
     *
     * @return mixed json object.
     */
    public function getData()
    {

        //파라미터를 받는다.
        $sServer = $this->input->post('server', 'root');

        $aResult = array(
            'event_count'       => $this->getChartEventCount($sServer),
            'exec_result_count' => $this->getAvgNumOfQueryExecResults($sServer),
            'exec_count'        => $this->getNumOfQueryExec($sServer),
            'server_exec_count' => $this->getStatusOfQueryExec($sServer)
        );

        $this->output->set_content_type('application/json')->set_output(json_encode($aResult));
    }

    //SQL 수행 누적 건수
    public function getStatusOfQueryExec($sServer = 'root')
    {
        $sServer = str_replace("-", ":", $sServer);
        $aAgents   = $this->redis->sMembers($sServer.":agent");

        $tmp     = array();

        $this->redis->multi();
        foreach ($aAgents as $sIdx => $nAgentId) {

            $this->redis->hGet('server:'.$nAgentId, 'agent_name');
            $this->redis->hGetAll('total_grid:server:'.$nAgentId);
        }
        $aResult = $this->redis->exec();

        $nAgentIdx = 0;
        for ($nIdx = 0; $nIdx < count($aResult); $nIdx += 2) {

            $nNext = $nIdx + 1;
            $nAgentId = $aAgents[$nAgentIdx];

            array_push($tmp, array(
                'agent_id'          => $aAgents[$nAgentIdx],
                'agent_name'        => $aResult[$nIdx],
                'cnt_table'         => @(int)$aResult[$nNext][$nAgentId.':cnt_table'],
                'cnt_conv'          => @(int)$aResult[$nNext][$nAgentId.':cnt_conv'],
                'cnt_fail'          => @(int)$aResult[$nNext][$nAgentId.':cnt_fail'],
                'cnt_exec'          => @(int)$aResult[$nNext][$nAgentId.':cnt_exec'],
                'cnt_personal_info' => @(int)$aResult[$nNext][$nAgentId.':cnt_personal_info']
            ));

            $nAgentIdx++;
        }

        return $tmp;
    }

    //위험 수준별 실시간 건수
    public function getChartEventCount($sServer = 'root')
    {
        $aLevel = array_fill_keys(array('notice', 'attention', 'alert', 'danger', 'serious'), 0);

        $aAgents = $this->redis->sMembers('root:agent');

        if (count($aAgents) == 0) {

            return [];
        }

        $tmp = array();

        $this->redis->multi();
        foreach ($aAgents as $nIdx => $nAgent) {

            $this->redis->hGet('server:'.$nAgent, 'agent_name');
            $this->redis->hGetAll('event_count:server:'.$nAgent);
        }
        $aResult = $this->redis->exec();

        $nAgentIdx = 0;
        for ($nIdx = 0; $nIdx < count($aResult); $nIdx += 2) {

            array_push($tmp, array_merge(
                $aLevel,
                $aResult[$nIdx + 1],
                array(
                    'agent_id'   => $aAgents[$nAgentIdx],
                    'agent_name' => $aResult[$nIdx]
                )
            ));

            $nAgentIdx++;
        }

        return $tmp;
    }

    //데이터 조회 건수 Top 10
    public function getAvgNumOfQueryExecResults($sServer = 'root')
    {

        $sServer = str_replace("-", ":", $sServer);
        $aData   = $this->redis->hGetAll('exec_result_count:'.$sServer);

        arsort($aData);
        $aData = array_slice($aData, 0, 10);

        $tmp = array();
        foreach ($aData as $sIdx => $nVal) {

            list($agent_id, $uniqsql_id, $ipaddr) = explode(":", $sIdx);

            $agent_name   = $this->redis->hGet('server:'.$agent_id, 'agent_name');
            $sql_type     = $this->redis->hGet('uniqsql:'.$uniqsql_id, 'sql_type');
            $ref_tables   = $this->redis->hGet('uniqsql:'.$uniqsql_id, 'ref_tables');
            $result_count = $nVal;

            array_push($tmp, array(
                'agent_id'     => $agent_id,
                'ip'           => $ipaddr,
                'uniqsql_id'   => $uniqsql_id,
                'agent_name'   => $agent_name,
                'sql_type'     => $sql_type,
                'ref_tables'   => $ref_tables,
                'result_count' => $result_count
            ));
        }

        return $tmp;
    }

    //쿼리 수행 건수 Top 10
    public function getNumOfQueryExec($sServer = 'root')
    {

        $sServer = str_replace("-", ":", $sServer);
        $aData   = $this->redis->hGetAll('exec_count:'.$sServer);

        arsort($aData);
        $aData = array_slice($aData, 0, 10);

        $tmp = array();
        foreach ($aData as $sIdx => $nVal) {

            list($agent_id, $uniqsql_id, $ipaddr) = explode(":", $sIdx);

            $agent_name = $this->redis->hGet('server:'.$agent_id, 'agent_name');
            $sql_type   = $this->redis->hGet('uniqsql:'.$uniqsql_id, 'sql_type');
            $ref_tables = $this->redis->hGet('uniqsql:'.$uniqsql_id, 'ref_tables');
            $exec_count = $nVal;

            array_push($tmp, array(
                'agent_id'   => $agent_id,
                'ip'         => $ipaddr,
                'uniqsql_id' => $uniqsql_id,
                'agent_name' => $agent_name,
                'sql_type'   => $sql_type,
                'ref_tables' => $ref_tables,
                'exec_count' => $exec_count
            ));
        }

        return $tmp;
    }

    //이벤트 리스트 최근 20
    public function getEventDataTop20()
    {

        //인자로 받은 type을 기준으로 불러올 기간의 시작, 종료일을 가져온다.
        $aDate = getDatePeriod('now', "-1 day");

        //시작 종료일 셋팅
        $sFDate = $aDate['start_date'];
        $sTDate = $aDate['end_date'];

        $this->load->model('tbl_eventlog');
        $this->tbl_eventlog->db->where('event_time BETWEEN UNIX_TIMESTAMP("'.$sFDate.'") AND UNIX_TIMESTAMP("'.$sTDate.'")');
        $this->tbl_eventlog->db->order_by('eventlog_id', 'DESC');
        $aData = $this->tbl_eventlog->select(array(
            'agent_name',
            'event_level',
            'event_msg'
        ), true)->joinAgentInfo()->limit(0, 20)->get();

        $this->output->set_content_type('application/json')->set_output(json_encode($aData));
    }

    /**
     * getServerList
     *
     * server list 정보를 가져온다.
     *
     * @access public
     *
     * @return mixed Value.
     */
    public function getServerList($json = true)
    {
        //필요한 모델을 로드한다.
        $this->load->model(array(
            'tbl_agent_info'
        ));

        //에이전트 그룹정보와 조인한 tbl_agent_info를 가져온다.
        $aData = array_pop($this->tbl_agent_info->select('group_concat(agent_name) as lists')->get());
        $aList = explode(",", $aData['lists']);

        if ($json) $this->output->set_content_type('application/json')->set_output(json_encode($aList));
        else return $aList;
    }
}
/* End of file main.php */
/* Location: ./application/controllers/main/main.php */