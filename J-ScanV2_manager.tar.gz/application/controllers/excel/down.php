<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* Down
*
* Down 클래스
*
* @uses     CI_Controller
* @category log
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class Down extends CI_Controller {

    /**
     * index
     *
     * 메인 컨트롤러 index
     *
     * @access public
     *
     * @return mixed Value.
     */
	public function index()
	{

        return $this->export();
	}

    /**
     * export
     * 
     * 쿼리를 export 한다.
     * 
     * @access public
     *
     * @return excel file
     */
    public function export(){

        //파라미터를 받는다.
        $sParams = $this->input->post('params');
        $aParams = json_decode($sParams, true);

        ini_set('memory_limit', '-1');
        set_time_limit(0);

        $this->load->library("PHPExcel", null, "PHPExcel");

        $this->PHPExcel->setActiveSheetIndex(0);
        $sheet = $this->PHPExcel->getActiveSheet();

        $col = 'A';
        foreach($aParams['columns'] as $nIdx => $aColumn){

            $sheet->SetCellValue($col.'1', $aColumn['text']);
            $sheet->getStyle($col.'1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('E7E7E7');
            $col++;
        }

        $nRow = 2;
        foreach($aParams['rows'] as $nIdx => $aRow){

            $col = 'A';
            foreach($aParams['columns'] as $nIdx => $aColumn){

                $sVal = $aRow[$aColumn['index']];

                $col_idx = $col.$nRow;

                $preg_val = preg_replace("/(xx1[a-zA-Z0-9_.\'\",()]+)/", "[p]$1[p]", $sVal, -1);

                $tmp = explode('[p]', $preg_val);

                if(count($tmp) > 1){

                    $objRichText = new PHPExcel_RichText();

                    foreach($tmp as $tidx => $tval){

                        if(preg_match("/(xx1[a-zA-Z0-9_.\'\",()]+)/", $tval) == true){

                            $objPayable = $objRichText->createTextRun($tval);
                            $objPayable->getFont()->setBold(true);
                            $objPayable->getFont()->setItalic(true);
                            $objPayable->getFont()->setColor( new PHPExcel_Style_Color( PHPExcel_Style_Color::COLOR_RED ) );
                        }
                        else {

                            $objRichText->createText($tval);
                        }
                    }
     
                    $sheet->SetCellValue($col_idx, $objRichText);
                }
                else {

                    $sheet->SetCellValue($col_idx, $sVal);
                }

                // $sheet->getStyle($col_idx)->getAlignment()->setWrapText(true)->setVertical(PHPExcel_Style_Alignment::VERTICAL_TOP);
                // $calculatedWidth = $sheet->getColumnDimension($col_idx)->setAutoSize(true);

                $col++;
            }

            $nRow++;
        }

        $styleArray = array(
               'borders' => array(
                     'allborders' => array(
                            'style' => PHPExcel_Style_Border::BORDER_THIN,
                            'color' => array('argb' => '00000000'),
                     )
               )
        );

        $this->PHPExcel->getActiveSheet()->getStyle('A1:'.chr(ord($col) - 1).--$nRow)->applyFromArray($styleArray);

        $this->PHPExcel->getActiveSheet()->setTitle('Export Data');

        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="export_'.date("YmdHis").'.xlsx"');
        header('Cache-Control: max-age=0');

        $objWriter = PHPExcel_IOFactory::createWriter($this->PHPExcel, 'Excel2007');
        $objWriter->save('php://output');
    }
}
/* End of file sql_convert.php */
/* Location: ./application/controllers/manage/sql_convert.php */