/*
SQLyog Ultimate v8.82 
MySQL - 5.6.14 : Database - WhiteSQL
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`WhiteSQL` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `WhiteSQL`;

/*Table structure for table `mt_event` */

DROP TABLE IF EXISTS `mt_event`;

CREATE TABLE `mt_event` (
  `notice` int(10) NOT NULL COMMENT '알림',
  `attention` int(10) NOT NULL COMMENT '주의',
  `alert` int(10) NOT NULL COMMENT '경보',
  `danger` int(10) NOT NULL COMMENT '위험',
  `serious` int(10) NOT NULL COMMENT '심각'
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COMMENT='[데몬]이벤트 서머리';

/*Table structure for table `mt_state` */

DROP TABLE IF EXISTS `mt_state`;

CREATE TABLE `mt_state` (
  `cpu` tinyint(4) NOT NULL COMMENT 'CPU사용률',
  `mem` tinyint(4) NOT NULL COMMENT '메모리 사용률',
  `disk` tinyint(4) NOT NULL COMMENT '디스크 사용률',
  `key` tinyint(4) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COMMENT='[데몬]시스템 자원 사용률 서머리';

/*Table structure for table `mt_sum_sqllog` */

DROP TABLE IF EXISTS `mt_sum_sqllog`;

CREATE TABLE `mt_sum_sqllog` (
  `sum_time` int(10) NOT NULL,
  `date_f` date NOT NULL,
  `time_f` tinyint(4) NOT NULL,
  `agent_id` int(10) NOT NULL,
  `uniqsql_id` bigint(20) NOT NULL,
  `class_id` int(10) NOT NULL,
  `sql_type` varchar(8) NOT NULL,
  `whitesql_id` int(10) NOT NULL DEFAULT '0',
  `execute_yn` tinyint(4) NOT NULL,
  `convert_yn` tinyint(4) DEFAULT NULL,
  `block_yn` tinyint(4) NOT NULL,
  `sum_count` int(10) NOT NULL DEFAULT '0',
  `avg_elapsedtime` float(10,3) NOT NULL DEFAULT '0.000',
  `avg_result_count` int(10) NOT NULL DEFAULT '0',
  `read_yn` tinyint(1) NOT NULL
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_agent_dbconn` */

DROP TABLE IF EXISTS `tbl_agent_dbconn`;

CREATE TABLE `tbl_agent_dbconn` (
  `agent_id` int(11) NOT NULL COMMENT 'Agent ID',
  `dbconn_id` int(11) NOT NULL COMMENT 'DB 연결 ID',
  PRIMARY KEY (`agent_id`,`dbconn_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_agent_info` */

DROP TABLE IF EXISTS `tbl_agent_info`;

CREATE TABLE `tbl_agent_info` (
  `agent_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '서버 아이디',
  `agent_name` varchar(40) NOT NULL DEFAULT '' COMMENT '서버이름',
  `ipaddr` varchar(16) NOT NULL DEFAULT '' COMMENT '서버아이피',
  `port` int(10) unsigned NOT NULL DEFAULT '20225' COMMENT '서버 데몬(watch dispatcher) listen port, 기본값 20225',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '서버그룹아이디(tbl_agent_group_info.group_id) 기본값 0',
  `status` enum('0','1') NOT NULL DEFAULT '0' COMMENT '서버상태(1:connected,0:disconnected)',
  `agent_mode` enum('0','1','2','3') NOT NULL DEFAULT '0' COMMENT '동작모드(0:bypass, 1:logging, 2:monitoring, 3:protect)',
  `privacy_flag` enum('0','1') NOT NULL DEFAULT '0' COMMENT '개인정보체크여부(0,1)',
  `sync_flag` enum('0','1') NOT NULL DEFAULT '0' COMMENT '동기화 수행 필요성 체크(0:동기화 대상, 1:동기화완료)',
  `license_check` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '라이선스 체크여부(0:라이센스에러, 1:데모라이센스, 2:정식라이센스)',
  `license_expiredate` date DEFAULT NULL COMMENT '라이센스 만료기한',
  `license_key` varchar(64) DEFAULT NULL COMMENT '라이센스키',
  `license_status` enum('0','1') DEFAULT '0' COMMENT '라이센스상태(0:정상, 1:에러)',
  `description` varchar(100) DEFAULT NULL COMMENT '설명',
  `last_work_time` int(10) unsigned NOT NULL COMMENT '최근 수정 시간',
  `last_work_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '최근 수정 사용자 ID(tbl_userinfo.user_id)',
  `rs_logging_yn` enum('0','1') DEFAULT '0' COMMENT '결과레코드로깅여부(0:로깅안함, 1:로깅)',
  `del_yn` enum('0','1') DEFAULT '0' COMMENT '삭제여부(0:미삭제, 1:삭제)',
  `server_type` enum('1','2') DEFAULT '1' COMMENT '서버구분값(1:Agent, 2:DB모니터링)',
  `sid` varchar(184) DEFAULT NULL COMMENT 'SID',
  `db_user_id` varchar(128) DEFAULT NULL COMMENT '접속유저ID',
  `db_passwd` varchar(256) DEFAULT NULL COMMENT '접속유저비밀번호',
  `db_kind` enum('0','1','2','3','4') DEFAULT '0' COMMENT '디비종류(0:없음, 1:oracle, 2:mssql, 3:mysql)',
  PRIMARY KEY (`agent_id`),
  KEY `fk_tbl_agent_info_tbl_agentgroup_info1_idx` (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='서버 정보';

/*Table structure for table `tbl_agentgroup_info` */

DROP TABLE IF EXISTS `tbl_agentgroup_info`;

CREATE TABLE `tbl_agentgroup_info` (
  `group_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '그룹아이디',
  `group_name` varchar(40) NOT NULL DEFAULT '' COMMENT '그룹이름',
  `description` varchar(100) DEFAULT NULL COMMENT '설명',
  `last_work_time` int(10) unsigned NOT NULL COMMENT '최근수정시간',
  `last_work_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '최근수정사용자(tbl_userinfo.user_id)',
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='서버그룹정보';

/*Table structure for table `tbl_anal_log` */

DROP TABLE IF EXISTS `tbl_anal_log`;

CREATE TABLE `tbl_anal_log` (
  `sqllog_id` varchar(22) NOT NULL,
  `sql_type` varchar(8) NOT NULL,
  `uniqsql_id` bigint(20) NOT NULL,
  `dbconn_id` int(10) DEFAULT NULL COMMENT '디비 커넥션 아이디',
  `class_name` text NOT NULL COMMENT '클래스명',
  `class_id` bigint(20) NOT NULL COMMENT '클래스아이디',
  `whitesql_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'White SQL 아이디',
  `convsql_id` int(10) NOT NULL DEFAULT '0' COMMENT 'Convert(변환) SQL 아이디',
  `blocksql_id` int(10) NOT NULL DEFAULT '0' COMMENT 'Block(차단) SQL 아이디',
  `sqllog_check` varchar(255) DEFAULT NULL,
  `log_reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `result_data_saved` enum('0','1') NOT NULL DEFAULT '0' COMMENT '결과값 저장 여부',
  `privacytbl_yn` enum('0','1') DEFAULT '0' COMMENT '개인정보테이블 접근 여부',
  PRIMARY KEY (`sqllog_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_blocksql_list` */

DROP TABLE IF EXISTS `tbl_blocksql_list`;

CREATE TABLE `tbl_blocksql_list` (
  `blocksql_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '블록SQL아이디',
  `agent_id` int(10) unsigned NOT NULL COMMENT '서버아이디(=tbl_agent_info.user_id)',
  `policy_name` varchar(255) NOT NULL COMMENT '정책이름',
  `policy_type` enum('1','2','3','4','5','6','7','8') NOT NULL COMMENT '정책 종류(1:BLOCK_SQL, 2:USER_BLOCK_IP, 3:USER_BLOCK_LOGIN_ID)',
  `policy_id` int(10) unsigned NOT NULL COMMENT '정책아이디',
  `apply_starttime` int(10) NOT NULL COMMENT '정책적용시작시간',
  `apply_endtime` int(10) NOT NULL COMMENT '정책적용완료시간',
  `event_level` tinyint(4) NOT NULL COMMENT '이벤트레벨(아직사용하지 않는다 나중에 정책이 정해지면 추가작업)',
  `description` varchar(255) DEFAULT NULL COMMENT '설명',
  `reg_time` int(10) NOT NULL COMMENT '정책등록시간',
  `reg_user_id` int(10) NOT NULL COMMENT '정책추가유저아이디',
  `state` char(1) NOT NULL DEFAULT 'A' COMMENT '상태값(A:추가, M:수정, D:삭제, N:정상=싱크가 완료되었다는 의미)\n상태가 A일때 수정이 일어나도 A를 유지',
  `on_off` enum('0','1') NOT NULL DEFAULT '0' COMMENT '정책 켜기(0:끄기, 1:켜기)',
  `sync_flag` enum('0','1') NOT NULL DEFAULT '0' COMMENT '동기화 수행 대상여부(0:동기화대상, 1:동기화완료)',
  `sync_succ_flag` enum('0','1') NOT NULL DEFAULT '0' COMMENT '동기화 수행 결과(0:실패, 1:성공)',
  `sync_time` int(10) DEFAULT NULL COMMENT '동기화 수행 시간',
  `sync_user_id` int(10) unsigned DEFAULT NULL COMMENT '동기화 사용자 ID',
  `last_work_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '최근 수정 시간',
  `last_work_user_id` varchar(20) NOT NULL COMMENT '최근 수정자 아이디(=tbl_userinfo.user_id)',
  PRIMARY KEY (`blocksql_id`),
  KEY `fk_tbl_blocksql_list_tbl_agent_info1_idx` (`agent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Block SQL 리스트';

/*Table structure for table `tbl_class_trace` */

DROP TABLE IF EXISTS `tbl_class_trace`;

CREATE TABLE `tbl_class_trace` (
  `class_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '클래스아이디',
  `hash` varchar(32) NOT NULL COMMENT '해시값',
  `class_string` varchar(128) NOT NULL COMMENT '클래스이름',
  PRIMARY KEY (`class_id`)
) ENGINE=MyISAM AUTO_INCREMENT=320 DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_convsql_list` */

DROP TABLE IF EXISTS `tbl_convsql_list`;

CREATE TABLE `tbl_convsql_list` (
  `convsql_id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Convert SQL 아이디',
  `agent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '서버아이디(=tbl_agent_info.agent_id)',
  `whitesql_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'WhiteSQL ID',
  `uniqsql_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Unique SQL 아이디(=tbl_uniqsql.uniqsql_id)',
  `class_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Class 아이디',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등록시간',
  `reg_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등록 유저 아이디',
  `conv_sqltext` text NOT NULL COMMENT 'Convert SQL',
  `state` enum('A','M','D','N') NOT NULL DEFAULT 'A' COMMENT '상태값(A:추가, M:수정, D:삭제, N:정상=싱크가 완료되었다는 의미)\n상태가 A일때 수정이 일어나도 A를 유지',
  `on_off` enum('0','1') NOT NULL DEFAULT '0' COMMENT '정책 켜기(0:끄기, 1:켜기)',
  `sync_flag` enum('0','1') NOT NULL DEFAULT '0' COMMENT '동기화 수행 대상여부(0:동기화대상, 1:동기화완료)',
  `sync_succ_flag` enum('0','1') NOT NULL DEFAULT '0' COMMENT '동기화 수행 결과(0:실패, 1:성공)',
  `sync_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '동기화 수행 시간',
  `sync_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '동기화 사용자 ID',
  `last_work_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '최근 수정 시간',
  `last_work_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '최근 수정자 아이디(=tbl_userinfo.user_id)',
  PRIMARY KEY (`convsql_id`),
  KEY `idx_sqlchange_uniq1` (`agent_id`,`uniqsql_id`,`class_id`),
  KEY `fk_tbl_convsql_list_tbl_class_trace1_idx` (`class_id`),
  KEY `fk_tbl_convsql_list_tbl_uniqsql1_idx` (`uniqsql_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Convert SQL 리스트';

/*Table structure for table `tbl_dbconn` */

DROP TABLE IF EXISTS `tbl_dbconn`;

CREATE TABLE `tbl_dbconn` (
  `dbconn_id` int(10) NOT NULL AUTO_INCREMENT COMMENT '디비 Connection id',
  `hash` varchar(32) NOT NULL COMMENT '해쉬값',
  `dbconn_url` varchar(256) NOT NULL COMMENT '디비 연결 정보 URL',
  `dbconn_account` varchar(64) NOT NULL COMMENT '디비 연결 계정명',
  `collect_time` int(10) NOT NULL COMMENT '수집 시간',
  `ipaddr` varchar(16) DEFAULT NULL COMMENT '서버IP',
  `port` int(10) DEFAULT NULL COMMENT '서버Port',
  `sid` varchar(184) DEFAULT NULL COMMENT 'SID',
  `dbname` varchar(128) DEFAULT NULL COMMENT '시스템명',
  PRIMARY KEY (`dbconn_id`),
  UNIQUE KEY `ipaddr_port_sid` (`ipaddr`,`port`,`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='JDBC DB 연결 정보';

/*Table structure for table `tbl_eventlog` */

DROP TABLE IF EXISTS `tbl_eventlog`;

CREATE TABLE `tbl_eventlog` (
  `eventlog_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '이벤트 로그아이디',
  `event_type` enum('0','1') NOT NULL DEFAULT '0' COMMENT '이벤트 타입(0:정책에 의한 차단(알림,주의,경보,위험,심각), 1:System 문제발생)',
  `event_time` int(10) NOT NULL COMMENT '이벤트 발생 시간',
  `event_level` enum('1','2','3','4','5') NOT NULL COMMENT '이벤트 레벨(1:알림, 2:주의, 3:경보, 4:위험, 5:심각)',
  `event_kind` enum('0','1','2','3','4','5','6','7','8','9','10','11') NOT NULL COMMENT '이벤트 종류(0:정보변경, 1:정책변경, 2:SQL수행실패, 3:NonWhiteSQL발생, 4:개인정보, 5:SQLInjection, 6:UserBlockSQL, 7:정책위배, 8:대량의데이터조회, 9:자동화된데이터조회)',
  `policy_type` enum('0','1','2','3','4','5','6','7') NOT NULL DEFAULT '0' COMMENT '정책 유형(0:자동검사, 1:SQL, 2:SQL변경, 3:IP, 4:LOGIN_ID, 5:주요TABLE, 6:SQL유형, 7:개인정보TABLE)',
  `event_msg` varchar(255) NOT NULL COMMENT '이벤트 메시지',
  `event_confirm_flag` tinyint(1) NOT NULL DEFAULT '0' COMMENT '이벤트 확인 여부',
  `event_confirm_comment` text COMMENT '이벤트 확인시 남기는 메시지',
  `event_tblname` varchar(32) NOT NULL DEFAULT '' COMMENT '관련테이블명(policy_history, work_history)',
  `event_tblid` varchar(22) NOT NULL COMMENT '관련테이블 Primary key(sqllog인 경우 tbl_sqllog.sqllog_id)',
  `agent_id` int(10) NOT NULL DEFAULT '0' COMMENT '이벤트 발생 서버 아이디(=tbl_agent_info.agent_id)',
  PRIMARY KEY (`eventlog_id`),
  KEY `fk_tbl_eventlog_tbl_agent_info1_idx` (`agent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='이벤트 로그 테이블';

/*Table structure for table `tbl_log` */

DROP TABLE IF EXISTS `tbl_log`;

CREATE TABLE `tbl_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Log ID Primary Key',
  `sqllog_id` varchar(22) NOT NULL,
  `agent_id` int(10) NOT NULL,
  `agent_mode` tinyint(4) NOT NULL,
  `request_time` datetime(6) NOT NULL,
  `prestmt` varchar(8) NOT NULL,
  `sql_str` text,
  `sql_param` text NOT NULL,
  `dbconn_url` varchar(256) NOT NULL DEFAULT '' COMMENT '디비 커넥션 정보',
  `dbconn_account` varchar(64) NOT NULL DEFAULT '',
  `class_trace` text NOT NULL COMMENT '??',
  `policy_id` int(10) NOT NULL DEFAULT '0' COMMENT 'Block(차단) SQL 아이디',
  `block_yn` tinyint(1) NOT NULL DEFAULT '0' COMMENT '차단 여부',
  `login_id` varchar(100) NOT NULL DEFAULT '' COMMENT '어플리케이션 로그인 아이디',
  `ipaddr` varchar(16) NOT NULL DEFAULT '' COMMENT '아이피 어드레스',
  `exec_starttime` bigint(13) NOT NULL DEFAULT '0',
  `exec_elapsedtime` float(10,3) NOT NULL DEFAULT '0.000',
  `execute_yn` tinyint(4) NOT NULL,
  `fail_code` text,
  `result_count` int(10) NOT NULL DEFAULT '0',
  `privacy_type` enum('jumin','passport','none') NOT NULL DEFAULT 'none',
  `privacy_value` varchar(32) DEFAULT NULL,
  `result_data` text,
  `log_reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  UNIQUE KEY `sqllog_id` (`sqllog_id`),
  KEY `request_time` (`request_time`) USING BTREE,
  KEY `log_reg_date` (`log_reg_date`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=478020 DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_newsql` */

DROP TABLE IF EXISTS `tbl_newsql`;

CREATE TABLE `tbl_newsql` (
  `newsql_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'New SQL 아이디',
  `hash` varchar(32) NOT NULL COMMENT '해시값',
  `sqllog_id` varchar(22) NOT NULL COMMENT 'SQL Log 아이디',
  `uniqsql_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Uniq SQL 아이디',
  `class_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'class 아이디',
  `agent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'agent 아이디',
  `sql_type` enum('SELECT','INSERT','UPDATE','DELETE','CREATE','ALTER','DROP','TRUNCATE','GRANT','REVOKE','EXPLAIN PLAN','RENAME','ETC') NOT NULL COMMENT 'New SQL 타입',
  `orig_sqltext` text NOT NULL COMMENT 'New SQL',
  `reg_date` datetime NOT NULL COMMENT '발생일자',
  PRIMARY KEY (`newsql_id`),
  KEY `idx_uniqsql_sqltype` (`sql_type`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_policy_history` */

DROP TABLE IF EXISTS `tbl_policy_history`;

CREATE TABLE `tbl_policy_history` (
  `policy_history_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '정책 히스토리 아이디',
  `policy_type` enum('0','1','2','3','4','5','6','7','8') NOT NULL COMMENT '정책 유형(0:WhiteSQL, 1:SQL, 2:SQL변경, 3:IP, 4:LOGIN_ID, 5:주요TABLE, 6:SQL유형, 7:개인정보TABLE)',
  `policy_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '정책 아이디',
  `agent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '서버 아이디',
  `work_type` enum('add','mod','del') NOT NULL DEFAULT 'add' COMMENT '작업 종류(0:ADD, 1:MOD, 2:DEL)',
  `work_time` int(10) unsigned NOT NULL COMMENT '작업 시간',
  `work_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '작업자 아이디(=tbl_userinfo.user_id)',
  `work_message` text COMMENT '작업 메시지',
  `work_before` text COMMENT '작업 전 내용(JSON)',
  `work_after` text COMMENT '작업 후 내용(JSON)',
  PRIMARY KEY (`policy_history_id`)
) ENGINE=MyISAM AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_policy_list` */

DROP TABLE IF EXISTS `tbl_policy_list`;

CREATE TABLE `tbl_policy_list` (
  `policy_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '정책 아이디',
  `policy_name` varchar(255) NOT NULL COMMENT '정책명',
  `policy_type` enum('1','2','3','4','5','6','7') NOT NULL DEFAULT '1' COMMENT '정책 유형(1:SQL, 2:SQL변경, 3:IP, 4:LOGIN_ID, 5:주요TABLE, 6:SQL유형, 7:개인정보TABLE)',
  `policy_properties` longtext COMMENT '부가 속성(JSON 포맷)',
  `agent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '서버 아이디(=tbl_agent_info.agent_id)',
  `alarm_level` enum('1','2','3','4','5') NOT NULL DEFAULT '1' COMMENT '알람 레벨(1:알림, 2:주의, 3:경보, 4:위험, 5:심각)',
  `block` enum('0','1') NOT NULL DEFAULT '0' COMMENT '차단 여부(0:안함, 1:차단)',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등록시간',
  `reg_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등록 유저 아이디',
  `state` enum('A','M','D','N') NOT NULL DEFAULT 'A' COMMENT '상태값(A:추가, M:수정, D:삭제, N:정상=싱크가 완료되었다는 의미)\n상태가 A일때 수정이 일어나도 A를 유지',
  `on_off` enum('0','1') NOT NULL DEFAULT '0' COMMENT '정책 켜기(0:끄기, 1:켜기)',
  `sync_flag` enum('0','1') NOT NULL DEFAULT '0' COMMENT '동기화 수행 대상여부(0:동기화대상, 1:동기화완료)',
  `sync_succ_flag` enum('0','1') NOT NULL DEFAULT '0' COMMENT '동기화 수행 결과(0:실패, 1:성공)',
  `sync_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '동기화 수행 시간',
  `sync_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '동기화 사용자 ID',
  `last_work_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '최근 수정 시간',
  `last_work_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '최근 수정자 아이디(=tbl_userinfo.user_id)',
  `del_yn` enum('0','1') NOT NULL DEFAULT '0' COMMENT '삭제여부(0:미삭제, 1:삭제)',
  PRIMARY KEY (`policy_id`),
  KEY `idx_sqlchange_uniq1` (`agent_id`)
) ENGINE=MRG_MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_privacytbl_list` */

DROP TABLE IF EXISTS `tbl_privacytbl_list`;

CREATE TABLE `tbl_privacytbl_list` (
  `privacytbl_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '일련번호',
  `agent_id` int(10) unsigned NOT NULL COMMENT '에이전트 ID',
  `privacytbl_name` varchar(255) NOT NULL COMMENT '개인정보 테이블명칭',
  `privacytbl` varchar(255) DEFAULT NULL COMMENT '개인정보 테이블',
  `state` enum('A','M','D','N') NOT NULL COMMENT '상태값(A:추가, M:수정, D:삭제, N:정상=싱크가 완료되었다는 의미)',
  `sync_flag` enum('0','1') NOT NULL DEFAULT '0' COMMENT '동기화 수행 대상 여부',
  `sync_succ_flag` enum('0','1') NOT NULL DEFAULT '0' COMMENT '동기화 성공여부',
  `sync_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '동기화 수행시간',
  `sync_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '동기화 수행자 ID',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등록일시',
  `last_work_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '최종 작업 일시',
  `last_work_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '최종 작업 수행자 ID',
  `reg_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '등록자',
  `del_yn` enum('0','1') NOT NULL DEFAULT '0' COMMENT '삭제여부(0:미삭제, 1:삭제)',
  PRIMARY KEY (`privacytbl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_sqllog` */

DROP TABLE IF EXISTS `tbl_sqllog`;

CREATE TABLE `tbl_sqllog` (
  `sqllog_id` bigint(20) unsigned NOT NULL,
  `agent_id` int(10) NOT NULL,
  `agent_mode` tinyint(4) NOT NULL,
  `request_time` datetime(6) NOT NULL,
  `sql_type` varchar(8) NOT NULL,
  `req_sqltext` text,
  `uniqsql_id` bigint(20) NOT NULL,
  `sqlparam` text NOT NULL,
  `dbconn_id` int(10) DEFAULT NULL COMMENT '디비 커넥션 아이디',
  `dbconn_url` varchar(256) NOT NULL DEFAULT '' COMMENT '디비 커넥션 정보',
  `dbconn_account` varchar(64) NOT NULL DEFAULT '',
  `class_text` text NOT NULL COMMENT '클래스명',
  `class_id` bigint(20) NOT NULL COMMENT '클래스아이디',
  `whitesql_id` bigint(20) NOT NULL DEFAULT '0' COMMENT 'White SQL 아이디',
  `convsql_id` int(10) NOT NULL DEFAULT '0' COMMENT 'Convert(변환) SQL 아이디',
  `blocksql_id` int(100) NOT NULL DEFAULT '0' COMMENT 'Block(차단) SQL 아이디',
  `block_yn` tinyint(1) NOT NULL DEFAULT '0' COMMENT '차단 여부',
  `login_id` varchar(100) NOT NULL DEFAULT '' COMMENT '어플리케이션 로그인 아이디',
  `ipaddr` varchar(16) NOT NULL DEFAULT '' COMMENT '아이피 어드레스',
  `session_id` varchar(256) NOT NULL COMMENT '세션 아이디',
  `session_createtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '세션 생성시간',
  `exec_starttime` int(10) unsigned NOT NULL DEFAULT '0',
  `exec_endtime` int(10) unsigned NOT NULL DEFAULT '0',
  `exec_elapsedtime` float(10,3) NOT NULL DEFAULT '0.000',
  `execute_yn` tinyint(4) NOT NULL,
  `result_count` int(10) NOT NULL DEFAULT '0',
  `fail_code` text,
  `sqllog_check` varchar(255) DEFAULT NULL,
  `privacy_type` enum('card','jumin','none') NOT NULL DEFAULT 'none',
  `privacy_value` varchar(32) DEFAULT NULL,
  `log_reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `result_data_saved` enum('0','1') NOT NULL DEFAULT '0' COMMENT '결과값 저장 여부',
  `privacytbl_yn` enum('0','1') DEFAULT '0' COMMENT '개인정보테이블 접근 여부',
  KEY `index_request_time` (`request_time`),
  KEY `index_sqllog_id` (`sqllog_id`),
  KEY `index_log_reg_date` (`log_reg_date`),
  KEY `dsgsdgsdgs` (`req_sqltext`(19),`sqlparam`(20)) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8
/*!50100 PARTITION BY RANGE (TO_DAYS(request_time))
(PARTITION p201308 VALUES LESS THAN (735477) ENGINE = InnoDB,
 PARTITION p201309 VALUES LESS THAN (735507) ENGINE = InnoDB,
 PARTITION p201310 VALUES LESS THAN (735538) ENGINE = InnoDB,
 PARTITION p201311 VALUES LESS THAN (735568) ENGINE = InnoDB,
 PARTITION p201312 VALUES LESS THAN (735599) ENGINE = InnoDB,
 PARTITION p201401 VALUES LESS THAN (735630) ENGINE = InnoDB,
 PARTITION p201402 VALUES LESS THAN (735658) ENGINE = InnoDB,
 PARTITION p201403 VALUES LESS THAN (735689) ENGINE = InnoDB,
 PARTITION p201404 VALUES LESS THAN (735719) ENGINE = InnoDB,
 PARTITION p201405 VALUES LESS THAN (735750) ENGINE = InnoDB,
 PARTITION p201406 VALUES LESS THAN (735780) ENGINE = InnoDB,
 PARTITION p201407 VALUES LESS THAN (735811) ENGINE = InnoDB,
 PARTITION p201408 VALUES LESS THAN (735842) ENGINE = InnoDB,
 PARTITION p201409 VALUES LESS THAN (735872) ENGINE = InnoDB,
 PARTITION p201410 VALUES LESS THAN (735903) ENGINE = InnoDB,
 PARTITION p201411 VALUES LESS THAN (735933) ENGINE = InnoDB,
 PARTITION p201412 VALUES LESS THAN (735964) ENGINE = InnoDB,
 PARTITION petc VALUES LESS THAN MAXVALUE ENGINE = InnoDB) */;

/*Table structure for table `tbl_sqllog_convert_summary` */

DROP TABLE IF EXISTS `tbl_sqllog_convert_summary`;

CREATE TABLE `tbl_sqllog_convert_summary` (
  `date_f` date NOT NULL COMMENT '서머리 날짜',
  `agent_id` int(20) unsigned NOT NULL COMMENT '서머리 서버 아이디(=tbl_agent_info.agent_id)',
  `uniqsql_id` bigint(20) NOT NULL COMMENT 'Uniq SQL 아이디(=tbl_uniqsql.uniqsql_id)',
  `class_id` int(10) NOT NULL COMMENT '클래스 아이디(=tbl_class_trace.class_id)',
  `sum_count` int(10) NOT NULL DEFAULT '0' COMMENT '해당 Uniq SQL 수행 건수',
  `avg_elapsedtime` float(10,3) NOT NULL DEFAULT '0.000' COMMENT '해당 Uniq SQL 의 평균 수행시간',
  `avg_result_count` int(10) NOT NULL DEFAULT '0' COMMENT '해당 Uniq SQL 의 평균 결과 수',
  UNIQUE KEY `NewIndex1` (`date_f`,`agent_id`,`uniqsql_id`,`class_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_sqllog_privacy` */

DROP TABLE IF EXISTS `tbl_sqllog_privacy`;

CREATE TABLE `tbl_sqllog_privacy` (
  `log_id` bigint(20) NOT NULL COMMENT 'SQL Log 아이디',
  `privacytbl_id` int(11) NOT NULL COMMENT 'Privacy Table 아이디',
  PRIMARY KEY (`log_id`,`privacytbl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_sqllog_result_data` */

DROP TABLE IF EXISTS `tbl_sqllog_result_data`;

CREATE TABLE `tbl_sqllog_result_data` (
  `sqllog_id` varchar(22) NOT NULL COMMENT 'sqllog_id',
  `result_data` blob COMMENT '결과 데이터',
  PRIMARY KEY (`sqllog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_summary` */

DROP TABLE IF EXISTS `tbl_summary`;

CREATE TABLE `tbl_summary` (
  `name` varchar(255) NOT NULL,
  `type` enum('now','day','week','month') NOT NULL COMMENT '서머리 타입(일자별, 주별, 월별)',
  `view_group` varchar(15) NOT NULL COMMENT '서머리 그룹(root, group-아이디, server-아이디)',
  `data` text COMMENT 'JSON 형식의 데이터',
  `sdate` datetime NOT NULL COMMENT '서머리시작일',
  `edate` datetime NOT NULL COMMENT '서머리종료일',
  PRIMARY KEY (`name`,`type`,`view_group`,`sdate`,`edate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_summary_alarm_level` */

DROP TABLE IF EXISTS `tbl_summary_alarm_level`;

CREATE TABLE `tbl_summary_alarm_level` (
  `level1` int(11) unsigned NOT NULL COMMENT '알림',
  `level2` int(11) unsigned NOT NULL COMMENT '주의',
  `level3` int(11) unsigned NOT NULL COMMENT '경보',
  `level4` int(11) unsigned NOT NULL COMMENT '위험',
  `level5` int(11) unsigned NOT NULL COMMENT '심각'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_summary_event_count` */

DROP TABLE IF EXISTS `tbl_summary_event_count`;

CREATE TABLE `tbl_summary_event_count` (
  `type` enum('day','week','month') NOT NULL COMMENT '서머리 타입(일자별, 주별, 월별)',
  `view_group` varchar(15) NOT NULL COMMENT '서머리 그룹(root, group-아이디, server-아이디)',
  `agent_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '서머리 서버 아이디(=tbl_agent_info.agent_id)',
  `agent_name` varchar(255) DEFAULT NULL COMMENT '서머리 서버 이름',
  `notice` int(4) unsigned NOT NULL COMMENT '알림',
  `attention` int(4) unsigned NOT NULL DEFAULT '0' COMMENT '주의',
  `alert` int(4) unsigned NOT NULL COMMENT '경보',
  `danger` int(4) unsigned NOT NULL COMMENT '위험',
  `serious` int(4) unsigned NOT NULL COMMENT '심각',
  `sdate` date NOT NULL COMMENT '서머리시작일',
  `edate` date NOT NULL COMMENT '서머리종료일',
  PRIMARY KEY (`type`,`view_group`,`agent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_summary_sql_count` */

DROP TABLE IF EXISTS `tbl_summary_sql_count`;

CREATE TABLE `tbl_summary_sql_count` (
  `type` enum('day','week','month') NOT NULL COMMENT '서머리 타입(일자별, 주별, 월별)',
  `view_group` varchar(10) NOT NULL COMMENT '서머리 그룹(root, group-아이디, server-아이디)',
  `agent_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '서머리 서버 아이디(=tbl_agent_info.agent_id)',
  `agent_name` varchar(255) DEFAULT NULL COMMENT '서머리 서버 이름',
  `ip` varchar(15) DEFAULT NULL COMMENT '아이피',
  `login_id` varchar(50) DEFAULT NULL COMMENT '로그인',
  `uniqsql_id` int(11) DEFAULT NULL COMMENT '유니크SQL ID',
  `sql_text` text COMMENT 'SQl',
  `exec_count` int(11) unsigned NOT NULL COMMENT '수행건수',
  `rank` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '랭킹',
  `sdate` date DEFAULT NULL COMMENT '서머리시작일',
  `edate` date DEFAULT NULL COMMENT '서머리종료일',
  PRIMARY KEY (`type`,`view_group`,`rank`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_summary_sql_policy` */

DROP TABLE IF EXISTS `tbl_summary_sql_policy`;

CREATE TABLE `tbl_summary_sql_policy` (
  `type` enum('day','week','month') NOT NULL COMMENT '서머리 타입(일자별, 주별, 월별)',
  `view_group` varchar(15) NOT NULL COMMENT '서머리 그룹(root, group-아이디, server-아이디)',
  `agent_id` int(11) unsigned NOT NULL COMMENT '서머리 서버 아이디(=tbl_agent_info.agent_id)',
  `agent_name` varchar(255) NOT NULL COMMENT '서머리 서버명',
  `exec_sql` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '실행 쿼리 건수',
  `white_sql` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'White SQL 쿼리 건수',
  `conv_sql` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Convert SQL 쿼리 건수',
  `fail_sql` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '실패 SQL 쿼리 건수 ',
  `block_sql` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '차단 SQL 쿼리 건수 ',
  `sdate` date DEFAULT NULL COMMENT '서머리시작일',
  `edate` date DEFAULT NULL COMMENT '서머리종료일',
  PRIMARY KEY (`type`,`view_group`,`agent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='정책별 쿼리 수';

/*Table structure for table `tbl_summary_sql_result` */

DROP TABLE IF EXISTS `tbl_summary_sql_result`;

CREATE TABLE `tbl_summary_sql_result` (
  `newsql_id` int(11) unsigned NOT NULL COMMENT 'NewSQL ID',
  `agent_id` int(11) unsigned NOT NULL COMMENT '에이저늩아이디',
  `class_id` int(11) unsigned NOT NULL COMMENT '클래스아이디',
  `uniqsql_id` int(11) unsigned NOT NULL COMMENT '유니크SQL아이디',
  `result_avg` text NOT NULL COMMENT '평균조회결과건수',
  `result_cnt` int(11) NOT NULL COMMENT '총조회결과건수',
  `sdate` date DEFAULT NULL COMMENT '서머리시작일',
  `edate` date DEFAULT NULL COMMENT '서머리종료일',
  PRIMARY KEY (`newsql_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_summary_sql_result_count` */

DROP TABLE IF EXISTS `tbl_summary_sql_result_count`;

CREATE TABLE `tbl_summary_sql_result_count` (
  `type` enum('day','week','month') NOT NULL COMMENT '서머리 타입(일자별, 주별, 월별)',
  `view_group` varchar(10) NOT NULL COMMENT '서머리 그룹(root, group-아이디, server-아이디)',
  `agent_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '서머리 서버 아이디(=tbl_agent_info.agent_id)',
  `agent_name` varchar(255) DEFAULT NULL COMMENT '서머리 서버 이름',
  `ip` varchar(15) DEFAULT NULL COMMENT '아이피',
  `login_id` varchar(50) DEFAULT NULL COMMENT '로그인',
  `uniqsql_id` int(11) DEFAULT NULL COMMENT '유니크SQL ID',
  `sql_text` text COMMENT 'SQl',
  `result_count` int(11) NOT NULL COMMENT '조회건수',
  `rank` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '랭킹',
  `sdate` date DEFAULT NULL COMMENT '서머리시작일',
  `edate` date DEFAULT NULL COMMENT '서머리종료일',
  PRIMARY KEY (`type`,`view_group`,`rank`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='쿼리 평균 수행 시간  TOP 10';

/*Table structure for table `tbl_summary_sql_server` */

DROP TABLE IF EXISTS `tbl_summary_sql_server`;

CREATE TABLE `tbl_summary_sql_server` (
  `type` enum('day','week','month') NOT NULL COMMENT '서머리 타입(일자별, 주별, 월별)',
  `view_group` varchar(15) NOT NULL COMMENT '서머리 그룹(root, group-아이디, server-아이디)',
  `agent_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '서머리 서버 아이디(=tbl_agent_info.agent_id)',
  `agent_name` varchar(255) NOT NULL COMMENT '서머리 서버 이름',
  `cnt_exec` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '수행 건수',
  `cnt_select` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '조회 건수',
  `cnt_fail` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '실패 쿼리 건수',
  `cnt_block` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '정책 위반 건수',
  `cnt_conv` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '쿼리 변경 건수',
  `sdate` date DEFAULT NULL COMMENT '서머리시작일',
  `edate` date DEFAULT NULL COMMENT '서머리종료일',
  PRIMARY KEY (`type`,`view_group`,`agent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='서버별 쿼리 실행 현황';

/*Table structure for table `tbl_uniqsql` */

DROP TABLE IF EXISTS `tbl_uniqsql`;

CREATE TABLE `tbl_uniqsql` (
  `uniqsql_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Uniq SQL 아이디',
  `sql_type` enum('SELECT','INSERT','UPDATE','DELETE','CREATE','ALTER','DROP','TRUNCATE','GRANT','REVOKE','EXPLAIN PLAN','RENAME','ETC') NOT NULL COMMENT 'Uniq SQL 타입',
  `hash` varchar(32) NOT NULL COMMENT 'Uniq SQL의 해쉬 값',
  `uniq_sqltext` text NOT NULL COMMENT 'Uniq SQL',
  `orig_sqltext` text NOT NULL COMMENT '원본 SQL',
  `ref_tables` text NOT NULL COMMENT 'SQL에서 참조된 테이블(JSON : [''Table A'', ''Table B'', ''Table C'']',
  PRIMARY KEY (`uniqsql_id`),
  KEY `idx_uniqsql_sqltype` (`sql_type`),
  KEY `idx_uniqsql_sqlhash` (`hash`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COMMENT='Uniq SQL 정보';

/*Table structure for table `tbl_uniqsql_execution_count` */

DROP TABLE IF EXISTS `tbl_uniqsql_execution_count`;

CREATE TABLE `tbl_uniqsql_execution_count` (
  `uniqsql_id` bigint(20) NOT NULL COMMENT '유니크 SQL ID',
  `ipaddr` varchar(15) NOT NULL COMMENT '실행 IP',
  `exec_cnt` int(11) DEFAULT NULL COMMENT '실행 수',
  `agent_id` int(10) NOT NULL DEFAULT '0' COMMENT '에이전트 ID',
  PRIMARY KEY (`uniqsql_id`,`ipaddr`,`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_uniqsql_tables` */

DROP TABLE IF EXISTS `tbl_uniqsql_tables`;

CREATE TABLE `tbl_uniqsql_tables` (
  `uniqsqltbl_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'uniqsql 테이블 아이디',
  `uniqsql_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'uniqsql 아이디',
  `tbl_name` varchar(255) NOT NULL COMMENT '테이블 이름',
  PRIMARY KEY (`uniqsqltbl_id`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_userinfo` */

DROP TABLE IF EXISTS `tbl_userinfo`;

CREATE TABLE `tbl_userinfo` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT COMMENT '유저 아이디',
  `user_name` varchar(45) NOT NULL DEFAULT '' COMMENT '유저 이름',
  `user_loginid` varchar(16) NOT NULL COMMENT '유저 로그인 아이디',
  `user_pass` varchar(64) NOT NULL COMMENT '유저 패스워드',
  `user_level` tinyint(4) NOT NULL COMMENT '유저 레벨',
  `use_yn` tinyint(1) NOT NULL COMMENT '사용 여부',
  `user_email` varchar(128) DEFAULT NULL COMMENT '유저 이메일',
  `user_firstdate` timestamp NULL DEFAULT NULL COMMENT '최초 접속 시간',
  `user_lastdate` timestamp NULL DEFAULT NULL COMMENT '마지막 접속 시간',
  `description` varchar(255) DEFAULT NULL COMMENT '설명',
  `last_work_time` int(10) unsigned NOT NULL COMMENT '최근 수정 시간',
  `last_work_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '최근 수정자 아이디(=tbl_userinfo.user_id)',
  `servers` text COMMENT '사용자관리서버',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_loginid_UNIQUE` (`user_loginid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='유저 정보';

/*Table structure for table `tbl_whitesql_list` */

DROP TABLE IF EXISTS `tbl_whitesql_list`;

CREATE TABLE `tbl_whitesql_list` (
  `whitesql_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'White SQL 아이디',
  `hash` varchar(32) NOT NULL COMMENT '해시값',
  `agent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'White SQL 추가된 서버 아이디(=tbl_agent_info.agent_id)',
  `uniqsql_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Uniq SQL 아이디(=tbl_uniqsql.uniqsql_id)',
  `class_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '클래스 아이디(=tbl_class_trace.class_id)',
  `reg_time` int(10) NOT NULL DEFAULT '0' COMMENT '등록 시간',
  `state` enum('A','M','D','N') NOT NULL DEFAULT 'A' COMMENT '상태값(A:추가, M:수정, D:삭제, N:정상=싱크가 완료되었다는 의미)\n상태가 A일때 수정이 일어나도 A를 유지',
  `on_off` enum('0','1') NOT NULL DEFAULT '1' COMMENT '정책 켜기(0:끄기, 1:켜기)',
  `sync_flag` enum('0','1') NOT NULL DEFAULT '0' COMMENT '동기화 수행 대상여부(0:동기화대상, 1:동기화완료)',
  `sync_succ_flag` enum('0','1') NOT NULL DEFAULT '0' COMMENT '동기화 수행 결과(0:실패, 1:성공)',
  `sync_time` int(10) unsigned DEFAULT NULL COMMENT '동기화 수행 시간',
  `sync_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '동기화 사용자 ID',
  `approval_yn` enum('0','1') NOT NULL DEFAULT '0' COMMENT '승인 여부',
  `approval_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '승인 시간',
  `approval_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '승인 사용자 아이디(=tbl_userinfo.user_id)',
  `last_work_time` int(10) unsigned DEFAULT NULL COMMENT '최근 수정 시간',
  `last_work_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '최근 수정자 아이디(=tbl_userinfo.user_id)',
  PRIMARY KEY (`whitesql_id`),
  KEY `idx_whitesql_uniq1` (`agent_id`,`uniqsql_id`,`class_id`),
  KEY `fk_tbl_whitesql_list_tbl_class_trace1_idx` (`class_id`),
  KEY `fk_tbl_whitesql_list_tbl_uniqsql1_idx` (`uniqsql_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Table structure for table `tbl_work_history` */

DROP TABLE IF EXISTS `tbl_work_history`;

CREATE TABLE `tbl_work_history` (
  `work_history_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '작업 히스토리 아이디',
  `work_type` enum('add','mod','del') NOT NULL DEFAULT 'add' COMMENT '작업 종류',
  `agent_id` int(10) unsigned NOT NULL COMMENT '서버 아이디(=tbl_agent_info.agent_id)',
  `work_time` int(10) unsigned NOT NULL COMMENT '작업 시간',
  `work_user_id` int(10) NOT NULL DEFAULT '0' COMMENT '작업자 ID(=tbl_userinfo.user_id)',
  `work_message` text COMMENT '작업 메시지',
  `work_target` varchar(64) DEFAULT NULL COMMENT '작업한 대상(사용자정보, 서버정보, 그룹정보, 관리정보등)',
  `work_before` text COMMENT '작업 전 내용',
  `work_after` text COMMENT '작업 후 내용',
  PRIMARY KEY (`work_history_id`)
) ENGINE=MyISAM AUTO_INCREMENT=165 DEFAULT CHARSET=utf8;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
