<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| DAEMON CONNECTIVITY SETTINGS
| -------------------------------------------------------------------
| 이 파일은 데몬이 운영될때 필요한 정책이 들어있다.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|
|	['system_manager_ip'] MPolicy IP
|	['system_manager_log_port'] MSaver 리슨 포트
|	['system_manager_listen_port'] MPolicy 리슨 포트
|	['system_state_check_period'] 시스템 상태 체크 주기 
|	['system_agent_health_check_period'] 서버 헬스 체크 주기
|	['system_log_file_size'] 로그파일 사이즈 해당 사이즈를 기준으로 로그파일이 분할된다.
|	['system_max_agent_num'] 최대 설정 가능 에이전트 수
|	
*/
$config['system_manager_ip']				= '{system_manager_ip}';
$config['system_manager_log_port']			= '{system_manager_log_port}';
$config['system_manager_listen_port']		= '{system_manager_listen_port}';
$config['system_state_check_period']		= '{system_state_check_period}';
$config['system_agent_health_check_period']	= '{system_agent_health_check_period}';
$config['system_log_file_size']				= '{system_log_file_size}';
$config['system_max_agent_num']				= '{system_max_agent_num}';

/* End of file daemon.php */
/* Location: ./application/config/daemon.php */