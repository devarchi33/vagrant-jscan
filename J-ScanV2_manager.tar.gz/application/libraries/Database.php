<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

class Database{

    public $conn;
    public $insert_id = 0;
    private $hostname, $database, $username, $password;

    public function __construct($hostname, $username, $password, $database){

        $this->hostname = $hostname; 
        $this->username = $username;
        $this->password = $password;
        $this->database = $database;

        $this->connect();
    }

    private function connect(){

        if(!$this->_connect()){

            debug(1, get_class($this), "Trying to connect to the database", "Database");

            sleep(10);

            $this->connect();
        }
        else {

            //debug(1, get_class($this), "Connected to database", "database");
        }
    }

    private function _connect(){

        $this->conn = @new mysqli(
            $this->hostname, 
            $this->username, 
            $this->password, 
            $this->database
        );

        if($this->conn->connect_error){          

            $this->conn->close();
            return false;
        }
        else {

            return true;
        }
    }

    public function query($sSql, $callback = null, $ignore = false){

        if(!$this->conn){

            $this->connect();
        }

        $oResult = $this->conn->query($sSql);

        $this->insert_id = (int)$this->conn->insert_id;

        if($this->conn->errno){

            if($ignore == true){

                return false;
            }

            $sError  = $this->conn->errno." : ".$this->conn->error."\n";
            $sError .= "The Query is : \n";
            $sError .= $sSql."\n";

            debug(1, get_class($this), $sError, "Database");

            if($this->conn->errno == '2006'){

                //간헐적인 MySQL Has Gone Away 다시 연결을 맺어준다.
                $this->connect();
                $result = $this->query($sSql, $callback);
                return $result;
            }
            else {

                return false;
            }
        }

        
        if($callback){

            if($oResult){

                $result = $callback($oResult, $this->conn, array(
                    'insert_id' => $this->insert_id
                ));
                //$oResult->close();
            }
            else {

                $result = false;
            }
        }
        else{

            $result = true;
        }

        return $result;
    }

    public function getInsertId(){

        return $this->insert_id;
    }
}