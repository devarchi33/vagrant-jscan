<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

/*
 * 로그 클래스
 */
class Log extends CI_Log
{

	public $ci;

    public function __construct()
    {
    	parent::__construct();

    	//CodeIgniter 객체
    	$this->ci = &get_instance();
    }
	
	public function enable($sLevel){

		$this->_threshold = $this->_levels[strtoupper($sLevel)];
	}
}
?>