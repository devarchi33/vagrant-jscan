<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

require_once APPPATH."libraries/QueryParser.php";

/**
* AnalysisLogSaver
*
* 큐에서 꺼낸 로그를 받아서 분석 후 큐에 저장하는 Thread
*
* @uses     native php
* @category daemon
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2013, Iruentech Corporation All rights reserved.
* @link
*/
class AnalysisLogSaver{

    private $keyMQSaver  = null;
    private $num = null;
    private $redis = null;

    public function __construct(
        $num
    ){

        $this->num = $num;
        $this->path = "/tmp/jscan/";

        $this->redis = new Redis();
        $this->redis->connect('211.170.163.68', 6479);
    }

    public function run(){
        
        $this->currentTime = null;

        $nWriteCnt = 0;

        $fp = null;
        while(true){

            $sLog = $this->redis->lpop('bulk_insert_log');

            if (!$sLog) {

                sleep(1);
                continue;
            }

            $aRow = json_decode($sLog, true);

            $sType = $aRow['log_type'];
            unset($aRow['log_type']);

            if($sType == 'anal_log'){

                $sLog = implode("\f", array(
                    $aRow['sqllog_id'],
                    $aRow['sql_type'],
                    $aRow['uniqsql_id'],
                    $aRow['dbconn_id'],
                    $aRow['class_name'],
                    $aRow['class_id'],
                    $aRow['whitesql_id'],
                    $aRow['convsql_id'],
                    $aRow['blocksql_id'],
                    $aRow['sqllog_check'],
                    $aRow['result_data_saved'],
                    $aRow['privacytbl_yn'],
                    $aRow['agent_id'],
                    $aRow['agent_mode'],
                    $aRow['request_time'],
                    $aRow['prestmt'],
                    $aRow['sql_str'],
                    $aRow['sql_param'],
                    $aRow['dbconn_url'],
                    $aRow['dbconn_account'],
                    $aRow['class_trace'],
                    $aRow['policy_id'],
                    $aRow['block_yn'],
                    $aRow['login_id'],
                    $aRow['ipaddr'],
                    $aRow['exec_starttime'],
                    $aRow['exec_elapsedtime'],
                    $aRow['execute_yn'],
                    $aRow['fail_code'],
                    $aRow['result_count'],
                    $aRow['privacy_type'],
                    $aRow['privacy_value'],
                    $aRow['result_data'],
                ));
            }
            else {

                $sLog = implode("\f", array(
                    $aRow['event_type'],
                    $aRow['event_time'],
                    $aRow['event_level'],
                    $aRow['event_kind'],
                    $aRow['policy_type'],
                    $aRow['event_msg'],
                    $aRow['event_confirm_flag'],
                    $aRow['event_tblname'],
                    $aRow['event_tblid'],
                    $aRow['agent_id']
                ));
            }

            $now = time();

            if($this->currentTime != $now){

                if($fp) { fclose($fp); }
                $fp = fopen($this->path.$sType."/".$now, "a+");

//                debug(1, get_class($this), "[AnalisysLogSaver] Write ".$nWriteCnt." / Sec", );

                $nWriteCnt = 0;
            }

            fwrite($fp, $sLog."\r\n");

            $nWriteCnt++;

            $this->currentTime = $now;
        }

        fclose($fp);
    }
}