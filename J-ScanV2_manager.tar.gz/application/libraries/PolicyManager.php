<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

require_once APPPATH."libraries/Database.php";
require_once APPPATH."helpers/cmd_socket_helper.php";

/**
* PolicyManager
*
* 정책 매니저
*
* @uses     native php
* @category daemon
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2013, Iruentech Corporation All rights reserved.
* @link
*/
class PolicyManager{

    public $socket; 

    public $key = null;
    public $msg_id; 
    public $db;

    public function __construct($hostname, $username, $password, $database){

        require_once APPPATH."config/queue.php";

        $this->key = $config['mq_policy_sender'];
        
        //데이터 베이스 연결
        $this->db = new Database($hostname, $username, $password, $database);

        //메시지큐 연결
        $this->msg_id = msg_get_queue($this->key, 0600) ;
    }

    public function getMsgId(){

        return $this->msg_id;
    }

    public function checkAgent($sRemoteIp, $nPort){

        $sSql = 'SELECT * FROM tbl_agent_info WHERE ipaddr = "'.$sRemoteIp.'" AND port="'.$nPort.'" ANd del_yn="0"';
        $aAgent = $this->db->query($sSql, function($oResult){
            
            return $oResult->fetch_array(MYSQLI_ASSOC);
        });

        return $aAgent;
    }

    public function syncPolicy($sRemoteIp, $nPort){

        return $this->requestPolicyFile($sRemoteIp, $nPort);
    }

    public function requestPolicyFile($sRemoteIp, $nPort){

        debug(1, get_class($this), "requestPolicyFile ".$sRemoteIp.", ".$nPort);

        $aAgent = $this->checkAgent($sRemoteIp, $nPort);

        if($aAgent){

            if($this->sendQueue('sendPolicyFile', array($aAgent))){

                return array(
                    'result'    => true, 
                    'message'   => ''
                );
            }
            else {

                return array(
                    'result'    => false, 
                    'message'   => 'Queue Error'
                );
            }
        }
        else {

            return array(
                'result'    => false, 
                'message'   => 'Agent is not registered'
            );
        }
    }

    public function sendQueue($cmd, $params){

        $msg = serialize(array(
            'cmd' => $cmd,
            'params' => $params
        ));

        if (!msg_send($this->msg_id, 1, $msg, true, true, $msg_err)){
            
            return false;
        }
        else {

            return true;
        }
    }

    public function createSocket(){

        debug(1, get_class($this), "createSocket ");
        
        require_once APPPATH."config/daemon.php";

        $nPort = $config['system_manager_listen_port'];
        $sAddr = $config['system_manager_ip'];

        $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        if(!$this->socket){

            throw new Exception('Create socket failed.');
        }

        socket_set_option($this->socket, SOL_SOCKET, SO_KEEPALIVE, 0);
        socket_set_option($this->socket, SOL_SOCKET, SO_REUSEADDR, 1);   

        $bResult = socket_bind($this->socket, $sAddr, $nPort);

        if(!$bResult){

            throw new Exception('Socket address was not bound. '."$sAddr:$nPort");
        }

        socket_listen($this->socket);    
    }

    public function run() {

        try{

            $this->createSocket();
            
            debug(1, get_class($this), "create socket complete");

            while(true)
            {
                $client = socket_accept($this->socket);

                if ($client === false) 
                { 
                    usleep(100); 

                    debug(2, get_class($this), "CONNECT ".$client);
                }
                else if ($client > 0)  {

                    debug(2, get_class($this), "CONNECT ".$client);
                    
                    $sReqData = socket_read($client, 20000);
                    
                    debug(2, get_class($this), $sReqData);

                    $aReqData = json_decode($sReqData, true);

                    debug(2, get_class($this), print_r($aReqData, true));

                    if(is_array($aReqData) == true){

                        extract($aReqData);

                        if(method_exists($this, $cmd) == true){

                            $sResult = call_user_func_array(array($this, $cmd), $params);

                            if(is_array($sResult) === true){

                                socket_write($client, json_encode($sResult));
                            }
                            else {

                                socket_write($client, $sResult);
                            }
                        }
                        else {

                            socket_write($client, json_encode(array(
                                'result'    => false, 
                                'message'   => 'This command is not valid'
                            )));
                        }
                    }
                    else {

                        debug(1, get_class($this), $sReqData);
                    }
                }
                else {

                    debug(2, get_class($this), "ERROR ".socket_strerror($client));
                }
            }
        }
        catch(Exception $e){

            debug(1, get_class($this), $e->getMessage());
        }
    }
}