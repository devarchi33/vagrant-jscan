<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


/**
 * RealtimeDataSaver
 *
 * 분석 클래스
 *
 * @uses     native php
 * @category daemon
 * @package  WhiteSQL
 * @author   정주원 <jjwcom@nate.com>
 * @license  Copyright (c) 2013, Iruentech Corporation All rights reserved.
 * @link
 */
class RealtimeDataSaver
{
    public $num        = 0;
    public $bufferSize = 0;

    public function __construct($nNum)
    {
        $this->num = $nNum;

        $this->level = array(1 => 'notice', 2 => 'attention', 3 => 'alert', 4 => 'danger', 5 => 'serious');

        $this->redis = new Redis();
        $this->redis->connect('127.0.0.1', 6379);

        $this->logIdx = 0;

        $this->bufferSize = 50;
    }

    public function run()
    {

        debug(1, get_class($this), "Start Daemon", "RealtimeDataSaver");

        while (true) {

            $sLog = $this->redis->lPop('realtime');

            if (!$sLog) {

                sleep(1);
                continue;
            }

            $t1 = startCheckTime();

            $aLog = json_decode($sLog, true);

            if ($aLog['report_type'] == 'event') {

                $this->analEventLog($aLog);

            } else if ($aLog['report_type'] == 'monitoring') {

                $this->analMonitoringLog($aLog);

            } else {

                $this->analSQLLog($aLog);

            }

//            $aLog['event_level'] = rand(1, 5);
//
//            $this->analEventLog($aLog);
            $exec_time = endCheckTime($t1);

//            debug(1, get_class($this), "Analyzer No.".$this->num.", execution time ".$exec_time.",".print_r($aLog, true));
        }
    }

    /**
     * truncate
     *
     * 공유메모리를 비운다.
     *
     * @access public
     *
     * @return void
     */
    public function truncate($sKey)
    {

        $this->redis->delete($sKey);
    }

    /**
     * cacheRealtimeSQLLog
     *
     * 이벤트 개수를 분석하여 변수에 저장
     *
     * @access public
     *
     * @return void
     */
    public function cacheRealtimeSQLLog(&$aRow)
    {
        if ($this->logIdx > 20) {

            $this->logIdx = 0;
        }

        $sKey = 'realtime_sql_log:'.$this->logIdx;

        $nCnt = $this->redis->lLen('realtime_sql_log');

        $this->redis->multi();

        if ($nCnt > $this->bufferSize) {

            $this->redis->lPop('realtime_sql_log');
        }

        $this->redis->hMSet($sKey, $aRow);
        $this->redis->rPush('realtime_sql_log', $this->logIdx);

        $this->redis->exec();

        $this->logIdx++;
    }

    /**
     * analExecCountPerSec
     *
     * 이벤트 개수를 분석하여 변수에 저장
     *
     * @access public
     *
     * @return void
     */
    public function analExecCountPerSec($sType, $nId, &$aRow)
    {

        $sKey     = $this->key('exec_count_per_sec', $sType, $nId);
        $sListKey = $this->key('exec_count_per_sec:list', $sType, $nId);
        $nListCnt = $this->redis->lLen($sListKey);
        $nHash    = $aRow['request_time_int'];

        if ($nListCnt > $this->bufferSize) {

            $sDelHash = $this->redis->lPop($sListKey);
            $this->redis->hDel($sKey, $sDelHash);
        }

//        debug(1, get_class($this), "Del Hash ".$sDelHash);

        if (!$this->redis->hExists($sKey, $nHash)) {

            $this->redis->rPush($sListKey, $nHash);
        }

        $this->redis->hIncrBy($sKey, $nHash, 1);
    }

    /**
     * analExecTimePerSec
     *
     * 이벤트 개수를 분석하여 변수에 저장
     *
     * @access public
     *
     * @return void
     */
    public function analExecTimePerSec($sType, $nId, &$aRow)
    {

        $sKey             = $this->key('exec_time_per_sec', $sType, $nId);
        $sListKey         = $this->key('exec_time_per_sec:list', $sType, $nId);
        $nListCnt         = $this->redis->lLen($sListKey);
        $nHash            = $aRow['request_time_int'];
        $exec_elapsedtime = $aRow['exec_elapsedtime'];

        if ($nListCnt > $this->bufferSize) {

            $sDelHash = $this->redis->lPop($sListKey);
            $this->redis->hDel($sKey, $sDelHash);
        }

        if (!$this->redis->hExists($sKey, $nHash)) {

            $this->redis->rPush($sListKey, $nHash);
        }

        $this->redis->hIncrByFloat($sKey, $nHash, $exec_elapsedtime);
    }


    /**
     * analNumOfEvent
     *
     * 이벤트 개수를 분석하여 변수에 저장
     *
     * @access public
     *
     * @return void
     */
    public function analEventCount($sType, $nId, &$aRow)
    {

        $sKey        = $this->key('event_count', $sType, $nId);
        $event_level = $aRow['event_level'];
        $sHash       = $this->level[$event_level];

        $this->redis->hIncrBy($sKey, $sHash, 1);
    }

    /**
     * analWarningLevel
     *
     * 현재 에이전트의 최고 위험 수준을 설정한다.
     *
     * @access public
     *
     * @return void
     */
    public function analWarningLevel($sType, $nId, &$aRow)
    {

        $sKey        = $this->key('warning_level', $sType, $nId);
        $event_level = $aRow['event_level'];
        $nLevel      = (int)$this->redis->get($sKey);

        if ($nLevel < $event_level) {

            $this->redis->set($sKey, $event_level);
        }
    }

    /**
     * analExecResultCount
     *
     * 쿼리 수행 결과 건수를 분석하여 변수에 저장
     *
     * @access public
     *
     * @return void
     */
    public function analExecResultCount($sType, $nId, &$aRow)
    {

        $sKey         = $this->key('exec_result_count', $sType, $nId);
        $uniqsql_id   = $aRow['uniqsql_id'];
        $agent_id     = $aRow['agent_id'];
        $ipaddr       = $aRow['ipaddr'];
        $result_count = $aRow['result_count'];
        $sHash        = $agent_id.":".$uniqsql_id.":".$ipaddr;

        $this->redis->hIncrBy($sKey, $sHash, $result_count);
    }


    /**
     * analExecCount
     *
     * 쿼리 수행 건수를 분석하여 변수에 저장
     *
     * @access public
     *
     * @return void
     */
    public function analExecCount($sType, $nId, &$aRow)
    {

        $sKey       = $this->key('exec_count', $sType, $nId);
        $uniqsql_id = $aRow['uniqsql_id'];
        $agent_id   = $aRow['agent_id'];
        $ipaddr     = $aRow['ipaddr'];
        $sHash      = $agent_id.":".$uniqsql_id.":".$ipaddr;

        $this->redis->hIncrBy($sKey, $sHash, 1);
    }

    /**
     * analSQLPolicy
     *
     * 정책별 쿼리수를 분석하여 변수에 저장
     *
     * @access public
     *
     * @return void
     */
    public function analSQLPolicy($sType, $nId, &$aRow)
    {

        // 0: None White SQL , 1: SQL, 2: SQL Convert, 3: IP, 4: LOGIN_ID, 5: 주요TABLE, 6: SQL유형, 7: 개인정보TABLE
        $sKey        = $this->key('sql_policy', $sType, $nId);
        $whitesql_id = $aRow['whitesql_id'];
        $policy_type = $aRow['policy_type'];

        if ($whitesql_id == 0) {

            $this->redis->hIncrBy($sKey, 0, 1);

        } else {

            $this->redis->hIncrBy($sKey, $policy_type, 1);
        }
    }

    /**
     * analTotalGrid
     *
     * 서버별 쿼리 실행 현황 분석하여 변수에 저장
     *
     * @access public
     *
     * @return void
     */
    public function analTotalGrid($sType, $nId, &$aRow)
    {

        $sKey        = $this->key('total_grid', $sType, $nId);
        $execute_yn  = $aRow['execute_yn'];
        $policy_type = $aRow['policy_type'];
        $agent_id    = $aRow['agent_id'];

        if ($policy_type == POLICY_PERSONAL_INFO_TABLE) {

            $this->redis->hIncrBy($sKey, $agent_id.':cnt_personal_info', 1);
        }

        if ($policy_type == POLICY_TABLE) {

            $this->redis->hIncrBy($sKey, $agent_id.':cnt_table', 1);
        }

        if ($policy_type == POLICY_SQL_CONVERT) {

            $this->redis->hIncrBy($sKey, $agent_id.':cnt_conv', 1);
        }

        if (!$execute_yn) {

            $this->redis->hIncrBy($sKey, $agent_id.':cnt_fail', 1);
        }

        $this->redis->hIncrBy($sKey, $agent_id.':cnt_exec', 1);
    }

    /**
     * analMostAccessIP
     *
     * 최다 접근 IP
     *
     * @access public
     *
     * @return void
     */
    public function analMostAccessIP($sType, $nId, &$aRow)
    {

        $sKey        = $this->key('most_access_ip', $sType, $nId);
        $ipaddr      = $aRow['ipaddr'];
        $policy_type = $aRow['policy_type'];
        $sHash       = $ipaddr;

//        if ($policy_type != POLICY_PERSONAL_INFO_TABLE) {
//
//            return;
//        }

        $this->redis->hIncrBy($sKey, $sHash, 1);
    }

    /**
     * analMuchLookupIP
     *
     * 다량 조회 IP
     *
     * @access public
     *
     * @return void
     */
    public function analMuchLookupIP($sType, $nId, &$aRow)
    {

        $sKey         = $this->key('much_lookup_ip', $sType, $nId);
        $ipaddr       = $aRow['ipaddr'];
        $result_count = $aRow['result_count'];
        $policy_type  = $aRow['policy_type'];
        $sHash        = $ipaddr;

//        if ($policy_type != POLICY_PERSONAL_INFO_TABLE) {
//
//            return;
//        }

        $this->redis->hIncrBy($sKey, $sHash, $result_count);
    }

    /**
     * analPersonalInfoAccessIP
     *
     * 개인정보접근 IP
     *
     * @access public
     *
     * @return void
     */
    public function analPersonalInfoAccessIP($sType, $nId, &$aRow)
    {

        $sKey          = $this->key('personal_info_access_ip', $sType, $nId);
        $ipaddr        = $aRow['ipaddr'];
        $privacytbl_yn = $aRow['privacytbl_yn'];
        $sHash         = $ipaddr;

        if (!$privacytbl_yn) {

            return;
        }

        $this->redis->hIncrBy($sKey, $sHash, 1);
    }

    /**
     * analSQLLog
     *
     * SQL 로그 분석
     *
     * @access public
     *
     * @return void
     */
    public function analSQLLog(&$aLog)
    {
        $agent_id = $aLog['agent_id'];

        $this->cacheRealtimeSQLLog($aLog);

        $aLog['request_time_int'] = preg_replace("/[:\s-]/", "", substr($aLog['request_time'], 0, 19));

        $this->analExecTimePerSec('server', $agent_id, $aLog);
        $this->analExecCountPerSec('server', $agent_id, $aLog);
        $this->analExecResultCount('server', $agent_id, $aLog);
        $this->analExecCount('server', $agent_id, $aLog);
        $this->analTotalGrid('server', $agent_id, $aLog);
        $this->analMostAccessIP('server', $agent_id, $aLog);
        $this->analMuchLookupIP('server', $agent_id, $aLog);
        $this->analPersonalInfoAccessIP('server', $agent_id, $aLog);

        $group_id = $this->redis->hGet("server:".$agent_id, 'group_id');

        $this->analExecResultCount('group', $group_id, $aLog);
        $this->analExecCount('group', $group_id, $aLog);
        $this->analTotalGrid('group', $group_id, $aLog);
        $this->analMostAccessIP('group', $group_id, $aLog);
        $this->analMuchLookupIP('group', $group_id, $aLog);
        $this->analPersonalInfoAccessIP('group', $group_id, $aLog);

        $this->analExecResultCount('root', null, $aLog);
        $this->analExecCount('root', null, $aLog);
        $this->analTotalGrid('root', null, $aLog);
        $this->analMostAccessIP('root', null, $aLog);
        $this->analMuchLookupIP('root', null, $aLog);
        $this->analPersonalInfoAccessIP('root', null, $aLog);


    }

    /**
     * analMonitoringLog
     *
     * 모니터링 모드에서의 로그 분석
     *
     * @access public
     *
     * @return void
     */
    public function analMonitoringLog(&$aLog)
    {
        $agent_id = $aLog['agent_id'];

        $this->analSQLPolicy('server', $agent_id, $aLog);

        $group_id = $this->redis->hGet("server:".$agent_id, 'group_id');

        $this->analSQLPolicy('group', $group_id, $aLog);

        $this->analSQLPolicy('root', null, $aLog);
    }

    /**
     * analEventLog
     *
     * SQL 이벤트 분석
     *
     * @access public
     *
     * @return void
     */
    public function analEventLog(&$aLog)
    {
        $agent_id = $aLog['agent_id'];
        $this->analEventCount('server', $agent_id, $aLog);
        $this->analWarningLevel('server', $agent_id, $aLog);

        $group_id = $this->redis->hGet("server:".$agent_id, 'group_id');

        $this->analEventCount('group', $group_id, $aLog);

        $this->analEventCount('root', null, $aLog);
    }

    public function key($sKey, $sType, $sId = null)
    {

        return $sKey.":".$sType.($sId ? ":".$sId : "");
    }
}