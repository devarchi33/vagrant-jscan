<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH."libraries/Database.php";
require_once APPPATH."libraries/QueryParser.php";

/**
 * LogAnalyzer
 *
 * 로그 테이블에 저장된 로그를 읽어 데이터를 분석하여 분석 테이블에 넣는다.
 *
 * @uses     native php
 * @category daemon
 * @package  WhiteSQL
 * @author   정주원 <jjwcom@nate.com>
 * @license  Copyright (c) 2013, Iruentech Corporation All rights reserved.
 * @link
 */
class LogAnalyzer
{

    private $privacyTables = array();
    private $parser        = null;
    private $redis         = null;

    public function __construct($num)
    {

        $this->num = $num;

        //데이터 베이스 연결
        $this->parser = new QueryParser();

        $this->redis = new Redis();
        $this->redis->connect('127.0.0.1', 6379);
    }

    public function run()
    {
        debug(1, get_class($this), "Start Daemon", "LogAnalyzer");

        while (true) {

            $sLog = $this->redis->lPop('saver');

            if (!$sLog) {

                sleep(1);
                continue;
            }

            $t1             = startCheckTime();
            $this->currTime = time();

            $aLog = explode("\f", $sLog);

            $aLog = array(
                'log_id'           => $aLog[0],
                'agent_id'         => $aLog[1],
                'agent_mode'       => $aLog[2],
                'request_time'     => $aLog[3],
                'prestmt'          => $aLog[4],
                'sql_str'          => $aLog[5],
                'sql_param'        => $aLog[6],
                'dbconn_url'       => $aLog[7],
                'dbconn_account'   => $aLog[8],
                'class_trace'      => $aLog[9],
                'policy_id'        => (int)$aLog[10],
                'block_yn'         => $aLog[11],
                'login_id'         => $aLog[12],
                'ipaddr'           => $aLog[13],
                'exec_starttime'   => $aLog[14],
                'exec_elapsedtime' => $aLog[15],
                'execute_yn'       => $aLog[16],
                'fail_code'        => $aLog[17],
                'result_count'     => $aLog[18],
                'privacy_type'     => $aLog[19],
                'privacy_value'    => $aLog[20],
                'result_data'      => $aLog[21],
                'whitesql_id'      => '0',
                'privacytbl_yn'    => '0',
                'class_id'         => '0',
                'convsql_id'       => '0',
                'policy_type'      => '0'
            );

            $this->checkClassString($aLog);

            $this->checkDBConn($aLog);

            $this->checkUniqSQL($aLog);

            $this->checkNewSQL($aLog);

            $this->checkPrivacySQL($aLog);

            $this->checkWhiteSQL($aLog);

            $this->checkPolicies($aLog);

            $this->savePrivacyTables($aLog);

            $this->saveResultRecord($aLog);

            @$this->saveSQLLog($aLog);

            @$this->saveEventLog($aLog);

            $exec_time = endCheckTime($t1);
        }
    }

    private function checkClassString(&$aLog)
    {
        if (isset($aLog['class_trace']) === false || empty($aLog['class_trace']) === true) {

            return;
        }

        //로그에서 class_trace을 받아 첫줄을 자르고 여기에 넣어줘야함
        $sClassString = strtok($aLog['class_trace'], "\n");

        $sHashKey = md5($sClassString);

        $aClass = $this->fetch('class_trace', $sHashKey);
        if ($aClass) {

            $aLog['class_id']   = $sHashKey;
            $aLog['class_name'] = $aClass['class_string'];

            return;
        }

        $this->set('class_trace', $sHashKey, array(
            'class_string' => $sClassString
        ));

        $this->syncToMySQL('class_trace', array(
            'class_id'     => $sHashKey,
            'class_string' => $sClassString
        ));

        $aLog['class_id']   = $sHashKey;
        $aLog['class_name'] = $sClassString;

        return;
    }

    private function checkDBConn(&$aLog)
    {

        $sDBConnUrl     = @$aLog['dbconn_url'];
        $sDBConnAccount = @$aLog['dbconn_account'];
        $nAgentId       = (int)$aLog['agent_id'];

        if (!$sDBConnUrl || !$sDBConnAccount) {

            $aLog['dbconn_id'] = 0;

            return;
        }

        $aDBConnUrl = $this->parseDBConnUrl($sDBConnUrl);
        $sIPAddr    = $aDBConnUrl['host'];
        $nPort      = $aDBConnUrl['port'];
        $sSID       = $aDBConnUrl['sid'];
        $sDBName    = $aDBConnUrl['system'];

        $sHashKey = md5($sIPAddr.":".$nPort.":".$sSID);

        if ($this->exists('dbconn', $sHashKey)) {

            $aLog['dbconn_id'] = $sHashKey;

            return;
        }

        $this->set('dbconn', $sHashKey, array(
            'dbconn_id' => $sHashKey
        ));

        /**
         *
         * mySQL로 보내기 위해 Redis Queue로 전송한다.
         */
        $this->syncToMySQL('dbconn', array(
            'dbconn_id'      => $sHashKey,
            'dbconn_url'     => $sDBConnUrl,
            'dbconn_account' => $sDBConnAccount,
            'collect_time'   => time(),
            'ipaddr'         => $sIPAddr,
            'port'           => $nPort,
            'sid'            => $sSID,
            'dbname'         => $sDBName.":".$sIPAddr,
        ));

        /**
         *
         * mySQL로 보내기 위해 Redis Queue로 전송한다.
         */
        $this->syncToMySQL('agent_dbconn', array(
            'agent_id'  => $nAgentId,
            'dbconn_id' => $sHashKey
        ));

        $aLog['dbconn_id'] = $sHashKey;

        return;
    }

    private function checkUniqSQL(&$aLog)
    {

        $sOrigSql = $aLog['sql_str'];
        $aTokens  = $this->parser->tokenize(trim($sOrigSql));
        $sUniqSQL = $this->parser->getUniqSQL($aTokens);

        $sHashKey = md5($sUniqSQL);
        $aUniqSQL = $this->fetch('uniqsql', $sHashKey);

        if ($aUniqSQL) {

            $aLog['sql_type']   = $aUniqSQL['sql_type'];
            $aLog['uniqsql_id'] = $sHashKey;
            $aLog['ref_tables'] = $aUniqSQL['ref_tables'];

            return;
        }

        $sSQLType = $this->parser->getSQLType($aTokens);
        $aTables  = $this->parser->getRefTables($aTokens);

        $sRefTables = '';
        if (count($aTables) > 0) {

            $sRefTables = json_encode($aTables);
        }

        $this->set('uniqsql', $sHashKey, array(
            'sql_type'   => $sSQLType,
            'ref_tables' => $sRefTables
        ));

        $this->syncToMySQL('uniqsql', array(
            'uniqsql_id'   => $sHashKey,
            'sql_type'     => $sSQLType,
            'uniq_sqltext' => $sUniqSQL,
            'orig_sqltext' => $sOrigSql,
            'ref_tables'   => $sRefTables
        ));

        if (count($aTables) > 0) {

            foreach ($aTables as $nIdx => $aTable) {

                $this->syncToMySQL('uniqsql_tables', array(
                    'uniqsql_id' => $sHashKey,
                    'tbl_name'   => $aTable['table']
                ));
            }
        }

        $aLog['sql_type']   = $sSQLType;
        $aLog['uniqsql_id'] = $sHashKey;
        $aLog['ref_tables'] = $sRefTables;

        return;
    }

    private function checkNewSQL(&$aLog)
    {

        $nAgentId   = (int)$aLog['agent_id'];
        $nAgentMode = $aLog['agent_mode'];
        $nClassId   = $aLog['class_id'];
        $nUniqSqlId = $aLog['uniqsql_id'];
        $nLogId     = $aLog['log_id'];
        $sSqlType   = $aLog['sql_type'];
        $sSqlText   = $aLog['sql_str'];

        //NewSQL 등록여부 검색
        $sHashKey = md5($nAgentId.":".$nClassId.":".$nUniqSqlId);

        //등록되어 있는 경우
        if ($this->exists('newsql', $sHashKey)) {

            $aLog['newsql_id'] = $sHashKey;

            return;
        }

        $this->set('newsql', $sHashKey, array(
            'newsql_id' => $sHashKey
        ));

        $this->syncToMySQL('newsql', array(
            'newsql_id'    => $sHashKey,
            'sqllog_id'    => $nLogId,
            'uniqsql_id'   => $nUniqSqlId,
            'class_id'     => $nClassId,
            'agent_id'     => $nAgentId,
            'sql_type'     => $sSqlType,
            'orig_sqltext' => addslashes($sSqlText),
            'reg_date'     => date("Y-m-d H:i:s")
        ));

        $aLog['newsql_id'] = $sHashKey;


        //모니터링 모드인 경우 이벤트 발생
        if ($nAgentMode >= AGENT_MODE_LOGGING) {

            //NewSQL 이벤트를 등록한다.
            $this->insertNewSQLEvent($aLog['newsql_id'], $nAgentId);
        }

        return;
    }

    private function checkPrivacySQL(&$aLog)
    {

        $nUniqSqlId = $aLog['uniqsql_id'];
        $nAgentId   = (int)$aLog['agent_id'];

        $this->privacyTables = $this->fetch('privacy_tables', $nAgentId.':'.$nUniqSqlId);

        if (count($this->privacyTables) > 0) {

            $aLog['privacytbl_yn'] = '1';

            return;
        }

        return;
    }

    private function checkWhiteSQL(&$aLog)
    {

        $nAgentId   = (int)$aLog['agent_id'];
        $nClassId   = $aLog['class_id'];
        $nUniqSqlId = $aLog['uniqsql_id'];
        $nAgentMode = $aLog['agent_mode'];
        $sIPAddr    = $aLog['ipaddr'];

        $nCnt = $this->countUniqSQLExecution($nUniqSqlId, $nAgentId, $sIPAddr);

        $sHashKey = md5($nAgentId.":".$nClassId.":".$nUniqSqlId);

        $aWhiteSQL = $this->fetch('whitesql', $sHashKey);

        //있다면 로그에 whitesql_id를 할당하고 종료
        if ($aWhiteSQL) {

            if ($aWhiteSQL['approval_yn'] == "1") {

                $aLog['whitesql_id'] = $sHashKey;
            }

            return;
        }

        //등록되어 있지 않은 경우이고 수집모드(agent_mode = 1)인 경우
        if ($nAgentMode < AGENT_MODE_LOGGING) {

            return;
        }

        //4개 미만의 IP에서 실행이 되었다면 더이상 수행을 멈춘다.
        if ($nCnt < 4) {

            return;
        }

        //4개 이상의 IP에서 실행이 되었다면 WhiteSQL로 자동 등록한다.
        $this->set('whitesql', $sHashKey, array(
            'approval_yn' => '0',
            'on_off'      => '1'
        ));

        $this->syncToMySQL('whitesql', array(
            'whitesql_id' => $sHashKey,
            'agent_id'    => $nAgentId,
            'uniqsql_id'  => $nUniqSqlId,
            'class_id'    => $nClassId,
            'reg_time'    => $this->currTime,
            'state'       => 'A',
            'on_off'      => '1'
        ));

        //모니터링 모드인 경우 이벤트 발생
        if ($nAgentMode == AGENT_MODE_MONITORING) {

            $this->insertWhiteSQLEvent($sHashKey, $nAgentId);
        }

        return;
    }

    private function countUniqSQLExecution($nUniqSqlId, $nAgentId, $sIPAddr)
    {
        $key = 'count_uniqsql:'.$nUniqSqlId.':'.$nAgentId;

        $this->redis->hIncrBy($key, $sIPAddr, 1);

        $this->syncToMySQL('count_uniqsql', array(
            'uniqsql_id' => $nUniqSqlId,
            'agent_id'   => $nAgentId,
            'ipaddr'     => $sIPAddr
        ));

        return array_sum($this->redis->hGetAll($key));
    }


    public function parseDBConnUrl($sDBConnUrl)
    {

        //Oracle jdbc:oracle:thin:@hostname:port:SID
        //MSSQL jdbc:Microsoft:sqlserver://localhost:1433;databasename=DB명
        //MySQL jdbc:mysql://localhost:3306/DB명

        //jdbc:oracle:thin:@192.168.0.13:1521:ORCL
        $aPrefix = array(
            'oracle' => 'jdbc:oracle:thin:@',
            'mssql'  => 'jdbc:Microsoft:sqlserver://',
            'mysql'  => 'jdbc:mysql://'
        );

        $sSystem = 'unknown';
        foreach ($aPrefix as $nIdx => $sPrefix) {

            if (strpos($sDBConnUrl, $sPrefix) !== false) {

                $sSystem = $nIdx;
                break;
            }
        }

        if ($sSystem != 'unknown') {

            $sDBConnUrl = substr($sDBConnUrl, strlen($aPrefix[$sSystem]));
        }

        switch ($sSystem) {

            case "oracle":

                $aTmp = preg_split('/[:]/', $sDBConnUrl);

                $aReturn = array(
                    'system' => $sSystem,
                    'host'   => $aTmp[0],
                    'port'   => $aTmp[1],
                    'sid'    => $aTmp[2],
                    'scheme' => ''
                );
                break;

            case "mssql":

                $aTmp = preg_split('/[:;]|(databasename=)/', $sDBConnUrl);

                $aReturn = array(
                    'system' => $sSystem,
                    'host'   => $aTmp[0],
                    'port'   => $aTmp[1],
                    'sid'    => '',
                    'scheme' => @$aTmp[3]
                );

                break;

            case "mysql":

                $aTmp = preg_split('/[:\/]/', $sDBConnUrl);

                $aReturn = array(
                    'system' => $sSystem,
                    'host'   => $aTmp[0],
                    'port'   => $aTmp[1],
                    'sid'    => '',
                    'scheme' => @$aTmp[2]
                );
                break;

            default:

                $aReturn = array(
                    'system' => $sSystem,
                    'host'   => '',
                    'port'   => '',
                    'sid'    => '',
                    'scheme' => ''
                );
                break;
        }

        return $aReturn;
    }

    private function checkPolicies(&$aLog)
    {

        $policy_id  = $aLog['policy_id'];
        $agent_id   = $aLog['agent_id'];
        $newsql_id  = $aLog['newsql_id'];
        $ref_tables = $aLog['ref_tables'];
        $sql_type   = $aLog['sql_type'];
        $login_id   = $aLog['login_id'];
        $ipaddr     = $aLog['ipaddr'];

//        debug(1, get_class($this), 'Check Policy Number : '.$policy_id, "LogAnalyzer");

        if ($policy_id > 0) {

            return;
        }

        $aLog['policy_id'] = 0;

        //SQL 수행자 IP(ipaddr)가 정책에 등록된 IP인지 체크한다
        if ($ipaddr) {

            $sHashKey = md5($agent_id.":".POLICY_IP.":".$ipaddr);

            if ($nPolicy = $this->fetch('policy', $sHashKey)) {

                debug(1, get_class($this), "[ Policy Detacted ] IP Address ".$sHashKey, "LogAnalyzer");

                $aPolicy = $this->fetch('policy', $nPolicy);

                $aLog['policy_id']   = $nPolicy;
                $aLog['alarm_level'] = $aPolicy['alarm_level'];
                $aLog['policy_type'] = $aPolicy['policy_type'];

                return;
            }
        }

        //SQL 수행자 LoginID(login_id)가 정책에 등록된 ID인지 체크한다.
        if ($login_id) {

            $sHashKey = md5($agent_id.":".POLICY_LOGIN_ID.":".$login_id);

            if ($nPolicy = $this->get('policy', $sHashKey)) {

                debug(1, get_class($this), "[ Policy Detacted ] Login ID ".$sHashKey, "LogAnalyzer");

                $aPolicy = $this->fetch('policy', $nPolicy);

                $aLog['policy_id']   = $nPolicy;
                $aLog['alarm_level'] = $aPolicy['alarm_level'];
                $aLog['policy_type'] = $aPolicy['policy_type'];

                return;
            }
        }

        //SQL(newsql_id)가 정책에 등록된 sql_id인지 체크한다.
        if ($newsql_id) {

            $sHashKey = md5($agent_id.":".POLICY_SQL.":".$newsql_id);

            if ($nPolicy = $this->fetch('policy', $sHashKey)) {

                debug(1, get_class($this), "[ Policy Detacted ] NewSQL ".$sHashKey, "LogAnalyzer");

                $aPolicy = $this->fetch('policy', $nPolicy);

                $aLog['policy_id']   = $nPolicy;
                $aLog['alarm_level'] = $aPolicy['alarm_level'];
                $aLog['policy_type'] = $aPolicy['policy_type'];

                return;
            }
        }

        if ($ref_tables) {

            $aRefTables = json_decode($ref_tables, true);

            foreach ($aRefTables as $nIdx => $aRow) {

                //사용된 테이블명(sql_tablelist)이 개인정보정책에 등록된 테이블인지 체크한다.
                $sHashKey = md5($agent_id.":".POLICY_PERSONAL_INFO_TABLE.":".strtoupper($aRow['table']));

                if ($nPolicy = $this->fetch('policy', $sHashKey)) {

                    debug(1, get_class($this), "[ Policy Detacted ] Personal Information Table ".$sHashKey, "LogAnalyzer");

                    $aPolicy = $this->fetch('policy', $nPolicy);

                    $aLog['policy_id']   = $nPolicy;
                    $aLog['alarm_level'] = $aPolicy['alarm_level'];
                    $aLog['policy_type'] = $aPolicy['policy_type'];

                    return;
                }

                //사용된 테이블명(sql_tablelist)이 주요정보정책에 등록된 테이블인지 체크한다.
                $sHashKey = md5($agent_id.":".POLICY_TABLE.":".strtoupper($aRow['table']));
                if ($nPolicy = $this->fetch('policy', $sHashKey)) {

                    debug(1, get_class($this), "[ Policy Detacted ] Policy Table ".$sHashKey, "LogAnalyzer");

                    $aPolicy = $this->fetch('policy', $nPolicy);

                    $aLog['policy_id']   = $nPolicy;
                    $aLog['alarm_level'] = $aPolicy['alarm_level'];
                    $aLog['policy_type'] = $aPolicy['policy_type'];

                    return;
                }
            }
        }

        if ($sql_type) {

            $sHashKey = md5($agent_id.":".POLICY_SQL_TYPE.":".$sql_type);

            if ($nPolicy = $this->fetch('policy', $sHashKey)) {

                debug(1, get_class($this), "[ Policy Detacted ] SQL Type ".$sHashKey, "LogAnalyzer");

                $aPolicy = $this->fetch('policy', $nPolicy);

                $aLog['policy_id']   = $nPolicy;
                $aLog['alarm_level'] = $aPolicy['alarm_level'];
                $aLog['policy_type'] = $aPolicy['policy_type'];

                return;
            }
        }
    }

    private function saveResultRecord(&$aLog)
    {
        if ($aLog['result_data'] == "N/A") {

            return;
        }

        $this->syncToMySQL('sqllog_result_data', array(
            'sqllog_id'   => $aLog['log_id'],
            'result_data' => addslashes($aLog['result_data'])
        ));
    }

    public function insertWhiteSQLEvent($nWhiteSQLId, $nAgentId)
    {

        //WhiteSQL 자동 등록 이벤트 등록
        $this->makeAlarm(
            EVENT_TYPE_POLICY, EVENT_TYPE_NOTICE, EVENT_KIND_WHITE_SQL, POLICY_WHITE_SQL, $this->currTime,
            'White SQL로 추정되어 자동 등록하였습니다',
            'tbl_whitesql_list', $nWhiteSQLId, $nAgentId
        );
    }

    public function insertNewSQLEvent($nNewSQLId, $nAgentId)
    {

        //NewSQL 자동 등록 이벤트 등록
        $this->makeAlarm(
            EVENT_TYPE_POLICY, EVENT_TYPE_NOTICE, EVENT_KIND_NEWSQL, POLICY_NONE_WHITE_SQL, $this->currTime,
            '신규 SQL이 탐지되어 등록되었습니다.',
            'tbl_newsql', $nNewSQLId, $nAgentId
        );
    }

    public function makeAlarm($nType, $nLevel, $nKind, $nPolicyType, $nTime, $sMsg, $sTblName, $nTblId, $nAgentId)
    {
        $this->sendBulkInsert('event_log', array(
            'event_type'         => $nType,
            'event_time'         => $nTime,
            'event_level'        => $nLevel,
            'event_kind'         => $nKind,
            'policy_type'        => $nPolicyType,
            'event_msg'          => $sMsg,
            'event_confirm_flag' => '0',
            'event_tblname'      => $sTblName,
            'event_tblid'        => $nTblId,
            'agent_id'           => $nAgentId,
        ));

        $this->sendRealtimeReport('event', array(
            'event_type'  => $nType,
            'agent_id'    => $nAgentId,
            'event_level' => $nLevel,
            'event_kind'  => $nKind,
            'policy_type' => $nPolicyType
        ));
    }

    public function saveSQLLog($aLog)
    {
        if ($aLog['result_data'] == "N/A") {

            $aLog['result_data_saved'] = '0';

        } else {

            $aLog['result_data_saved'] = '1';
        }

        $this->sendBulkInsert('anal_log', array(
            'sqllog_id'         => $aLog['log_id'],
            'sql_type'          => $aLog['sql_type'],
            'uniqsql_id'        => $aLog['uniqsql_id'],
            'dbconn_id'         => $aLog['dbconn_id'],
            'class_name'        => $aLog['class_name'],
            'class_id'          => $aLog['class_id'],
            'whitesql_id'       => $aLog['whitesql_id'],
            'convsql_id'        => $aLog['convsql_id'],
            'blocksql_id'       => $aLog['policy_id'],
            'sqllog_check'      => $aLog['sqllog_check'],
            'result_data_saved' => $aLog['result_data_saved'],
            'privacytbl_yn'     => $aLog['privacytbl_yn'],
            'agent_id'          => $aLog['agent_id'],
            'agent_mode'        => $aLog['agent_mode'],
            'request_time'      => $aLog['request_time'],
            'prestmt'           => $aLog['prestmt'],
            'sql_str'           => $aLog['sql_str'],
            'sql_param'         => $aLog['sql_param'],
            'dbconn_url'        => $aLog['dbconn_url'],
            'dbconn_account'    => $aLog['dbconn_account'],
            'class_trace'       => $aLog['class_trace'],
            'policy_id'         => $aLog['policy_id'],
            'block_yn'          => $aLog['block_yn'],
            'login_id'          => $aLog['login_id'],
            'ipaddr'            => $aLog['ipaddr'],
            'exec_starttime'    => $aLog['exec_starttime'],
            'exec_elapsedtime'  => $aLog['exec_elapsedtime'],
            'execute_yn'        => $aLog['execute_yn'],
            'fail_code'         => $aLog['fail_code'],
            'result_count'      => $aLog['result_count'],
            'privacy_type'      => $aLog['privacy_type'],
            'privacy_value'     => $aLog['privacy_value'],
            'result_data'       => $aLog['result_data']
        ));

        $this->sendRealtimeReport('log', array(
            'agent_id'          => $aLog['agent_id'],
            'policy_type'       => $aLog['policy_type'],
            'privacy_type'      => $aLog['privacy_type'],
            'result_count'      => $aLog['result_count'],
            'whitesql_id'       => $aLog['whitesql_id'],
            'uniqsql_id'        => $aLog['uniqsql_id'],
            'ipaddr'            => $aLog['ipaddr'],
            'sql_type'          => $aLog['sql_type'],
            'login_id'          => $aLog['login_id'],
            'execute_yn'        => $aLog['execute_yn'],
            'convsql_id'        => $aLog['convsql_id'],
            'exec_elapsedtime'  => $aLog['exec_elapsedtime'],
            'login_id'          => $aLog['login_id'],
            'ipaddr'            => $aLog['ipaddr'],
            'privacytbl_yn'     => $aLog['privacytbl_yn'],
            'class_name'        => $aLog['class_name'],
            'request_time'      => $aLog['request_time'],
            'result_data_saved' => $aLog['result_data_saved'],
            'sql_str'           => $aLog['sql_str']
        ));

        if ($aLog['agent_mode'] < AGENT_MODE_MONITORING) return;

        $this->sendRealtimeReport('monitoring', array(
            'agent_id'          => $aLog['agent_id'],
            'policy_type'       => $aLog['policy_type'],
            'whitesql_id'       => $aLog['whitesql_id'],
        ));
    }

    public function savePrivacyTables(&$aLog)
    {

        foreach ($this->privacyTables as $nPrivacyTblId) {

            $this->syncToMySQL('sqllog_privacy', array(
                'sqllog_id'     => $aLog['log_id'],
                'privacytbl_id' => $nPrivacyTblId,
            ));
        }
    }

    public function saveEventLog(&$aLog)
    {

        $whitesql_id  = $aLog['whitesql_id'];
        $execute_yn   = $aLog['execute_yn'];
        $log_id       = $aLog['log_id'];
        $agent_id     = $aLog['agent_id'];
        $policy_type  = $aLog['policy_type'];
        $class_id     = $aLog['class_id'];
        $uniqsql_id   = $aLog['uniqsql_id'];
        $ipaddr       = $aLog['ipaddr'];
        $login_id     = $aLog['login_id'];
        $block_yn     = $aLog['block_yn'];
        $privacy_type = $aLog['privacy_type'];
        $result_count = $aLog['result_count'];

        //debug(1, get_class($this), 'Save EventLog Agent_mode : '.$agent_mode, "LogAnalyzer");

        //경보이벤트 생성 모드(모니터링, 보호 모드)인지 체크
        if ($agent_mode < AGENT_MODE_MONITORING) return;

        //WhiteSQL 여부 체크
        if ($whitesql_id < 1) {

            $this->makeAlarm(
                EVENT_TYPE_POLICY, EVENT_TYPE_ATTENTION, EVENT_KIND_NONE_WHITESQL, POLICY_NONE_WHITE_SQL, $this->currTime,
                'WhiteSQL에 등록되지 않는 SQL이 수행되었습니다.',
                'tbl_log', $log_id, $agent_id
            );

            return;
        }

        //SQL수행여부 체크
        if (!$execute_yn) {

            $this->makeAlarm(
                EVENT_TYPE_POLICY, EVENT_TYPE_ATTENTION, EVENT_KIND_NONE, $policy_type, $this->currTime,
                'SQL 수행이 실패되었습니다.',
                'tbl_log', $log_id, $agent_id
            );

            return;
        }

        //개인정보 조회 여부 체크
        if ($privacy_type != 'none') {

            $this->makeAlarm(
                EVENT_TYPE_POLICY, EVENT_TYPE_ALERT, EVENT_KIND_PERSONAL_INFO_TABLE, POLICY_PERSONAL_INFO_TABLE, $this->currTime,
                '데이터 조회 결과에 개인정보가 포함되어 있습니다.',
                'tbl_log', $log_id, $agent_id
            );

            return;
        }

        //SQL 수행 차단이 발생하였는 지 체크
        if ($block_yn) {

            $this->makeAlarm(
                EVENT_TYPE_POLICY, EVENT_TYPE_SERIOUS, EVENT_KIND_NONE, $policy_type, $this->currTime,
                'SQL 수행이 차단 되었습니다.',
                'tbl_log', $log_id, $agent_id
            );

            return;
        }


        //멤케쉬에서 전날의 95%신뢰구간을 가져와서 이상징후를 탐지한다.
        $sField      = $agent_id.':'.$class_id.':'.$uniqsql_id.':'.$ipaddr.':'.$login_id;
        $aPercentile = $this->fetch('95Percentile', $sField);

        if ($aPercentile) {

            list($fMin, $fMax) = $aPercentile;

            if ($fMin > $result_count || $fMax < $result_count) {

                debug(1, get_class($this), "95% Percentile detaction -".$fMin." to +".$fMax." value : ".$result_count, "LogAnalyzer");

                // -'.$fMin.' ~ +'.$fMax.' 이상값 : '.$result_count
                $this->makeAlarm(
                    EVENT_TYPE_POLICY, EVENT_TYPE_SERIOUS, EVENT_KIND_NONE, $policy_type, $this->currTime,
                    '개인정보 테이블 조회 이상 징후가 감지 되었습니다.\n평균 조회량을 훨씬 상회하는 조회가 발생했습니다.',
                    'tbl_log', $log_id, $agent_id
                );

                return;
            }
        }

        //정책의 위배 여부를 체크
        if ($policy_id > 0) {

            // debug(1, get_class($this), " Policy detected ".$policy_id);

            $aPolicy = $this->fetch('policy', $policy_id);

            $alarm_level = $aLog['alarm_level'] = $aPolicy['alarm_level'];
            $policy_type = $aLog['policy_type'] = $aPolicy['policy_type'];

            $aMsgs = array();

            array_push($aMsgs, "[".$aPolicy['policy_name']."]");

            $bDetact = true;
            switch ($policy_type) {

                case POLICY_SQL:

                    array_push($aMsgs, '주의해야 할 SQL이 탐지되었습니다.');
                    $nEventKind = EVENT_KIND_ATTENTION_SQL;
                    break;

                case POLICY_SQL_CONVERT:

                    array_push($aMsgs, 'SQL변경 정책이 정상적으로 수행되었습니다.');
                    $nEventKind         = EVENT_KIND_SQL_CONVERT;
                    $aLog['convsql_id'] = $policy_id;
                    break;

                case POLICY_IP:

                    array_push($aMsgs, '주의해야 할 IP가 탐지되었습니다.');
                    $nEventKind = EVENT_KIND_ATTENTION_IP;
                    break;

                case POLICY_LOGIN_ID:

                    array_push($aMsgs, '주의해야 할 loginId가 탐지되었습니다.');
                    $nEventKind = EVENT_KIND_ATTENTION_LOGIN_ID;
                    break;

                case POLICY_TABLE:

                    array_push($aMsgs, '주요 테이블에 대한 데이터 작업이 탐지되었습니다.');
                    $nEventKind = EVENT_KIND_ATTENTION_TABLE;
                    break;

                case POLICY_SQL_TYPE:

                    array_push($aMsgs, '주의해야 할 데이터 작업 유형이 탐지되었습니다.');
                    $nEventKind = EVENT_KIND_ATTENTION_SQL_TYPE;
                    break;

                case POLICY_PERSONAL_INFO_TABLE:

                    array_push($aMsgs, '개인정보 테이블에 대한 데이터 작업이 탐지되었습니다.');
                    $nEventKind = EVENT_KIND_PERSONAL_INFO_TABLE;
                    break;
            }

            $bDetact = true;

            if ($policy_type == POLICY_PERSONAL_INFO_TABLE || $policy_type == POLICY_TABLE) {

                $bDetact = false;

                //!(조회량이 입력값보다 작거나 같고 조회 시간이 입력값 사이 인 경우는 참 이다.)
                if (@$aPolicy['allow_quantity'] > 0) {

                    if ($result_count > $aPolicy['allow_quantity']) {

                        $bDetact = true;

                        array_push($aMsgs, '1회 조회 허용량을 초과하였습니다.');

                        if ($alarm_level < EVENT_TYPE_DANGER) {

                            $alarm_level = EVENT_TYPE_DANGER;
                        }
                    }
                }

                if (@$aPolicy['allow_ftime'] && @$aPolicy['allow_ttime']) {

                    $nAllowFTime = str_replace(":", "", $aPolicy['allow_ftime']);
                    $nAllowTTime = str_replace(":", "", $aPolicy['allow_ttime']);
                    $nNow        = date("His");

                    if (!($nNow >= $nAllowFTime && $nNow <= $nAllowTTime)) {

                        $bDetact = true;

                        array_push($aMsgs, '조회시간을 벗어났습니다.');

                        if ($alarm_level < EVENT_TYPE_DANGER) {

                            $alarm_level = EVENT_TYPE_DANGER;
                        }
                    }
                }
            }

            if ($bDetact) {

                $this->makeAlarm(
                    EVENT_TYPE_POLICY, $alarm_level, $nEventKind, $policy_type, $this->currTime,
                    implode("\n", $aMsgs), 'tbl_log', $log_id, $agent_id
                );
            }

            return;
        }
    }

    public function sendBulkInsert($sType, $aRow)
    {

        $aRow['log_type'] = $sType;
        $this->redis->rPush('bulk_insert_log', json_encode($aRow));
    }

    public function syncToMySQL($sType, $aRow)
    {

        $aRow['sync_type'] = $sType;
        $this->redis->rPush('sync_to_mysql', json_encode($aRow));
    }

    public function sendRealtimeReport($sType, $aRow)
    {
        $aRow['report_type'] = $sType;
        $this->redis->rPush('realtime', json_encode($aRow));
    }

    public function exists($key, $hash)
    {

        return $this->redis->exists($key.":".$hash);
    }

    public function set($key, $hash, $aRow)
    {

        $this->redis->hMSet($key.":".$hash, $aRow);
    }

    public function fetch($key, $hash)
    {

        return $this->redis->hGetAll($key.":".$hash);
    }

    public function get($key, $field)
    {
        return $this->redis->hget($key, $field);
    }
}