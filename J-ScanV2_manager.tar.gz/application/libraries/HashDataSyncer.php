<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH."libraries/Database.php";

class HashDataSyncer{

    public function __construct($hostname, $username, $password, $database){

        $this->redis = new Redis();
        $this->redis->connect('127.0.0.1', 6379);

        $this->db = new Database($hostname, $username, $password, $database);
    }

    public function run(){

        debug(1, get_class($this), "Start Daemon SyncToMySQL", "HashDataSyncer");

        while (true) {

            $sLog = $this->redis->lpop('sync_to_mysql');

            if (!$sLog) {

                usleep(1000);
                continue;
            }

            $t1 = startCheckTime();

            $aLog = json_decode($sLog, true);

//            debug(1, get_class($this), print_r($aLog, true), "HashDataSyncer");

            if(!method_exists($this, $aLog['sync_type'])){

                debug(1, get_class($this), "The method is not exists : ".$aLog['sync_type'], "HashDataSyncer");
                continue;
            }

            $this->{$aLog['sync_type']}($aLog);

            $exec_time = endCheckTime($t1);

            usleep(100);
        }

    }

    private function whitesql($aRow){

        $this->db->query("
            INSERT INTO tbl_whitesql_list(
                `whitesql_id`, `agent_id`,
                `uniqsql_id`, `class_id`,
                `state`, `on_off`
            )
            VALUES (
                '".$aRow['whitesql_id']."', '".$aRow['agent_id']."',
                '".$aRow['uniqsql_id']."', '".$aRow['class_id']."',
                '".$aRow['state']."', '".$aRow['on_off']."'
            )
        ");
    }

    private function count_uniqsql($aRow){

        $this->db->query("
            INSERT INTO tbl_uniqsql_execution_count(uniqsql_id, agent_id, ipaddr, exec_cnt)
            VALUES ('".$aRow['uniqsql_id']."', '".$aRow['agent_id']."', '".$aRow['ipaddr']."', 1)
            ON DUPLICATE KEY UPDATE exec_cnt = exec_cnt + 1
        ");
    }

    private function newsql($aRow){

        $this->db->query("
            INSERT INTO tbl_newsql(
                `newsql_id`, `sqllog_id`,
                `uniqsql_id`, `class_id`,
                `agent_id`, `sql_type`,
                `orig_sqltext`, `reg_date`
            )
            VALUES (
                '".$aRow['newsql_id']."', '".$aRow['sqllog_id']."',
                '".$aRow['uniqsql_id']."', '".$aRow['class_id']."',
                '".$aRow['agent_id']."', '".$aRow['sql_type']."',
                '".$aRow['orig_sqltext']."', '".$aRow['reg_date']."'
            )
        ");
    }

    private function uniqsql_tables($aRow){

        $this->db->query("
            INSERT INTO tbl_uniqsql_tables(
                uniqsql_id, tbl_name
            )
            VALUES (
                '".$aRow['uniqsql_id']."', '".$aRow['tbl_name']."'
            )
        ");
    }

    private function uniqsql($aRow){

        $this->db->query("
            INSERT INTO tbl_uniqsql(
                uniqsql_id, sql_type,
                uniq_sqltext, orig_sqltext,
                ref_tables
            )
            VALUES (
                '".$aRow['uniqsql_id']."', '".$aRow['sql_type']."',
                '".addslashes($aRow['uniq_sqltext'])."', '".addslashes($aRow['orig_sqltext'])."',
                '".$aRow['ref_tables']."'
            )
        ");
    }

    private function class_trace($aRow){

        $this->db->query("
            INSERT INTO tbl_class_trace(
                class_id, class_string
            )
            VALUES (
                '".$aRow['class_id']."', '".$aRow['class_string']."'
            )
        ");
    }

    private function agent_dbconn($aRow){

        $this->db->query("
            INSERT INTO tbl_agent_dbconn(
                dbconn_id, agent_id
            )
            VALUES (
                '".$aRow['dbconn_id']."', '".$aRow['agent_id']."'
            )
        ");
    }

    private function dbconn($aRow){

        $this->db->query("
            INSERT INTO tbl_dbconn(
                dbconn_id, dbconn_url,
                dbconn_account, collect_time,
                ipaddr, port,
                sid, dbname
            )
            VALUES (
                '".$aRow['dbconn_id']."', '".$aRow['dbconn_url']."',
                '".$aRow['dbconn_account']."', '".$aRow['collect_time']."',
                '".$aRow['ipaddr']."', '".$aRow['port']."',
                '".$aRow['sid']."', '".$aRow['dbname']."'
            )
        ");
    }
}