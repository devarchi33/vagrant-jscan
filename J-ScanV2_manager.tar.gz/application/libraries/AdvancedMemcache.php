<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

class AdvancedMemcache extends Memcache{

    private $mem;

    public function __construct(){


    }

    public function getAll(){

        $list = array(); 
        $allSlabs = $this->getExtendedStats('slabs'); 
        $items = $this->getExtendedStats('items'); 
        foreach($allSlabs as $server => $slabs) { 

            foreach($slabs AS $slabId => $slabMeta) { 

                $cdump = $this->getExtendedStats('cachedump', (int)$slabId); 

                // print_r($cdump);
                // foreach($cdump AS $keys => $arrVal) { 

                //     if(!$arrVal){

                //         continue;
                //     }

                //     foreach($arrVal AS $k => $v) {                    

                //         if(strpos($k, $str) > -1){

                //             $list[$k] = $this->get($k);
                //         }
                //     } 
                // }
            } 
        } 

        return $list;  
    }

    public function like($str){

        $list = array(); 
        $allSlabs = $this->getExtendedStats('slabs'); 
        $items = $this->getExtendedStats('items'); 
        foreach($allSlabs as $server => $slabs) { 

            foreach($slabs AS $slabId => $slabMeta) { 

                $cdump = $this->getExtendedStats('cachedump', (int)$slabId); 

                foreach($cdump AS $keys => $arrVal) { 

                    if(!$arrVal){

                        continue;
                    }

                    foreach($arrVal AS $k => $v) {                    

                        if(strpos($k, $str) > -1){

                            $list[$k] = $this->get($k);
                        }
                    } 
                }
            } 
        } 

        return $list;  
    }

    public function likeDel($str){

        $list = $this->like($str);
        foreach($list as $k => $v){

            $this->delete($k);
        }
    }
}