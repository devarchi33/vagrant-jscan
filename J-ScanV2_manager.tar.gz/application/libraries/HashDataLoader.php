<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH."libraries/Database.php";
require_once APPPATH."libraries/AdvancedMemcache.php";

class HashDataLoader
{

    public function __construct($hostname, $username, $password, $database)
    {

        $this->redis = new Redis();
        $this->redis->connect('127.0.0.1', 6379);

        $this->db = new Database($hostname, $username, $password, $database);
    }

    public function cache()
    {

        $this->cacheAgent();
        $this->cacheUniqSQL();
        $this->cacheWhiteSQL();
        $this->cacheNewSQL();
        $this->cacheClassSting();
        $this->cacheDBConnURL();
        $this->cachePolicies();
        $this->cachePrivacyTables();
    }

    private function cacheAgent()
    {

        $mem = &$this->redis;

        $keys = array_merge($mem->keys('server:*'), $mem->keys('group:*'), $mem->keys('root:*'));
        array_walk($keys, function ($item, $key) use ($mem) {

            $mem->delete($item);
        });

        $sSql = '
            SELECT a.agent_id, a.group_id, a.agent_name, a.ipaddr, a.port, a.agent_mode, a.status, a.license_status, b.group_name
            FROM tbl_agent_info a
            LEFT OUTER JOIN tbl_agentgroup_info b ON b.group_id = a.group_id
            WHERE a.del_yn = "0"
        ';
        $this->db->query($sSql, function ($oResult) use ($mem) {

            while ($aRow = $oResult->fetch_array(MYSQLI_ASSOC)) {

                $mem->hMSet("server:".$aRow['agent_id'], array(
                    'group_id'       => $aRow['group_id'],
                    'agent_name'     => $aRow['agent_name'],
                    'agent_mode'     => $aRow['agent_mode'],
                    'status'         => $aRow['status'],
                    'license_status' => $aRow['license_status'],
                    'ipaddr'         => $aRow['ipaddr'],
                    'port'           => $aRow['port']
                ));

                $mem->hMSet("group:".$aRow['group_id'], array(
                    'group_name' => $aRow['group_name']
                ));

                $mem->sAdd("root:agent", $aRow['agent_id']);
                $mem->sAdd("group:".$aRow['group_id'].":agent", $aRow['agent_id']);
                $mem->sAdd("server:".$aRow['agent_id'].":agent", $aRow['agent_id']);
            }
        });
    }

    private function cacheUniqSQL()
    {

        $mem = &$this->redis;

        $this->delete('uniqsql');

        $sSql = 'SELECT uniqsql_id, ref_tables, sql_type FROM tbl_uniqsql';
        $this->db->query($sSql, function ($oResult) use ($mem) {

            while ($aRow = $oResult->fetch_array(MYSQLI_ASSOC)) {

                $mem->hMSet("uniqsql:".$aRow['uniqsql_id'], array(
                    'sql_type'   => $aRow['sql_type'],
                    'uniqsql_id' => $aRow['uniqsql_id'],
                    'ref_tables' => $aRow['ref_tables']
                ));
            }
        });
    }

    private function cacheWhiteSQL()
    {

        $mem = &$this->redis;

        $this->delete('whitesql');

        //사용중인 WhiteSQL 내역을 승인내역과 함께 캐시한다.
        $sSql = 'SELECT whitesql_id, on_off, approval_yn FROM tbl_whitesql_list WHERE on_off = "1"';

        $this->db->query($sSql, function ($oResult) use ($mem) {

            while ($aRow = $oResult->fetch_array(MYSQLI_ASSOC)) {

                $mem->hMSet("whitesql:".$aRow['whitesql_id'], array(
                    'approval_yn' => $aRow['approval_yn'],
                    'on_off'      => $aRow['on_off']
                ));
            }
        });

    }

    private function cacheNewSQL()
    {

        $mem = &$this->redis;

        $this->delete('newsql');

        $sSql = 'SELECT newsql_id FROM tbl_newsql';
        $this->db->query($sSql, function ($oResult) use ($mem) {

            while ($aRow = $oResult->fetch_array(MYSQLI_ASSOC)) {

                $mem->hMSet("newsql:".$aRow['newsql_id'], array());
            }
        });
    }

    private function cacheClassSting()
    {

        $mem = &$this->redis;

        $this->delete('clsstr');

        $sSql = 'SELECT class_id, class_string FROM tbl_class_trace';
        $this->db->query($sSql, function ($oResult) use ($mem) {

            while ($aRow = $oResult->fetch_array(MYSQLI_ASSOC)) {

                $mem->hMSet("class_trace:".$aRow['class_id'], array(
                    'class_string' => $aRow['class_string']
                ));
            }
        });
    }

    private function cacheDBConnURL()
    {

        $mem = &$this->redis;

        $this->delete('dbconn');

        $sSql = 'SELECT dbconn_id FROM tbl_dbconn';
        $this->db->query($sSql, function ($oResult) use ($mem) {

            while ($aRow = $oResult->fetch_array(MYSQLI_ASSOC)) {

                $mem->hMSet("dbconn:".$aRow['dbconn_id'], array());
            }
        });
    }

    private function cachePolicies()
    {

        $mem = &$this->redis;

        $this->delete('policy');

        $sSql = '
            SELECT agent_id, policy_id, policy_name, policy_type, alarm_level, policy_properties
            FROM tbl_policy_list WHERE on_off = "1" AND del_yn = "0"
        ';
        $this->db->query($sSql, function ($oResult) use ($mem) {

            while ($aRow = $oResult->fetch_array(MYSQLI_ASSOC)) {

                $aProperties = json_decode($aRow['policy_properties'], true);

                if ($aRow['policy_type'] == POLICY_SQL) {

                    if ($aProperties['newsql_id']) {

                        $sHashKey = md5($aRow['agent_id'].":".$aRow['policy_type'].":".$aProperties['newsql_id']);
                    }
                } else {

                    $sHashKey = md5($aRow['agent_id'].":".$aRow['policy_type'].":".strtoupper($aProperties['target']));
                }

                if ($sHashKey) {

                    $mem->hMSet("policy:".$sHashKey, array(
                        'policy_id' => $aRow['policy_id']
                    ));
                }

                $mem->hMSet('policy:'.$aRow['policy_id'], array(
                    'policy_name'    => $aRow['policy_name'],
                    'alarm_level'    => $aRow['alarm_level'],
                    'policy_type'    => $aRow['policy_type'],
                    'allow_ftime'    => @$aProperties['allow_ftime'],
                    'allow_ttime'    => @$aProperties['allow_ttime'],
                    'allow_quantity' => @$aProperties['allow_quantity']
                ));
            }
        });
    }

    private function cachePrivacyTables()
    {

        $mem = &$this->redis;

        $this->delete('privacy_tables');

        $sSql = "
            SELECT b.privacytbl_id, b.privacytbl, b.agent_id, a.uniqsql_id FROM tbl_uniqsql_tables a
            INNER JOIN tbl_privacytbl_list b ON b.privacytbl = a.tbl_name
            GROUP BY b.agent_id, a.uniqsql_id
        ";
        $this->db->query($sSql, function ($oResult) use ($mem) {

            while ($aRow = $oResult->fetch_array(MYSQLI_ASSOC)) {

                $mem->hSet('privacy_tables:'.$aRow['agent_id'].':'.$aRow['uniqsql_id'], $aRow['privacytbl_id'], $aRow['privacytbl']);
            }
        });
    }

    private function delete($prefix)
    {

        while (false !== ($key = $this->redis->scan($it, $prefix."*"))) {

//            debug(1, get_class($this), print_r($it, true));
//            debug(1, get_class($this), $prefix."*:".print_r($key, true));
            $this->redis->delete($key);
        }
    }

    public function run()
    {

        $this->cache();

        require_once APPPATH."config/queue.php";

        $this->keyMQSync = $config['mq_sync'];

        $this->mqSync = msg_get_queue($this->keyMQSync, 0600);

        while (true) {

            msg_receive($this->mqSync, 1, $msg_type, 100000, $sCmd, true, MSG_IPC_NOWAIT, $msg_error);

            if ($sCmd) {

                call_user_func_array(array($this, 'cache'.$sCmd), array());

                debug(1, get_class($this), "Sync ".$sCmd, "HashDataLoader");
                // debug(1, get_class($this), print_r($aLog, true), "HashDataLoader");
            }

            usleep(100);
        }

    }
}