<?
class Email extends CI_Email{

	private $CI;

	public function __construct(){
		
		parent:: __construct();
		
		$this->CI = & get_instance();		
		$this->CI->config->load('smtp', true);
		
		$this->initialize($this->CI->config->item('smtp'));
		
		$this->from('system@ntree.nsmartad.com', '엔트리2.0');
	}
}
?>