<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH."libraries/Database.php";

/**
 * LogBulkSaver
 *
 * log 저장 경로에 저장된 로그를 설정된 간격으로 한번 씩 읽어서 LOAD DATA INFILE문을 실행한다.
 *
 * @uses     native php
 * @category daemon
 * @package  WhiteSQL
 * @author   정주원 <jjwcom@nate.com>
 * @license  Copyright (c) 2013, Iruentech Corporation All rights reserved.
 * @link
 */
class LogBulkSaver
{

    private $db = null;

    public function __construct(
        $hostname, $username, $password, $database
    )
    {

        //데이터 베이스 연결
        $this->db           = new Database($hostname, $username, $password, $database);
        $this->pathAuditLog = "/tmp/jscan/audit/";
        $this->pathAnalLog  = "/tmp/jscan/anal_log/";
        $this->pathEventLog = "/tmp/jscan/event_log/";
    }

    public function run()
    {
        while (true) {

            $nSearchTime = time() - 20;

            $this->bulkAuditLog($nSearchTime);
            $this->bulkAnalLog($nSearchTime);
            $this->bulkEventLog($nSearchTime);

            sleep(1);
        }
    }

    public function bulkAuditLog($nSearchTime)
    {

        $sPath = $this->pathAuditLog;

        foreach ($this->getFileList($sPath, $nSearchTime) as $idx => $file) {

            $t1 = startCheckTime();

            $sSQL   = "
                    LOAD DATA INFILE '".$sPath.$file."' INTO TABLE `tbl_log`
                    FIELDS TERMINATED BY '\f'
                    OPTIONALLY ENCLOSED BY '\"'
                    LINES TERMINATED BY '\r\n'
                    (
                        `sqllog_id`,`agent_id`,`agent_mode`,`request_time`,
                        `prestmt`,`sql_str`,`sql_param`,`dbconn_url`,
                        `dbconn_account`,`class_trace`,`policy_id`,`block_yn`,
                        `login_id`,`ipaddr`,`exec_starttime`,`exec_elapsedtime`,
                        `execute_yn`,`fail_code`,`result_count`,`privacy_type`,
                        `privacy_value`,`result_data`
                    )
                ";
            $result = $this->db->query($sSQL);

            if ($result) {

                unlink($sPath.$file);
                debug(1, get_class($this), "LOAD DATA INFILE Excution : ".endCheckTime($t1), "LogBulkSaver");
                continue;
            }

            debug(1, get_class($this), "LOAD DATA INFILE Failure : vi ".$sPath.$file.", ".$this->db->conn->errno." : ".$this->db->conn->error, "LogBulkSaver");
        }
    }

    public function bulkAnalLog($nSearchTime)
    {

        $sPath = $this->pathAnalLog;

        foreach ($this->getFileList($sPath, $nSearchTime) as $idx => $file) {

            $t1 = startCheckTime();

            $sSQL   = "
                    LOAD DATA INFILE '".$sPath.$file."' INTO TABLE `tbl_anal_log`
                    FIELDS TERMINATED BY '\f'
                    OPTIONALLY ENCLOSED BY '\"'
                    LINES TERMINATED BY '\r\n'
                    (
                        `sqllog_id`, `sql_type`,
                        `uniqsql_id`, `dbconn_id`,
                        `class_name`, `class_id`,
                        `whitesql_id`, `convsql_id`,
                        `blocksql_id`, `sqllog_check`,
                        `result_data_saved`,
                        `privacytbl_yn`, `agent_id`,
                        `agent_mode`, `request_time`,
                        `prestmt`, `sql_str`,
                        `sql_param`, `dbconn_url`,
                        `dbconn_account`, `class_trace`,
                        `policy_id`, `block_yn`,
                        `login_id`, `ipaddr`,
                        `exec_starttime`, `exec_elapsedtime`,
                        `execute_yn`, `fail_code`,
                        `result_count`, `privacy_type`,
                        `privacy_value`, `result_data`
                    )
                ";
            $result = $this->db->query($sSQL);

            if ($result) {

                unlink($sPath.$file);
                debug(1, get_class($this), "LOAD DATA INFILE Excution : ".endCheckTime($t1), "LogBulkSaver");
                continue;
            }

            debug(1, get_class($this), "LOAD DATA INFILE Failure : vi ".$sPath.$file.", ".$this->db->conn->errno." : ".$this->db->conn->error, "LogBulkSaver");
        }
    }

    public function bulkEventLog($nSearchTime)
    {

        $sPath = $this->pathEventLog;

        foreach ($this->getFileList($sPath, $nSearchTime) as $idx => $file) {

            $t1 = startCheckTime();

            $sSQL   = "
                    LOAD DATA INFILE '".$sPath.$file."' INTO TABLE `tbl_eventlog`
                    FIELDS TERMINATED BY '\f'
                    OPTIONALLY ENCLOSED BY '\"'
                    LINES TERMINATED BY '\r\n'
                    (
                        `event_type`, `event_time`,
                        `event_level`, `event_kind`,
                        `policy_type`, `event_msg`,
                        `event_confirm_flag`, `event_tblname`,
                        `event_tblid`, `agent_id`
                    )
                ";
            $result = $this->db->query($sSQL);

            if ($result) {

                unlink($sPath.$file);
                debug(1, get_class($this), "LOAD DATA INFILE Excution : ".endCheckTime($t1), "LogBulkSaver");
                continue;
            }

            debug(1, get_class($this), "LOAD DATA INFILE Failure : vi ".$sPath.$file.", ".$this->db->conn->errno." : ".$this->db->conn->error, "LogBulkSaver");
        }
    }

    public function getFileList($path, $searchTime)
    {

        $list = array();
        if ($handle = opendir($path)) {
            while (false !== ($entry = readdir($handle))) {
                if ($entry != "." && $entry != ".." && substr($entry, 0, 1) != ".") {

                    if ($searchTime >= $entry) {

                        array_push($list, $entry);
                    }
                }
            }
            closedir($handle);
        }

        return $list;
    }
}

