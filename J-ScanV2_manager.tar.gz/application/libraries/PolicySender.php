<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

require_once APPPATH."libraries/Database.php";
require_once APPPATH."helpers/cmd_socket_helper.php";

/**
* PolicyManager
*
* 정책 매니저
*
* @uses     native php
* @category daemon
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2013, Iruentech Corporation All rights reserved.
* @link
*/
class PolicySender{

    public $socket; 

    public $key = null;
    public $msg_id; 
    public $db;

    public function __construct($hostname, $username, $password, $database){


        require_once APPPATH."config/queue.php";

        $this->key = $config['mq_policy_sender'];

        //데이터 베이스 연결
        $this->db = new Database($hostname, $username, $password, $database);

        //메세지 큐 연결
        $this->msg_id = msg_get_queue($this->key, 0600) ;
    }
  
    public function getMsgId(){

        return $this->msg_id;
    }


    public function makePolicyFile($aAgent){

        if(!$aAgent) return;
        
        //debug(2, get_class($this), 'makePolicyFile');

        $sSql = '
            SELECT * FROM tbl_policy_list WHERE agent_id = '.$aAgent['agent_id'].' AND 
            policy_type = '.POLICY_SQL_CONVERT.'
        ';
        $aPolicyData = $this->db->query($sSql, function($oResult){

            $aData = array();
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                array_push($aData, $aRow);
            }

            return $aData;
        });

        $xml = new XmlWriter();
        $xml->openMemory();
        $xml->startDocument('1.0', 'UTF-8');
        $xml->startElement('root');
        $xml->startElement('agent_info');
        $xml->writeAttribute('type', 'all'); 

        //동작모드(0=bypass, 1=collect, 2=monitoring)
        $xml->startElement('mod');
        $xml->text($aAgent['agent_mode']);
        $xml->endElement();

        $xml->startElement('agent_id');
        $xml->text($aAgent['agent_id']);
        $xml->endElement();

        $xml->startElement('result_logging');
        $xml->text($aAgent['rs_logging_yn']);
        $xml->endElement();

        $xml->startElement('auth_check');
        $xml->text($aAgent['privacy_flag']);
        $xml->endElement();

        $xml->startElement('license_type');
        $xml->text($aAgent['license_check']);
        $xml->endElement();

        $xml->startElement('license_value');
        $xml->text($aAgent['license_key']);
        $xml->endElement();

        $xml->startElement('logging_mod');
        $xml->text("0");
        $xml->endElement();

        // end the document and output
        $xml->endElement();

        if($aPolicyData){

            $xml->startElement('policy_list');
            foreach($aPolicyData as $nIdx => $aRow){

                //debug(4, get_class($this), print_r($aRow, true));            

                $aProperties = json_decode($aRow['policy_properties'], true);

                $xml->startElement('policy');

                if($aRow['policy_type'] == POLICY_SQL){

                    $xml->writeAttribute('type', 'sql'); 
                }
                else if($aRow['policy_type'] == POLICY_SQL_CONVERT){

                    $xml->writeAttribute('type', 'sql_change'); 
                }

                $xml->startElement('id');
                $xml->text($aRow['policy_id']);
                $xml->endElement();
                $xml->startElement('onoff');
                $xml->text($aRow['on_off']);
                $xml->endElement();


                $sSql = 'SELECT * FROM tbl_uniqsql WHERE uniqsql_id = '.$aProperties['uniqsql_id'];
                $aUniqSQL = $this->db->query($sSql, function($oResult){

                    return $oResult->fetch_array(MYSQLI_ASSOC);
                });

                $xml->startElement('uniq_sql');
                $xml->writeCData(@$aUniqSQL[0]['uniq_sqltext']);
                $xml->endElement();
                
                if($aRow['policy_type'] == POLICY_SQL_CONVERT){

                    $xml->startElement('change_sql');
                    $xml->writeCData($aProperties['convert']);
                    $xml->endElement();
                }

                $xml->endElement();
            }

            $xml->endElement();
        }
        $xml->endElement();
        
        $sXML = $xml->outputMemory(true);
    
        return $sXML;
    }

    public function sendPolicyFile($aAgent){

        if($sXML = $this->makePolicyFile($aAgent)){

            //debug(1, get_class($this), 'makePolicyFile');

            debug(1, get_class($this), 'sendXMLToHost '.$aAgent['ipaddr'].', '.$aAgent['port']);

            $aResult = sendXMLToHost($aAgent['ipaddr'], $aAgent['port'], $sXML);

            debug(1, get_class($this), 'send complete '.print_r($aResult, true));

            if($aResult){

                // trans_result value
                // LICENCE_PASS. 정상 수신 및 라이센스 정상
                // COMPANY_FAIL : 회사 코드 오류
                // PRODUCT_FAIL : 제품 코드 오류
                // SYSTEM_FAIL. MAC Address 불일치

                if(@$aResult['trans_result'] == "LICENSE_PASS"){

                    //정상                    
                    $this->saveLicenseCheck(
                        $aAgent['agent_id'], 
                        LICENSE_STATUS_NORMAL, 
                        $aResult['expiration_date']
                    );
                    //$this->pushAlarm();
                }
                else {

                    //오류
                    $this->saveLicenseCheck(
                        $aAgent['agent_id'], 
                        LICENSE_STATUS_ERROR,
                        $aResult['expiration_date']
                    );
                    // $this->pushAlarm();
                }
            }
            
            debug(1, get_class($this), print_r($aResult, true), "PolicySender");
        }
    }

    //라이선스 체크여부(1:데모라이센스, 2:정식라이센스)
    public function saveLicenseCheck($nAgentId, $nStatus, $sExpireDate){

        if(!$sExpireDate) $sExpireDate = date("Y-m-d");

        $sSql = '
            UPDATE tbl_agent_info SET 
                license_status = "'.$nStatus.'",
                license_expiredate = "'.$sExpireDate.'",
                last_work_time = '.time().'
            WHERE agent_id = '.$nAgentId.'
        ';
        $this->db->query($sSql);

        return array(
            'result' => 'success',
            'message' => ''
        );
    }

    public function pushAlarm(){

        // multiple recipients
        $to  = 'jjwcom@nate.com'; // note the comma

        // subject
        $subject = '라이센스 체크 결과';

        // message
        $message = '
            <html>
            <head>
                <title>라이센스 체크 결과</title>
            </head>
            <body>
                <p>라이센스 체크가 정상적으로 이루어짐!</p>
                <table>
                <tr>
                    <th>서버명</th><th>IP</th><th>Port</th><th>등록일</th>
                </tr>
                <tr>
                    <td>IP</td><td>3rd</td><td>August</td><td>1970</td>
                </tr>
                </table>
            </body>
            </html>
        ';

        // // To send HTML mail, the Content-type header must be set
        // $headers  = 'MIME-Version: 1.0' . "\r\n";
        // $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

        // //$headers .= 'To: Mary <mary@example.com>, Kelly <kelly@example.com>' . "\r\n";
        // $headers .= 'From: 시스템 <jjwcom@iruen.com>' . "\r\n";
        // //$headers .= 'Cc: birthdayarchive@example.com' . "\r\n";
        // //$headers .= 'Bcc: birthdaycheck@example.com' . "\r\n";

        // Mail it
        mail($to, $subject, $message);
    }

    public function run() {

        while(true){

            msg_receive ($this->msg_id, 1, $msg_type, 16384, $msg, true, MSG_IPC_NOWAIT, $msg_error);

            if ($msg) {

                $aQueue = unserialize($msg);

                debug(1, get_class($this), 'receive '. print_r($aQueue, true));

                call_user_func_array(array($this, $aQueue['cmd']), $aQueue['params']);
            }

            sleep(1);
        }
    }
}