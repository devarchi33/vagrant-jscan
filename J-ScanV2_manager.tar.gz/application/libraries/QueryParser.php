<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* QueryParser
*
* 쿼리를 파싱한다.
*
* @uses     native php
* @category daemon
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2013, Iruentech Corporation All rights reserved.
* @link
*/
class QueryParser {

     public function __construct(){
        
        $this->sql_types              = array('DROP', 'CREATE', 'UPDATE', 'DELETE', 'INSERT', 'SELECT');
        
        $this->openComments           = array("#", "-- ", "/*");
        $this->closeComments          = array("\n", "\n", "*/");
        
        $this->boundaries             = array('`', '~', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '+', '-', '=', '\\', '[', ']', '{', '}', ';', ':', '<', '>', ',', '.', '/', '?');
        $this->comparison             = array('=', '<=', '>=', '!=', '<', '>');
        
        $this->joins                  = array('STRAIGHT JOIN', 'NATURAL JOIN', 'INNER JOIN', 'LFET INNER JOIN', 'RIGHT INNER JOIN', 'LEFT OUTER JOIN', 'LEFT JOIN', 'RIGHT OUTER JOIN', 'RIGHT JOIN', 'CROSS JOIN', 'JOIN');
        $this->functions              = array('ABS', 'ACOS', 'ASIN', 'ATAN', 'ATAN2', 'BITAND', 'CEIL', 'COS', 'COSH', 'EXP', 'FLOOR', 'LN', 'LOG', 'MOD', 'NANVL', 'POWER', 'REMAINDER', 'ROUND', 'SIGN', 'SIN', 'SINH', 'SQRT', 'TAN', 'TANH', 'TRUNC', 'WIDTH_BUCKET', 'CHR', 'CONCAT', 'INITCAP', 'LOWER', 'LPAD', 'LTRIM', 'NLS_INITCAP', 'NLS_LOWER', 'NLSSORT', 'NLS_UPPER', 'REGEXP_REPLACE', 'REGEXP_SUBSTR', 'REPLACE', 'RPAD', 'RTRIM', 'SOUNDEX', 'SUBSTR', 'TRANSLATE', 'TREAT', 'TRIM', 'UPPER', 'NLS_CHARSET_DECL_LEN', 'NLS_CHARSET_ID', 'NLS_CHARSET_NAME', 'ASCII', 'INSTR', 'LENGTH', 'REGEXP_INSTR', 'ADD_MONTHS', 'CURRENT_DATE', 'CURRENT_TIMESTAMP', 'DBTIMEZONE', 'EXTRACT', 'FROM_TZ', 'LAST_DAY', 'LOCALTIMESTAMP', 'MONTHS_BETWEEN', 'NEW_TIME', 'NEXT_DAY', 'NUMTODSINTERVAL', 'NUMTOYMINTERVAL', 'ROUND', 'SESSIONTIMEZONE', 'SYS_EXTRACT_UTC', 'SYSDATE', 'SYSTIMESTAMP', 'TO_CHAR', 'TO_TIMESTAMP', 'TO_TIMESTAMP_TZ', 'TO_DSINTERVAL', 'TO_YMINTERVAL', 'TRUNC', 'TZ_OFFSET', 'GREATEST', 'LEAST', 'ASCIISTR', 'BIN_TO_NUM', 'CAST', 'CHARTOROWID', 'COMPOSE', 'CONVERT', 'DECOMPOSE', 'HEXTORAW', 'NUMTODSINTERVAL', 'NUMTOYMINTERVAL', 'RAWTOHEX', 'RAWTONHEX', 'ROWIDTOCHAR', 'ROWIDTONCHAR', 'SCN_TO_TIMESTAMP', 'TIMESTAMP_TO_SCN', 'TO_BINARY_DOUBLE', 'TO_BINARY_FLOAT', 'TO_CHAR', 'TO_CHAR', 'TO_CHAR', 'TO_CLOB', 'TO_DATE', 'TO_DSINTERVAL', 'TO_LOB', 'TO_MULTI_BYTE', 'TO_NCHAR', 'TO_NCHAR', 'TO_NCHAR', 'TO_NCLOB', 'TO_NUMBER', 'TO_DSINTERVAL', 'TO_SINGLE_BYTE', 'TO_TIMESTAMP', 'TO_TIMESTAMP_TZ', 'TO_YMINTERVAL', 'TO_YMINTERVAL', 'TRANSLATE ... USING', 'UNISTR', 'BFILENAME', 'EMPTY_BLOB, EMPTY_CLOB', 'CARDINALITY', 'COLLECT', 'POWERMULTISET', 'POWERMULTISET_BY_CARDINALITY', 'SET', 'SYS_CONNECT_BY_PATH', 'CLUSTER_ID', 'CLUSTER_PROBABILITY', 'CLUSTER_SET', 'FEATURE_ID', 'FEATURE_SET', 'FEATURE_VALUE', 'PREDICTION', 'PREDICTION_COST', 'PREDICTION_DETAILS', 'PREDICTION_PROBABILITY', 'PREDICTION_SET', 'APPENDCHILDXML', 'DELETEXML', 'DEPTH', 'EXTRACT', 'EXISTSNODE', 'EXTRACTVALUE', 'INSERTCHILDXML', 'INSERTXMLBEFORE', 'PATH', 'SYS_DBURIGEN', 'SYS_XMLAGG', 'SYS_XMLGEN', 'UPDATEXML', 'XMLAGG', 'XMLCDATA', 'XMLCOLATTVAL', 'XMLCOMMENT', 'XMLCONCAT', 'XMLFOREST', 'XMLPARSE', 'XMLPI', 'XMLQUERY', 'XMLROOT', 'XMLSEQUENCE', 'XMLSERIALIZE', 'XMLTABLE', 'XMLTRANSFORM', 'DECODE', 'DUMP', 'ORA_HASH', 'VSIZE', 'COALESCE', 'LNNVL', 'NULLIF', 'NVL', 'NVL2', 'SYS_CONTEXT', 'SYS_GUID', 'SYS_TYPEID', 'UID', 'USER', 'USERENV');
        $this->plsql_reserved_words   = array('ABORT', 'BETWEEN', 'CRASH', 'DIGITS', 'ACCEPT', 'BINARY_INTEGER', 'CREATE', 'DISPOSE', 'ACCESS', 'BODY', 'CURRENT', 'DISTINCT', 'ADD', 'BOOLEAN', 'CURRVAL', 'DO', 'ALL', 'BY', 'CURSOR', 'DROP', 'ALTER', 'CASE', 'DATABASE', 'ELSE', 'AND', 'CHAR', 'DATA_BASE', 'ELSIF', 'ANY', 'CHAR_BASE', 'DATE', 'END', 'ARRAY', 'CHECK', 'DBA', 'ENTRY', 'ARRAYLEN', 'CLOSE', 'DEBUGOFF', 'EXCEPTION', 'AS', 'CLUSTER', 'DEBUGON', 'EXCEPTION_INIT', 'ASC', 'CLUSTERS', 'DECLARE', 'EXISTS', 'ASSERT', 'COLAUTH', 'DECIMAL', 'EXIT', 'ASSIGN', 'COLUMNS', 'DEFAULT', 'FALSE', 'AT', 'COMMIT', 'DEFINITION', 'FETCH', 'AUTHORIZATION', 'COMPRESS', 'DELAY', 'FLOAT', 'AVG', 'CONNECT', 'DELETE', 'FOR', 'BASE_TABLE', 'CONSTANT', 'DELTA', 'FORM', 'BEGIN', 'COUNT', 'DESC', 'FROM', 'FUNCTION', 'NEW', 'RELEASE', 'SUM', 'GENERIC', 'NEXTVAL', 'REMR', 'TABAUTH', 'GOTO', 'NOCOMPRESS', 'RENAME', 'TABLE', 'GRANT', 'NOT', 'RESOURCE', 'TABLES', 'GROUP', 'NULL', 'RETURN', 'TASK', 'HAVING', 'NUMBER', 'REVERSE', 'TERMINATE', 'IDENTIFIED', 'NUMBER_BASE', 'REVOKE', 'THEN', 'IF', 'OF', 'ROLLBACK', 'TO', 'IN', 'ON', 'ROWID', 'TRUE', 'INDEX', 'OPEN', 'ROWLABEL', 'TYPE', 'INDEXES', 'OPTION', 'ROWNUM', 'UNION', 'INDICATOR', 'OR', 'ROWTYPE', 'UNIQUE', 'INSERT', 'ORDER', 'RUN', 'UPDATE', 'INTEGER', 'OTHERS', 'SAVEPOINT', 'USE', 'INTERSECT', 'OUT', 'SCHEMA', 'VALUES', 'INTO', 'PACKAGE', 'SELECT', 'VARCHAR', 'IS', 'PARTITION', 'SEPARATE', 'VARCHAR2', 'LEVEL', 'PCTFREE', 'SET', 'VARIANCE', 'LIKE', 'POSITIVE', 'SIZE', 'VIEW', 'LIMITED', 'PRAGMA', 'SMALLINT', 'VIEWS', 'LOOP', 'PRIOR', 'SPACE', 'WHEN', 'MAX', 'PRIVATE', 'SQL', 'WHERE', 'MIN', 'PROCEDURE', 'SQLCODE', 'WHILE', 'MINUS', 'PUBLIC', 'SQLERRM', 'WITH', 'MLSLABEL', 'RAISE', 'START', 'WORK', 'MOD', 'RANGE', 'STATEMENT', 'XOR', 'MODE', 'REAL', 'STDDEV', 'NATURAL', 'RECORD', 'SUBTYPE');
        $this->oracle_reserved_words  = array('ACCESS', 'ELSE', 'MODIFY', 'START', 'ADD', 'EXCLUSIVE', 'NOAUDIT', 'SELECT', 'ALL', 'EXISTS', 'NOCOMPRESS', 'SESSION', 'ALTER', 'FILE', 'NOT', 'SET', 'AND', 'FLOAT', 'NOTFOUND', 'SHARE', 'ANY', 'FOR', 'NOWAIT', 'SIZE', 'ARRAYLEN', 'FROM', 'NULL', 'SMALLINT', 'AS', 'GRANT', 'NUMBER', 'SQLBUF', 'ASC', 'GROUP', 'OF', 'SUCCESSFUL', 'AUDIT', 'HAVING', 'OFFLINE', 'SYNONYM', 'BETWEEN', 'IDENTIFIED', 'ON', 'SYSDATE', 'BY', 'IMMEDIATE', 'ONLINE', 'TABLE', 'CHAR', 'IN', 'OPTION', 'THEN', 'CHECK', 'INCREMENT', 'OR', 'TO', 'CLUSTER', 'INDEX', 'ORDER', 'TRIGGER', 'COLUMN', 'INITIAL', 'PCTFREE', 'UID', 'COMMENT', 'INSERT', 'PRIOR', 'UNION', 'COMPRESS', 'INTEGER', 'PRIVILEGES', 'UNIQUE', 'CONNECT', 'INTERSECT', 'PUBLIC', 'UPDATE', 'CREATE', 'INTO', 'RAW', 'USER', 'CURRENT', 'IS', 'RENAME', 'VALIDATE', 'DATE', 'LEVEL', 'RESOURCE', 'VALUES', 'DECIMAL', 'LIKE', 'REVOKE', 'VARCHAR', 'DEFAULT', 'LOCK', 'ROW', 'VARCHAR2', 'DELETE', 'LONG', 'ROWID', 'VIEW', 'DESC', 'MAXEXTENTS', 'ROWLABEL', 'WHENEVER', 'DISTINCT', 'MINUS', 'ROWNUM', 'WHERE', 'DROP', 'MODE', 'ROWS', 'WITH');
        $this->reserved_words         = array_merge($this->plsql_reserved_words, $this->oracle_reserved_words);
        $this->keywords               = array('ADMIN', 'CURSOR', 'FOUND', 'MOUNT', 'AFTER', 'CYCLE', 'FUNCTION', 'NEXT', 'ALLOCATE', 'DATABASE', 'GO', 'NEW', 'ANALYZE', 'DATAFILE', 'GOTO', 'NOARCHIVELOG', 'ARCHIVE', 'DBA', 'GROUPS', 'NOCACHE', 'ARCHIVELOG', 'DEC', 'INCLUDING', 'NOCYCLE', 'AUTHORIZATION', 'DECLARE', 'INDICATOR', 'NOMAXVALUE', 'AVG', 'DISABLE', 'INITRANS', 'NOMINVALUE', 'BACKUP', 'DISMOUNT', 'INSTANCE', 'NONE', 'BEGIN', 'DOUBLE', 'INT', 'NOORDER', 'BECOME', 'DUMP', 'KEY', 'NORESETLOGS', 'BEFORE', 'EACH', 'LANGUAGE', 'NORMAL', 'BLOCK', 'ENABLE', 'LAYER', 'NOSORT', 'BODY', 'END', 'LINK', 'NUMERIC', 'CACHE', 'ESCAPE', 'LISTS', 'OFF', 'CANCEL', 'EVENTS', 'LOGFILE', 'OLD', 'CASCADE', 'EXCEPT', 'MANAGE', 'ONLY', 'CHANGE', 'EXCEPTIONS', 'MANUAL', 'OPEN', 'CHARACTER', 'EXEC', 'MAX', 'OPTIMAL', 'CHECKPOINT', 'EXPLAIN', 'MAXDATAFILES', 'OWN', 'CLOSE', 'EXECUTE', 'MAXINSTANCES', 'PACKAGE', 'COBOL', 'EXTENT', 'MAXLOGFILES', 'PARALLEL', 'COMMIT', 'EXTERNALLY', 'MAXLOGHISTORY', 'PCTINCREASE', 'COMPILE', 'FETCH', 'MAXLOGMEMBERS', 'PCTUSED', 'CONSTRAINT', 'FLUSH', 'MAXTRANS', 'PLAN', 'CONSTRAINTS', 'FREELIST', 'MAXVALUE', 'PLI', 'CONTENTS', 'FREELISTS', 'MIN', 'PRECISION', 'CONTINUE', 'FORCE', 'MINEXTENTS', 'PRIMARY', 'CONTROLFILE', 'FOREIGN', 'MINVALUE', 'PRIVATE', 'COUNT', 'FORTRAN', 'MODULE', 'PROCEDURE', 'PROFILE', 'SAVEPOINT', 'SQLSTATE', 'TRACING', 'QUOTA', 'SCHEMA', 'STATEMENT_ID', 'TRANSACTION', 'READ', 'SCN', 'STATISTICS', 'TRIGGERS', 'REAL', 'SECTION', 'STOP', 'TRUNCATE', 'RECOVER', 'SEGMENT', 'STORAGE', 'UNDER', 'REFERENCES', 'SEQUENCE', 'SUM', 'UNLIMITED', 'REFERENCING', 'SHARED', 'SWITCH', 'UNTIL', 'RESETLOGS', 'SNAPSHOT', 'SYSTEM', 'USE', 'RESTRICTED', 'SOME', 'TABLES', 'USING', 'REUSE', 'SORT', 'TABLESPACE', 'WHEN', 'ROLE', 'SQL', 'TEMPORARY', 'WRITE', 'ROLES', 'SQLCODE', 'THREAD', 'WORK', 'ROLLBACK', 'SQLERROR', 'TIME');
        
        $boundaries                   = implode("|", array_map(array($this, 'preg_quote'), $this->boundaries));
        
        $this->regexpWhiteSpace       = "/^\s+/";
        $this->regexpTrim             = "/(^\s*)|(\s*$)/";
        $this->regexpBoundaries       = "/^(".$boundaries.")/";
        $this->regexpSplit            = "/(".$boundaries."|$|\s)/";
        $this->regexpJoins            = "/^(".implode("|", $this->joins).")/i";
        $this->regexpLimit            = "/^LIMIT\s+[0-9]+((\s+?,|,)?(\s+)?[0-9]+)/";
        $this->regexpDelimiter        = "/^;/";
        $this->regexpComparison       = "/^(".implode("|", $this->comparison).")/";
        $this->regexpFunctions        = "/^(".implode("|", $this->functions).")[(]/i";
        $this->regexpKeywords         = "/^(".implode("|", $this->keywords).")($|\s|".$boundaries.")/i";
        $this->regexpReservedWords    = "/^(".implode("|", $this->reserved_words).")($|\s|".$boundaries.")/i";
        $this->regexpQuotedString     = "/^(\'(?:[^\'\\\\]|\\\\.)*\'|\"(?:[^\"\\\\]|\\\\.)*\")/";
        $this->regexpTable            = "/^([`]?([a-zA-Z0-9_$#]+)[`]?[.@])?[`]?([a-zA-Z0-9_$#]+)[`]?/";
        $this->regexpNumber           = "/^[0-9]+\b/";
        
        $this->TYPE_STRING        = 0;
        $this->TYPE_COMMENT       = 1;
        $this->TYPE_SPACE         = 2;
        $this->TYPE_TOP_LEVEL     = 3;
        $this->TYPE_JOIN          = 4;
        $this->TYPE_CONDITION     = 5;
        $this->TYPE_FUNCTION      = 6;
        $this->TYPE_BOUNDARY      = 7;
        $this->TYPE_QUOTE         = 8;
        $this->TYPE_DELIMITER     = 9;
        $this->TYPE_QUERY_END     = 10;
        $this->TYPE_LIMIT         = 11;
        $this->TYPE_COMPARISON    = 12;
        $this->TYPE_RESERVED_WORD = 13;
        $this->TYPE_KEYWORD       = 14;
        $this->TYPE_TABLE         = 15;
        $this->TYPE_NUMBER        = 16;
        $this->TYPE_QUOTED_STRING = 17;
    }

    public function parse($string, $delimiter){

        if($delimiter){

            $this->regexpDelimiter = "/^".$this->preg_quote($delimiter)."/";
        }

        $tokens = $this->tokenize($string);
    }

    public function tokenize($string){

        //2014.10.28 인용문자열이라도 무조건 일단은 전부 대문자로 치환하고 작업을 하기로 한다..
        $string = strtoupper($string);
        
        $len = strlen($string);
        $tokens = array();
        $this->start_detect_table = false;

        while($len){

            $token = $this->getNextToken($string);

            $string = substr($string, strlen($token['value']));
            
            if($len == strlen($string)){

                break;
            }
            else {

                $len = strlen($string);
            }

            array_push($tokens, $token);
        }

        return $tokens;
    }

    public function getNextToken($string){

        $tokens = array();

        if(preg_match($this->regexpWhiteSpace, $string, $matches)){

            return array(
                'type' => $this->TYPE_SPACE,
                'value' => $matches[0]
            );
        }

        $cmts = $this->openComments;
        $inCmt = -1;
        foreach($cmts as $idx => $ocmt){

            if(substr($string, 0, strlen($ocmt)) == $ocmt){

                $inCmt = $idx;
                break;
            }
        }

        if($inCmt > -1){

            $ccmt = $this->closeComments[$inCmt];

            $pos = strpos($string, $ccmt);

            if($pos === false){

                $value = substr($string, 0);
            }
            else {

                $value = substr($string, 0, $pos + strlen($ccmt));
            }

            return array(
                'type' => $this->TYPE_COMMENT,
                'value' => $value
            );
        }

        if(preg_match($this->regexpDelimiter, $string, $matches)){

            return array(
                'type' => $this->TYPE_QUERY_END,
                'value' => $matches[0]
            );
        }

        if(preg_match($this->regexpComparison, $string, $matches)){

            return array(
                'type' => $this->TYPE_COMPARISON,
                'value' => $matches[0]
            );
        }

        if(preg_match($this->regexpJoins, $string, $matches)){

            $this->start_detect_table = true;

            return array(
                'type' => $this->TYPE_JOIN,
                'value' => $matches[0]
            );
        }

        if(preg_match($this->regexpFunctions, $string, $matches)){

            return array(
                'type' => $this->TYPE_FUNCTION,
                'value' => $matches[0]
            );
        }

        if(preg_match($this->regexpKeywords, $string, $matches)){

            return array(
                'type' => $this->TYPE_KEYWORD,
                'value' => $matches[1]
            );
        }

        if(preg_match($this->regexpReservedWords, $string, $matches)){

            $upper = strtoupper($matches[1]);

            if(in_array($upper, array('FROM', 'UPDATE', 'INSERT', 'TABLE'))){

                $this->start_detect_table = true;
            }

            return array(
                'type' => $this->TYPE_RESERVED_WORD,
                'value' => $matches[1]
            );
        }

        if($this->start_detect_table == true){

            if(preg_match($this->regexpTable, $string, $matches)){

                $this->start_detect_table = false;

                return array(
                    'type' => $this->TYPE_TABLE,
                    'value' => $matches[0]
                );
            }
        }

        if(preg_match($this->regexpQuotedString, $string, $matches)){

            return array(
                'type' => $this->TYPE_QUOTED_STRING,
                'value' => $matches[0]
            );
        }

        if(preg_match($this->regexpBoundaries, $string, $matches)){

            return array(
                'type' => $this->TYPE_BOUNDARY,
                'value' => $matches[0]
            );
        }

        if(preg_match($this->regexpLimit, $string, $matches)){

            return array(
                'type' => $this->TYPE_LIMIT,
                'value' => $matches[0]
            );
        }

        if(preg_match("/^DELIMITER\s([^\s]+)/i", $string, $matches)){

            $this->regexpDelimiter = "/^"+$this->preg_quote($matches[1])."/";
            return array(
                'type' => $this->TYPE_DELIMITER,
                'value' => $matches[0]
            );
        }

        if(preg_match($this->regexpSplit, $string, $matches, PREG_OFFSET_CAPTURE)) {

            $value = substr($string, 0, $matches[0][1]);

            if(preg_match($this->regexpNumber, $value, $matches)){

                return array(
                    'type' => $this->TYPE_NUMBER,
                    'value' => $value
                );
            }
            else {

                return array(
                    'type' => $this->TYPE_STRING,
                    'value' => $value
                );
            }
        }
        else {

            $value = $string;
        }

        return array(
            'type' => $this->TYPE_STRING,
            'value' => $value
        );
    }

    public function preg_quote($str) {

        return preg_quote($str,'/');
    }

    public function getUniqSQL($tokens){

        if(is_string($tokens) == true){

            $tokens = trim($tokens);
            $tokens = $this->tokenize($tokens);
        }

        $sSQL = '';
        $start_detect_params = false;
        $prev_token_type = null;
        foreach($tokens as $idx => $token){

            $type = $token['type'];
            $value = $token['value'];

            if($idx > 0 && $tokens[$idx-1]['type'] != $this->TYPE_SPACE){

                $prev_token_type = $tokens[$idx-1]['type'];
            }

            if($type == $this->TYPE_COMMENT){

                continue;
            }

            if($type == $this->TYPE_STRING){

                $sSQL .= strtoupper($value);
                continue;
            }   


            if($type == $this->TYPE_JOIN){

                $sSQL .= strtoupper($value);
                continue;
            }

            if($type == $this->TYPE_RESERVED_WORD){

                $value = strtoupper($value);
                
                if($value == 'VALUES'){

                    $start_detect_params = true;
                }

                $sSQL .= strtoupper($value);
                continue;
            }

            if($type == $this->TYPE_KEYWORD){

                $sSQL .= strtoupper($value);
                continue;
            }

            if($type == $this->TYPE_FUNCTION){

                $sSQL .= strtoupper($value);
                continue;
            }        
            
            if($type == $this->TYPE_SPACE){

                $sSQL .= ' ';
                continue;
            }   

            if($type == $this->TYPE_TABLE){

                $sSQL .= strtoupper($value);
                continue;
            }   

            if($type == $this->TYPE_COMPARISON){

                $sSQL .= $value;
                continue;
            }

            if($type == $this->TYPE_QUOTED_STRING){
                
                $sSQL .= $prev_token_type == $this->TYPE_COMPARISON || $start_detect_params ? "?" : $value;

                continue;
            }

            if($type == $this->TYPE_NUMBER){

                $sSQL .= $prev_token_type == $this->TYPE_COMPARISON || $start_detect_params ? "?" : $value;

                continue;
            }

            $sSQL .= $value;
        }

        $sSQL = preg_replace('/\s?+,\s?+/', ', ', $sSQL);
        $sSQL = preg_replace('/\(\s+/', '(', $sSQL);
        $sSQL = preg_replace('/\s+\)/', ')', $sSQL);

        return $sSQL;
    }

    public function getRefTables($tokens){

        $tables = array();
        foreach($tokens as $idx => $token){

            if($token['type'] == $this->TYPE_TABLE){

                if(preg_match($this->regexpTable, $token['value'], $matches)){

                    array_push($tables, array(
                        'db' => $matches[2],
                        'table' => $matches[3]
                    ));
                }
            }
        }

        return $tables;
    }

    public function getSQLType($tokens){
        
        $type = null;

        foreach($tokens as $idx => $token){

            if($type !== null){

                break;
            }

            if($token['type'] == $this->TYPE_RESERVED_WORD){

                $upper = strtoupper($token['value']);
                if(in_array($upper, $this->sql_types)){

                    $type = $upper;
                    break;
                }
            }
        }

        if($type == null) {

            $type = 'ETC';
        }
        
        return $type;
    }
}