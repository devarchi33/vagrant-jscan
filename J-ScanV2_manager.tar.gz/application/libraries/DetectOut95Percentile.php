<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH."libraries/Database.php";
require_once APPPATH."helpers/statistics_helper.php";

/**
* DetectOut95Percentile
*
* 신뢰도 95%를 벗어나는 데이터를 탐지하는 클래스
*
* @category server
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class DetectOut95Percentile {

    public $agents;
    public $db;
    public $redis;

    private $detectList = array(
        'detectLookupIPCumulativeTotal',
        'detectLookupLoginIDCumulativeTotal',
        'detectLookupIPCount',
        'detectLookupLoginIDCount'
    );

    public function __construct($hostname, $username, $password, $database){

        //데이터 베이스 연결
        $this->db = new Database($hostname, $username, $password, $database);


        //redis 연결
        $this->redis = new Redis();
        $this->redis->connect('211.170.163.68', 6479);
    }

    /**
     * loadAgent
     * 
     * 삭제 되지 않은 에이전트 정보를 $this->agents 배열에 담는다.
     * 
     * @access public
     *
     * @return void
     */
    public function loadAgent(){

        $this->agents['agent'] = array();
        $this->agents['group'] = array();

        //공유메모리 연결
        $sSql = "SELECT * FROM tbl_agent_info WHERE del_yn = '0'";
        $this->db->query($sSql, function($oResult){

            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                $this->agents['agent'][] = $aRow['agent_id'];
                $this->agents['group'][$aRow['group_id']][] = $aRow['agent_id'];
            }
        });
    }

    /**
     * run
     * 
     * 탐지 실행
     *     
     * @access public
     *
     * @return void
     */
	public function run()
	{
        // 탐지를 수행할 시각
        $detectHour = '01';
        $debug = true;

        while(true) {

            //일별 탐지 수행 날짜와 시각(매일)
            $detectTimeOfDay = date('Ymd'.$detectHour);

            //주별 탐지 수행 날짜와 시각(매주 한번)
            $detectTimeOfWeek  = date('Ymd'.$detectHour, strtotime('-'.(date('w')-1).' days'));

            //월별 탐지 수행 날짜와 시각(매월 한번)
            $detectTimeOfMonth = date('Ym01'.$detectHour);

            $now = date("YmdH");

            //디버그 모드가 true이거나 날짜가 하루 바뀌었으면
            //전날의 95% 신뢰구간을 멤케쉬에 등록해둔다.
            if($debug == true || $prevDate < date("Ymd")){

                $this->savePercentile();
            }

            //디버그 모드가 true이거나 현재 시각이 일별 탐지 수행 날짜와 같다면 탐지 로직을 수행한다.
            if($debug == true || $now == $detectTimeOfDay) {
                
                $this->loadAgent();
                $this->detectServer(true);
            }

            //디버그 모드가 true이거나 현재 시각이 주별 탐지 수행 날짜와 같다면 탐지 로직을 수행한다.
            if($debug == true || $now == $detectTimeOfWeek) {
                
                $this->loadAgent();
                $this->detectServer(true);
            }

            //디버그 모드가 true이거나 현재 시각이 월별 탐지 수행 날짜와 같다면 탐지 로직을 수행한다.
            if($debug == true || $now == $detectTimeOfMonth) {
                
                $this->loadAgent();
                $this->detectServer(true);
            }

            $prevDate = date("Ymd");

            //디버그 모드는 한번만 실행하게 하면 되므로 로직을 한번 실행하고 나면 false로 셋팅한다.
            $debug = false;

            sleep(1);
        }
	}

    public function detectServer(){

        $aType = array('day', 'week', 'month');

        foreach($this->agents['agent'] as $nIdx => $nAgentId){

            array_walk($this->detectList, function($item, $key, $aType) use ($nAgentId){

                foreach($aType as $nIdx => $sType){

                    $this->$item($sType, 'server-'.$nAgentId);
                }

            }, $aType);
        }
    }

    /**
     * @param $type
     * @param $server
     */
    public function detectLookupIPCumulativeTotal($type, $server){

        $sSql = "
            SELECT * FROM tbl_summary 
            WHERE name ='lookup_ip_cumulative_total' AND type='".$type."' AND view_group = '".$server."' 
            ORDER BY edate DESC LIMIT 1
        ";

        $aSpecimen = array(); //표본
        $this->db->query($sSql, function($oResult) use (&$aSpecimen){
            
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                $data = json_decode($aRow['data'], true);

                foreach($data as $idx => $datas){

                    array_push($aSpecimen, $datas['value']);
                }
            }
        });

        if(count($aSpecimen) == 0){

            return;
        }
            
        //이상치(Outliers)를 제거하고 95% 신뢰구간을 구한다.
        $aPercentile = getPercentile(removeOutliers($aSpecimen));

        list($fMin, $fMax) = $aPercentile;

        debug(1, get_class($this), print_r(array_merge($aSpecimen, array('min'=>$fMin, 'max'=>$fMax)), true), "detect");

        $bAlert = false;
        foreach($aSpecimen as $nIdx => $nVal){

            if($fMin > $nVal){

                $bAlert = true;
                break;
            }

            if($fMax < $nVal){

                $bAlert = true;
                break;
            }
        }

        if($bAlert){

            $this->insertDetectEvent($sServer, 'IP별 누적총량이 신뢰구간 95%를 벗어나는 IP가 탐지되었습니다.');
        }
    }

    public function detectLookupLoginIDCumulativeTotal($type, $server){

        $sSql = "
            SELECT * FROM tbl_summary 
            WHERE name ='lookup_login_id_cumulative_total' AND type='".$type."' AND view_group = '".$server."' 
            ORDER BY edate DESC LIMIT 1
        ";

        $aSpecimen = array();
        $this->db->query($sSql, function($oResult) use (&$aSpecimen){
            
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                $data = json_decode($aRow['data'], true);

                foreach($data as $idx => $datas){

                    array_push($aSpecimen, $datas['value']);
                }
            }
        });

        if(count($aSpecimen) == 0){

            return;
        }

        $aPercentile = getPercentile(removeOutliers($aSpecimen));

        list($fMin, $fMax) = $aPercentile;

        debug(1, get_class($this), print_r(array_merge($aSpecimen, array('min'=>$fMin, 'max'=>$fMax)), true), "detect");

        $bAlert = false;
        foreach($aSpecimen as $nIdx => $nVal){

            if($fMin > $nVal){

                $bAlert = true;
                break;
            }

            if($fMax < $nVal){

                $bAlert = true;
                break;
            }
        }

        if($bAlert){

            $this->insertDetectEvent($sServer, '로그인 아이디별 누적총량이 신뢰구간 95%를 벗어나는 아이디가 탐지되었습니다.');
        }
    }

    public function detectLookupIPCount($type, $server){

        $sSql = "
            SELECT * FROM tbl_summary 
            WHERE name ='lookup_ip_count' AND type='".$type."' AND view_group = '".$server."' 
            ORDER BY edate DESC LIMIT 1
        ";

        $aSpecimen = array();
        $this->db->query($sSql, function($oResult) use (&$aSpecimen){
            
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                $data = json_decode($aRow['data'], true);

                foreach($data as $idx => $datas){

                    array_push($aSpecimen, $datas['value']);
                }
            }
        });

        if(count($aSpecimen) == 0){

            return;
        }

        $aPercentile = getPercentile(removeOutliers($aSpecimen));

        list($fMin, $fMax) = $aPercentile;

        debug(1, get_class($this), print_r(array_merge($aSpecimen, array('min'=>$fMin, 'max'=>$fMax)), true), "detect");

        $bAlert = false;
        foreach($aSpecimen as $nIdx => $nVal){

            if($fMin > $nVal){

                $bAlert = true;
                break;
            }

            if($fMax < $nVal){

                $bAlert = true;
                break;
            }
        }

        if($bAlert){

            $this->insertDetectEvent($sServer, 'IP별 조회량이 신뢰구간 95%를 벗어나는 IP가 탐지되었습니다.');
        }
    }

    public function detectLookupLoginIDCount($type, $server){

        $sSql = "
            SELECT * FROM tbl_summary 
            WHERE name ='lookup_login_id_count' AND type='".$type."' AND view_group = '".$server."' 
            ORDER BY edate DESC LIMIT 1
        ";
        
        $aSpecimen = array();
        $this->db->query($sSql, function($oResult) use (&$aSpecimen){
            
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                $data = json_decode($aRow['data'], true);

                foreach($data as $idx => $datas){

                    array_push($aSpecimen, $datas['value']);
                }
            }
        });

        if(count($aSpecimen) == 0){

            return;
        }

        $aPercentile = getPercentile(removeOutliers($aSpecimen));

        list($fMin, $fMax) = $aPercentile;

        debug(1, get_class($this), print_r(array_merge($aSpecimen, array('min'=>$fMin, 'max'=>$fMax)), true), "detect");

        $bAlert = false;
        foreach($aSpecimen as $nIdx => $nVal){

            if($fMin > $nVal){

                $bAlert = true;
                break;
            }

            if($fMax < $nVal){

                $bAlert = true;
                break;
            }
        }

        if($bAlert){

            $this->insertDetectEvent($sServer, '로그인 아이디별 조회량이 신뢰구간 95%를 벗어나는 아이가 탐지되었습니다.');
        }
    }

    public function insertDetectEvent($sServer, $sMsg){

        debug(1, get_class($this), "Detected!!", "detect");

        $nAgentId = str_replace('server-', '', $sServer);

        //NewSQL 자동 등록 이벤트 등록
        $this->makeAlarm(
            EVENT_TYPE_POLICY, EVENT_TYPE_NOTICE, 7, SYSTEM_DETECT, time(),
            $sMsg, '', null, $nAgentId
        );
    }

    /**
     * savePercentile
     * 
     * 구해진 95%신뢰구간을 맴케쉬에 저장한다.
     * 
     * @access public
     *
     * @return void
     */
    public function savePercentile(){

        $aPeriod = getDatePeriod('month', "-1 day");

        $sFDate = $aPeriod['start_date'];
        $sTDate = $aPeriod['end_date'];

        $sSql = "
            SELECT 
                concat(`sqllog`.agent_id, ':', `sqllog`.class_id, ':', `sqllog`.uniqsql_id, ':', `sqllog`.ipaddr, ':', `sqllog`.login_id) as idx, `sqllog`.result_count
            FROM tbl_eventlog `log`
            LEFT OUTER JOIN tbl_sqllog `sqllog` ON `sqllog`.sqllog_id=`log`.event_tblid
            WHERE `log`.event_time BETWEEN UNIX_TIMESTAMP('".$sFDate." 00:00:00.000000') AND UNIX_TIMESTAMP('".$sTDate." 23:59:59.999999')
            AND policy_type = '".POLICY_PERSONAL_INFO_TABLE."'
        ";
        $aSpecimens = array();
        $this->db->query($sSql, function($oResult) use (&$aSpecimens){

            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                $aSpecimens[$aRow['idx']][] = $aRow['result_count'];
            }
        });

        foreach($aSpecimens as $sIdx => $aSpecimen){

            $aPercentile = getPercentile(removeOutliers($aSpecimen));

            list($fMin, $fMax) = $aPercentile;

            $this->redis->hSet('95Percentile:'.$sIdx, 'min', $fMin);
            $this->redis->hSet('95Percentile:'.$sIdx, 'max', $fMax);
        }
    }

    public function makeAlarm($nType, $nLevel, $nKind, $nPolicyType, $nTime, $sMsg, $sTblName, $nTblId, $nAgentId){

        $sSql = "
            INSERT INTO tbl_eventlog (
                event_type,
                event_time,
                event_level,
                event_kind,
                policy_type,
                event_msg,
                event_confirm_flag,
                event_tblname,
                event_tblid,
                agent_id
            )
            VALUES (
                '".$nType."',
                '".$nTime."',
                '".$nLevel."',
                '".$nKind."',
                '".$nPolicyType."',
                '".$sMsg."',
                '0',
                '".$sTblName."',
                '".$nTblId."',
                '".$nAgentId."'
            )
        ";
        $this->db->query($sSql);
    }

    /**
     * getServerList
     * 
     * loadAgent를 통해 $this->agents에 저장된 에이전트 배열에서 지정된 서머리 그룹에 맞는 에이전트 리스트를 가져온다.
     * 
     * @param string $sServer 서머리 그룹(root, group-아이디, server-아이디)을 의미한다.
     *
     * @access public
     *
     * @return void
     */
    public function getServerList($sServer){

        if($sServer == 'root'){

            $sServers = null;
        }
        else if(strpos($sServer, 'group') > -1){

            $nGroupId = str_replace("group-", "", $sServer);
            if($this->agents['group'][$nGroupId]){

                $aServers = $this->agents['group'][$nGroupId];
                $sServers = implode(",", $aServers);
            }
            else {

                $sServers = false;
            }
        }
        else {

            $sServers = str_replace("server-", "", $sServer);
        }

        return $sServers;
    }
}
/* End of file DetectOut95Percentile.php */
/* Location: ./application/libraries/DetectOut95Percentile.php */