<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH."libraries/Database.php";
/**
* HealthChecker
*
* 에이전트 상태체크 클래스
*
* @category server
* @package  WhiteSQL
* @author   정주원 <jjwcom@nate.com>
* @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
* @link
*/
class HealthChecker {

    private $db;

    public function __construct($hostname, $username, $password, $database){

        $this->redis = new Redis();
        $this->redis->connect('127.0.0.1', 6379);

        //데이터 베이스 연결
        $this->db = new Database($hostname, $username, $password, $database);
    }

	public function run()
	{
        require_once(APPPATH."helpers/cmd_socket_helper.php");

        while(true) {

            $sSql = 'select agent_id, agent_name, ipaddr, port, license_status from tbl_agent_info where del_yn = "0" AND server_type="1"';
            $this->db->query($sSql, function($oResult){

                while($aAgent = $oResult->fetch_array(MYSQLI_ASSOC)){

                    //debug(1, get_class($this), 'Check Agent '.$aAgent['ipaddr'].":".$aAgent['port']);

                    $aResult = sendXMLToHost($aAgent['ipaddr'], $aAgent['port'], "check_dispatcher");

                    if($aResult){

                        if(isset($aResult['check_result']) === true && $aResult['check_result'] == "DISPATCHER_LIVE"){

                            //정상
                            $this->setAgentStatus($aAgent['agent_id'], $aAgent['agent_name'], AGENT_CONNECTED, $aAgent['license_status']);
                        }
                        else {

                            //오류
                            $this->setAgentStatus($aAgent['agent_id'], $aAgent['agent_name'], AGENT_DISCONNECTED, $aAgent['license_status']);
                        }
                    }
                    else {

                        $this->setAgentStatus($aAgent['agent_id'], $aAgent['agent_name'], AGENT_DISCONNECTED, $aAgent['license_status']);
                    }

                    debug(1, get_class($this), 'Agent Check Result : '.print_r($aResult, true), 'HealthChecker');
                }
            });

            sleep(5);
        }
	}

    public function setAgentStatus($nAgentId, $sAgentName, $nStatus, $nLicenseStatus){

        $this->redis->hSet('server:'.$nAgentId, 'status', $nStatus);
        $this->redis->hSet('server:'.$nAgentId, 'license_status', $nLicenseStatus);

        $sSql = 'UPDATE tbl_agent_info SET status = "'.$nStatus.'" WHERE agent_id = '.$nAgentId;
        $this->db->query($sSql);

        if($nStatus == AGENT_DISCONNECTED){

            debug(1, get_class($this), 'Agent '.$nAgentId.'::'.$sAgentName.' Disconnected', 'HealthChecker');
        }
    }
}
/* End of file HealthChecker.php */
/* Location: ./application/libraries/HealthChecker.php */