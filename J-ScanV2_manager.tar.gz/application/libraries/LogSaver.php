<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH."libraries/Database.php";
require_once APPPATH."libraries/AdvancedMemcache.php";
require_once APPPATH."libraries/QueryParser.php";

/**
 * LogSaver
 *
 * 큐에서 꺼낸 로그를 받아서 분석 후 큐에 저장하는 Thread
 *
 * @uses     native php
 * @category daemon
 * @package  WhiteSQL
 * @author   정주원 <jjwcom@nate.com>
 * @license  Copyright (c) 2013, Iruentech Corporation All rights reserved.
 * @link
 */
class LogSaver
{

    private $keyMQSaver = null;
    private $num        = null;
    private $redis      = null;

    public function __construct(
        $num, $ip, $port, $pid
    )
    {

        $this->num           = $num;
        $this->ip            = $ip;
        $this->port          = $port;
        $this->auditQueueKey = 'audit:'.$ip.':'.$port;
        $this->pid           = $pid;
        $this->path          = "/tmp/jscan/audit/";

        $this->redis = new Redis();
        $this->redis->connect('211.170.163.68', 6479);
    }

    public function run()
    {

        $this->currentTime = time();

        $fp = fopen($this->path.$this->currentTime, "a+");

        $nWriteCnt = 0;

        while (true) {

            $sLog = $this->redis->lpop($this->auditQueueKey);

            if (!$sLog) {

                sleep(1);
                continue;
            }

            $aLog = explode("\f", $sLog);

            $license_status = $this->redis->hGet('server:'.$aLog[0], 'license_status');

            if ($license_status == 1) {

                continue;
            }

            debug(1, get_class($this), print_r($aLog, true), 'LogSaver');

            if (count($aLog) < 21) {

                debug(1, get_class($this), "Invalid Log ".print_r($aLog, true), 'LogSaver');

                return false;
            }

            $request_time = $aLog[2];

            try {

                $time         = date("Y-m-d H:i:s", substr($request_time, 0, 10));
                $micro        = str_pad(substr($request_time, 10), 6, 0, STR_PAD_RIGHT);
                $request_time = $time.".".$micro;
            } catch (Exception $e) {


            }

            //$sqllog_id = (string)date('ymdHis').substr(microtime(), 2, 8);
            $sqllog_id = str_replace(".", "", uniqid('', true)).$this->pid;

            $aLog = @array(
                $sqllog_id,
                $aLog[0],   //agent_id
                $aLog[1],   //agent_mode
                $request_time,   //request_time
                $aLog[3],  //prestmt
                $aLog[4],   // sql_str
                $aLog[5],   //sql_param
                $aLog[6],   //dbcon_url
                $aLog[7],   //cbconn_account
                $aLog[8],   //class_trace
                (int)$aLog[9],   //policy_id
                $aLog[10],   //block_yn
                $aLog[11],  //login_id
                $aLog[12],  //ipaddr
                (int)$aLog[13],  //exec_starttime
                $aLog[14],  //exec_elapsedtime
                $aLog[15],  //execute_yn
                $aLog[16],  //fail_code
                $aLog[17],  //result_count
                $aLog[18],  //privacy_type
                $aLog[19],  //privacy_value
                $aLog[20]   //result_data
            );

            $sLog = implode("\f", $aLog);

            $now = time();

            if ($this->currentTime != $now) {

                fclose($fp);
                $fp = fopen($this->path.$now, "a+");

                debug(1, get_class($this), "[Saver Thread ".$this->num."] Write ".$nWriteCnt." / Sec", 'LogSaver');

                $nWriteCnt = 0;
            }

            $this->redis->rpush('saver', $sLog);

            fwrite($fp, $sLog."\r\n");

            $nWriteCnt++;

            $this->currentTime = $now;
        }

        fclose($fp);
    }
}