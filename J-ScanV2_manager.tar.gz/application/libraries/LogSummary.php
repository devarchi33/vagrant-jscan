<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require_once APPPATH."libraries/Database.php";

/**
 *
 * LogSummary
 *
 * 서머리 클래스
 *
 * @category server
 * @package  WhiteSQL
 * @author   정주원 <jjwcom@nate.com>
 * @license  Copyright (c) 2011, Iruentech Corporation All rights reserved.
 * @link
 */

class LogSummary {

    public $agents;
    public $db;

    private $summaries = array(
        'summaryStatusOfQueryExec',
        'summaryAvgNumOfQueryExecResults',
        'summaryNumOfQueryExec',
        'summaryNumOfEvent',
        'summaryNumOfQueryExecByPolicy',
        'summaryMostAccessIp',
        'summaryMuchLookupIp',
        'summaryPersonalInfoAccessIP',
        'summaryLookupIPCumulativeTotal',
        'summaryLookupLoginIDCumulativeTotal',
        'summaryLookupIPCount',
        'summaryLookupLoginIDCount'
    );

    public function __construct($hostname, $username, $password, $database){

        //데이터 베이스 연결
        $this->db = new Database($hostname, $username, $password, $database);
    }

    /**
     * loadAgent
     *
     * 삭제 되지 않은 에이전트 정보를 $this->agents 배열에 담는다.
     *
     * @access public
     *
     * @return void
     */
    public function loadAgent(){

        $this->agents['agent'] = array();
        $this->agents['group'] = array();

        //공유메모리 연결
        $sSql = "SELECT * FROM tbl_agent_info WHERE del_yn = '0'";
        $this->db->query($sSql, function($oResult){

            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                $this->agents['agent'][] = $aRow['agent_id'];
                $this->agents['group'][$aRow['group_id']][] = $aRow['agent_id'];
            }
        });
    }

    /**
     * run
     *
     * 통계 서머리 실행
     *
     * 1) 5초에 한번 서버별, 그룹별, 취상위 루트 순으로 서머리
     * 2) 날이 변경 될때 한번식 써머리 (전일, 1주일(전날부터), 1개월(전날부터))
     *
     * @param integer $nSDate 시작 오프셋
     * @param integer $nEDate 종료 오프셋
     *
     * @access public
     *
     * @return void
     */
    public function run($nSDate = null, $nEDate = null)
    {
        $second = 1;
        $last_date = strtotime('-1 day');
        //$last_date = date("Y-m-d");

        //debug(1, get_class($this), "INIT ".$last_date);

        while(true) {

            if($second % 5 == 0) {

                // $this->loadAgent();

                // $this->summaryConvert();

                //5초에 한번씩 서머리한다.
                // $this->summaryServer(true);
                // $this->summaryGroup(true);
                // $this->summaryRoot(true);

                // $this->removeRecentData();
            }

            //날이 변경될때 한번씩 서머리한다.
            if($last_date != date("Y-m-d")){

                //debug(1, get_class($this), "Date changed $last_date > ".date("Y-m-d"));

                $last_date = date("Y-m-d");

                $this->loadAgent();

                $this->truncateSummary();

                $this->summaryServer();
                $this->summaryGroup();
                $this->summaryRoot();
                $this->summarySQLResult();
            }

            $second++;

            sleep(1);
        }
    }

    /**
     * truncateSummary
     *
     * 서머리를 테이블을 비운다.
     *
     * @access public
     *
     * @return void
     */
    public function truncateSummary(){

        $this->db->query('truncate table tbl_summary');
        $this->db->query('truncate table tbl_summary_sql_result');

        //debug(1, get_class($this), "Data truncated");
    }

    /**
     * removeRecentData
     *
     * 실시간 통계 데이터중 30초가 지난 데이터는 삭제한다.
     *
     * @access public
     *
     * @return void
     */
    public function removeRecentData(){

        $sSql = 'DELETE FROM tbl_summary WHERE `type`="now" AND `edate` < "'.date("Y-m-d H:i:s", strtotime("-30 minutes")).'"';
        //debug(1, get_class($this), $sSql, "database");
        $this->db->query($sSql);
    }

    /**
     * summaryServer
     *
     * 각 서버(에이전트)단위의 통합 통계를 서머리한다.
     *
     * @param boolean $bIsNow 실시간 통계 수행 여
     *
     * @access public
     *
     * @return void
     */
    public function summaryServer($bIsNow = false){

        $time_start = microtime(true);

        $aType = $bIsNow ? array('now') : array('day', 'week', 'month');

        // print "\n";

        foreach($this->agents['agent'] as $nIdx => $nAgentId){

            // print "----------------- Agent.".$nAgentId."\n";

            array_walk($this->summaries, function($item, $key, $aType) use ($nAgentId){

                // print $item." ";

                foreach($aType as $nIdx => $sType){

                    // print $sType." ";

                    $this->$item('server-'.$nAgentId, $sType);
                }

                // print "\n";

            }, $aType);

            // print "----------------- Agent End \n";
        }

        $time_end = microtime(true);
        $execution_time = ($time_end - $time_start)/60;
        // echo 'Total Execution Time: '.$execution_time." Mins \n";
    }

    /**
     * summaryGroup
     *
     * 각 서버그룹단위의 통합 통계를 서머리한다.
     *
     * @param boolean $bIsNow 실시간 통계 수행 여
     *
     * @access public
     *
     * @return void
     */
    public function summaryGroup($bIsNow = false){

        $time_start = microtime(true);

        $aType = $bIsNow ? array('now') : array('day', 'week', 'month');

        // print "\n";

        foreach($this->agents['group'] as $nGroupId => $aRow){

            // print "----------------- Group.".$nGroupId."\n";

            array_walk($this->summaries, function($item, $key, $aType) use ($nGroupId){

                // print $item." ";

                foreach($aType as $nIdx => $sType){

                    // print $sType." ";

                    $this->$item('group-'.$nGroupId, $sType);
                }

                // print "\n";

            }, $aType);
        }

        // print "----------------- Group End \n";

        $time_end = microtime(true);
        $execution_time = ($time_end - $time_start)/60;
        // echo 'Total Execution Time: '.$execution_time." Mins \n";
    }

    /**
     * summaryRoot
     *
     * 전체 그룹의 통합 통계를 서머리한다.
     *
     * @param boolean $bIsNow 실시간 통계 수행 여
     *
     * @access public
     *
     * @return void
     */
    public function summaryRoot($bIsNow = false){

        $time_start = microtime(true);

        $aType = $bIsNow ? array('now') : array('day', 'week', 'month');

        // print "\n";
        // print "----------------- Root \n";

        array_walk($this->summaries, function($item, $key, $aType){

            // print $item." ";

            foreach($aType as $nIdx => $sType){

                // print $sType." ";

                $this->$item('root', $sType);
            }

            // print "\n";
        }, $aType);

        // print "----------------- Root End \n";

        $time_end = microtime(true);
        $execution_time = ($time_end - $time_start)/60;
        // echo 'Total Execution Time: '.$execution_time." Mins \n";
    }

    /**
     * summaryConvert
     *
     * 통계
     *
     * @param boolean $sYMD 서머리할 일자
     *
     * @access public
     *
     * @return void
     */
    public function summaryConvert($sYMD = null){

        if($sYMD == null) $sYMD = date("Y-m-d");

        $sSql = "
            INSERT INTO  `tbl_sqllog_convert_summary`
            (
                `date_f`,
                `agent_id`,
                `uniqsql_id`,
                `class_id`,
                `sum_count`,
                `avg_elapsedtime`,
                `avg_result_count`
            )
            SELECT 
                DATE_FORMAT(`log`.request_time, '%Y%m%d') AS ymd, `log`.agent_id, `log`.uniqsql_id, `log`.class_id, 
                COUNT(1) AS sum_count,
                AVG(exec_elapsedtime) AS avg_elapsedtime,
                AVG(result_count) AS avt_result_count
            FROM tbl_anal_log `log`
            WHERE `log`.request_time BETWEEN '".$sYMD." 00:00:00.000000' AND '".$sYMD." 23:59:59.999999'  AND convsql_id > 0
            GROUP BY ymd, agent_id, uniqsql_id, class_id
            ON DUPLICATE KEY UPDATE
                `sum_count`        = VALUES(`sum_count`),
                `avg_elapsedtime`  = VALUES(`avg_elapsedtime`),
                `avg_result_count` = VALUES(`avg_result_count`)
        ";
        $this->db->query($sSql);

        // debug(1, get_class($this), "Summary convert log ".$sYMD);
    }

    /**
     * summaryConvert
     *
     * 통계
     *
     * @param boolean $sYMD 서머리할 일자
     *
     * @access public
     *
     * @return void
     */
    public function summaryAvgNumOfQueryExecResults($sServer, $sType = 'day'){

        //인자로 받은 type을 기준으로 불러올 기간의 시작, 종료일을 가져온다.
        $aDate = getDatePeriod($sType, "-1 day");

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $sServers = $this->getServerList($sServer);

        //선택된 서버가 없으면
        if($sServers === false) return;

        //시작 종료일 셋팅
        $sFDate = $aDate['start_date'];
        $sTDate = $aDate['end_date'];

        //서머리 쿼리 실행
        $sSql = '
            SELECT 
                a.agent_id, ipaddr as ip, uniqsql_id,
                IFNULL((SELECT agent_name FROM tbl_agent_info b WHERE b.agent_id = a.agent_id), "알수 없음") AS agent_name,
                (SELECT sql_type FROM tbl_uniqsql b WHERE b.uniqsql_id = a.uniqsql_id) AS sql_type,
                (SELECT ref_tables FROM tbl_uniqsql b WHERE b.uniqsql_id = a.uniqsql_id) AS ref_tables,
                a.result_count AS result_count,
                @rank := @rank + 1 AS rank
            FROM (
                SELECT 
                    agent_id, uniqsql_id, ipaddr, result_count, @rank := 0 AS rank
                FROM (
                    SELECT 
                        `log`.agent_id, `log`.uniqsql_id, `log`.ipaddr, sum(result_count) as result_count
                    FROM tbl_anal_log `log`
                    WHERE `log`.request_time BETWEEN "'.$sFDate.' 00:00:00.000000" AND "'.$sTDate.' 23:59:59.999999"
                    AND `log`.sql_type = "SELECT"
                    '.($sServers !== null ? 'AND `log`.agent_id in ('.$sServers.')' : '').'
                    GROUP BY `log`.agent_id, `log`.ipaddr, `log`.uniqsql_id
                ) a
                ORDER BY result_count DESC LIMIT 10
            ) a
        ';
        $this->db->query($sSql, function($oResult) use ($sType, $sServer, $sFDate, $sTDate){

            $aList = array();
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                array_push($aList, $aRow);
            }

            $this->storeSummary(
                'avg_num_of_query_exec_results', $sType, $sServer,
                $sFDate, $sTDate, json_encode($aList)
            );
        });

        //debug(1, get_class($this), "Summary tbl_summary_sql_avg_time ".$sFDate." - ".$sTDate);
    }

    public function summaryNumOfQueryExec($sServer, $sType = 'day'){

        //인자로 받은 type을 기준으로 불러올 기간의 시작, 종료일을 가져온다.
        $aDate = getDatePeriod($sType, "-1 day");

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $sServers = $this->getServerList($sServer);

        //선택된 서버가 없으면
        if($sServers === false) return;

        //시작 종료일 셋팅
        $sFDate = $aDate['start_date'];
        $sTDate = $aDate['end_date'];

        //서머리 쿼리 실행
        $sSql = '
            SELECT 
                a.agent_id, ipaddr as ip, uniqsql_id,
                IFNULL((SELECT agent_name FROM tbl_agent_info b WHERE b.agent_id = a.agent_id), "알수 없음") AS agent_name,
                (SELECT sql_type FROM tbl_uniqsql b WHERE b.uniqsql_id = a.uniqsql_id) AS sql_type,
                (SELECT ref_tables FROM tbl_uniqsql b WHERE b.uniqsql_id = a.uniqsql_id) AS ref_tables,
                a.exec_count AS exec_count,
                @rank := @rank + 1 AS rank
            FROM (
                SELECT
                    agent_id, uniqsql_id, ipaddr, exec_count, 
                    @rank := 0 AS rank
                FROM (
                    SELECT 
                        `log`.agent_id, `log`.uniqsql_id, `log`.ipaddr, COUNT(1) AS exec_count
                    FROM tbl_anal_log `log`
                    WHERE `log`.request_time BETWEEN "'.$sFDate.' 00:00:00.000000" AND "'.$sTDate.' 23:59:59.999999"
                    '.($sServers !== null ? 'AND `log`.agent_id in ('.$sServers.')' : '').'
                    GROUP BY `log`.agent_id, `log`.uniqsql_id, `log`.ipaddr
                ) a 
                ORDER BY exec_count DESC LIMIT 10
            ) a
        ';
        $this->db->query($sSql, function($oResult) use ($sType, $sServer, $sFDate, $sTDate){

            $aList = array();
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                array_push($aList, $aRow);
            }

            $this->storeSummary(
                'num_of_query_exec', $sType, $sServer,
                $sFDate, $sTDate, json_encode($aList)
            );
        });

        //debug(1, get_class($this), "Summary tbl_summary_sql_avg_time ".$sFDate." - ".$sTDate);
    }

    public function summaryStatusOfQueryExec($sServer, $sType = 'day'){

        //인자로 받은 type을 기준으로 불러올 기간의 시작, 종료일을 가져온다.
        $aDate = getDatePeriod($sType, "-1 day");

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $sServers = $this->getServerList($sServer);

        //선택된 서버가 없으면
        if($sServers === false) return;

        //시작 종료일 셋팅
        $sFDate = $aDate['start_date'];
        $sTDate = $aDate['end_date'];

        $sSql = '
            SELECT 
                b.agent_id, IFNULL(b.agent_name, "알수 없음") as agent_name, 
                IFNULL(a.`cnt_exec`, 0) as `cnt_exec`, 
                IFNULL(a.`cnt_fail`, 0) as `cnt_fail`, 
                IFNULL(c.`cnt_personal_info`, 0) as `cnt_personal_info`, 
                IFNULL(c.`cnt_table`, 0) as `cnt_table`, 
                IFNULL(c.`cnt_conv`, 0) as `cnt_conv`,
                event_level
            FROM tbl_agent_info b 
            LEFT OUTER JOIN (
                SELECT 
                    `log`.agent_id, 
                    COUNT(1) AS `cnt_exec`,
                    SUM(IF(`log`.execute_yn = 0, 1, 0)) AS `cnt_fail`
                FROM tbl_anal_log `log`
                LEFT OUTER JOIN tbl_policy_list policy ON policy.policy_id = `log`.blocksql_id
                WHERE `log`.request_time BETWEEN "'.$sFDate.'.000000" AND "'.$sTDate.'.999999"
                '.($sServers !== null ? 'AND `log`.agent_id in ('.$sServers.')' : '').'
                GROUP BY agent_id
            ) a ON b.agent_id = a.agent_id
            LEFT OUTER JOIN (
                SELECT 
                    agent_id,
                    SUM(IF(`evtlog`.policy_type = "'.POLICY_PERSONAL_INFO_TABLE.'", 1, 0)) AS `cnt_personal_info`,
                    SUM(IF(`evtlog`.policy_type = "'.POLICY_TABLE.'", 1, 0)) AS `cnt_table`,
                    SUM(IF(`evtlog`.policy_type = "'.POLICY_SQL_CONVERT.'", 1, 0)) AS `cnt_conv`,
                    MAX(`evtlog`.event_level) AS `event_level`
                FROM tbl_eventlog `evtlog`
                WHERE `evtlog`.event_time BETWEEN UNIX_TIMESTAMP("'.$sFDate.'") AND UNIX_TIMESTAMP("'.$sTDate.'")
                '.($sServers !== null ? 'AND `evtlog`.agent_id in ('.$sServers.')' : '').'
                GROUP BY `evtlog`.agent_id
            ) c ON c.agent_id = a.agent_id
            WHERE del_yn = "0"
        ';

        // debug(1, get_class($this), $sSql);

        $this->db->query($sSql, function($oResult) use ($sType, $sServer, $sFDate, $sTDate){

            $aList = array();
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                array_push($aList, $aRow);
            }

            $this->storeSummary(
                'status_of_query_exec', $sType, $sServer,
                $sFDate, $sTDate, json_encode($aList)
            );
        });

        //debug(1, get_class($this), "Summary tbl_summary_sql_server ".$sFDate." - ".$sTDate);
    }

    public function summaryNumOfQueryExecByPolicy($sServer, $sType = 'day'){

        //인자로 받은 type을 기준으로 불러올 기간의 시작, 종료일을 가져온다.
        $aDate = getDatePeriod($sType, "-1 day");

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $sServers = $this->getServerList($sServer);

        //선택된 서버가 없으면
        if($sServers === false) return;

        //시작 종료일 셋팅
        $sFDate = $aDate['start_date'];
        $sTDate = $aDate['end_date'];

        $sSql = '
            SELECT 
                b.agent_id, IFNULL(b.agent_name, "알수 없음") AS agent_name, 
                IFNULL(a.`0`, 0) AS `0`,
                IFNULL(a.`1`, 0) AS `1`,
                IFNULL(a.`2`, 0) AS `2`,
                IFNULL(a.`3`, 0) AS `3`,
                IFNULL(a.`4`, 0) AS `4`,
                IFNULL(a.`5`, 0) AS `5`,
                IFNULL(a.`6`, 0) AS `6`,
                IFNULL(a.`7`, 0) AS `7`
            FROM tbl_agent_info b 
            LEFT OUTER JOIN (
                SELECT 
                    `evtlog`.agent_id, 
                    SUM(IF(`evtlog`.event_kind  = "3", 1, 0)) AS `0`,
                    SUM(IF(`evtlog`.policy_type = "1", 1, 0)) AS `1`,
                    SUM(IF(`evtlog`.policy_type = "2", 1, 0)) AS `2`,
                    SUM(IF(`evtlog`.policy_type = "3", 1, 0)) AS `3`,
                    SUM(IF(`evtlog`.policy_type = "4", 1, 0)) AS `4`,
                    SUM(IF(`evtlog`.policy_type = "5", 1, 0)) AS `5`,
                    SUM(IF(`evtlog`.policy_type = "6", 1, 0)) AS `6`,
                    SUM(IF(`evtlog`.policy_type = "7", 1, 0)) AS `7`
                FROM tbl_eventlog `evtlog`
                WHERE `evtlog`.event_time BETWEEN UNIX_TIMESTAMP("'.$sFDate.'") AND UNIX_TIMESTAMP("'.$sTDate.'")
                '.($sServers !== null ? 'AND `evtlog`.agent_id in ('.$sServers.')' : '').'
                GROUP BY agent_id
            ) a ON b.agent_id = a.agent_id 
            WHERE `b`.del_yn = "0"
            '.($sServers !== null ? 'AND b.agent_id in ('.$sServers.')' : '').'
        ';
        $this->db->query($sSql, function($oResult) use ($sType, $sServer, $sFDate, $sTDate){

            $aList = array();
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                array_push($aList, $aRow);
            }

            $this->storeSummary(
                'num_of_query_exec_by_policy', $sType, $sServer,
                $sFDate, $sTDate, json_encode($aList)
            );
        });

        //debug(1, get_class($this), "Summary ".__FUNCTION__." ".$sFDate." - ".$sTDate);
    }

    /**
     * summaryNumOfEvent
     *
     * 메인페이지 - 전체 이벤트 발생 건수
     *
     * @param string $sServer 서머리할 서버, 그룹명, 전체 중 하나
     * @param string $sType 1일전, 1주일, 1개월, 실시간 통계 플래그
     *
     * @access public
     *
     * @return void
     */
    public function summaryNumOfEvent($sServer, $sType = 'day'){

        //인자로 받은 type을 기준으로 불러올 기간의 시작, 종료일을 가져온다.
        $aDate = getDatePeriod($sType, "-1 day");

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $sServers = $this->getServerList($sServer);

        //선택된 서버가 없으면
        if($sServers === false) return;

        //시작 종료일 셋팅
        $sFDate = $aDate['start_date'];
        $sTDate = $aDate['end_date'];

        $sSql = '
            SELECT 
                b.agent_id, IFNULL(b.agent_name, "알수 없음") as agent_name, 
                IFNULL(a.notice, 0) as notice, 
                IFNULL(a.attention, 0) as attention, 
                IFNULL(a.alert, 0) as alert, 
                IFNULL(a.danger, 0) as danger, 
                IFNULL(a.serious, 0) as serious
            FROM tbl_agent_info b 
            LEFT OUTER JOIN (
                SELECT
                    `evtlog`.agent_id, 
                    SUM(IF(event_level = "1", 1, 0)) AS `notice`,
                    SUM(IF(event_level = "2", 1, 0)) AS `attention`,
                    SUM(IF(event_level = "3", 1, 0)) AS `alert`,
                    SUM(IF(event_level = "4", 1, 0)) AS `danger`,
                    SUM(IF(event_level = "5", 1, 0)) AS `serious` 
                FROM `tbl_eventlog` as `evtlog`
                WHERE `evtlog`.event_time BETWEEN UNIX_TIMESTAMP("'.$sFDate.'") AND UNIX_TIMESTAMP("'.$sTDate.'")
                '.($sServers !== null ? 'AND `evtlog`.agent_id in ('.$sServers.')' : '').'
                GROUP BY agent_id
            ) a ON b.agent_id = a.agent_id 
            WHERE `b`.del_yn = "0"
            '.($sServers !== null ? 'AND b.agent_id in ('.$sServers.')' : '').'
        ';
        $this->db->query($sSql, function($oResult) use ($sType, $sServer, $sFDate, $sTDate){

            $aList = array();
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                array_push($aList, $aRow);
            }

            $this->storeSummary(
                'num_of_event', $sType, $sServer,
                $sFDate, $sTDate, json_encode($aList)
            );
        });

        //debug(1, get_class($this), "Summary ".__FUNCTION__." ".$sFDate." - ".$sTDate);
    }

    /**
     * summaryMostAccessIp
     *
     * 메인페이지 - 최다 접근 아이피
     *
     * @param string $sServer 서머리할 서버, 그룹명, 전체 중 하나
     * @param string $sType 1일전, 1주일, 1개월, 실시간 통계 플래그
     *
     * @access public
     *
     * @return void
     */
    public function summaryMostAccessIp($sServer, $sType = 'day'){

        //인자로 받은 type을 기준으로 불러올 기간의 시작, 종료일을 가져온다.
        $aDate = getDatePeriod($sType, "-1 day");

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $sServers = $this->getServerList($sServer);

        //선택된 서버가 없으면
        if($sServers === false) return;

        //시작 종료일 셋팅
        $sFDate = $aDate['start_date'];
        $sTDate = $aDate['end_date'];

        $sSql = '
            SELECT
                ip, value, 
                @rank := @rank + 1 AS rank
            FROM (
                SELECT 
                    `log`.ipaddr as ip,
                    COUNT(1) AS value,
                    @rank := 0 AS rank
                FROM tbl_anal_log `log`
                WHERE `log`.request_time BETWEEN "'.$sFDate.'.000000" AND "'.$sTDate.'.999999"
                '.($sServers !== null ? 'AND `log`.agent_id in ('.$sServers.')' : '').'
                GROUP BY `log`.ipaddr
                ORDER BY value DESC LIMIT 20
            ) a
        ';
        $this->db->query($sSql, function($oResult) use ($sType, $sServer, $sFDate, $sTDate){

            $aList = array();
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                array_push($aList, $aRow);
            }

            $this->storeSummary(
                'most_access_ip', $sType, $sServer,
                $sFDate, $sTDate, json_encode($aList)
            );
        });

        //debug(1, get_class($this), "Summary ".__FUNCTION__." ".$sFDate." - ".$sTDate);
    }

    /**
     * summaryMuchLookupIp
     *
     * 메인페이지 - 다량 조회 IP
     *
     * @param string $sServer 서머리할 서버, 그룹명, 전체 중 하나
     * @param string $sType 1일전, 1주일, 1개월, 실시간 통계 플래그
     *
     * @access public
     *
     * @return void
     */
    public function summaryMuchLookupIp($sServer, $sType = 'day'){

        //인자로 받은 type을 기준으로 불러올 기간의 시작, 종료일을 가져온다.
        $aDate = getDatePeriod($sType, "-1 day");

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $sServers = $this->getServerList($sServer);

        //선택된 서버가 없으면
        if($sServers === false) return;

        //시작 종료일 셋팅
        $sFDate = $aDate['start_date'];
        $sTDate = $aDate['end_date'];

        $sSql = '
            SELECT
                ip, `value`, 
                @rank := @rank + 1 AS rank
            FROM (
                SELECT 
                    `log`.ipaddr AS ip, SUM(result_count) AS `value`,
                    @rank := 0 AS rank
                FROM tbl_anal_log `log`
                WHERE `log`.request_time BETWEEN "'.$sFDate.'.000000" AND "'.$sTDate.'.999999"
                '.($sServers !== null ? 'AND `log`.agent_id in ('.$sServers.')' : '').'
                GROUP BY ipaddr
                ORDER BY `value` DESC LIMIT 20
            ) a
        ';
        $this->db->query($sSql, function($oResult) use ($sType, $sServer, $sFDate, $sTDate){

            $aList = array();
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                array_push($aList, $aRow);
            }

            $this->storeSummary(
                'much_lookup_ip', $sType, $sServer,
                $sFDate, $sTDate, json_encode($aList)
            );
        });

        //debug(1, get_class($this), "Summary ".__FUNCTION__." ".$sFDate." - ".$sTDate);
    }

    /**
     * summaryPersonalInfoAccessIP
     *
     * 메인페이지 - 개인 정보 접근 IP
     *
     * @param string $sServer 서머리할 서버, 그룹명, 전체 중 하나
     * @param string $sType 1일전, 1주일, 1개월, 실시간 통계 플래그
     *
     * @access public
     *
     * @return void
     */
    public function summaryPersonalInfoAccessIP($sServer, $sType = 'day'){

        //인자로 받은 type을 기준으로 불러올 기간의 시작, 종료일을 가져온다.
        $aDate = getDatePeriod($sType, "-1 day");

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $sServers = $this->getServerList($sServer);

        //선택된 서버가 없으면
        if($sServers === false) return;

        //시작 종료일 셋팅
        $sFDate = $aDate['start_date'];
        $sTDate = $aDate['end_date'];

        $sSql = '
            SELECT
                ip, `value`, 
                @rank := @rank + 1 AS rank
            FROM (
                SELECT 
                    `log`.ipaddr AS ip, SUM(`log`.result_count) AS `value`,
                    @rank := 0 AS rank
                FROM tbl_anal_log `log`
                WHERE `log`.request_time BETWEEN "'.$sFDate.'.000000" AND "'.$sTDate.'.999999"
                AND `log`.privacytbl_yn = "1"
                '.($sServers !== null ? 'AND `log`.agent_id in ('.$sServers.')' : '').'
                GROUP BY `log`.ipaddr
                ORDER BY `value` DESC LIMIT 20
            ) a
        ';
        $this->db->query($sSql, function($oResult) use ($sType, $sServer, $sFDate, $sTDate){

            $aList = array();
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                array_push($aList, $aRow);
            }

            $this->storeSummary(
                'personal_info_access_ip', $sType, $sServer,
                $sFDate, $sTDate, json_encode($aList)
            );
        });

        //debug(1, get_class($this), "Summary ".__FUNCTION__." ".$sFDate." - ".$sTDate);
    }

    /**
     * summaryPersonalInfoAccessIP
     *
     * 메인페이지 - 개인 정보 접근 IP
     *
     * @param string $sServer 서머리할 서버, 그룹명, 전체 중 하나
     * @param string $sType 1일전, 1주일, 1개월, 실시간 통계 플래그
     *
     * @access public
     *
     * @return void
     */
    public function summaryLookupIPCount($sServer, $sType = 'day'){

        //인자로 받은 type을 기준으로 불러올 기간의 시작, 종료일을 가져온다.
        $aDate = getDatePeriod($sType, "-1 day");

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $sServers = $this->getServerList($sServer);

        //선택된 서버가 없으면
        if($sServers === false) return;

        //시작 종료일 셋팅
        $sFDate = $aDate['start_date'];
        $sTDate = $aDate['end_date'];

        $sSql = '
            SELECT 
                `evtlog`.agent_id,
                `agent`.agent_name,
                IFNULL(`log`.ipaddr, "-") AS ip,
                IFNULL(count(1), 0) AS `value`
            FROM tbl_eventlog `evtlog`
            LEFT OUTER JOIN tbl_anal_log `log` ON `log`.sqllog_id=`evtlog`.event_tblid
            LEFT OUTER JOIN tbl_agent_info `agent` ON `agent`.agent_id = `evtlog`.agent_id
            WHERE `evtlog`.event_time BETWEEN UNIX_TIMESTAMP("'.$sFDate.'") AND UNIX_TIMESTAMP("'.$sTDate.'")
            AND `evtlog`.policy_type = "'.POLICY_PERSONAL_INFO_TABLE.'"
            '.($sServers !== null ? 'AND `evtlog`.agent_id in ('.$sServers.')' : '').'
            GROUP BY `evtlog`.agent_id, ip
            ORDER BY `value` DESC
        ';
        $this->db->query($sSql, function($oResult) use ($sType, $sServer, $sFDate, $sTDate){

            $aList = array();
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                array_push($aList, $aRow);
            }

            $this->storeSummary(
                'lookup_ip_count', $sType, $sServer,
                $sFDate, $sTDate, json_encode($aList)
            );
        });

        //debug(1, get_class($this), "Summary ".__FUNCTION__." ".$sFDate." - ".$sTDate);
    }

    /**
     * summaryLookupLoginIDCount
     *
     * 서머리 데이터 테이블에 저장
     *
     * @param string $sServer 서머리 그룹(root, group-아이디, server-아이디)을 의미한다.
     * @param string $sType 서머리 타입(실시간, 일자별, 주별, 월별) 'now','day','week','month'
     *
     * @access public
     *
     * @return void
     */
    public function summaryLookupLoginIDCount($sServer, $sType = 'day'){

        //인자로 받은 type을 기준으로 불러올 기간의 시작, 종료일을 가져온다.
        $aDate = getDatePeriod($sType, "-1 day");

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $sServers = $this->getServerList($sServer);

        //선택된 서버가 없으면
        if($sServers === false) return;

        //시작 종료일 셋팅
        $sFDate = $aDate['start_date'];
        $sTDate = $aDate['end_date'];

        $sSql = '
            SELECT 
                `evtlog`.agent_id,
                `agent`.agent_name,
                IFNULL(`log`.login_id, "-") AS login_id,
                IFNULL(count(1), 0) AS `value`
            FROM tbl_eventlog `evtlog`
            LEFT OUTER JOIN tbl_anal_log `log` ON `log`.sqllog_id=`evtlog`.event_tblid
            LEFT OUTER JOIN tbl_agent_info `agent` ON `agent`.agent_id = `evtlog`.agent_id
            WHERE `evtlog`.event_time BETWEEN UNIX_TIMESTAMP("'.$sFDate.'") AND UNIX_TIMESTAMP("'.$sTDate.'")
            AND `evtlog`.policy_type = "'.POLICY_PERSONAL_INFO_TABLE.'"
            '.($sServers !== null ? 'AND `evtlog`.agent_id in ('.$sServers.')' : '').'
            GROUP BY `evtlog`.agent_id, login_id
            ORDER BY `value` DESC
        ';
        $this->db->query($sSql, function($oResult) use ($sType, $sServer, $sFDate, $sTDate){

            $aList = array();
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                array_push($aList, $aRow);
            }

            $this->storeSummary(
                'lookup_login_id_count', $sType, $sServer,
                $sFDate, $sTDate, json_encode($aList)
            );
        });

        //debug(1, get_class($this), "Summary ".__FUNCTION__." ".$sFDate." - ".$sTDate);
    }

    public function summaryLookupIPCumulativeTotal($sServer, $sType = 'day'){

        //인자로 받은 type을 기준으로 불러올 기간의 시작, 종료일을 가져온다.
        $aDate = getDatePeriod($sType, "-1 day");

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $sServers = $this->getServerList($sServer);

        //선택된 서버가 없으면
        if($sServers === false) return;

        //시작 종료일 셋팅
        $sFDate = $aDate['start_date'];
        $sTDate = $aDate['end_date'];

        $sSql = '
            SELECT 
                `evtlog`.agent_id,
                `agent`.agent_name,
                IFNULL(`log`.ipaddr, "-") AS ip,
                IFNULL(SUM(`log`.result_count), 0) AS `value`
            FROM tbl_eventlog `evtlog`
            LEFT OUTER JOIN tbl_anal_log `log` ON `log`.sqllog_id=`evtlog`.event_tblid
            LEFT OUTER JOIN tbl_agent_info `agent` ON `agent`.agent_id = `evtlog`.agent_id
            WHERE `evtlog`.event_time BETWEEN UNIX_TIMESTAMP("'.$sFDate.'") AND UNIX_TIMESTAMP("'.$sTDate.'")
            AND `evtlog`.policy_type = "'.POLICY_PERSONAL_INFO_TABLE.'"
            '.($sServers !== null ? 'AND `evtlog`.agent_id in ('.$sServers.')' : '').'
            GROUP BY `evtlog`.agent_id, ip
            ORDER BY `value` DESC
        ';
        $this->db->query($sSql, function($oResult) use ($sType, $sServer, $sFDate, $sTDate){

            $aList = array();
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                array_push($aList, $aRow);
            }

            $this->storeSummary(
                'lookup_ip_cumulative_total', $sType, $sServer,
                $sFDate, $sTDate, json_encode($aList)
            );
        });

        //debug(1, get_class($this), "Summary ".__FUNCTION__." ".$sFDate." - ".$sTDate);
    }

    public function summaryLookupLoginIDCumulativeTotal($sServer, $sType = 'day'){

        //인자로 받은 type을 기준으로 불러올 기간의 시작, 종료일을 가져온다.
        $aDate = getDatePeriod($sType, "-1 day");

        //인자로 받은 server를 기준으로 agent_id를 얻어온다.
        $sServers = $this->getServerList($sServer);

        //선택된 서버가 없으면
        if($sServers === false) return;

        //시작 종료일 셋팅
        $sFDate = $aDate['start_date'];
        $sTDate = $aDate['end_date'];

        $sSql = '
            SELECT 
                `evtlog`.agent_id,
                `agent`.agent_name,
                IFNULL(`log`.login_id, "-") AS login_id,
                IFNULL(SUM(`log`.result_count), 0) AS `value`
            FROM tbl_eventlog `evtlog`
            LEFT OUTER JOIN tbl_anal_log `log` ON `log`.sqllog_id=`evtlog`.event_tblid
            LEFT OUTER JOIN tbl_agent_info `agent` ON `agent`.agent_id = `log`.agent_id
            WHERE `evtlog`.event_time BETWEEN UNIX_TIMESTAMP("'.$sFDate.'") AND UNIX_TIMESTAMP("'.$sTDate.'")
            AND `evtlog`.policy_type = "'.POLICY_PERSONAL_INFO_TABLE.'"
            '.($sServers !== null ? 'AND `evtlog`.agent_id in ('.$sServers.')' : '').'
            GROUP BY `evtlog`.agent_id, login_id
            ORDER BY `value` DESC
        ';
        $this->db->query($sSql, function($oResult) use ($sType, $sServer, $sFDate, $sTDate){

            $aList = array();
            while($aRow = $oResult->fetch_array(MYSQLI_ASSOC)){

                array_push($aList, $aRow);
            }

            $this->storeSummary(
                'lookup_login_id_cumulative_total', $sType, $sServer,
                $sFDate, $sTDate, json_encode($aList)
            );
        });

        //debug(1, get_class($this), "Summary ".__FUNCTION__." ".$sFDate." - ".$sTDate);
    }

    /**
     * summarySQLResult
     *
     * 서머리 데이터 테이블에 저장
     *
     * @param string $sType 서머리 타입(실시간, 일자별, 주별, 월별) 'now','day','week','month'
     *
     * @access public
     *
     * @return void
     */
    public function summarySQLResult($sType = 'day'){

        //인자로 받은 type을 기준으로 불러올 기간의 시작, 종료일을 가져온다.
        $aDate = getDatePeriod($sType, "-1 day");

        //시작 종료일 셋팅
        $sFDate = $aDate['start_date'];
        $sTDate = $aDate['end_date'];

        $sSql = '
            INSERT INTO tbl_summary_sql_result(
                newsql_id, agent_id, class_id, uniqsql_id, 
                result_avg, result_cnt, sdate, edate
            )
            SELECT 
                IFNULL(b.newsql_id, 0) as newsql_id, 
                IFNULL(a.agent_id, 0) as agent_id, 
                IFNULL(a.class_id, 0) as class_id, 
                IFNULL(a.uniqsql_id, 0) as uniqsql_id,
                a.result_avg, a.result_cnt, "'.$sFDate.'", "'.$sTDate.'"
            FROM (
                SELECT 
                    `log`.agent_id, `log`.class_id, `log`.uniqsql_id, 
                    AVG(result_count) as result_avg, count(result_count) AS result_cnt
                FROM tbl_anal_log `log`
                WHERE request_time BETWEEN "'.$sFDate.'.000000" AND "'.$sTDate.'.999999"
                GROUP BY agent_id, class_id, uniqsql_id ASC
            ) a
            LEFT OUTER JOIN tbl_newsql b ON a.agent_id = b.agent_id AND a.class_id = b.class_id AND a.uniqsql_id = b.uniqsql_id
            ON DUPLICATE KEY UPDATE 
                result_avg = a.result_avg,
                result_cnt = a.result_cnt
        ';
        $this->db->query($sSql);

        //debug(1, get_class($this), "Summary ".__FUNCTION__." ".$sFDate." - ".$sTDate);
    }

    /**
     * storeSummary
     *
     * 서머리 데이터 테이블에 저장
     *
     * @param string $sName 서머리명
     * @param string $sType 서머리 타입(실시간, 일자별, 주별, 월별) 'now','day','week','month'
     * @param string $sServer 서머리 그룹(root, group-아이디, server-아이디)을 의미한다.
     * @param string $sFDate 서머리 시작일(From)
     * @param string $sTDate 서머리 종료일(To)
     * @param string $sData JSON 형식의 서머리 object 배열 데이터
     *
     * @access public
     *
     * @return void
     */
    public function storeSummary($sName, $sType, $sServer, $sFDate, $sTDate, $sData){

        $sSql = "
            INSERT INTO tbl_summary (
                name, type, view_group,
                data, sdate, edate 
            )
            VALUES (
               '".$sName."', '".$sType."', '".$sServer."', 
               '".addslashes($sData)."', '".$sFDate."', '".$sTDate."'
            )
        ";
        $this->db->query($sSql);
    }

    /**
     * getServerList
     *
     * loadAgent를 통해 $this->agents에 저장된 에이전트 배열에서 지정된 서머리 그룹에 맞는 에이전트 리스트를 가져온다.
     *
     * @param string $sServer 서머리 그룹(root, group-아이디, server-아이디)을 의미한다.
     *
     * @access public
     *
     * @return void
     */
    public function getServerList($sServer){

        if($sServer == 'root'){

            $sServers = null;
        }
        else if(strpos($sServer, 'group') > -1){

            $nGroupId = str_replace("group-", "", $sServer);
            if($this->agents['group'][$nGroupId]){

                $aServers = $this->agents['group'][$nGroupId];
                $sServers = implode(",", $aServers);
            }
            else {

                $sServers = false;
            }
        }
        else {

            $sServers = str_replace("server-", "", $sServer);
        }

        return $sServers;
    }
}
/* End of file LogSummary.php */
/* Location: ./application/libraries/LogSummary.php */