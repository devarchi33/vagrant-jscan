<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

/*
 * 로그 클래스
 */
class LoginCheck
{

	public $ci;

    public function __construct()
    {
    	//CodeIgniter 객체
    	$this->ci = &get_instance();
    }
	
	public function check($sLevel){

        if($this->ci->input->is_cli_request() === true) return;

        $sCalledClass = $this->ci->router->fetch_class();

        if(in_array($sCalledClass, array('home', 'login', 'install')) === true) return;

        $check = checkValidCookie();

        if($check['result'] !== 'success'){

            //JSON 응답
            $this->ci->output->set_content_type('application/json');

            $this->ci->output->_display(json_encode(array(
                'result' => 'fail',
                'no_auth' => true,
                'message' => '로그인이 필요합니다.'
            )));

            exit();
        }
	}
}
?>