<?php
//define("DEBUG_SPACE", "DetactOut95Percentile");
define("DEBUG_LEVEL", "1");

require_once "common.php";
require_once APPPATH."config/database.php";
require_once APPPATH."config/constants.php";
require_once APPPATH."helpers/common_helper.php";
require_once APPPATH."libraries/DetectOut95Percentile.php";

extract($db[$active_group]);

switch ($pid = pcntl_fork()) {
	case -1:

		// @fail
		die('Fork failed');
		break;

	case 0:

        $DetectOut95Percentile = new DetectOut95Percentile($hostname, $username, $password, $database);
        $DetectOut95Percentile->run();

		break;
}

file_put_contents(ROOTPATH.'run/'.SELF.'.pid', $pid);

exit();
/* End of file DetectOut95Percentile.php */
/* Location: ./DetectOut95Percentile.php */