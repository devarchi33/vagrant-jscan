<?

define('ROOTPATH', dirname(__FILE__)."/../");

require_once ROOTPATH."path.php";

//function exception_handler($severity, $message, $filepath, $line){
//
//	print "$severity, $message, $filepath, $line";
//}
//
//set_error_handler('exception_handler');
?>