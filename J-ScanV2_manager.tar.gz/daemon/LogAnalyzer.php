<?php
//define("DEBUG_SPACE", "LogAnalyzer");
define("DEBUG_LEVEL", "1");

require_once "common.php";
require_once APPPATH."config/database.php";
require_once APPPATH."config/constants.php";
require_once APPPATH."helpers/common_helper.php";
require_once APPPATH."libraries/LogAnalyzer.php";

extract($db[$active_group]);

//세이버 실행 다섯개를 기본적으로 띄워준다.
for ($nNum = 1; $nNum <= 5; $nNum++) {

    switch ($pid = pcntl_fork()) {
        case -1:

            // @fail
            die('Fork failed');
            break;

        case 0:

            $LogAnalyzer = new LogAnalyzer($nNum);
            $LogAnalyzer->run();

            break;
    }

    file_put_contents(ROOTPATH.'run/'.SELF.'.pid', $pid);
}

/* End of file LogAnalyzer.php */
/* Location: ./LogAnalyzer.php */