<?php
//define("DEBUG_SPACE", "LogSaver");
define("DEBUG_LEVEL", "1");

require_once "common.php";
require_once APPPATH."config/database.php";
require_once APPPATH."config/constants.php";
require_once APPPATH."helpers/common_helper.php";;
require_once APPPATH."libraries/HashDataLoader.php";

extract($db[$active_group]);

//정책정보를 캐시하고, 동기화 하는 데몬을 띄워준다.
switch ($pid = pcntl_fork()) {
	case -1:

		// @fail
		die('Fork failed');
		break;

	case 0:

        $Cache = new HashDataLoader(
        	$hostname, $username, $password, $database
        );
        $Cache->run();


        break;
}

file_put_contents(ROOTPATH.'run/'.SELF.'.pid', $pid);

exit();

/* End of file index.php */
/* Location: ./index.php */