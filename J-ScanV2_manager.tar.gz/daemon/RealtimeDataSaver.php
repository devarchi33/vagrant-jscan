<?php
//define("DEBUG_SPACE", "PolicyManager");
define("DEBUG_LEVEL", "1");

require_once "common.php";
require_once APPPATH."config/constants.php";
require_once APPPATH."helpers/common_helper.php";
require_once APPPATH."libraries/RealtimeDataSaver.php";

for ($nNum = 1; $nNum <= 3; $nNum++) {

    switch ($pid = pcntl_fork()) {
        case -1:

            // @fail
            die('Fork failed');
            break;

        case 0:

            $RealtimeDataSaver = new RealtimeDataSaver($nNum);
            $RealtimeDataSaver->run();

            break;
    }

    file_put_contents(ROOTPATH.'run/'.SELF.'.pid', $pid);
}

exit();

/* End of file index.php */
/* Location: ./index.php */