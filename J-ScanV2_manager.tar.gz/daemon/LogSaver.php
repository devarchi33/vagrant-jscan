<?php
//define("DEBUG_SPACE", "LogSaver");
define("DEBUG_LEVEL", "1");

require_once "common.php";
require_once APPPATH."config/saver.php";
require_once APPPATH."config/database.php";
require_once APPPATH."config/constants.php";
require_once APPPATH."helpers/common_helper.php";
require_once APPPATH."libraries/LogSaver.php";

switch ($pid = pcntl_fork()) {
    case -1:

        // @fail
        die('Fork failed');
        break;

    case 0:

        $redis = new Redis();
        $redis->connect('211.170.163.68', 6479);

        $nMaxProcessPerAgent = 3;

        $aOldList = array();
        $aPIDList = array();

        while(1){

            $aKeys = $redis->keys('server:*');
            $aNewList = preg_grep("/^server\:[0-9]+$/", $aKeys);

            $aAddList = array_diff($aNewList, $aOldList);
            $aSubList = array_diff($aOldList, $aNewList);

            $aOldList = array_diff($aOldList, $aSubList);
            $aOldList = array_merge($aOldList, $aAddList);

            foreach($aAddList as $nIdx => $sServer){

                $aServer = $redis->hGetAll($sServer);

                //세이버 실행 다섯개를 기본적으로 띄워준다.
                for ($nNum = 1; $nNum <= $nMaxProcessPerAgent; $nNum++) {

                    switch ($pid2 = pcntl_fork()) {
                        case -1:

                            // @fail
                            die('Fork failed');
                            break;

                        case 0:

                            $LogSaver = new LogSaver($nNum, $aServer['ipaddr'], $aServer['port'], substr(md5(rand()), 0 , 8));
                            $LogSaver->run();

                            break;
                    }

                    $aPIDList[$sServer][] = $pid2;
                }
            }

            foreach($aSubList as $nIdx => $sServer){

                foreach($aPIDList[$sServer] as $nPIDX => $nPID){

                    posix_kill($nPID, SIGUSR1);
                }
            }

            sleep(1);
        }

        break;
}


exit();


//
//
//exit();

/* End of file LogSaver.php */
/* Location: ./LogSaver.php */