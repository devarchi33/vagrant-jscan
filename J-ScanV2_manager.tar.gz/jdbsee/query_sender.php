<?php
require_once "./path.php";
require_once APPPATH."helpers/common_helper.php";

$aAgents = array(
	"192.168.0.13",
	"192.168.0.22"
	//"192.168.0.23"
	// "192.168.0.26"
);

function sendQuery($sSQL){

	global $aAgents;

	$aParams = array(
	    'keyInSql' => $sSQL,
	    'keyInParameters' => '',
	    'selectCount' => 1
	);

	$sParams = http_build_query($aParams);

	unset($aParams);

	$nParamsLen = strlen($sParams);

	$key = array_rand($aAgents, 1);
	//print "[".date("Y-m-d H:i:s")."-".$aAgents[$key]."] ";
	$sContents = file_get_contents('http://'.$aAgents[$key].':8080/jkeeper-web/keyin/oracle/keyinAction', false, 
	    stream_context_create(
	        array(
	        	'http'=> array('method' => 'POST' , 
	        	'header' => "Content-Type: application/x-www-form-urlencoded; charset=UTF-8\r\nConnection: close\r\nContent-Length: $nParamsLen\r\n", 'content' => $sParams))
	    )
	);

	unset($sParams);
	unset($nParamsLen);

	//debug(1, "Send Query");
	return $sContents;
}


function openUrl(){

	file_get_contents('http://192.168.0.32:8080/Home2');
}

$aSQLs = array(
	"select * from dept",
	"select * from emp",
	"select * from tab",
	"update emp set ename = 'juwon' where empno=7369",
	"update emp set ename = 'JONES' where empno=7654",
	"update emp set ename = 'MARTIN' where empno=7654",
	"update emp set ename = 'CLARK' where empno=7782",
	"update emp set ename = 'SCOTT' where empno=7788",
	"insert into emp(EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7521, 'WARD', 'SALESMAN', 7698, '1981/2/22', 1250, 500, 30)",
	"insert into emp(EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7566, 'JONES', 'MANAGER', 7839, '1981/4/2', 2975, null, 20)",
	"insert into emp(EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7654, 'MARTIN', 'SALESMAN', 7698, '1981/9/28', 1250, 1400, 30)",
	"insert into emp(EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7698, 'BLAKE', 'MANAGER', 7839, '1981/5/1', 2850, null, 30)",
	"insert into emp(EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7782, 'CLARK', 'MANAGER', 7839, '1981/6/9', 2450, null, 10)",
	"insert into emp(EMPNO,ENAME,JOB,MGR,HIREDATE,SAL,COMM,DEPTNO) values (7788, 'SCOTT', 'ANALYST', 7566, '1987/4/19', 3000, null, 20)",
	"delete from emp where empno = 7521",
	"delete from emp where empno = 7566",
	"delete from emp where empno = 7654",
	"delete from emp where empno = 7698",
	"delete from emp where empno = 7782",
	"delete from emp where empno = 7788"
);

switch ($pid = pcntl_fork()) {
	case -1:

		// @fail
		die('Fork failed');
		break;

	case 0:
		
		while(true){

			if(!rand(0, 4)){

				openUrl();
			}
			else {

				$sSQL = $aSQLs[array_rand($aSQLs, 1)];
				$sContents = sendQuery($sSQL);
			}

			sleep(rand(1, 3));
		}

		break;
}