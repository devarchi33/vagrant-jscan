<?php

require_once dirname(__FILE__)."/path.php";
require_once APPPATH."config/constants.php";
require_once APPPATH."helpers/common_helper.php";
require_once APPPATH."libraries/LogReceiver.php";

//define("DEBUG_SPACE", "Logger");
define("DEBUG_LEVEL", "1");

switch ($pid = pcntl_fork()) {
	case -1:

		// @fail
		die('Fork failed');
		break;

	case 0:

		$Logger = new LogReceiver();
		$Logger->run();

		break;
}

file_put_contents('./run/'.basename(__FILE__).'.pid', $pid);

exit();

/* End of file index.php */
/* Location: ./index.php */